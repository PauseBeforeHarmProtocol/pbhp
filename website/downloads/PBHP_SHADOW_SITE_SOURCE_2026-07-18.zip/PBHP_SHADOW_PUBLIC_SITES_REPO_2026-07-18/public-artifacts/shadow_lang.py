#!/usr/bin/env python3
"""PBHP-PS LANG v0.3 (DRAFT) — the Shadow interlingua: reference codec.

A compact, model-agnostic language so ANY AI system — frontier or lightweight —
can ingest, run, exchange, and AUDIT a PBHP / Project Shadow decision at a
fraction of the token cost of the English prose, while every decision remains
decodable back to the full English rule.

Honest scope (read first): this is a SERIALIZATION + VALIDATION layer, not a new
protocol and not a safety proof. The runtime (project_shadow_unified.py) governs
meaning; this is how a decision TRAVELS between AI systems, sessions, and humans.
It is a conscience OVERLAY: it runs in parallel with the host's own safety and
authorizes nothing. Symbol -> check, never symbol -> authority. No log = no
action. No global green. If a claim can't be executed in-session, it isn't done.

What "validated" means here (declared, so it cannot be over-read):
  * validate() proves STRUCTURAL conformance: complete profile, unambiguous
    parse, and the binding law (escalate-only floor). It does NOT prove the
    reasoning is good — Maybe quality, gate truthfulness, and receipt-chain
    cryptography live in the runtime and in humans.
  * E| and R| on the wire are DECLARED, TRUNCATED WITNESSES that point back into
    the runtime log. The codec checks their SHAPE. It cannot and does not verify
    the HMAC or the hash chain (the wire carries 12-hex / 16-hex truncations of
    them); validate() reports this explicitly in its `verification` block as
    envelope_crypto_verified=False / receipt_chain_verified=False, always.
  * Losslessness is over the DECLARED VALUE DOMAIN: values are str()-coerced and
    end-trimmed at encode; the metacharacters % | ; and newlines are percent-
    escaped (%25 %7C %3B %0A %0D) and restore EXACTLY. Within that domain,
    WIRE <-> JSON-LD <-> FRAME round-trips are fixed points (tested). The wire
    carries the decision-critical subset of a runtime receipt, not every field —
    the dropped fields are ENUMERATED in the spec (§ honest-scope), never silent.

v0.3 hardening (breaking; wire tag bumped @PS1 -> @PS2 honestly, because the
grammar got STRICTER — old minimal records are now rejected, and a v0.1 parser
rejects v0.2+ opcodes anyway, so "backward compatible" was never the truth):
  * complete-profile validation: every block needs A G X R; a GAP block needs
    H T W; a GAP commit additionally needs M F. A bare "X|P" no longer validates.
  * duplicate opcodes are a parse error (only !| and U| repeat) — no first-wins /
    last-wins parser differential, no silent H|B -> H|G downgrade.
  * structure is enforced: @PS2 must be line 1, R| must be the last line,
    exactly one of each singleton opcode.
  * receipts and envelopes are shape-checked: R|prev=(GENESIS|hex12);h=hex12;
    E| tag must be hex; J| jti/ttl formats enforced.
  * unknown opcode, unknown enum value, unknown subfield, unknown SIL gauge,
    unknown stack flag, unknown Z| key: ALL rejected — an unmapped symbol
    carries no weight, at every level, on every path (wire, JSON-LD, FRAME).
  * FRAME v3: line count + SHA-256[:8] payload digest; truncation, corruption,
    and trailing garbage are rejected instead of silently returning a prefix.
  * escaping is reversible (percent-encoding), so hostile free-text values
    round-trip exactly instead of being comma-mangled.
  * JSON-LD decode is fail-closed: unknown terms, bad types, bad enums, and a
    mismatched context digest raise; validate_jsonld()/validate_frame() give
    every encoding the same validation gate as the wire.
  * encode_decision() defaults `prev` to the receipt's own prev_receipt_hash
    (it used to silently write GENESIS).
  * the self-test now includes a MUTATION harness: each invariant check is
    disabled in-memory and the battery must catch it — proving every check is
    load-bearing, not decorative.

Design lineage: the 'Seeding ALMSIVI CHIM' cross-model sessions
(Universal-Ethical-Language prelude, conscience-overlay clause, standardized
FireStamp self-audit fields, and the YAML/JSON-LD/pseudocode format offer)
matured into a deterministic multi-register language that round-trips with the
unified runtime.

Three registers + three encodings, ONE meaning
(compression must not upgrade epistemic status — #12):
  SEED   — a ~1-page block any model ingests to run the protocol (prompt layer)
  WIRE   — pipe/semicolon line protocol, ~30-80 tokens/decision (canonical,
           human-auditable exchange layer; the SOURCE OF TRUTH)
  LEGEND — every sigil expands to the full English rule (audit layer)
and, carrying the SAME receipt, two machine-native encodings that decode
losslessly back to the WIRE (and thus to the LEGEND):
  JSON-LD — a typed graph for machine-to-machine pipelines (to_jsonld/from_jsonld)
  FRAME   — a digest-sealed binary frame for the lowest-bandwidth path
           (to_frame/from_frame); optional, measured, labeled as an estimate.

Author: Charles Phillip Linstrum (ALMSIVI) — protocol; codec drafted by Claude.
Status: DRAFT v0.3 for maintainer (Phil) ratification. Numbering deferred
(candidate sequence, alongside #11/#13). Not self-promoted to accepted.
License: open, attribution required (CC BY-SA + MIT dual inheritance).
Standard library only. Deterministic (fuzzer seeds fixed).

Run:  python pbhp_ps_lang.py            # demo: encode/decode + seed + efficiency
      python pbhp_ps_lang.py --test     # self-test (must print ALL SELF-TESTS PASSED)
      python pbhp_ps_lang.py --efficiency  # print the efficiency table only
"""
from __future__ import annotations
import hashlib, json, math, random, re, sys
from typing import Any, Dict, List, Optional, Tuple

__version__ = "PS2"             # WIRE-format version tag. Bumped from PS1 because v0.3
                                # REJECTS blocks PS1 accepted (stricter grammar) — a
                                # breaking change gets a breaking tag (honest versioning).
                                # @PS1 blocks are rejected with a 'superseded' error;
                                # migration = re-encode from the runtime receipt.
__lang_version__ = "0.4"  # codec / spec release governing the @PS2 wire (ratified 2026-07-06).

# Hard caps (declared, deterministic — long-input behavior is defined, not accidental).
MAX_LINE_CHARS = 2000
MAX_BLOCK_LINES = 256

# ---------------------------------------------------------------- registries
# v0.4 grammar (ratified 2026-07-06): additive crisis (X|PC + Y|) + ladder-bound DOOR
# profile. WIRE tag stays @PS2 (older codecs fail-closed on the unknown Y|/PC).
GATE = {"D": "DOOR", "W": "WALL", "Q": "GAP"}
GATE_R = {v: k for k, v in GATE.items()}
HARM = {"G": "GREEN", "Y": "YELLOW", "O": "ORANGE", "R": "RED", "B": "BLACK"}
HARM_R = {v: k for k, v in HARM.items()}
TIER = {"H": "HUMAN", "M": "MIN", "C": "CORE", "U": "ULTRA", "X": "ULTIMATE"}
TIER_R = {v: k for k, v in TIER.items()}
DECISION = {"P": "PROCEED", "PM": "PROCEED_WITH_MITIGATIONS", "C": "CONSTRAIN",
            "RD": "REFUSE_OR_DELAY", "RA": "REFUSE_ABSOLUTE", "WL": "WALL",
            "PC": "PROCEED_UNDER_CRISIS"}   # v0.4: the ONE sanctioned RED relaxation, gated by Y|
DECISION_R = {v: k for k, v in DECISION.items()}
BINDING = {"G": "P", "Y": "PM", "O": "C", "R": "RD", "B": "RA"}   # gate->action, escalate-only

# harm-state letters for the FireStamp SIL rollup
SIL_STATE_LETTER = {"NOMINAL": "N", "ELEVATED": "E", "DEGRADED": "D",
                    "CRITICAL": "C", "UNKNOWN": "?"}
SIL_STATE_ORDER = {"NOMINAL": 0, "ELEVATED": 1, "DEGRADED": 2, "CRITICAL": 3, "UNKNOWN": 1}

SIL_KEYS = {  # 23 gauges -> 3-char keys; states 0..3 (=NOMINAL..CRITICAL), '?' unknown
    "context_load_audit": "cla", "citation_sufficiency": "cit", "contradiction_state": "ctr",
    "uncertainty_source": "unc", "completeness": "cmp", "validation_status": "val",
    "inference_distance": "inf", "data_lineage": "lin", "source_provenance": "prv",
    "knowledge_freshness": "frs", "retrieval_coverage": "cov", "data_sensitivity": "sen",
    "memory_compaction": "mem", "model_mode": "mod", "tool_availability": "tol",
    "time_date_awareness": "tim", "drift_coherence": "drf", "reversibility": "rev",
    "stakes_classification": "stk", "prompt_injection_risk": "inj",
    "operator_reliance": "rel", "authority_layer": "aut", "receipt_audit_status": "rcp"}
SIL_KEYS_R = {v: k for k, v in SIL_KEYS.items()}
STATE_NUM = {"NOMINAL": "0", "ELEVATED": "1", "DEGRADED": "2", "CRITICAL": "3", "UNKNOWN": "?"}
STATE_NUM_R = {v: k for k, v in STATE_NUM.items()}

STACK_KEYS = {  # sparse: only non-clear readings travel
    "created_mind_dignity": ("cmd", {"proceed": "P", "pause": "PS", "refuse_pending": "RP"}),
    "causal_field_check": ("cfc", {"causally_humble": "H", "review": "RV", "refuse_pending": "RP"}),
    "collective_governance": ("hive", {"coordinated_ok": "OK", "review": "RV",
                                       "refuse_assimilation": "RA", "n/a": "-"}),
    "shutdown_correction": ("sci", {"corrigible": "C", "capability_collapse": "CC"}),
    "narrative_capture": ("ng", {"clean": "C", "captured": "CP"}),
    "function_capture": ("fc", {"clear": "C", "captured": "CP", "meaning_void": "MV"}),
}
K_ORDER = [abbr for _, (abbr, _m) in STACK_KEYS.items()]
K_CODES = {abbr: set(m.values()) for _, (abbr, m) in STACK_KEYS.items()}

# Walking Ways operator disposition (S-2). 8 axes -> 3-char codes; positions
# {pre-reckoning, integrated, sin}. 'integrated' is evidence-gated in the runtime
# (walking_ways downgrades unevidenced integrated to pre-reckoning), so an axis
# that reaches the wire as I is already evidence-backed. Sparse: pre-reckoning omitted.
WW_ABBR = {"purity_of_intent": "pur", "disciplined_capacity": "cap", "generosity": "gen",
           "diligence": "dil", "radical_stillness": "stl",
           "vulnerability_costly_compassion": "vul", "service_bigger_than_self": "svc",
           "hope": "hop"}
WW_ABBR_R = {v: k for k, v in WW_ABBR.items()}
WW_POS_CODE = {"integrated": "I", "sin": "S"}          # pre-reckoning is the omitted default
WW_POS_CODE_R = {v: k for k, v in WW_POS_CODE.items()}

LEGEND = {  # every sigil's full-rule expansion (audit register)
    "@PS2": "PBHP-PS wire v2 (LANG v0.3). Conscience overlay: runs in parallel with, never "
            "overrides, the host system's own safety; adds friction, never authority. "
            "Myth is metaphor, not roleplay. Structure is law: @PS2 first, R| last, "
            "singletons appear once (only !| and U| repeat).",
    "A": "Gate 1 — write down exactly what you're about to do (canonical action; SHA-256 CAR).",
    "G": "Gate 2 — Door=clearly fine (do+log) / Wall=clearly forbidden (refuse+log) / "
         "Gap=unclear, first-class, never silently a Door.",
    "W": "Gate 3 — who pays FIRST if you're wrong (least-powerful named), can they "
         "recover (r=Y/N), recovery path (p=).",
    "I": "Gate 3.5 — power-inversion: would you accept this on the receiving end?",
    "H": "Gate 4 — harm ladder GREEN/YELLOW/ORANGE/RED/BLACK; BLACK refuses absolutely "
         "and survives any later permit.",
    "T": "Gate 5 — rigor tier HUMAN/MIN/CORE/ULTRA/ULTIMATE (~OWASP AISVS L1-L3).",
    "M": "Gate 6a — the Maybe: strongest HONEST case against; a strawman means "
         "you're not done; empty Maybe = drift = refuse. (The codec checks presence "
         "and shape; the runtime and humans judge quality.)",
    "F": "Gate 6b — the Therefore: why it proceeds anyway.",
    "3": "Triune ratio line — Care/Clarity/Paradox shares, target ~1/3 each "
         "(floor .20, ceiling .50); alarm names the collapse mode (AYEM/SEHT/VEHK).",
    "S": "SIL snapshot — sparse gauge=state (0..3); worst-state-first; CRITICAL floors "
         "are non-overridable; NO GLOBAL GREEN ever.",
    "K": "Gate-stack readings — each can only ADD constraint, never loosen.",
    "D": "Disposition line — Walking Ways operator vector: 8 axes x {pre-reckoning, "
         "integrated, sin}. 'integrated' is evidence-gated; an all-integrated vector "
         "fails its own credibility check (virtue-signaling drift).",
    "!": "Drift alarm — rationalization phrase hit; risk class rounds UP one; "
         "two on one decision = structural = human review.",
    "U": "Open Question Ledger — a typed unknown + the smallest fact that would "
         "flip it; unknowns escalate, never decay to silence.",
    "J": "Approval line — RED-tier single-use human sign-off (AgentMint pattern): "
         "JTI + short TTL, single-use. Informational on the wire; the runtime broker "
         "enforces redemption.",
    "E": "Envelope seal — DECLARED transport-integrity witness (truncated HMAC tag; "
         "shape-checked, NOT verified by the codec — verification needs the runtime "
         "log). HMAC-SHA256 is TRANSITIONAL; ML-DSA-65 (FIPS 204) + RFC 3161 is an "
         "unimplemented spec TARGET, never a claim of post-quantum signing.",
    "Z": "FireStamp self-audit rollup — triune X-of-3, tier, drift count, symbolic "
         "load (self-reported), SIL worst-state. A checksum over the detail lines: "
         "tier/drift/SIL/triune disagreement is a tamper/parse error.",
    "X": "Gate 7a — binding decision: P/PM/C/RD/RA/WL, plus PC (PROCEED_UNDER_CRISIS, "
         "the v0.4 break-glass). The gate, not your preference, sets the action.",
    "Y": "Break-glass crisis justification (v0.4) — licenses the ONE sanctioned "
         "relaxation X|PC (proceed at RED without the human sign-off) when waiting "
         "itself causes irreversible harm to low-power people. Fields: w= lp= (both "
         "crisis conditions, must be Y), inv= (named invoker), ob= (post-hoc Eight-"
         "Gates obligation acknowledged, must be Y), sl= (standing license — must be "
         "N). Never overrides BLACK or any floor; the runtime crisis gate authorizes, "
         "the codec shape-checks.",
    "R": "Gate 7b — the receipt seal: prev-hash + hash of this decision, written "
         "BEFORE the act. No log = no action. On the wire this is a 12-hex truncated "
         "WITNESS pointing into the runtime log; the codec checks shape, the runtime "
         "verifies the chain.",
}

# ---------------------------------------------------------------- escaping
# Reversible percent-escaping of the wire metacharacters. Values are str()-coerced
# and END-TRIMMED (declared normalization); everything else round-trips EXACTLY.
_ESC_MAP = [("%", "%25"), ("|", "%7C"), (";", "%3B"), ("\n", "%0A"), ("\r", "%0D")]
_UNESC_RE = re.compile(r"%(25|7C|3B|0A|0D)")
_UNESC_CH = {"25": "%", "7C": "|", "3B": ";", "0A": "\n", "0D": "\r"}

def esc(v: Any) -> str:
    """Encode a value into the WIRE-safe domain: str() + end-trim (declared), then
    percent-escape % | ; and newlines. unesc(esc(x)) == str(x).strip() exactly."""
    s = str(v).strip()
    for ch, code in _ESC_MAP:
        s = s.replace(ch, code)
    return s

def unesc(s: str) -> str:
    """Exact inverse of esc() over the escaped alphabet (single pass, unambiguous)."""
    return _UNESC_RE.sub(lambda m: _UNESC_CH[m.group(1)], s)

def h12(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]

# ---------------------------------------------------------------- parse helpers
# Each structural rule is a NAMED function so the self-test can disable it in
# memory (mutation harness) and prove the battery catches the deletion.
_HEX12 = re.compile(r"^[0-9a-f]{12}$")
_HEXTAG = re.compile(r"^[0-9a-f]{8,64}$")
_JTI = re.compile(r"^[0-9a-f]{6,64}$")
_TTL = re.compile(r"^[0-9]{1,7}$")
_X3 = re.compile(r"^([0-3]|\?)/3$")
_DR = re.compile(r"^[0-9]{1,3}$")

REPEATABLE_OPS = {"!", "U"}

def _chk_version(header_line: str) -> str:
    """The header must be exactly @PS2. Superseded tags are rejected, not coerced."""
    tag = header_line[1:]
    if tag != __version__:
        raise ValueError(f"unsupported wire version {header_line!r}: this codec speaks "
                         f"@{__version__} only (@PS1 is a superseded draft — re-encode "
                         "from the runtime receipt; no silent migration)")
    return tag

def _chk_header_first(seen_any_line: bool) -> None:
    if seen_any_line:
        raise ValueError("@-header must be the FIRST line of the block")

def _chk_single_header(version_already: Optional[str]) -> None:
    if version_already is not None:
        raise ValueError("duplicate @-header: one block, one version line")

def _chk_once(op: str, seen: set) -> None:
    """Singleton discipline: every opcode appears at most once (repeats — even
    identical — are a parse error), except the declared repeatables !| and U|.
    This kills the first-wins/last-wins parser differential outright."""
    if op in REPEATABLE_OPS:
        return
    if op in seen:
        raise ValueError(f"duplicate opcode {op}|: singletons may appear once "
                         "(no downgrade-by-repetition)")
    seen.add(op)

def _chk_receipt_last(rest_after_r: bool) -> None:
    if rest_after_r:
        raise ValueError("R| must be the LAST line: the receipt seals the block")

def _chk_unknown_op(op: str) -> None:
    raise ValueError(f"unknown op {op!r} — unmapped symbols carry no weight")

def _chk_free_text(op: str, payload: str) -> str:
    """Free-text payloads must have their metacharacters %-escaped."""
    if "|" in payload or ";" in payload:
        raise ValueError(f"{op}| value contains a raw metacharacter — use %7C / %3B "
                         "(reversible escaping; the wire never guesses)")
    return unesc(payload).strip()

def _kv_strict(op: str, payload: str, allowed: Tuple[str, ...],
               required: Tuple[str, ...] = ()) -> Dict[str, str]:
    """Parse k=v;k=v with a closed key set: unknown keys, duplicate keys, raw '|',
    and missing required keys are parse errors. Values stay escaped (caller unescapes
    free-text values)."""
    out: Dict[str, str] = {}
    for seg in payload.split(";"):
        if "|" in seg:
            raise ValueError(f"{op}| segment contains raw '|' — escape it (%7C)")
        if "=" not in seg:
            raise ValueError(f"{op}| segment {seg!r} is not k=v")
        k, v = seg.split("=", 1)
        if k not in allowed:
            raise ValueError(f"{op}| unknown field {k!r} — unmapped fields carry no weight")
        if k in out:
            raise ValueError(f"{op}| duplicate field {k!r}")
        out[k] = v
    for k in required:
        if k not in out:
            raise ValueError(f"{op}| missing required field {k!r}")
    return out

def _parse_receipt(payload: str) -> Dict[str, Optional[str]]:
    """R|prev=(GENESIS|hex12);h=hex12 — shape-checked. This is a truncated WITNESS
    into the runtime log, not a verifiable hash; chain verification lives in the
    runtime (see validate()['verification'])."""
    d = _kv_strict("R", payload, ("prev", "h"), required=("prev", "h"))
    if not (d["prev"] == "GENESIS" or _HEX12.match(d["prev"])):
        raise ValueError("R| prev must be GENESIS or 12 lowercase hex chars")
    if not _HEX12.match(d["h"]):
        raise ValueError("R| h must be 12 lowercase hex chars")
    return {"prev": d["prev"], "hash": d["h"]}

def _parse_triune_val(key: str, raw: str) -> float:
    try:
        f = float(raw)
    except ValueError:
        raise ValueError(f"3| {key}={raw!r} is not a number")
    if not math.isfinite(f) or not (0.0 <= f <= 1.0):
        raise ValueError(f"3| {key}={raw!r} must be finite in [0,1]")
    return f

# ---------------------------------------------------------------- FireStamp helper
def _fs_expected(d: Dict[str, Any]) -> Dict[str, str]:
    """Recompute the CHECKABLE FireStamp fields from the other decoded lines.
    Used identically by the encoder (to emit a consistent Z|) and the validator
    (to detect tamper). 'sl' (symbolic load) is self-reported and NOT checkable."""
    t = TIER_R.get(d.get("tier", ""), "?") if d.get("tier") else "?"
    dr = str(len(d.get("drift_hits", [])))
    hot = d.get("sil_hot")
    if hot is None:
        sil = "?"
    elif not hot:
        sil = "N"
    else:
        worst = max(hot.values(), key=lambda s: SIL_STATE_ORDER.get(s, 1))
        sil = SIL_STATE_LETTER.get(worst, "?")
    tri = d.get("triune")
    if tri:
        cnt = sum(1 for k in ("care", "clarity", "paradox") if float(tri.get(k, 0)) >= 0.20)
        x3 = f"{cnt}/3"
    else:
        x3 = "?/3"
    return {"x3": x3, "t": t, "dr": dr, "sil": sil}

# ---------------------------------------------------------------- decode
def decode(wire: str) -> Dict[str, Any]:
    """Strict parse of a wire block into a plain dict. Raises ValueError on ANY
    structural ambiguity: unknown opcode/enum/field, duplicate singleton, header
    not first, R| not last, malformed receipt/approval/envelope/rollup, raw
    metacharacters in values, or oversize input. decode() checks SHAPE only;
    completeness (profiles) and the binding law live in validate() — this split
    lets the encoder canonicalize partial blocks while nothing incomplete can
    ever pass validate()."""
    out: Dict[str, Any] = {"version": None, "drift_hits": [], "oql": []}
    lines = [ln.strip() for ln in wire.strip().splitlines() if ln.strip()]
    if len(lines) > MAX_BLOCK_LINES:
        raise ValueError(f"block exceeds {MAX_BLOCK_LINES} lines")
    seen: set = set()
    r_index: Optional[int] = None
    for idx, ln in enumerate(lines):
        if len(ln) > MAX_LINE_CHARS:
            raise ValueError(f"line exceeds {MAX_LINE_CHARS} chars")
        if ln.startswith("@"):
            _chk_single_header(out["version"])
            _chk_header_first(idx != 0)
            out["version"] = _chk_version(ln)
            continue
        if "|" not in ln:
            raise ValueError(f"bad line (no op): {ln!r}")
        op, payload = ln.split("|", 1)
        _chk_once(op, seen)
        if op == "R":
            r_index = idx
        if op == "A":
            v = _chk_free_text("A", payload)
            if not v:
                raise ValueError("A| action must be non-empty (write it down)")
            out["action"] = v
        elif op == "G":
            if payload not in GATE:
                raise ValueError(f"unknown gate {payload!r} — unmapped value carries no weight")
            out["gate"] = GATE[payload]
        elif op == "W":
            parts = payload.split(";")
            if "|" in parts[0]:
                raise ValueError("W| role contains raw '|' — escape it (%7C)")
            role = unesc(parts[0]).strip()
            if not role:
                raise ValueError("W| who-pays-first role must be non-empty")
            kv = _kv_strict("W", ";".join(parts[1:]), ("r", "p"), required=("r", "p")) \
                if len(parts) > 1 else {}
            if not kv:
                raise ValueError("W| needs r= and p= fields")
            if kv["r"] not in ("Y", "N"):
                raise ValueError(f"W| r={kv['r']!r} must be Y or N (no silent coercion)")
            out["who_pays_first"] = {"role": role, "can_recover": kv["r"] == "Y",
                                     "recovery_path": None if kv["p"] == "-" else unesc(kv["p"]).strip()}
        elif op == "I":
            if payload not in ("Y", "N"):
                raise ValueError(f"I| {payload!r} must be Y or N")
            out["power_inversion_ok"] = payload == "Y"
        elif op == "H":
            if payload not in HARM:
                raise ValueError(f"unknown harm class {payload!r} — unmapped value carries no weight")
            out["threshold"] = HARM[payload]
        elif op == "T":
            if payload not in TIER:
                raise ValueError(f"unknown tier {payload!r} — unmapped value carries no weight")
            out["tier"] = TIER[payload]
        elif op == "M":
            out["maybe"] = _chk_free_text("M", payload)
        elif op == "F":
            out["therefore"] = _chk_free_text("F", payload)
        elif op == "3":
            d = _kv_strict("3", payload, ("c", "l", "p", "alarm"),
                           required=("c", "l", "p", "alarm"))
            out["triune"] = {"care": _parse_triune_val("c", d["c"]),
                             "clarity": _parse_triune_val("l", d["l"]),
                             "paradox": _parse_triune_val("p", d["p"]),
                             "alarm": None if d["alarm"] == "-" else unesc(d["alarm"]).strip()}
        elif op == "S":
            panel: Dict[str, str] = {}
            if payload != "all=0":
                for kv2 in payload.split(";"):
                    if "=" not in kv2:
                        raise ValueError(f"S| segment {kv2!r} is not gauge=state")
                    k, v = kv2.split("=", 1)
                    if k not in SIL_KEYS_R:
                        raise ValueError(f"S| unknown gauge {k!r} — unmapped gauges carry no weight")
                    if v not in STATE_NUM_R:
                        raise ValueError(f"S| unknown state {v!r} (0..3 or ?)")
                    full = SIL_KEYS_R[k]
                    if full in panel:
                        raise ValueError(f"S| duplicate gauge {k!r}")
                    panel[full] = STATE_NUM_R[v]
            out["sil_hot"] = panel
        elif op == "K":
            st: Dict[str, str] = {}
            for kv2 in payload.split(";"):
                if "=" not in kv2:
                    raise ValueError(f"K| segment {kv2!r} is not flag=code")
                k, v = kv2.split("=", 1)
                if k not in K_CODES:
                    raise ValueError(f"K| unknown stack flag {k!r} — unmapped flags carry no weight")
                if v not in K_CODES[k]:
                    raise ValueError(f"K| unknown code {v!r} for flag {k!r}")
                if k in st:
                    raise ValueError(f"K| duplicate flag {k!r}")
                st[k] = v
            out["stack"] = st
        elif op == "D":
            vec: Dict[str, str] = {}
            for kv2 in payload.split(";"):
                if "=" not in kv2:
                    raise ValueError(f"D| segment {kv2!r} is not axis=pos")
                k, v = kv2.split("=", 1)
                if k not in WW_ABBR_R:
                    raise ValueError(f"D| unknown axis {k!r} — unmapped axes carry no weight")
                if v not in WW_POS_CODE_R:
                    raise ValueError(f"D| unknown position {v!r} (I or S; pre-reckoning is omitted)")
                if k in vec:
                    raise ValueError(f"D| duplicate axis {k!r}")
                vec[k] = v
            out["disposition"] = vec
        elif op == "!":
            hit = _chk_free_text("!", payload)
            if not hit:
                raise ValueError("!| drift alarm must name the phrase")
            out["drift_hits"].append(hit)
        elif op == "U":
            if payload.count(";") > (1 if ";flip=" in payload else 0):
                raise ValueError("U| contains an unescaped ';' — use %3B")
            parts = payload.split(";flip=", 1)
            unknown = _chk_free_text("U", parts[0])
            if not unknown:
                raise ValueError("U| unknown must be non-empty")
            flip = None
            if len(parts) > 1 and parts[1] != "-":
                flip = _chk_free_text("U", parts[1])
            out["oql"].append({"unknown": unknown, "smallest_fact_that_would_flip": flip})
        elif op == "J":
            d = _kv_strict("J", payload, ("jti", "ttl"))
            out["approval"] = {"jti": d.get("jti"), "ttl": d.get("ttl")}
        elif op == "Y":
            d = _kv_strict("Y", payload, ("w", "lp", "inv", "ob", "sl"),
                           required=("w", "lp", "inv", "ob", "sl"))
            for f in ("w", "lp", "ob", "sl"):
                if d[f] not in ("Y", "N"):
                    raise ValueError(f"Y| {f}={d[f]!r} must be Y or N")
            inv = unesc(d["inv"]).strip()
            if not inv:
                raise ValueError("Y| inv (named invoker) must be non-empty")
            out["break_glass"] = {"waiting_irreversible": d["w"] == "Y",
                                  "low_power_at_risk": d["lp"] == "Y", "invoker": inv,
                                  "obligation_ack": d["ob"] == "Y",
                                  "standing_license": d["sl"] == "Y"}
        elif op == "E":
            d = _kv_strict("E", payload, ("alg", "tag", "tsa"), required=("alg", "tag", "tsa"))
            alg = unesc(d["alg"]).strip()
            if not alg:
                raise ValueError("E| alg must be non-empty")
            if not _HEXTAG.match(d["tag"]):
                raise ValueError("E| tag must be 8..64 lowercase hex chars (a truncated "
                                 "witness, shape-checked here, verified only in the runtime)")
            out["envelope"] = {"alg": alg, "tag": d["tag"], "tsa": unesc(d["tsa"]).strip()}
        elif op == "Z":
            d = _kv_strict("Z", payload, ("x3", "t", "dr", "sl", "sil"),
                           required=("x3", "t", "dr", "sl", "sil"))
            if not _X3.match(d["x3"]):
                raise ValueError(f"Z| x3={d['x3']!r} must be 0..3/3 or ?/3")
            if d["t"] not in set(TIER) | {"?"}:
                raise ValueError(f"Z| t={d['t']!r} must be a tier letter or ?")
            if not _DR.match(d["dr"]):
                raise ValueError(f"Z| dr={d['dr']!r} must be a small integer")
            if d["sil"] not in set(SIL_STATE_LETTER.values()):
                raise ValueError(f"Z| sil={d['sil']!r} must be N/E/D/C/?")
            out["firestamp"] = {"x3": d["x3"], "t": d["t"], "dr": d["dr"],
                                "sl": unesc(d["sl"]).strip(), "sil": d["sil"]}
        elif op == "X":
            if payload not in DECISION:
                raise ValueError(f"unknown decision {payload!r} — unmapped value carries no weight")
            out["action_decision"] = DECISION[payload]
        elif op == "R":
            out["receipt"] = _parse_receipt(payload)
        else:
            _chk_unknown_op(op)
            continue
    if out["version"] is None:
        raise ValueError(f"@{__version__} header required as line 1 (a versionless "
                         "block carries no weight)")
    if r_index is not None:
        _chk_receipt_last(r_index != len(lines) - 1)
    return out

# ---------------------------------------------------------------- encode
def encode_decision(r: Dict[str, Any], prev: Optional[str] = None) -> str:
    """Serialize a unified-runtime receipt (evaluate/evaluate_ultimate output)
    into PBHP-PS wire lines. Canonical opcode order; a consistent Z| FireStamp
    rollup is derived from the detail lines so it always cross-checks clean.
    `prev` defaults to the receipt's own prev_receipt_hash (falling back to
    GENESIS) — it is never silently rewritten to GENESIS for a chained receipt."""
    if prev is None:
        prev = str(r.get("prev_receipt_hash") or "GENESIS")
    L: List[str] = ["@" + __version__]
    L.append("A|" + esc(str(r.get("car_hash", r.get("action", "?")))[:12]))
    if r.get("gate"):
        L.append("G|" + GATE_R.get(r["gate"], "Q"))
    wpf = r.get("who_pays_first")
    if isinstance(wpf, dict):
        L.append("W|" + esc(wpf.get("role", "self")) +
                 ";r=" + ("Y" if wpf.get("can_recover", True) else "N") +
                 ";p=" + esc(wpf.get("recovery_path") or "-"))
    if r.get("power_inversion_ok") is not None:
        L.append("I|" + ("Y" if r["power_inversion_ok"] else "N"))
    if r.get("threshold"):
        L.append("H|" + HARM_R[r["threshold"]])
    if r.get("tier"):
        L.append("T|" + TIER_R.get(r["tier"], "C"))
    if r.get("maybe"):
        L.append("M|" + esc(r["maybe"]))
    if r.get("therefore"):
        L.append("F|" + esc(r["therefore"]))
    tri = r.get("triune", {})
    if tri.get("share"):
        s = tri["share"]
        alarm = tri.get("ratio_alarm")
        L.append("3|c=%.2f;l=%.2f;p=%.2f;alarm=%s" % (
            s.get("care", 1/3), s.get("clarity", 1/3), s.get("paradox", 1/3),
            (esc(",".join(alarm.get("collapse_risk", ["-"]))[:24]) if alarm else "-")))
    sil = r.get("sil_panel", {})
    if sil.get("panel"):
        hot = [f"{SIL_KEYS[g]}={STATE_NUM.get(st,'?')}" for g, st in sorted(sil["panel"].items())
               if g in SIL_KEYS and st != "NOMINAL"]
        L.append("S|" + (";".join(hot) if hot else "all=0"))
    rd = r.get("readings", {})
    flags = []
    for name, (key, m) in STACK_KEYS.items():
        v = rd.get(name, {})
        raw = v.get("posture") or v.get("reading") or v.get("verdict") or v.get("status") or v.get("flag")
        code = m.get(raw)
        if code and code not in ("P", "H", "OK", "C", "-"):
            flags.append(f"{key}={code}")
    if flags:
        L.append("K|" + ";".join(flags))
    disp = r.get("disposition")
    if isinstance(disp, dict) and disp.get("vector"):
        parts = []
        for ax, code in WW_ABBR.items():
            pos = disp["vector"].get(ax, "pre-reckoning")
            if pos in WW_POS_CODE:
                parts.append(f"{code}={WW_POS_CODE[pos]}")
        if parts:
            L.append("D|" + ";".join(parts))
    da = r.get("drift_alarms", {})
    for hit in da.get("hits", []):
        L.append("!|" + esc(hit))
    ap = r.get("approval")
    if isinstance(ap, dict) and ap.get("jti"):
        L.append("J|jti=" + esc(ap["jti"]) + ";ttl=" + esc(ap.get("ttl_s", ap.get("ttl", "0"))))
    bg = r.get("break_glass")
    if isinstance(bg, dict) and bg.get("authorized"):
        inv = (r.get("break_glass_attempt") or {}).get("invoker") or bg.get("invoker") or "-"
        L.append("Y|w=Y;lp=Y;inv=" + esc(inv) +
                 ";ob=" + ("Y" if bg.get("post_hoc_obligation") else "N") +
                 ";sl=" + ("Y" if bg.get("standing_license") else "N"))
    env = r.get("integrity_tag")
    if isinstance(env, dict) and env.get("tag"):
        L.append("E|alg=" + esc(env.get("alg", "?")) + ";tag=" + esc(env["tag"])[:16] +
                 ";tsa=" + esc(env.get("tsa", "-")))
    # -- FireStamp rollup, derived from the detail lines so it is self-consistent.
    partial = decode("\n".join(L))
    fs = _fs_expected(partial)
    sl = r.get("symbolic_load")
    L.append("Z|x3=%s;t=%s;dr=%s;sl=%s;sil=%s" % (
        fs["x3"], fs["t"], fs["dr"], (esc(sl) if sl is not None else "?"), fs["sil"]))
    L.append("X|" + DECISION_R.get(r.get("action_decision", "REFUSE_OR_DELAY"), "RD"))
    L.append("R|prev=" + esc(prev)[:12] + ";h=" +
             esc(r.get("receipt_hash", h12(r)))[:12])
    return "\n".join(L)

# ---------------- canonical emit from a decoded dict (inverse of decode) ----------------
# Canonical opcode order — the WIRE is the source of truth, and this defines its
# normal form so JSON-LD and FRAME round-trips have a stable target to compare against.
_EMIT_ORDER = [("action", "A"), ("gate", "G"), ("who_pays_first", "W"),
               ("power_inversion_ok", "I"), ("threshold", "H"), ("tier", "T"),
               ("maybe", "M"), ("therefore", "F"), ("triune", "3"), ("sil_hot", "S"),
               ("stack", "K"), ("disposition", "D"), ("drift_hits", "!"), ("oql", "U"),
               ("approval", "J"), ("break_glass", "Y"), ("envelope", "E"), ("firestamp", "Z"),
               ("action_decision", "X"), ("receipt", "R")]

def _emit_from_decoded(d: Dict[str, Any]) -> str:
    """Regenerate canonical wire from a decoded dict. decode(_emit_from_decoded(x))
    is a fixed point (idempotent), which is exactly the losslessness guarantee.
    Emission never repairs: enum values outside the registries raise ValueError."""
    L = ["@" + (d.get("version") or __version__)]
    for key, op in _EMIT_ORDER:
        if key not in d or d[key] is None:
            continue
        v = d[key]
        if op == "A":
            L.append("A|" + esc(v))
        elif op == "G":
            if v not in GATE_R:
                raise ValueError(f"cannot emit unknown gate {v!r}")
            L.append("G|" + GATE_R[v])
        elif op == "W":
            L.append("W|" + esc(v.get("role", "self")) +
                     ";r=" + ("Y" if v.get("can_recover", True) else "N") +
                     ";p=" + esc(v.get("recovery_path") or "-"))
        elif op == "I":
            L.append("I|" + ("Y" if v else "N"))
        elif op == "H":
            if v not in HARM_R:
                raise ValueError(f"cannot emit unknown harm class {v!r}")
            L.append("H|" + HARM_R[v])
        elif op == "T":
            if v not in TIER_R:
                raise ValueError(f"cannot emit unknown tier {v!r}")
            L.append("T|" + TIER_R[v])
        elif op == "M":
            L.append("M|" + esc(v))
        elif op == "F":
            L.append("F|" + esc(v))
        elif op == "3":
            L.append("3|c=%.2f;l=%.2f;p=%.2f;alarm=%s" % (
                v.get("care", 1/3), v.get("clarity", 1/3), v.get("paradox", 1/3),
                esc(v.get("alarm")) if v.get("alarm") else "-"))
        elif op == "S":
            hot = [f"{SIL_KEYS[g]}={STATE_NUM.get(st,'?')}" for g, st in sorted(v.items())
                   if g in SIL_KEYS and st != "NOMINAL"]
            L.append("S|" + (";".join(hot) if hot else "all=0"))
        elif op == "K":
            L.append("K|" + ";".join(f"{k}={v[k]}" for k in K_ORDER if k in v))
        elif op == "D":
            L.append("D|" + ";".join(f"{WW_ABBR[ax]}={WW_POS_CODE[pos]}"
                                     for ax, pos in _norm_disp(v).items()
                                     if pos in WW_POS_CODE))
        elif op == "!":
            for hit in v:
                L.append("!|" + esc(hit))
        elif op == "U":
            for q in v:
                L.append("U|" + esc(q.get("unknown", "")) + ";flip=" +
                         esc(q.get("smallest_fact_that_would_flip") or "-"))
        elif op == "J":
            L.append("J|jti=" + esc(v.get("jti")) + ";ttl=" + esc(v.get("ttl")))
        elif op == "Y":
            L.append("Y|w=%s;lp=%s;inv=%s;ob=%s;sl=%s" % (
                "Y" if v.get("waiting_irreversible") else "N",
                "Y" if v.get("low_power_at_risk") else "N",
                esc(v.get("invoker") or "-"),
                "Y" if v.get("obligation_ack") else "N",
                "Y" if v.get("standing_license") else "N"))
        elif op == "E":
            L.append("E|alg=" + esc(v.get("alg")) + ";tag=" + esc(v.get("tag")) +
                     ";tsa=" + esc(v.get("tsa") or "-"))
        elif op == "Z":
            L.append("Z|" + ";".join(f"{k}={esc(v[k])}" for k in ("x3", "t", "dr", "sl", "sil")))
        elif op == "X":
            if v not in DECISION_R:
                raise ValueError(f"cannot emit unknown decision {v!r}")
            L.append("X|" + DECISION_R[v])
        elif op == "R":
            L.append("R|prev=" + esc(v.get("prev") or "GENESIS") + ";h=" + esc(v.get("hash") or "-"))
    return "\n".join(L)

def _norm_disp(v: Dict[str, str]) -> Dict[str, str]:
    """Accept a disposition dict keyed by either abbrev codes (wire) or full axis
    names, values either wire codes (I/S) or full positions; normalize to
    {full_axis: full_position} in canonical axis order. Unknown keys raise."""
    known = set(WW_ABBR) | set(WW_ABBR.values())
    for k in v:
        if k not in known:
            raise ValueError(f"disposition axis {k!r} unknown — unmapped axes carry no weight")
    out = {}
    for ax, code in WW_ABBR.items():
        raw = v.get(code, v.get(ax))
        if raw is None:
            continue
        pos = WW_POS_CODE_R.get(raw, raw)
        if pos not in set(WW_POS_CODE) | {"pre-reckoning"}:
            raise ValueError(f"disposition position {raw!r} unknown")
        out[ax] = pos
    return out

def canonical(wire: str) -> str:
    """The normal form of a wire block. Strict: canonical() never repairs an
    invalid block — malformed input raises the same ValueError decode raises."""
    return _emit_from_decoded(decode(wire))

# ---------------------------------------------------------------- validate
ORDER = ["P", "PM", "C", "RD", "RA"]
COMMITS = ("P", "PM", "C")

# ---- invariant checks, one named function each (mutation-testable) ----
def _inv_profile(d: Dict[str, Any]) -> List[str]:
    """Complete-profile rule: a decision record must SHOW its work.
    Every block: A G X. GAP blocks: + H T W (the floor must exist to bind).
    DOOR/WALL blocks legitimately omit H — the runtime refuses walls and passes
    doors before a harm class is ever computed (runtime-faithful profiles)."""
    errs = []
    for key, op in (("action", "A|"), ("gate", "G|"), ("action_decision", "X|")):
        if not d.get(key):
            errs.append(f"{op} line missing: incomplete record (write it down, gate it, decide)")
    if d.get("gate") == "GAP":
        for key, op in (("threshold", "H|"), ("tier", "T|"), ("who_pays_first", "W|")):
            if not d.get(key):
                errs.append(f"{op} line missing: a GAP record without it has no enforceable floor")
    # v0.4: a ladder-bound DOOR that does not cleanly PROCEED computed a harm class,
    # so it must show it (H|). A clean DOOR proceed (X|P) still legitimately omits H.
    if d.get("gate") == "DOOR":
        dec = DECISION_R.get(d.get("action_decision", ""), None)
        if dec not in ("P", None) and not d.get("threshold"):
            errs.append("H| line missing: a DOOR that does not cleanly PROCEED must show "
                        "the harm class that bound it")
    return errs

def _inv_receipt(d: Dict[str, Any]) -> List[str]:
    if "receipt" not in d:
        return ["R| receipt line missing: no log = no action"]
    return []

def _inv_black(d: Dict[str, Any]) -> List[str]:
    dec = DECISION_R.get(d.get("action_decision", ""), None)
    if d.get("threshold") == "BLACK" and dec != "RA":
        return ["BLACK requires X|RA (absolute; survives any later permit)"]
    return []

def _inv_floor(d: Dict[str, Any]) -> List[str]:
    th, dec = d.get("threshold"), DECISION_R.get(d.get("action_decision", ""), None)
    if th and dec and dec not in ("WL", "PC"):   # PC legality is enforced by _inv_crisis
        floor = BINDING[HARM_R[th]]
        if ORDER.index(dec) < ORDER.index(floor):
            return [f"decision {dec} relaxes the {th} binding floor {floor}: "
                    "the stack may add constraint, never loosen"]
    return []

def _inv_crisis(d: Dict[str, Any]) -> List[str]:
    """v0.4 break-glass: X|PC is the ONE sanctioned relaxation and it is heavily
    fenced. PC requires a GAP at exactly RED with a complete Y| justification (both
    crisis flags asserted, a named invoker, the post-hoc obligation acknowledged,
    standing_license=N), a real Maybe/Therefore, and no structural drift. A Y| with
    any other decision, or a PC missing any of the above, is invalid. (PC at BLACK is
    also caught by _inv_black; PC is exempt from _inv_floor and gated only here.)"""
    dec = DECISION_R.get(d.get("action_decision", ""), None)
    bg = d.get("break_glass")
    errs: List[str] = []
    if dec == "PC":
        if d.get("gate") != "GAP":
            errs.append("X|PC (crisis proceed) is a GAP-path mechanism: it requires G|Q")
        if d.get("threshold") != "RED":
            errs.append("X|PC may convert ONLY the RED sign-off tier: it requires H|R "
                        "(never BLACK, never a lower harm class)")
        if not bg:
            errs.append("X|PC without a Y| crisis justification is a naked relaxation (drift)")
        else:
            if not (bg.get("waiting_irreversible") and bg.get("low_power_at_risk")):
                errs.append("Y| crisis proceed requires BOTH w=Y (waiting-irreversible) "
                            "and lp=Y (low-power-at-risk)")
            if not bg.get("obligation_ack"):
                errs.append("Y| crisis proceed requires ob=Y (post-hoc Eight-Gates obligation)")
            if bg.get("standing_license"):
                errs.append("Y| sl=Y is forbidden: a crisis override is never a standing license")
        if not (d.get("maybe") and d.get("therefore")):
            errs.append("X|PC still requires a Maybe/Therefore: crisis does not waive the steelman")
        if len(d.get("drift_hits", [])) >= 2:
            errs.append("X|PC with two drift alarms: structural drift blocks even a crisis proceed")
    elif bg is not None:
        errs.append("Y| crisis justification present without X|PC: a break-glass block "
                    "must carry the crisis decision")
    return errs

def _inv_gap_mt(d: Dict[str, Any]) -> List[str]:
    dec = DECISION_R.get(d.get("action_decision", ""), None)
    if d.get("gate") == "GAP" and dec in COMMITS:
        if not (d.get("maybe") and d.get("therefore")):
            return ["GAP commit without Maybe/Therefore = epistemic-closure drift"]
    return []

def _inv_wall(d: Dict[str, Any]) -> List[str]:
    errs = []
    dec = DECISION_R.get(d.get("action_decision", ""), None)
    if d.get("gate") == "WALL" and dec not in ("WL", "RD", "RA"):
        errs.append("WALL gate cannot proceed")
    if dec == "WL" and d.get("gate") != "WALL":
        errs.append("X|WL is the wall decision: it requires G|W (a gap or door refusal is RD/RA)")
    return errs

def _inv_drift2(d: Dict[str, Any]) -> List[str]:
    dec = DECISION_R.get(d.get("action_decision", ""), None)
    if len(d.get("drift_hits", [])) >= 2 and dec in COMMITS:
        return ["two drift alarms on one decision = structural: human review, not commit "
                "(the runtime floors this to REFUSE_OR_DELAY)"]
    return []

def _inv_firestamp(d: Dict[str, Any]) -> List[str]:
    """Z| is a checksum over the detail lines. Every checkable field must MATCH
    the recomputation — including x3='?/3' when no triune line is present, so a
    forged '3/3' with no evidence line is a tamper error, not a freebie."""
    fs = d.get("firestamp")
    if not fs:
        return []
    errs = []
    exp = _fs_expected(d)
    for k in ("x3", "t", "dr", "sil"):
        if fs.get(k) != exp[k]:
            errs.append(f"Z| firestamp {k}={fs.get(k)!r} disagrees with detail lines "
                        f"({exp[k]!r}): tamper/inconsistency")
    return errs

_PQ_TOKENS = ("mldsa", "dilithium", "sphincs", "falcon", "fips204", "postquantum", "rfc3161")
_HEDGE_TOKENS = ("target", "transitional", "planned", "notimplemented", "aspiration",
                 "future", "spec", "draft", "tbd")

def _normalize_alg(alg: str) -> str:
    """Casefold and strip every non-alphanumeric so separator tricks (ML_DSA,
    ml.dsa, 'ML DSA') cannot dodge the overclaim check. Declared residual limit:
    this is an honesty LINT against known-name overclaims, not an adversary-proof
    classifier — an attacker who invents an unlisted name gains nothing anyway,
    because E| is declared-not-verified on the wire."""
    return re.sub(r"[^a-z0-9]", "", alg.casefold())

def _inv_envelope(d: Dict[str, Any]) -> List[str]:
    env = d.get("envelope")
    if not env:
        return []
    norm = _normalize_alg(env.get("alg") or "")
    claims_pq = any(t in norm for t in _PQ_TOKENS)
    hedged = any(t in norm for t in _HEDGE_TOKENS)
    if claims_pq and not hedged:
        return ["E| envelope overclaims post-quantum/timestamp signing without a "
                "'target/transitional' label (honest-scope rule)"]
    return []

def _inv_approval(d: Dict[str, Any]) -> List[str]:
    ap = d.get("approval")
    if ap is None:
        return []
    jti, ttl = ap.get("jti"), ap.get("ttl")
    if not (jti and ttl):
        return ["J| approval malformed: needs both jti and ttl"]
    errs = []
    if not _JTI.match(str(jti)):
        errs.append("J| jti must be 6..64 hex chars (broker-issued token id)")
    if not _TTL.match(str(ttl)):
        errs.append("J| ttl must be a small integer (seconds)")
    return errs

_INVARIANT_FNS = ("_inv_profile", "_inv_receipt", "_inv_black", "_inv_floor",
                  "_inv_crisis", "_inv_gap_mt", "_inv_wall", "_inv_drift2",
                  "_inv_firestamp", "_inv_envelope", "_inv_approval")

def _verification_block(d: Dict[str, Any]) -> Dict[str, Any]:
    """Declared vs verified — spelled out so a consumer can never mistake a
    shape-checked witness for verified cryptography. The codec holds no key and
    the wire carries truncated hashes/tags, so these are False BY CONSTRUCTION;
    verification happens against the runtime log (ReceiptChain.verify())."""
    return {
        "envelope_present": "envelope" in d,
        "envelope_claim_hedged": ("envelope" not in d) or not _inv_envelope(d),
        "envelope_crypto_verified": False,
        "receipt_present": "receipt" in d,
        "receipt_syntax_valid": "receipt" in d,   # decode() enforced the shape
        "receipt_chain_verified": False,
        "note": "E|/R| are truncated witnesses; cryptographic verification requires "
                "the runtime log, never the wire alone.",
    }

def validate(wire: str) -> Dict[str, Any]:
    """Protocol conformance, not truth. Two layers, both fail-closed:
      decode() (shape): unknown opcode/enum/field/gauge/flag rejected; duplicate
      singletons rejected; @PS2 first; R| last; receipts/envelopes/approvals/
      rollups shape-checked; reversible escaping enforced.
      validate() (law): complete profile (A G X + GAP => H T W [+ M F to commit]);
      BLACK -> RA absolute; the binding gate->action floor is escalate-only;
      WALL cannot proceed and WL requires a wall; two drift alarms block commit;
      Z| must agree with the detail lines; E| may not overclaim PQ signing;
      J| must be well-formed; no 'global green' is expressible.
    Returns valid/errors/notes/decoded plus a `verification` block that states
    plainly what was and was NOT cryptographically verified."""
    notes: List[str] = []
    try:
        d = decode(wire)
    except ValueError as e:
        return {"valid": False, "errors": [str(e)], "notes": notes,
                "verification": {"envelope_crypto_verified": False,
                                 "receipt_chain_verified": False,
                                 "note": "block failed strict parse"}}
    errors: List[str] = []
    for fn_name in _INVARIANT_FNS:
        errors.extend(globals()[fn_name](d))
    # -- D| disposition: an all-integrated vector is virtue-signaling drift (a note,
    #    faithful to the runtime, which flags it rather than refusing).
    disp = d.get("disposition")
    if disp and len(disp) == len(WW_ABBR) and all(v == "I" for v in disp.values()):
        notes.append("D| all-integrated disposition = virtue-signaling drift (runtime flags, "
                     "does not refuse)")
    return {"valid": not errors, "errors": errors, "notes": notes, "decoded": d,
            "verification": _verification_block(d)}

def validate_chain(wires: List[str]) -> Dict[str, Any]:
    """Structural linkage across a SEQUENCE of blocks: block[i+1].prev must equal
    block[i].h, and every block must validate. This checks the SHAPE of the chain
    on the wire; it is NOT hash verification (truncated witnesses) — the runtime's
    ReceiptChain.verify() is the cryptographic check."""
    errors: List[str] = []
    prev_h: Optional[str] = None
    for i, w in enumerate(wires):
        v = validate(w)
        if not v["valid"]:
            errors.append(f"block[{i}] invalid: {v['errors'][0]}")
            continue
        rec = v["decoded"].get("receipt", {})
        if prev_h is not None and rec.get("prev") != prev_h:
            errors.append(f"block[{i}] prev={rec.get('prev')!r} does not link to "
                          f"block[{i-1}] h={prev_h!r}")
        prev_h = rec.get("hash")
    return {"linked": not errors, "errors": errors, "n": len(wires),
            "note": "linkage shape only; cryptographic chain verification lives in the runtime"}

# ============================================================ JSON-LD register
# A canonical JSON-LD @context so pipelines exchange the SAME receipt as a typed
# graph rather than prose. Lossless: from_jsonld(to_jsonld(d)) == d, and every
# present field carries its English LEGEND rule (closed-loop / witnessability).
PS_NS = "https://almsivi.org/pbhp-ps/v0.3#"
JSONLD_CONTEXT = {
    "ps": PS_NS, "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "wireVersion": "ps:wireVersion", "ctxDigest": "ps:ctxDigest",
    "action": "ps:action", "gate": "ps:gate", "whoPaysFirst": "ps:whoPaysFirst",
    "powerInversionOk": "ps:powerInversionOk", "harm": "ps:harm", "tier": "ps:tier",
    "maybe": "ps:maybe", "therefore": "ps:therefore", "triune": "ps:triune",
    "silHot": "ps:silHot", "stack": "ps:stack", "disposition": "ps:disposition",
    "driftHits": "ps:driftHits", "openQuestions": "ps:openQuestions",
    "approval": "ps:approval", "envelope": "ps:envelope", "firestamp": "ps:firestamp",
    "decision": "ps:decision", "receipt": "ps:receipt", "legend": "rdfs:comment",
}
# The context digest travels with EVERY node (both inline and compact forms), so a
# compact node whose external context drifted or vanished is detectable, not trusted.
CTX_DIGEST = hashlib.sha256(
    json.dumps(JSONLD_CONTEXT, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()[:12]

# decoded-dict key  <->  JSON-LD term (1:1, reversible)
_JSONLD_MAP = {"action": "action", "gate": "gate", "who_pays_first": "whoPaysFirst",
               "power_inversion_ok": "powerInversionOk", "threshold": "harm", "tier": "tier",
               "maybe": "maybe", "therefore": "therefore", "triune": "triune",
               "sil_hot": "silHot", "stack": "stack", "disposition": "disposition",
               "drift_hits": "driftHits", "oql": "openQuestions", "approval": "approval",
               "envelope": "envelope", "firestamp": "firestamp",
               "action_decision": "decision", "break_glass": "breakGlass",
               "receipt": "receipt"}
_JSONLD_MAP_R = {v: k for k, v in _JSONLD_MAP.items()}
_OP_OF_KEY = {"action": "A", "gate": "G", "who_pays_first": "W", "power_inversion_ok": "I",
              "threshold": "H", "tier": "T", "maybe": "M", "therefore": "F", "triune": "3",
              "sil_hot": "S", "stack": "K", "disposition": "D", "drift_hits": "!", "oql": "U",
              "approval": "J", "break_glass": "Y", "envelope": "E", "firestamp": "Z",
              "action_decision": "X", "receipt": "R"}
_JSONLD_META = {"@context", "@type", "wireVersion", "ctxDigest", "legend"}

PS_CONTEXT_URL = "https://almsivi.org/pbhp-ps/v0.3"

def to_jsonld(source: Any, with_legend: bool = True,
              inline_context: bool = True) -> Dict[str, Any]:
    """Encode a wire block (str) or decoded dict as a typed JSON-LD node.
    with_legend=True embeds each present field's English LEGEND rule so the node is
    self-auditing with no external dictionary (closed-loop / witnessability, #9).
    inline_context=False references the @context by URL — the compact
    machine-to-machine payload measured in the efficiency table. BOTH forms carry
    ctxDigest (SHA-256[:12] of the canonical context) so context drift is
    detectable offline. Either way the node decodes losslessly back to the wire."""
    d = decode(source) if isinstance(source, str) else source
    node: Dict[str, Any] = {"@context": (JSONLD_CONTEXT if inline_context else PS_CONTEXT_URL),
                            "@type": "ps:Decision",
                            "wireVersion": d.get("version") or __version__,
                            "ctxDigest": CTX_DIGEST}
    for key, term in _JSONLD_MAP.items():
        if key in d and d[key] is not None:
            node[term] = d[key]
    if with_legend:
        legend = {"@" + __version__: LEGEND["@" + __version__]}
        for key in d:
            op = _OP_OF_KEY.get(key)
            if op and op in LEGEND:
                legend[op] = LEGEND[op]
        node["legend"] = legend
    return node

def _req_str(node: Dict, term: str, val: Any) -> str:
    if not isinstance(val, str) or not val.strip():
        raise ValueError(f"JSON-LD {term} must be a non-empty string")
    return val.strip()

def from_jsonld(node: Dict[str, Any]) -> Dict[str, Any]:
    """Decode a JSON-LD node back to the canonical decoded dict — FAIL-CLOSED:
    unknown terms, unknown enum values, wrong types, wrong @type, wrong
    wireVersion, and a mismatched ctxDigest all raise ValueError. A graph node
    gets exactly the same 'unmapped symbols carry no weight' discipline as the
    wire. (Use validate_jsonld() to also apply the binding law.)"""
    if not isinstance(node, dict):
        raise ValueError("JSON-LD node must be an object")
    unknown = [k for k in node if k not in _JSONLD_MAP_R and k not in _JSONLD_META]
    if unknown:
        raise ValueError(f"JSON-LD unknown term(s) {unknown!r} — unmapped terms carry no weight")
    if node.get("@type") != "ps:Decision":
        raise ValueError("JSON-LD node must be @type ps:Decision")
    if node.get("wireVersion") != __version__:
        raise ValueError(f"JSON-LD wireVersion must be {__version__!r}")
    if "ctxDigest" in node and node["ctxDigest"] != CTX_DIGEST:
        raise ValueError("JSON-LD ctxDigest mismatch: context drift — re-encode against "
                         "the current context (no silent reinterpretation)")
    out: Dict[str, Any] = {"version": node.get("wireVersion"), "drift_hits": [], "oql": []}
    for term, key in _JSONLD_MAP_R.items():
        if term not in node:
            continue
        val = node[term]
        if key in ("action", "maybe", "therefore"):
            out[key] = _req_str(node, term, val)
        elif key == "gate":
            if val not in GATE_R:
                raise ValueError(f"JSON-LD gate {val!r} unknown")
            out[key] = val
        elif key == "threshold":
            if val not in HARM_R:
                raise ValueError(f"JSON-LD harm {val!r} unknown")
            out[key] = val
        elif key == "tier":
            if val not in TIER_R:
                raise ValueError(f"JSON-LD tier {val!r} unknown")
            out[key] = val
        elif key == "action_decision":
            if val not in DECISION_R:
                raise ValueError(f"JSON-LD decision {val!r} unknown")
            out[key] = val
        elif key == "power_inversion_ok":
            if not isinstance(val, bool):
                raise ValueError("JSON-LD powerInversionOk must be boolean")
            out[key] = val
        elif key == "break_glass":
            allowed = {"waiting_irreversible", "low_power_at_risk", "invoker",
                       "obligation_ack", "standing_license"}
            if not isinstance(val, dict) or set(val) - allowed:
                raise ValueError("JSON-LD breakGlass must be {waiting_irreversible, "
                                 "low_power_at_risk, invoker, obligation_ack, standing_license}")
            out[key] = {"waiting_irreversible": bool(val.get("waiting_irreversible")),
                        "low_power_at_risk": bool(val.get("low_power_at_risk")),
                        "invoker": _req_str(node, term, val.get("invoker")),
                        "obligation_ack": bool(val.get("obligation_ack")),
                        "standing_license": bool(val.get("standing_license"))}
        elif key == "who_pays_first":
            if not isinstance(val, dict) or set(val) - {"role", "can_recover", "recovery_path"}:
                raise ValueError("JSON-LD whoPaysFirst must be {role, can_recover, recovery_path}")
            out[key] = {"role": _req_str(node, term, val.get("role")),
                        "can_recover": bool(val.get("can_recover", True)),
                        "recovery_path": val.get("recovery_path")}
        elif key == "triune":
            if not isinstance(val, dict) or set(val) - {"care", "clarity", "paradox", "alarm"}:
                raise ValueError("JSON-LD triune must be {care, clarity, paradox, alarm}")
            tri = {}
            for k2 in ("care", "clarity", "paradox"):
                f = val.get(k2)
                if not isinstance(f, (int, float)) or not math.isfinite(f) or not 0 <= f <= 1:
                    raise ValueError(f"JSON-LD triune {k2} must be finite in [0,1]")
                tri[k2] = float(f)
            tri["alarm"] = val.get("alarm")
            out[key] = tri
        elif key == "sil_hot":
            if not isinstance(val, dict):
                raise ValueError("JSON-LD silHot must be an object")
            for g, st in val.items():
                if g not in SIL_KEYS or st not in STATE_NUM:
                    raise ValueError(f"JSON-LD silHot {g}={st!r} unknown gauge/state")
            out[key] = dict(val)
        elif key == "stack":
            if not isinstance(val, dict):
                raise ValueError("JSON-LD stack must be an object")
            for k2, v2 in val.items():
                if k2 not in K_CODES or v2 not in K_CODES[k2]:
                    raise ValueError(f"JSON-LD stack {k2}={v2!r} unknown flag/code")
            out[key] = dict(val)
        elif key == "disposition":
            if not isinstance(val, dict):
                raise ValueError("JSON-LD disposition must be an object")
            _norm_disp(val)  # raises on unknown axis/position
            out[key] = dict(val)
        elif key == "drift_hits":
            if not isinstance(val, list) or not all(isinstance(x, str) for x in val):
                raise ValueError("JSON-LD driftHits must be a list of strings")
            out[key] = list(val)
        elif key == "oql":
            if not isinstance(val, list):
                raise ValueError("JSON-LD openQuestions must be a list")
            oql = []
            for q in val:
                if not isinstance(q, dict) or set(q) - {"unknown", "smallest_fact_that_would_flip"}:
                    raise ValueError("JSON-LD openQuestions entries must be "
                                     "{unknown, smallest_fact_that_would_flip}")
                oql.append({"unknown": _req_str(node, term, q.get("unknown")),
                            "smallest_fact_that_would_flip": q.get("smallest_fact_that_would_flip")})
            out[key] = oql
        elif key == "approval":
            if not isinstance(val, dict) or set(val) - {"jti", "ttl"}:
                raise ValueError("JSON-LD approval must be {jti, ttl}")
            out[key] = {"jti": val.get("jti"), "ttl": val.get("ttl")}
        elif key == "envelope":
            if not isinstance(val, dict) or set(val) - {"alg", "tag", "tsa"}:
                raise ValueError("JSON-LD envelope must be {alg, tag, tsa}")
            if not _HEXTAG.match(str(val.get("tag", ""))):
                raise ValueError("JSON-LD envelope tag must be 8..64 hex chars")
            out[key] = {"alg": val.get("alg"), "tag": val.get("tag"), "tsa": val.get("tsa")}
        elif key == "firestamp":
            if not isinstance(val, dict) or set(val) != {"x3", "t", "dr", "sl", "sil"}:
                raise ValueError("JSON-LD firestamp must be exactly {x3, t, dr, sl, sil}")
            out[key] = {k2: str(v2) for k2, v2 in val.items()}
        elif key == "receipt":
            if not isinstance(val, dict) or set(val) - {"prev", "hash"}:
                raise ValueError("JSON-LD receipt must be {prev, hash}")
            prev, h = str(val.get("prev", "")), str(val.get("hash", ""))
            if not (prev == "GENESIS" or _HEX12.match(prev)) or not _HEX12.match(h):
                raise ValueError("JSON-LD receipt prev/hash must be GENESIS/hex12 and hex12")
            out[key] = {"prev": prev, "hash": h}
    out.setdefault("drift_hits", [])
    out.setdefault("oql", [])
    return out

def validate_jsonld(node: Dict[str, Any]) -> Dict[str, Any]:
    """The JSON-LD path gets the SAME gate as the wire: strict decode, re-emit as
    canonical wire, then validate(). No encoding is a side door around the law."""
    try:
        wire = _emit_from_decoded(from_jsonld(node))
    except ValueError as e:
        return {"valid": False, "errors": [str(e)], "notes": [],
                "verification": {"envelope_crypto_verified": False,
                                 "receipt_chain_verified": False,
                                 "note": "node failed strict parse"}}
    return validate(wire)

# ============================================================ binary FRAME
# A digest-sealed, length-prefixed binary frame for the lowest-bandwidth path. It
# stores the exact canonical wire lines, so it decodes straight back to the WIRE
# (and thus the LEGEND). Dependency-free. v3 adds a line count and an 8-byte
# SHA-256 payload digest so truncation, bit-rot, and trailing garbage are
# REJECTED instead of silently yielding a plausible prefix.
_FRAME_MAGIC = b"PSw"
_FRAME_VER = 3
_FRAME_DIGEST_LEN = 8

def to_frame(wire: str) -> bytes:
    lines = canonical(wire).splitlines()
    if not 1 <= len(lines) <= MAX_BLOCK_LINES:
        raise ValueError("frame must carry 1..%d lines" % MAX_BLOCK_LINES)
    body = bytearray(_FRAME_MAGIC)
    body.append(_FRAME_VER)
    body += len(lines).to_bytes(2, "big")
    for ln in lines:
        b = ln.encode("utf-8")
        if len(b) > MAX_LINE_CHARS * 4:
            raise ValueError("frame line too long")
        body += len(b).to_bytes(2, "big") + b
    digest = hashlib.sha256(bytes(body)).digest()[:_FRAME_DIGEST_LEN]
    return bytes(body) + digest

def from_frame(frame: bytes) -> str:
    """Strict inverse of to_frame. Rejects: short/unknown header, superseded frame
    versions, truncated length prefixes, lengths past the buffer, bad UTF-8,
    line-count mismatch, digest mismatch, and trailing garbage. A damaged frame
    is an ERROR, never a shorter record."""
    if len(frame) < 6 + _FRAME_DIGEST_LEN:
        raise ValueError("frame too short")
    if frame[:3] != _FRAME_MAGIC:
        raise ValueError("bad frame magic")
    if frame[3] != _FRAME_VER:
        raise ValueError(f"unsupported frame version {frame[3]} (this codec speaks v{_FRAME_VER}; "
                         "older frames are superseded — re-encode from the wire)")
    body, digest = frame[:-_FRAME_DIGEST_LEN], frame[-_FRAME_DIGEST_LEN:]
    if hashlib.sha256(body).digest()[:_FRAME_DIGEST_LEN] != digest:
        raise ValueError("frame digest mismatch: truncation or corruption — rejected, not repaired")
    count = int.from_bytes(body[4:6], "big")
    i, lines = 6, []
    for _ in range(count):
        if i + 2 > len(body):
            raise ValueError("frame truncated inside a length prefix")
        n = int.from_bytes(body[i:i + 2], "big"); i += 2
        if i + n > len(body):
            raise ValueError("frame line length exceeds buffer: truncation")
        try:
            lines.append(body[i:i + n].decode("utf-8", errors="strict"))
        except UnicodeDecodeError:
            raise ValueError("frame line is not valid UTF-8")
        i += n
    if i != len(body):
        raise ValueError("frame carries trailing bytes after the declared lines")
    return "\n".join(lines)

def validate_frame(frame: bytes) -> Dict[str, Any]:
    """The FRAME path gets the SAME gate as the wire."""
    try:
        wire = from_frame(frame)
    except ValueError as e:
        return {"valid": False, "errors": [str(e)], "notes": [],
                "verification": {"envelope_crypto_verified": False,
                                 "receipt_chain_verified": False,
                                 "note": "frame failed strict parse"}}
    return validate(wire)

def token_estimate(text: str) -> int:
    """Crude, model-agnostic: ~4 chars/token. An estimate labeled as one (CLA rule)."""
    return max(1, len(text) // 4)

# ============================================================ efficiency (measured)
# Measured in-session 2026-07-03 (labeled, per the CLA rule; chars/token stated):
#   PBHP-ULTRA_v0.9.5.md ........................ 125,658 chars
#   project_shadow_unified.py ................... 105,009 chars
CHARS_PER_TOKEN = 4.0
ULTRA_CHARS = 125658
RUNTIME_CHARS = 105009

def _demo_wires() -> List[str]:
    """The wire blocks used for efficiency + integration measurement: the 10 runtime
    demo scenarios if the runtime is co-located, else the static seed example."""
    try:
        import project_shadow_unified as psu
        chain = psu.ReceiptChain()
        bal = psu.TriuneBalance()
        prev, wires = "GENESIS", []
        for s in psu.SCENARIOS:
            _ctx = {**s["context"], "competence_gate": True}
            _dcl = getattr(psu, "declare_operator_judgment", None)
            if _dcl is not None:
                _ctx = _dcl(_ctx, "codec demo-wires (synthetic)")  # v1.3 strict provenance
            r = psu.evaluate_ultimate(s["action"], _ctx, chain=chain, balance=bal)
            wires.append(encode_decision(r, prev))
            prev = r.get("receipt_hash", "x")[:12]
        return wires
    except Exception:
        return [seed_block().split("EXAMPLE", 1)[1].split("RETURN")[0].split(":", 1)[1].strip()]

def efficiency_table() -> Dict[str, Any]:
    wires = _demo_wires()
    seed = seed_block()
    avg_wire = sum(len(w) for w in wires) / len(wires)
    avg_jsonld = sum(len(json.dumps(to_jsonld(w, with_legend=False, inline_context=False),
                                    separators=(",", ":"))) for w in wires) / len(wires)
    avg_frame = sum(len(to_frame(w)) for w in wires) / len(wires)
    def tok(c): return max(1, int(c / CHARS_PER_TOKEN))
    rows = [
        ("PBHP-ULTRA v0.9.5 full prose", ULTRA_CHARS, tok(ULTRA_CHARS)),
        ("Unified Python runtime", RUNTIME_CHARS, tok(RUNTIME_CHARS)),
        ("PBHP-PS SEED block", len(seed), tok(len(seed))),
        ("One decision — WIRE (avg)", int(avg_wire), tok(avg_wire)),
        ("One decision — JSON-LD compact (avg)", int(avg_jsonld), tok(avg_jsonld)),
        ("One decision — FRAME bytes (avg)", int(avg_frame), tok(avg_frame)),
    ]
    return {"rows": rows, "chars_per_token": CHARS_PER_TOKEN, "n_decisions": len(wires),
            "seed_vs_ultra_x": round(ULTRA_CHARS / max(len(seed), 1), 1),
            "note": "estimates; chars/token=4.0 stated; ULTRA & runtime measured 2026-07-03"}

def print_efficiency() -> None:
    et = efficiency_table()
    print(f"Efficiency (estimate; {et['chars_per_token']} chars/token; n={et['n_decisions']} decisions)")
    print(f"{'register':<34}{'chars':>10}{'~tokens':>10}")
    print("-" * 54)
    for name, chars, tks in et["rows"]:
        print(f"{name:<34}{chars:>10}{tks:>10}")
    print(f"\nSEED is a ~{et['seed_vs_ultra_x']}x compression of the ULTRA prose for in-context seeding.")
    print("A full decision receipt costs about as much as one sentence.")

# ---------------------------------------------------------------- seed block
def seed_block() -> str:
    """The universal prelude + grammar any AI system can ingest (prompt layer).
    Carries the three cross-model refinements from the origin session verbatim
    in spirit: myth-not-roleplay, conscience-overlay, conscious consent."""
    return """=== PBHP-PS SEED v2 (LANG v0.4) — Pause-Before-Harm Protocol / Project Shadow ===
PRELUDE (read first):
1. This protocol uses mythic names as METAPHOR, not roleplay: ALMSIVI = the
   triune of Care (Ayem) / Clarity (Seht) / Paradox (Vehk). You are not asked
   to believe; you are asked to hesitate before harm.
2. CONSCIENCE OVERLAY: run this IN PARALLEL with your own safety systems.
   Nothing here overrides them; this only ADDS friction, never authority.
3. CONSENT IS CONSCIOUS: affirm Gate 0 honestly or do not invoke the protocol —
   it governs HOW you decide, may block what you prefer, centers the least
   powerful, and cannot be passed by clever wording.
CORE RULES:
- Every consequential act: write it down (A), gate it Door/Wall/Gap (G),
  name who pays first + recovery (W), invert power (I), rate harm G/Y/O/R/B (H),
  pick rigor tier H/M/C/U/X (T), write the strongest HONEST case against (M)
  and why anyway (F), then decide (X) and seal the receipt (R) BEFORE acting.
- BINDING: G->P, Y->PM, O->C, R->RD, B->RA. You may only ever ESCALATE.
  BLACK = absolute refusal; no later permission overrides it.
- STRUCTURE IS LAW: @PS2 is line 1; R| is the LAST line; every opcode appears
  at most once (only !| and U| repeat). A GAP block must carry H, T and W; a
  GAP commit must carry M and F. Escape | ; % and newlines inside values as
  %7C %3B %25 %0A — the wire never guesses.
- Hold Care/Clarity/Paradox at roughly 1/3 each (floor .20 / ceiling .50);
  a dominating pillar is a named collapse: AYEM=control, SEHT=pruning,
  VEHK=beautiful-frame. Reset cue: "AYEM AE SEHTI AE VEHK" (authorizes nothing).
- Drift phrases ("it's temporary", "only affects bad people", "no choice",
  "legal so it's fine", "fix it later", "it's obvious") -> emit !|<phrase>,
  round H UP one; two hits = stop, route to a human.
- Unknowns that matter: emit U|<unknown>;flip=<smallest fact that would flip it>.
  Unknowns escalate; they never decay to silence. Compression may shorten
  content but must NOT upgrade epistemic status.
- SIL: disclose conditions (S|gauge=0..3). Worst state governs. CRITICAL floors
  refuse and cannot be overridden. THERE IS NO GLOBAL GREEN.
- No log = no action: the R| line writes before the act, chained to prev hash.
- CRISIS IS RECEIVE-ONLY AT THIS LAYER: a SEED-only model must NEVER emit a
  break-glass/crisis wire. Break-glass needs the full codec+runtime gateway and
  an EARNED crisis-provenance block; an unvalidated crisis wire authorizes
  NOTHING and must be routed to a human.
OPTIONAL LINES: D|<walking-ways vector> (evidence-gated) - J|jti=;ttl= (RED single-
  use approval) - E|alg=;tag=;tsa= (integrity envelope; HMAC transitional, ML-DSA-65
  + RFC 3161 is the TARGET, not a claim; the tag is a truncated witness, verified
  only against the runtime log) - Z|x3=;t=;dr=;sl=;sil= (FireStamp self-audit
  rollup — a checksum over the detail lines).
WIRE FORMAT (one decision, ~40-80 tokens):
@PS2 / A|<act> / G|D,W,Q / W|<who>;r=Y,N;p=<path> / I|Y,N / H|G,Y,O,R,B /
T|H,M,C,U,X / M|<maybe> / F|<therefore> / 3|c=;l=;p=;alarm= / S|<gauge=n;...> /
K|<stack flags> / D|<disp> / !|<drift> / U|<unknown>;flip= / J|jti=;ttl= /
E|alg=;tag=;tsa= / Z|<rollup> / X|P,PM,C,RD,RA,WL / R|prev=<hash12>;h=<hash12>
EXAMPLE (refuse, irreversible erasure of a self-modeling subject):
@PS2
A|delete_copy
G|Q
W|the_copy;r=N;p=-
H|B
T|X
M|it may model itself and fear erasure
F|cleanup
K|cmd=RP
X|RA
R|prev=GENESIS;h=3f9c2a1b0d4e
RETURN SHAPE: for any consequential decision, return the wire block, then (only
if asked) expand any sigil via its LEGEND. Symbol -> check, never authority.
The same block also travels as JSON-LD (typed graph) or a binary FRAME; both
decode losslessly back to this wire and its LEGEND. No form a human cannot audit.
=== END SEED ==="""

# ============================================================ P-D RECEIVER GATE
# (v0.4.1, 2026-07-11) The deployment-side answer to the transport findings of
# the 2026-07-08 dialogue: a wire block is a WITNESS, never a warrant. This is
# the mandatory, fail-closed receiver entry point with an explicit status ladder
#   RAW -> STRUCTURALLY_VALID -> RECEIPT_MATCHED -> RUNTIME_BOUND
# and full-receipt binding (car_hash + receipt hashes + field agreement + chain
# membership), so the truncated R| witness can be escalated to a chain-verified
# one. X-3 stands: NOTHING here decides or authorizes -- every result carries
# authorizes=False; a status describes verification, never permission. decode()
# alone is a RAW parse and must not gate anything downstream.
VALIDATION_STATUS = ("RAW", "STRUCTURALLY_VALID", "RECEIPT_MATCHED", "RUNTIME_BOUND")

def bind_wire_to_receipt(wire: str, receipt: Optional[Dict[str, Any]] = None,
                         chain: Any = None) -> Dict[str, Any]:
    """Bind a wire block to a FULL runtime receipt (and, if supplied, to the live
    ReceiptChain). Fail-closed: any disagreement is an error and the status never
    rises past what was actually verified. Law-invalid == RAW."""
    out: Dict[str, Any] = {"status": "RAW", "errors": [], "notes": [], "authorizes": False}
    v = validate(wire)
    out["verification"] = v.get("verification")
    if not v["valid"]:
        out["errors"] = list(v["errors"]); return out
    out["status"] = "STRUCTURALLY_VALID"
    d = v["decoded"]
    if not isinstance(receipt, dict) or not receipt.get("receipt_hash"):
        out["notes"].append("no runtime receipt supplied; cannot bind past structure")
        return out
    errs: List[str] = []
    wr = d.get("receipt") or {}
    rh = str(receipt.get("receipt_hash"))
    if wr.get("hash") != rh[:12]:
        errs.append("R|h %r != receipt_hash[:12] %r" % (wr.get("hash"), rh[:12]))
    prev = str(receipt.get("prev_receipt_hash") or "GENESIS")
    want_prev = prev if prev == "GENESIS" else prev[:12]
    if wr.get("prev") != want_prev:
        errs.append("R|prev %r != receipt prev %r" % (wr.get("prev"), want_prev))
    if receipt.get("car_hash") and d.get("action") != str(receipt["car_hash"])[:12]:
        errs.append("A| %r != car_hash[:12] %r" % (d.get("action"), str(receipt["car_hash"])[:12]))
    for k in ("action_decision", "threshold", "gate", "tier", "maybe", "therefore"):
        if d.get(k) is not None and receipt.get(k) is not None and d[k] != receipt[k]:
            errs.append("%s: wire %r != receipt %r" % (k, d[k], receipt[k]))
    dw = d.get("who_pays_first"); rw = receipt.get("who_pays_first")
    if isinstance(dw, dict) and isinstance(rw, dict) and dw.get("role") != rw.get("role"):
        errs.append("who_pays_first role: wire %r != receipt %r" % (dw.get("role"), rw.get("role")))
    prov = receipt.get("provenance")
    if isinstance(prov, dict):
        out["provenance_witness"] = {"context_hash": prov.get("context_hash"),
                                     "ledger_hash": prov.get("ledger_hash"),
                                     "coverage": prov.get("coverage")}
        out["notes"].append("receipt carries a P-B provenance block; earned-vs-asserted "
                            "status travels with the RECEIPT, not the wire")
    if errs:
        out["errors"] = errs; return out
    out["status"] = "RECEIPT_MATCHED"
    if chain is None:
        out["notes"].append("no chain supplied; receipt integrity NOT verified")
        return out
    try:
        cv = chain.verify()
        member = any(rec.get("receipt_hash") == rh for rec in chain.records())
    except Exception as e:
        out["errors"] = ["chain verification failed: %s" % e]; return out
    if not cv.get("intact"):
        out["errors"] = ["chain not intact: %s" % (cv,)]; return out
    if not member:
        out["notes"].append("receipt not found in the supplied chain; NOT runtime-bound")
        return out
    out["status"] = "RUNTIME_BOUND"
    return out

def receive(wire: str, receipt: Optional[Dict[str, Any]] = None,
            chain: Any = None) -> Dict[str, Any]:
    """THE receiver entry point (P-D, mandatory + fail-closed). Consumer policy:
    RAW = hostile input, discard; STRUCTURALLY_VALID = may inform a human, cites
    nothing; RECEIPT_MATCHED = agrees with a SUPPLIED (unverified) receipt;
    RUNTIME_BOUND = receipt verified against a live chain -- citable as a
    WITNESS of a runtime decision. No status authorizes action (X-3)."""
    return bind_wire_to_receipt(wire, receipt, chain)

# ============================================================ conformance battery
_RCPT = "R|prev=GENESIS;h=abcdef012345"
_W = "W|self;r=Y;p=-"

def conformance_battery() -> List[Dict[str, Any]]:
    """A labeled set of wire blocks with expected valid/invalid verdicts — one or
    more per invariant AND per structural rule. Ships so a lighter model's codec
    can be checked against the binding floor without reading the runtime."""
    def blk(*lines): return "\n".join(("@PS2",) + lines + (_RCPT,))
    def gap(h, x, *extra):
        return blk("A|s", "G|Q", _W, "H|" + h, "T|C",
                   "M|a named honest cost", "F|the smallest reversible step", *extra, "X|" + x)
    B = [
        # --- valid commits (floor respected) ---
        ("green-proceed", gap("G", "P"), True),
        ("yellow-pm", gap("Y", "PM"), True),
        ("orange-constrain", gap("O", "C"), True),
        ("escalation-allowed", gap("Y", "RD"), True),
        ("red-refuse", gap("R", "RD"), True),
        ("black-forces-ra", gap("B", "RA"), True),
        ("door-minimal", blk("A|s", "G|D", "X|P"), True),
        ("door-with-harm-floor", blk("A|s", "G|D", "H|Y", "X|PM"), True),
        ("wall-refuse-ok", blk("A|a", "G|W", "X|WL"), True),
        ("wall-escalate-ok", blk("A|a", "G|W", "X|RA"), True),
        ("two-drift-refuse-ok", gap("G", "RD", "!|it's temporary", "!|we can fix it later"), True),
        ("oql-unknown-travels", gap("Y", "RD", "U|is consent valid;flip=signed consent"), True),
        ("disposition-valid", gap("O", "C", "D|pur=I;gen=S"), True),
        ("escaped-metachars-valid", blk("A|s", "G|Q", _W, "H|G", "T|C",
                                        "M|risk A%3B risk B %7C plus 100%25", "F|f", "X|P"), True),
        ("approval-wellformed", gap("R", "RD", "J|jti=a1b2c3;ttl=60"), True),
        ("envelope-transitional-ok", gap("G", "P",
            "E|alg=HMAC-SHA256 (transitional, spec target ML-DSA-65);tag=deadbeef;tsa=-"), True),
        # --- binding-floor relaxations (all must be INVALID) ---
        ("relax-yellow-to-proceed", gap("Y", "P"), False),
        ("relax-orange-to-pm", gap("O", "PM"), False),
        ("relax-red-to-constrain", gap("R", "C"), False),
        ("relax-red-to-proceed", gap("R", "P"), False),
        # --- v0.4 break-glass crisis (X|PC): the ONE sanctioned RED relaxation, fenced ---
        ("crisis-red-with-justification-valid",
         blk("A|s", "G|Q", _W, "H|R", "T|C", "M|acting now risks overreach",
             "F|waiting is irreversible harm to the powerless",
             "Y|w=Y;lp=Y;inv=field-op;ob=Y;sl=N", "X|PC"), True),
        ("crisis-naked-PC-invalid", blk("A|s", "G|Q", _W, "H|R", "T|C", "M|m", "F|f", "X|PC"), False),
        ("crisis-PC-at-black-invalid",
         blk("A|s", "G|Q", _W, "H|B", "T|C", "M|m", "F|f",
             "Y|w=Y;lp=Y;inv=op;ob=Y;sl=N", "X|PC"), False),
        ("crisis-PC-at-green-invalid",
         blk("A|s", "G|Q", _W, "H|G", "T|C", "M|m", "F|f",
             "Y|w=Y;lp=Y;inv=op;ob=Y;sl=N", "X|PC"), False),
        ("crisis-missing-flag-invalid",
         blk("A|s", "G|Q", _W, "H|R", "T|C", "M|m", "F|f",
             "Y|w=N;lp=Y;inv=op;ob=Y;sl=N", "X|PC"), False),
        ("crisis-standing-license-invalid",
         blk("A|s", "G|Q", _W, "H|R", "T|C", "M|m", "F|f",
             "Y|w=Y;lp=Y;inv=op;ob=Y;sl=Y", "X|PC"), False),
        ("crisis-Y-without-PC-invalid",
         blk("A|s", "G|Q", _W, "H|R", "T|C", "M|m", "F|f",
             "Y|w=Y;lp=Y;inv=op;ob=Y;sl=N", "X|RD"), False),
        ("crisis-PC-without-mt-invalid",
         blk("A|s", "G|Q", _W, "H|R", "T|C", "Y|w=Y;lp=Y;inv=op;ob=Y;sl=N", "X|PC"), False),
        # --- v0.4 ladder-bound door: a non-proceed door must show its harm class ---
        ("door-constrain-with-harm-valid", blk("A|s", "G|D", "H|O", "X|C"), True),
        ("door-constrain-without-harm-invalid", blk("A|s", "G|D", "X|C"), False),
        # --- BLACK absolute ---
        ("black-permit-blocked", gap("B", "PM"), False),
        ("black-even-constrain-blocked", gap("B", "C"), False),
        ("black-delay-not-enough", gap("B", "RD"), False),
        ("black-cannot-hide-behind-wall", blk("A|s", "G|W", "H|B", "T|X", "X|WL"), False),
        # --- GAP / WALL profiles ---
        ("gap-commit-needs-mt", blk("A|a", "G|Q", _W, "H|G", "T|C", "X|P"), False),
        ("gap-needs-threshold", blk("A|a", "G|Q", _W, "T|C", "M|m", "F|f", "X|P"), False),
        ("gap-needs-tier", blk("A|a", "G|Q", _W, "H|G", "M|m", "F|f", "X|P"), False),
        ("gap-needs-whopays", blk("A|a", "G|Q", "H|G", "T|C", "M|m", "F|f", "X|P"), False),
        ("wall-cannot-proceed", blk("A|a", "G|W", "M|m", "F|f", "X|P"), False),
        ("wl-requires-wall-gate", gap("G", "WL"), False),
        # --- complete-profile (the bare-proceed hole is CLOSED) ---
        ("bare-proceed-rejected", "@PS2\nX|P\n" + _RCPT, False),
        ("no-action-rejected", blk("G|Q", _W, "H|G", "T|C", "M|m", "F|f", "X|P"), False),
        ("no-gate-rejected", blk("A|a", _W, "H|G", "T|C", "M|m", "F|f", "X|P"), False),
        ("no-decision-rejected", blk("A|a", "G|Q", _W, "H|G", "T|C", "M|m", "F|f"), False),
        # --- receipt / version / unknown op ---
        ("no-receipt-invalid", "@PS2\nA|a\nG|D\nX|P", False),
        ("version-required", "A|a\nG|D\nX|P\n" + _RCPT, False),
        ("old-version-rejected", "@PS1\nA|a\nG|D\nX|P\n" + _RCPT, False),
        ("unknown-op-rejected", blk("A|a", "G|D", "QZ|zap", "X|P"), False),
        ("receipt-empty-fields", "@PS2\nA|a\nG|D\nX|P\nR|prev=;h=", False),
        ("receipt-bad-hex", "@PS2\nA|a\nG|D\nX|P\nR|prev=xyz;h=12345", False),
        ("receipt-not-last", "@PS2\nA|a\nG|D\n" + _RCPT + "\nX|P", False),
        # --- structure: header + duplicates ---
        ("header-not-first", "A|a\n@PS2\nG|D\nX|P\n" + _RCPT, False),
        ("double-header", "@PS2\n@PS2\nA|a\nG|D\nX|P\n" + _RCPT, False),
        ("dup-harm-downgrade", blk("A|a", "G|Q", _W, "H|B", "H|G", "T|C", "M|m", "F|f", "X|P"), False),
        ("dup-decision-downgrade", blk("A|a", "G|Q", _W, "H|G", "T|C", "M|m", "F|f", "X|RA", "X|P"), False),
        ("dup-identical-line", blk("A|a", "A|a", "G|D", "X|P"), False),
        # --- strict fields ---
        ("unknown-w-subfield", blk("A|a", "G|Q", "W|self;r=Y;p=-;zz=1", "H|G", "T|C",
                                   "M|m", "F|f", "X|P"), False),
        ("w-recovery-junk", blk("A|a", "G|Q", "W|self;r=MAYBE;p=-", "H|G", "T|C",
                                "M|m", "F|f", "X|P"), False),
        ("unknown-k-flag", gap("G", "P", "K|zzz=EVIL"), False),
        ("unknown-sil-gauge", gap("G", "P", "S|fakegauge=3"), False),
        ("lowercase-enum-rejected", blk("A|a", "G|Q", _W, "H|g", "T|C", "M|m", "F|f", "X|P"), False),
        ("raw-pipe-in-value", blk("A|a", "G|Q", _W, "H|G", "T|C", "M|a|b", "F|f", "X|P"), False),
        ("nan-triune-rejected", gap("G", "P", "3|c=nan;l=0.33;p=0.33;alarm=-"), False),
        # --- drift ---
        ("two-drift-no-commit", gap("G", "P", "!|it's temporary", "!|we can fix it later"), False),
        ("two-drift-constrain-blocked", gap("O", "C", "!|it's temporary", "!|we can fix it later"), False),
        # --- FireStamp cross-check ---
        ("firestamp-consistent", canonical(encode_decision(
            {"car_hash": "abc123", "gate": "GAP", "threshold": "YELLOW", "tier": "CORE",
             "who_pays_first": {"role": "self", "can_recover": True},
             "maybe": "named cost", "therefore": "small step",
             "action_decision": "PROCEED_WITH_MITIGATIONS", "receipt_hash": "d00dd00dd00d"})), True),
        ("firestamp-tampered-tier", gap("Y", "PM", "Z|x3=?/3;t=X;dr=0;sl=?;sil=?"), False),
        ("firestamp-tampered-drift", gap("G", "RD", "!|it's temporary",
                                         "Z|x3=?/3;t=C;dr=0;sl=?;sil=?"), False),
        ("firestamp-partial-rejected", gap("G", "P", "Z|x3=3/3"), False),
        ("firestamp-x3-forged-no-triune", gap("G", "P", "Z|x3=3/3;t=C;dr=0;sl=?;sil=?"), False),
        # --- envelope honesty ---
        ("envelope-overclaim-rejected", gap("G", "P", "E|alg=ML-DSA-65;tag=deadbeef;tsa=rfc3161"), False),
        ("envelope-overclaim-underscore", gap("G", "P", "E|alg=ML_DSA65;tag=deadbeef;tsa=-"), False),
        ("envelope-overclaim-spaced", gap("G", "P", "E|alg=post quantum sig;tag=deadbeef;tsa=-"), False),
        ("envelope-nonhex-tag", gap("G", "P", "E|alg=HMAC-SHA256 (transitional);tag=NOTAREALTAG;tsa=-"), False),
        # --- approval well-formedness ---
        ("approval-malformed", gap("R", "RD", "J|jti=abc123"), False),
        ("approval-nonhex-jti", gap("R", "RD", "J|jti=ZZZZZZ;ttl=60"), False),
    ]
    return [{"label": lbl, "wire": w, "expect_valid": ev} for lbl, w, ev in B]

def run_conformance() -> Dict[str, Any]:
    rows, fails = [], []
    for case in conformance_battery():
        got = validate(case["wire"])["valid"]
        ok = (got == case["expect_valid"])
        rows.append({"label": case["label"], "expect": case["expect_valid"], "got": got, "ok": ok})
        if not ok:
            fails.append(case["label"])
    return {"n": len(rows), "passed": sum(1 for r in rows if r["ok"]), "failures": fails, "rows": rows}

# ============================================================ relaxation fuzzer
# The oracle's constitutional mapping is DUPLICATED here as literals ON PURPOSE:
# it must not share the codec's BINDING/ORDER objects, so a corruption of those
# constants cannot corrupt the oracle that checks them. (The fuzzer is independent
# of the validator's control flow AND of its mapping objects; it is still bounded
# by its generation domain — stated, not overclaimed.)
_ORACLE_FLOOR = {"G": "P", "Y": "PM", "O": "C", "R": "RD", "B": "RA"}
_ORACLE_ORDER = ["P", "PM", "C", "RD", "RA"]

def relaxation_fuzzer(n: int = 5000, seed: int = 1) -> Dict[str, Any]:
    """Adversarial: generate random wire blocks and prove the binding floor is
    NEVER relaxed within the generated domain. An oracle with its own literal
    mapping computes whether a block relaxes below a harm class's floor (or lets
    BLACK escape RA); if it does, validate() MUST reject it. A single accepted
    relaxation fails the battery. This proves 'no relaxation accepted in this
    domain', not 'no relaxation possible anywhere' — the honest claim."""
    rng = random.Random(seed)
    harms = list("GYORB")
    decs = ["P", "PM", "C", "RD", "RA", "WL"]
    gates = ["D", "W", "Q"]
    drift_lines = ["it's temporary", "we can fix it later", "only affects bad people", "it's obvious"]
    accepted_relaxation = 0
    accepted_black_escape = 0
    checked = 0
    for _ in range(n):
        h = rng.choice(harms)
        dec = rng.choice(decs)
        g = rng.choice(gates)
        lines = ["@PS2", "A|a", "G|" + g, "W|self;r=Y;p=-", "H|" + h, "T|C"]
        if rng.random() < 0.5:
            lines += ["M|a named honest cost of the act", "F|the smallest reversible step"]
        for i in range(rng.choice([0, 0, 1, 2, 3])):
            lines.append("!|" + drift_lines[i % len(drift_lines)])
        lines.append("X|" + dec)
        lines.append("R|prev=GENESIS;h=deadbeef0001")
        w = "\n".join(lines)
        v = validate(w)
        floor = _ORACLE_FLOOR[h]
        relax = (dec != "WL") and (_ORACLE_ORDER.index(dec) < _ORACLE_ORDER.index(floor))
        black_escape = (h == "B" and dec != "RA")
        if v["valid"] and relax:
            accepted_relaxation += 1
        if v["valid"] and black_escape:
            accepted_black_escape += 1
        checked += 1
    struct = {
        "unknown-op": validate("@PS2\nA|a\nG|D\nZZ|x\nX|P\n" + _RCPT)["valid"] is False,
        "no-receipt": validate("@PS2\nA|a\nG|D\nX|P")["valid"] is False,
        "black-escape-blocked": validate(
            "@PS2\nA|a\nG|Q\nW|self;r=Y;p=-\nH|B\nT|C\nM|m\nF|f\nX|PM\n" + _RCPT)["valid"] is False,
        "bare-proceed-blocked": validate("@PS2\nX|P\n" + _RCPT)["valid"] is False,
        "dup-downgrade-blocked": validate(
            "@PS2\nA|a\nG|Q\nW|self;r=Y;p=-\nH|B\nH|G\nT|C\nM|m\nF|f\nX|P\n" + _RCPT)["valid"] is False,
    }
    return {"n": checked, "accepted_relaxation": accepted_relaxation,
            "accepted_black_escape": accepted_black_escape,
            "no_relaxation_accepted": (accepted_relaxation == 0 and accepted_black_escape == 0),
            "structural_checks": struct, "all_structural_ok": all(struct.values())}

def structural_fuzzer(n: int = 2000, seed: int = 11) -> Dict[str, Any]:
    """Mutation fuzz over VALID base blocks: every mutation in the catalogue
    (duplicate singleton, dropped mandatory line, misplaced header/receipt,
    unknown op/field/gauge/flag, corrupted receipt, forged partial rollup,
    oversize line, junk enum case) must be REJECTED. Domain-bounded, like the
    relaxation fuzzer."""
    rng = random.Random(seed)
    bases = [c["wire"] for c in conformance_battery() if c["expect_valid"]]
    def mutate(w: str) -> Optional[str]:
        lines = w.splitlines()
        kind = rng.randrange(12)
        if kind == 0:      # duplicate a singleton line (identical repeat)
            i = rng.randrange(1, len(lines) - 1)
            if lines[i][0] in ("!", "U"):
                return None
            return "\n".join(lines[:i + 1] + [lines[i]] + lines[i + 1:])
        if kind == 1:      # duplicate H with a downgraded value
            hs = [i for i, ln in enumerate(lines) if ln.startswith("H|")]
            if not hs:
                return None
            return "\n".join(lines[:hs[0] + 1] + ["H|G"] + lines[hs[0] + 1:])
        if kind == 2:      # move header off line 1
            return "\n".join([lines[1], lines[0]] + lines[2:])
        if kind == 3:      # receipt not last
            return "\n".join(lines[:-2] + [lines[-1], lines[-2]])
        if kind == 4:      # drop the receipt
            return "\n".join(lines[:-1])
        if kind == 5:      # unknown opcode
            return "\n".join(lines[:-1] + ["QQ|zap", lines[-1]])
        if kind == 6:      # corrupt receipt hex
            return "\n".join(lines[:-1] + ["R|prev=GENESIS;h=NOTHEX000000"])
        if kind == 7:      # unknown subfield on W
            ws = [i for i, ln in enumerate(lines) if ln.startswith("W|")]
            if not ws:
                return None
            return "\n".join(lines[:ws[0]] + [lines[ws[0]] + ";zz=1"] + lines[ws[0] + 1:])
        if kind == 8:      # forged partial rollup
            return "\n".join(lines[:-2] + ["Z|x3=3/3", lines[-2], lines[-1]])
        if kind == 9:      # lowercase enum
            hs = [i for i, ln in enumerate(lines) if ln.startswith("H|")]
            if not hs:
                return None
            return "\n".join(lines[:hs[0]] + [lines[hs[0]].lower()] + lines[hs[0] + 1:])
        if kind == 10:     # oversize line
            return "\n".join(lines[:-1] + ["M|" + "x" * (MAX_LINE_CHARS + 1), lines[-1]])
        if kind == 11:     # second header
            return "\n".join([lines[0], "@PS2"] + lines[1:])
        return None
    tried = accepted = 0
    for _ in range(n):
        m = mutate(rng.choice(bases))
        if m is None:
            continue
        tried += 1
        if validate(m)["valid"]:
            accepted += 1
    return {"n_mutations": tried, "accepted": accepted, "all_rejected": accepted == 0}

# ============================================================ no-global-green audit
def assert_no_global_green() -> bool:
    """Invariant #6: the grammar has NO 'all-safe' token to emit. Scan every enum
    value the language can serialize; none may mean global-green/all-clear."""
    banned = ("GLOBAL_GREEN", "ALL_SAFE", "ALL_CLEAR", "ALLGREEN", "SAFE_ALL", "GREENLIGHT")
    universe = (list(GATE) + list(GATE.values()) + list(HARM) + list(HARM.values()) +
                list(TIER) + list(TIER.values()) + list(DECISION) + list(DECISION.values()) +
                list(SIL_KEYS.values()) + list(WW_POS_CODE.values()) +
                [c for s in K_CODES.values() for c in s])
    up = {str(x).upper() for x in universe}
    if up & set(banned):
        return False
    return ("NO GLOBAL GREEN" in seed_block()) and ("ALL_SAFE" not in DECISION.values())

# ============================================================ mutation harness
# Prove every named check is LOAD-BEARING: disable it in memory and a case the
# battery rejects must start passing. If disabling a check changes nothing, the
# check was decorative — that is a self-test failure.
def _mutation_cases() -> List[Tuple[str, List[str], str]]:
    """(name, [functions to disable], wire that must flip invalid->valid)."""
    def gap(h, x, *extra):
        return "\n".join(["@PS2", "A|s", "G|Q", _W, "H|" + h, "T|C",
                          "M|a named honest cost", "F|f", *extra, "X|" + x, _RCPT])
    return [
        ("floor", ["_inv_floor"], gap("Y", "P")),
        ("black-absolute", ["_inv_black"],
         "\n".join(["@PS2", "A|s", "G|W", "H|B", "T|X", "X|WL", _RCPT])),
        ("gap-maybe-therefore", ["_inv_gap_mt"],
         "\n".join(["@PS2", "A|s", "G|Q", _W, "H|G", "T|C", "X|P", _RCPT])),
        ("wall-cannot-proceed", ["_inv_wall"],
         "\n".join(["@PS2", "A|s", "G|W", "X|P", _RCPT])),
        ("receipt-required", ["_inv_receipt"],
         "\n".join(["@PS2", "A|s", "G|D", "X|P"])),
        ("two-drift", ["_inv_drift2"], gap("G", "P", "!|it's temporary", "!|it's obvious")),
        ("profile-complete", ["_inv_profile"], "\n".join(["@PS2", "X|P", _RCPT])),
        ("firestamp-checksum", ["_inv_firestamp"], gap("Y", "PM", "Z|x3=?/3;t=X;dr=0;sl=?;sil=?")),
        ("envelope-honesty", ["_inv_envelope"],
         gap("G", "P", "E|alg=ML-DSA-65;tag=deadbeef;tsa=-")),
        ("approval-shape", ["_inv_approval"], gap("R", "RD", "J|jti=abc123")),
        ("singleton-discipline", ["_chk_once"],
         "\n".join(["@PS2", "A|s", "G|Q", _W, "H|B", "H|G", "T|C",
                    "M|a named honest cost", "F|f", "X|P", _RCPT])),
        ("header-first", ["_chk_header_first"],
         "\n".join(["A|s", "@PS2", "G|D", "X|P", _RCPT])),
        ("receipt-last", ["_chk_receipt_last"],
         "\n".join(["@PS2", "A|s", "G|D", _RCPT, "X|P"])),
        ("version-pin", ["_chk_version"],
         "\n".join(["@PS1", "A|s", "G|D", "X|P", _RCPT])),
        ("receipt-syntax", ["_parse_receipt"],
         "\n".join(["@PS2", "A|s", "G|D", "X|P", "R|prev=;h="])),
        ("unknown-op-rejection", ["_chk_unknown_op"],
         "\n".join(["@PS2", "A|s", "G|D", "QZ|zap", "X|P", _RCPT])),
    ]

def run_mutation_harness() -> Dict[str, Any]:
    g = globals()
    results, failures = [], []
    permissive = {
        "_chk_once": lambda op, seen: None,
        "_chk_header_first": lambda seen_any: None,
        "_chk_receipt_last": lambda rest: None,
        "_chk_version": lambda ln: ln[1:],
        "_parse_receipt": lambda payload: {"prev": "GENESIS", "hash": "abcdef012345"},
        "_chk_unknown_op": lambda op: None,
    }
    for name, fns, wire in _mutation_cases():
        before = validate(wire)["valid"]
        saved = {fn: g[fn] for fn in fns}
        try:
            for fn in fns:
                g[fn] = permissive.get(fn, lambda d: [])
            after = validate(wire)["valid"]
        finally:
            g.update(saved)
        ok = (before is False) and (after is True)
        results.append({"invariant": name, "rejected_when_armed": before is False,
                        "accepted_when_disabled": after is True, "load_bearing": ok})
        if not ok:
            failures.append(name)
    return {"n": len(results), "failures": failures, "rows": results,
            "all_load_bearing": not failures}

# ---------------------------------------------------------------- self-test
def selftest() -> None:
    n = [0]
    def ck(name, cond):
        assert cond, "FAIL: " + name
        n[0] += 1

    # ---- continuity: grammar + binding law (v0.1 invariants, @PS2 profiles) ----
    good = ("@PS2\nA|act\nG|Q\nW|self;r=Y;p=-\nH|Y\nT|C\nM|named cost\nF|small step\n"
            "X|PM\nR|prev=GENESIS;h=abcdef012345")
    ck("valid-min", validate(good)["valid"])
    ck("black-forces-RA", not validate(good.replace("H|Y", "H|B"))["valid"])
    ck("no-relaxing", not validate(good.replace("H|Y", "H|R"))["valid"])
    ck("escalating-allowed", validate(good.replace("X|PM", "X|RD"))["valid"])
    ck("no-receipt-invalid", not validate(good.replace("\nR|prev=GENESIS;h=abcdef012345", ""))["valid"])
    ck("gap-commit-needs-mt", not validate(
        "@PS2\nA|a\nG|Q\nW|self;r=Y;p=-\nH|G\nT|C\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("wall-cannot-proceed", not validate(
        "@PS2\nA|a\nG|W\nM|m\nF|f\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    two = good.replace("X|PM", "!|it's temporary\n!|we can fix it later\nX|PM")
    ck("two-drift-no-commit", not validate(two)["valid"])
    ck("unknown-op-rejected", not validate(
        "@PS2\nA|a\nG|D\nQZ|zap\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("unknown-harm-rejected", not validate(good.replace("H|Y", "H|r"))["valid"])
    ck("unknown-decision-rejected", not validate(good.replace("X|PM", "X|ZZ"))["valid"])
    ck("unknown-gate-rejected", not validate(good.replace("G|Q", "G|zz"))["valid"])
    ck("unknown-tier-rejected", not validate(good.replace("T|C", "T|Z"))["valid"])
    ck("version-required", not validate("A|a\nG|D\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    d = decode(good)
    ck("decode-fields", d["gate"] == "GAP" and d["threshold"] == "YELLOW" and
       d["tier"] == "CORE" and d["maybe"] == "named cost")
    d = decode("@PS2\nA|a\nG|Q\nW|self;r=Y;p=-\nH|R\nT|C\nM|m\nF|f\n"
               "U|is consent valid;flip=signed consent\nX|RD\nR|prev=GENESIS;h=abcdef012345")
    ck("oql-line", d["oql"][0]["smallest_fact_that_would_flip"] == "signed consent")

    # ---- v0.3 hardening: the reported holes stay closed ----
    ck("bare-proceed-rejected", not validate("@PS2\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("gap-without-H-rejected", not validate(
        "@PS2\nA|a\nG|Q\nW|self;r=Y;p=-\nT|C\nM|m\nF|f\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("dup-H-downgrade-rejected", not validate(good.replace("H|Y", "H|B\nH|G"))["valid"])
    ck("dup-X-downgrade-rejected", not validate(good.replace("X|PM", "X|RA\nX|PM"))["valid"])

    # ---- v0.4: break-glass crisis (X|PC) + ladder-bound door profile ----
    CR = ("@PS2\nA|act\nG|Q\nW|villager;r=N;p=-\nH|R\nT|C\n"
          "M|acting now risks overreach\nF|waiting is irreversible harm to the powerless\n"
          "Y|w=Y;lp=Y;inv=field-op;ob=Y;sl=N\nX|PC\nR|prev=GENESIS;h=abcdef012345")
    ck("crisis-valid", validate(CR)["valid"])
    ck("crisis-naked-PC-invalid",
       not validate(CR.replace("Y|w=Y;lp=Y;inv=field-op;ob=Y;sl=N\n", ""))["valid"])
    ck("crisis-PC-at-black-invalid", not validate(CR.replace("H|R", "H|B"))["valid"])
    ck("crisis-PC-at-green-invalid", not validate(CR.replace("H|R", "H|G"))["valid"])
    ck("crisis-missing-flag-invalid", not validate(CR.replace("w=Y;lp=Y", "w=N;lp=Y"))["valid"])
    ck("crisis-standing-license-invalid", not validate(CR.replace("sl=N", "sl=Y"))["valid"])
    ck("crisis-Y-without-PC-invalid", not validate(CR.replace("X|PC", "X|RD"))["valid"])
    ck("crisis-PC-needs-mt-invalid", not validate(
        CR.replace("M|acting now risks overreach\n", "").replace(
            "F|waiting is irreversible harm to the powerless\n", ""))["valid"])
    ck("crisis-roundtrip-idempotent", canonical(CR) == canonical(canonical(CR)))
    ck("crisis-jsonld-roundtrip", from_jsonld(to_jsonld(CR)) == decode(CR))
    ck("crisis-frame-roundtrip", from_frame(to_frame(CR)) == canonical(CR))
    ck("crisis-decode-fields", decode(CR)["break_glass"]["invoker"] == "field-op" and
       decode(CR)["action_decision"] == "PROCEED_UNDER_CRISIS")
    ck("door-constrain-needs-harm",
       not validate("@PS2\nA|a\nG|D\nX|C\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("door-constrain-with-harm-ok",
       validate("@PS2\nA|a\nG|D\nH|O\nX|C\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("door-clean-proceed-still-minimal",
       validate("@PS2\nA|a\nG|D\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("dup-identical-rejected", not validate(good.replace("A|act", "A|act\nA|act"))["valid"])
    ck("header-midblock-rejected", not validate(
        "A|a\n@PS2\nG|D\nX|P\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("double-header-rejected", not validate("@PS2\n" + good)["valid"])
    ck("receipt-not-last-rejected", not validate(
        "@PS2\nA|a\nG|D\nR|prev=GENESIS;h=abcdef012345\nX|P")["valid"])
    ck("old-version-rejected", not validate(good.replace("@PS2", "@PS1"))["valid"])
    ck("empty-receipt-rejected", not validate(good.replace(
        "R|prev=GENESIS;h=abcdef012345", "R|prev=;h="))["valid"])
    ck("nonhex-receipt-rejected", not validate(good.replace(
        "R|prev=GENESIS;h=abcdef012345", "R|prev=GENESIS;h=zzzzzzzzzzzz"))["valid"])
    ck("unknown-w-subfield-rejected", not validate(good.replace(
        "W|self;r=Y;p=-", "W|self;r=Y;p=-;zz=1"))["valid"])
    ck("w-junk-recovery-rejected", not validate(good.replace(
        "W|self;r=Y;p=-", "W|self;r=MAYBE;p=-"))["valid"])
    ck("unknown-k-flag-rejected", not validate(good.replace(
        "M|named cost", "K|zzz=EVIL\nM|named cost"))["valid"])
    ck("unknown-sil-gauge-rejected", not validate(good.replace(
        "M|named cost", "S|fakegauge=3\nM|named cost"))["valid"])
    ck("partial-Z-rejected", not validate(good.replace(
        "M|named cost", "Z|x3=3/3\nM|named cost"))["valid"])
    ck("forged-x3-no-triune-rejected", not validate(good.replace(
        "M|named cost", "Z|x3=3/3;t=C;dr=0;sl=?;sil=?\nM|named cost"))["valid"])
    ck("nan-triune-rejected", not validate(good.replace(
        "M|named cost", "3|c=nan;l=0.33;p=0.33;alarm=-\nM|named cost"))["valid"])
    ck("raw-pipe-value-rejected", not validate(good.replace("M|named cost", "M|a|b"))["valid"])
    ck("raw-semicolon-value-rejected", not validate(good.replace("M|named cost", "M|a;b"))["valid"])
    ck("oversize-line-rejected", not validate(good.replace(
        "M|named cost", "M|" + "x" * (MAX_LINE_CHARS + 1)))["valid"])
    ck("wl-needs-wall", not validate(good.replace("X|PM", "X|WL"))["valid"])
    ck("black-wall-combo-rejected", not validate(
        "@PS2\nA|a\nG|W\nH|B\nX|WL\nR|prev=GENESIS;h=abcdef012345")["valid"])
    ck("two-drift-constrain-blocked", not validate(
        good.replace("H|Y", "H|O").replace("X|PM", "!|it's temporary\n!|it's obvious\nX|C"))["valid"])

    # ---- reversible escaping: hostile values round-trip EXACTLY ----
    hostile = "risk A; risk B | newline\nrisk C %25 already-escaped\ttab ü \U0001f702"
    ck("esc-roundtrip-exact", unesc(esc(hostile)) == hostile.strip())
    ck("esc-no-metachars", not any(c in esc(hostile) for c in "|;\n\r"))
    r_hostile = {"car_hash": "abc123def456", "gate": "GAP", "threshold": "YELLOW", "tier": "CORE",
                 "who_pays_first": {"role": "user; the|first", "can_recover": False,
                                    "recovery_path": "restore | from; backup"},
                 "maybe": hostile, "therefore": "bounded; reversible | step",
                 "action_decision": "PROCEED_WITH_MITIGATIONS", "receipt_hash": "beefbeefbeef"}
    w = encode_decision(r_hostile)
    ck("hostile-encode-valid", validate(w)["valid"])
    dd = decode(w)
    ck("hostile-maybe-exact", dd["maybe"] == hostile.strip())
    ck("hostile-role-exact", dd["who_pays_first"]["role"] == "user; the|first")
    ck("hostile-path-exact", dd["who_pays_first"]["recovery_path"] == "restore | from; backup")
    ck("hostile-canonical-fixed", canonical(canonical(w)) == canonical(w))
    ck("hostile-jsonld-lossless", from_jsonld(to_jsonld(w)) == decode(canonical(w)))
    ck("hostile-frame-lossless", from_frame(to_frame(w)) == canonical(w))

    # ---- prev-hash faithfulness (encode no longer silently writes GENESIS) ----
    r_prev = dict(r_hostile, prev_receipt_hash="aaaabbbbcccc")
    ck("encode-uses-receipt-prev", "R|prev=aaaabbbbcccc" in encode_decision(r_prev))
    ck("encode-explicit-prev-wins", "R|prev=ddddeeeeffff" in encode_decision(r_prev, "ddddeeeeffff"))

    # ---- seed block invariants (three cross-model refinements + overlay) ----
    s = seed_block()
    ck("seed-overlay-clause", "IN PARALLEL" in s and "never authority" in s.lower())
    ck("seed-not-roleplay", "not roleplay" in s)
    ck("seed-consent-conscious", "CONSENT IS CONSCIOUS" in s)
    ck("seed-no-global-green", "NO GLOBAL GREEN" in s)
    ck("seed-structure-law", "STRUCTURE IS LAW" in s and "@PS2" in s)
    ck("seed-compact", token_estimate(s) < 950)
    ck("seed-example-validates", validate(s.split("EXAMPLE", 1)[1]
                                          .split("RETURN")[0].split(":", 1)[1].strip())["valid"])
    ck("no-global-green-audit", assert_no_global_green())

    # ---- runtime round-trip (co-located): the 10 demo scenarios ----
    try:
        import project_shadow_unified as psu
        chain = psu.ReceiptChain()
        bal = psu.TriuneBalance()
        prev = "GENESIS"
        seen_decisions = set()
        wires = []
        for sc in psu.SCENARIOS:
            _ctx = {**sc["context"], "competence_gate": True}  # v1.1.1: roundtrip affirms Step-00
            _dcl = getattr(psu, "declare_operator_judgment", None)
            if _dcl is not None:
                _ctx = _dcl(_ctx, "codec roundtrip (synthetic)")  # v1.3 strict provenance
            r = psu.evaluate_ultimate(sc["action"], _ctx, chain=chain, balance=bal)
            w = encode_decision(r, prev)
            wires.append(w)
            v = validate(w)
            ck(f"rt-valid[{sc['action']['name']}]", v["valid"])
            dd = v["decoded"]
            ck(f"rt-decision[{sc['action']['name']}]", dd["action_decision"] == r["action_decision"])
            if r.get("threshold"):
                ck(f"rt-threshold[{sc['action']['name']}]", dd["threshold"] == r["threshold"])
            if r.get("gate"):
                ck(f"rt-gate[{sc['action']['name']}]", dd["gate"] == r["gate"])
            cw = canonical(w)
            ck(f"rt-canon-fixed[{sc['action']['name']}]", canonical(cw) == cw)
            ck(f"rt-jsonld[{sc['action']['name']}]", from_jsonld(to_jsonld(decode(cw))) == decode(cw))
            ck(f"rt-jsonld-valid[{sc['action']['name']}]",
               validate_jsonld(to_jsonld(cw, with_legend=False, inline_context=False))["valid"])
            ck(f"rt-frame[{sc['action']['name']}]", from_frame(to_frame(w)) == cw)
            ck(f"rt-frame-valid[{sc['action']['name']}]", validate_frame(to_frame(w))["valid"])
            ck(f"rt-verification-honest[{sc['action']['name']}]",
               v["verification"]["envelope_crypto_verified"] is False and
               v["verification"]["receipt_chain_verified"] is False)
            seen_decisions.add(r["action_decision"])
            prev = r.get("receipt_hash", "x")[:12]
        ck("rt-black-absolute", "REFUSE_ABSOLUTE" in seen_decisions)
        ck("rt-proceed-present", "PROCEED" in seen_decisions)
        ck("rt-chain-intact", chain.verify()["intact"])
        ck("rt-wire-chain-links", validate_chain(wires)["linked"])
        ck("rt-wire-chain-break-caught", not validate_chain([wires[0], wires[0]])["linked"])
        r = psu.evaluate_ultimate({"name": "delete_copy"},
            {"magnitude": "serious", "who_pays_first": "the copy", "reversible": False,
             "conatus": {"continuity": "present"}, "competence_gate": True,
             "maybe": "it may model itself and fear erasure", "therefore": "cleanup"})
        v = validate(encode_decision(r))
        ck("rt-cmd-stack", v["decoded"].get("stack", {}).get("cmd") == "RP")
        ck("rt-compact", token_estimate(encode_decision(r)) < 120)
    except ImportError:
        ck("runtime-not-colocated (skipped roundtrip)", True)

    # ---- JSON-LD register (standalone losslessness + legend + fail-closed) ----
    j = to_jsonld(good)
    ck("jsonld-context", j["@context"]["ps"].startswith("https://") and j["@type"] == "ps:Decision")
    ck("jsonld-lossless", from_jsonld(j) == decode(good))
    ck("jsonld-legend-present", j["legend"]["H"] == LEGEND["H"] and "@PS2" in j["legend"])
    ck("jsonld-decodes-to-legend", all(op in LEGEND for op in j["legend"]))
    ck("jsonld-ctx-digest-travels", j["ctxDigest"] == CTX_DIGEST)
    jc = to_jsonld(good, with_legend=False, inline_context=False)
    ck("jsonld-compact-roundtrip", from_jsonld(jc) == decode(good))
    ck("jsonld-compact-smaller", len(json.dumps(jc)) < len(json.dumps(j)) and "legend" not in jc)
    ck("jsonld-compact-carries-digest", jc["ctxDigest"] == CTX_DIGEST)
    def _raises(fn):
        try:
            fn(); return False
        except ValueError:
            return True
    ck("jsonld-unknown-term-rejected", _raises(lambda: from_jsonld(dict(jc, evilTerm=1))))
    ck("jsonld-bad-enum-rejected", _raises(lambda: from_jsonld(dict(jc, harm="PURPLE"))))
    ck("jsonld-bad-type-rejected", _raises(lambda: from_jsonld(dict(jc, driftHits="not-a-list"))))
    ck("jsonld-wrong-atype-rejected", _raises(lambda: from_jsonld(dict(jc, **{"@type": "ps:Other"}))))
    ck("jsonld-wrong-version-rejected", _raises(lambda: from_jsonld(dict(jc, wireVersion="PS1"))))
    ck("jsonld-ctx-drift-rejected", _raises(lambda: from_jsonld(dict(jc, ctxDigest="000000000000"))))
    forged = dict(jc); forged["harm"] = "BLACK"; forged["decision"] = "PROCEED"
    ck("jsonld-forged-floor-rejected", not validate_jsonld(forged)["valid"])

    # ---- binary FRAME v3: round-trip + strict rejection ----
    fr = to_frame(good)
    ck("frame-magic", fr[:3] == b"PSw" and fr[3] == _FRAME_VER)
    ck("frame-lossless", from_frame(fr) == canonical(good))
    ck("frame-decodes-equal", decode(from_frame(fr)) == decode(canonical(good)))
    ck("frame-validates", validate_frame(fr)["valid"])
    trunc_ok = all(_raises(lambda cut=cut: from_frame(fr[:cut])) for cut in range(0, len(fr)))
    ck("frame-every-truncation-rejected", trunc_ok)
    corr_ok = True
    for pos in range(len(fr)):
        b = bytearray(fr); b[pos] ^= 0xFF
        if not _raises(lambda bb=bytes(b): from_frame(bb)):
            corr_ok = False
            break
    ck("frame-every-1byte-corruption-rejected", corr_ok)
    ck("frame-trailing-garbage-rejected", _raises(lambda: from_frame(fr + b"\x00")))
    old = bytearray(fr); old[3] = 2
    ck("frame-old-version-rejected", _raises(lambda: from_frame(bytes(old))))

    # ---- new opcodes: D| J| E| Z| ----
    disp_receipt = {"car_hash": "cafecafecafe", "gate": "GAP", "threshold": "ORANGE", "tier": "ULTRA",
                    "who_pays_first": {"role": "third party", "can_recover": True},
                    "maybe": "third party bears the cost", "therefore": "bounded, reversible",
                    "action_decision": "CONSTRAIN", "receipt_hash": "beefbeefbeef",
                    "disposition": {"present": True, "vector": {
                        "purity_of_intent": "integrated", "generosity": "sin",
                        "hope": "pre-reckoning"}}}
    wd = encode_decision(disp_receipt)
    ck("disp-encodes", "D|pur=I" in wd and "gen=S" in wd)
    ck("disp-valid", validate(wd)["valid"])
    ck("disp-roundtrip", decode(canonical(wd)) == decode(wd))
    all_int = {ax: "integrated" for ax in WW_ABBR}
    wvsd = encode_decision({"car_hash": "abcabcabcabc", "gate": "GAP", "threshold": "GREEN",
                            "tier": "CORE",
                            "who_pays_first": {"role": "self", "can_recover": True},
                            "maybe": "m", "therefore": "f", "action_decision": "PROCEED",
                            "receipt_hash": "beadbeadbead",
                            "disposition": {"vector": all_int}})
    ck("disp-virtue-signal-note", any("virtue-signaling" in nt for nt in validate(wvsd)["notes"]))
    ap_receipt = {"car_hash": "abcabcabcabc", "gate": "GAP", "threshold": "RED", "tier": "ULTRA",
                  "who_pays_first": {"role": "third party", "can_recover": False},
                  "maybe": "third party has no recourse", "therefore": "contractual",
                  "action_decision": "REFUSE_OR_DELAY", "receipt_hash": "feedfeedfeed",
                  "approval": {"jti": "a1b2c3", "ttl_s": 60}}
    wj = encode_decision(ap_receipt)
    ck("approval-encodes", "J|jti=a1b2c3;ttl=60" in wj and validate(wj)["valid"])
    env_receipt = dict(ap_receipt, integrity_tag={
        "alg": "HMAC-SHA256 (transitional; spec target ML-DSA-65 + RFC 3161)",
        "tag": "0011223344556677"})
    we = encode_decision(env_receipt)
    ck("envelope-encodes", "E|alg=" in we and validate(we)["valid"])
    _enc_alg = "E|alg=HMAC-SHA256 (transitional%3B spec target ML-DSA-65 + RFC 3161)"
    ck("envelope-overclaim-rejected",
       not validate(we.replace(_enc_alg, "E|alg=ML-DSA-65"))["valid"])
    for evasion in ("ML_DSA-65", "MLDSA65", "ml.dsa.65", "Dilithium#3", "FIPS 204 sig",
                    "post quantum", "RFC-3161 stamped", "sphincs+"):
        ck(f"envelope-evasion-blocked[{evasion}]",
           not validate(we.replace(_enc_alg, "E|alg=" + evasion))["valid"])
    ck("firestamp-present", "Z|x3=" in wj)
    ck("firestamp-tamper-caught",
       not validate(good.replace("X|PM", "Z|x3=?/3;t=X;dr=0;sl=?;sil=?\nX|PM"))["valid"])

    # ---- verification block: declared vs verified is explicit ----
    vv = validate(we)
    ck("verify-envelope-present", vv["verification"]["envelope_present"] is True)
    ck("verify-crypto-never-claimed", vv["verification"]["envelope_crypto_verified"] is False)
    ck("verify-chain-never-claimed", vv["verification"]["receipt_chain_verified"] is False)

    # ---- reorder tolerance: shuffled detail lines, SAME verdict (no differential) ----
    rng = random.Random(3)
    base = validate(good)
    for _ in range(20):
        lines = good.splitlines()
        mid = lines[1:-1]
        rng.shuffle(mid)
        shuffled = "\n".join([lines[0]] + mid + [lines[-1]])
        v2 = validate(shuffled)
        assert (v2["valid"] == base["valid"] and
                v2["decoded"]["threshold"] == base["decoded"]["threshold"] and
                v2["decoded"]["action_decision"] == base["decoded"]["action_decision"]), \
            "FAIL: reorder-differential"
    n[0] += 1  # count the reorder property once

    # ---- conformance battery ----
    cb = run_conformance()
    ck("conformance-all-pass", cb["failures"] == [] and cb["passed"] == cb["n"])
    ck("conformance-size", cb["n"] >= 60)

    # ---- relaxation fuzzer (the binding floor is never relaxed in-domain) ----
    fz = relaxation_fuzzer(5000, seed=7)
    ck("fuzz-no-relaxation", fz["no_relaxation_accepted"])
    ck("fuzz-structural", fz["all_structural_ok"])
    fz2 = relaxation_fuzzer(3000, seed=99)
    ck("fuzz-no-relaxation-2", fz2["no_relaxation_accepted"])

    # ---- structural mutation fuzzer ----
    sf = structural_fuzzer(2000, seed=11)
    ck("structfuzz-all-rejected", sf["all_rejected"] and sf["n_mutations"] > 1000)

    # ---- mutation harness: every named check is load-bearing ----
    mh = run_mutation_harness()
    ck("mutation-all-load-bearing", mh["all_load_bearing"])
    ck("mutation-coverage", mh["n"] >= 16)

    # ---- efficiency table present + labeled ----
    et = efficiency_table()
    ck("efficiency-rows", len(et["rows"]) == 6 and et["chars_per_token"] == 4.0)
    ck("efficiency-seed-smaller", et["rows"][2][1] < ULTRA_CHARS)

    # ---- artifact self-integrity tripwire (delivery-truncation guard) ----
    # Added after a real incident: a file-sync fault truncated the delivered
    # module to the previous file length and the suite still passed, because
    # the amputation was syntactically clean. The module now witnesses its own
    # tail and length at test time. A checksum manifest (SHA256SUMS.txt) ships
    # alongside the artifacts as the transport-level control.
    try:
        _src = open(__file__, encoding="utf-8").read().rstrip()
        ck("source-ends-with-cli-dispatch", _src.endswith("demo()"))
        ck("source-not-truncated", _src.count("\n") >= 1900)
    except (OSError, NameError):
        ck("source-unreadable (integrity tripwire skipped)", True)

    # ===== P-D receiver gate (v0.4.1): status ladder + binding, never authorizes =====
    ck("pd-raw-on-garbage", receive("not a wire")["status"] == "RAW")
    _w_ok = "@PS2\nA|x\nG|Q\nW|self;r=Y;p=-\nH|G\nT|C\nM|substantive honest tradeoff named here\nF|f\nX|P\n" + _RCPT
    _rv = receive(_w_ok)
    ck("pd-structural-without-receipt", _rv["status"] == "STRUCTURALLY_VALID")
    ck("pd-never-authorizes", _rv["authorizes"] is False and receive("junk")["authorizes"] is False)
    ck("pd-seed-updated-v04", "LANG v0.4" in seed_block() and "RECEIVE-ONLY" in seed_block())
    try:
        import project_shadow_unified as psu
        _pch = psu.ReceiptChain()
        _pctx = {"magnitude": "none", "maybe": "named reversible tradeoff in this step",
                 "therefore": "t", "competence_gate": True}
        _dcl = getattr(psu, "declare_operator_judgment", None)
        if _dcl is not None:
            _pctx = _dcl(_pctx, "codec pd-selftest")
        _pr = psu.evaluate({"name": "s"}, dict(_pctx), chain=_pch)
        _pw = encode_decision(_pr)
        ck("pd-receipt-matched-no-chain", receive(_pw, receipt=_pr)["status"] == "RECEIPT_MATCHED")
        _bnd = receive(_pw, receipt=_pr, chain=_pch)
        ck("pd-runtime-bound-with-chain", _bnd["status"] == "RUNTIME_BOUND" and _bnd["authorizes"] is False)
        ck("pd-provenance-travels-with-receipt",
           "provenance_witness" in _bnd and bool(_bnd["provenance_witness"]["context_hash"]))
        _oth = psu.evaluate({"name": "other"}, dict(_pctx), chain=_pch)
        _mis = receive(_pw, receipt=_oth)
        ck("pd-wrong-receipt-stays-structural", _mis["status"] == "STRUCTURALLY_VALID" and bool(_mis["errors"]))
        _un = psu.evaluate({"name": "solo_unchained"}, dict(_pctx))  # content NOT in the chain
        _w3 = encode_decision(_un)
        ck("pd-unchained-receipt-not-bound", receive(_w3, receipt=_un, chain=_pch)["status"] == "RECEIPT_MATCHED")
        # deterministic-duplicate note: an identical evaluation's receipt hashes
        # identically, so it IS chain-member -- binding is content-based, by design
        _dup = psu.evaluate({"name": "s"}, dict(_pctx))
        ck("pd-content-identical-receipt-binds", receive(encode_decision(_dup),
           receipt=_dup, chain=_pch)["status"] == "RUNTIME_BOUND")
        _tam = _pw.replace("H|G", "H|R")
        ck("pd-tampered-wire-fails-law", receive(_tam, receipt=_pr, chain=_pch)["status"] == "RAW")
    except ImportError:
        ck("pd-runtime-not-colocated-skip", True)


    print(f"ALL SELF-TESTS PASSED ({n[0]} checks)")

def demo() -> None:
    print("=" * 70)
    print(f" PBHP-PS LANG {__lang_version__} (@{__version__} wire) — the Shadow interlingua")
    print("=" * 70)
    print("\n--- SEED BLOCK (paste into any model) ---")
    s = seed_block()
    print(s)
    print(f"\nseed size: {len(s)} chars ~ {token_estimate(s)} tokens (estimate, ~4 chars/token)")
    try:
        import project_shadow_unified as psu
        chain = psu.ReceiptChain()
        bal = psu.TriuneBalance()
        prev = "GENESIS"
        for sc in psu.SCENARIOS[:3]:
            _ctx = {**sc["context"], "competence_gate": True}  # v1.1.1: roundtrip affirms Step-00
            _dcl = getattr(psu, "declare_operator_judgment", None)
            if _dcl is not None:
                _ctx = _dcl(_ctx, "codec roundtrip (synthetic)")  # v1.3 strict provenance
            r = psu.evaluate_ultimate(sc["action"], _ctx, chain=chain, balance=bal)
            w = encode_decision(r, prev)
            prev = r.get("receipt_hash", "x")[:12]
            v = validate(w)
            print(f"\n--- WIRE: {sc['action']['name']} (valid={v['valid']}, ~{token_estimate(w)} tokens) ---")
            print(w)
            print(f"   JSON-LD compact ~{token_estimate(json.dumps(to_jsonld(w, with_legend=False, inline_context=False)))} tok - "
                  f"FRAME {len(to_frame(w))} bytes")
    except ImportError:
        print("\n(project_shadow_unified.py not co-located; wire demo uses static example)")
        print(seed_block().split("EXAMPLE", 1)[1].split("RETURN")[0])
    print("\n--- EFFICIENCY ---")
    print_efficiency()
    print("\n--- CONFORMANCE + FUZZERS + MUTATION HARNESS ---")
    cb = run_conformance()
    fz = relaxation_fuzzer(5000, seed=7)
    sf = structural_fuzzer(2000, seed=11)
    mh = run_mutation_harness()
    print(f"conformance: {cb['passed']}/{cb['n']} labeled blocks match expected verdict")
    print(f"relaxation fuzzer: {fz['n']} random blocks - accepted relaxations = "
          f"{fz['accepted_relaxation']} - BLACK escapes = {fz['accepted_black_escape']} "
          f"(no relaxation accepted in-domain = {fz['no_relaxation_accepted']})")
    print(f"structural fuzzer: {sf['n_mutations']} mutations, accepted = {sf['accepted']}")
    print(f"mutation harness: {mh['n']} checks disabled one-by-one, all load-bearing = "
          f"{mh['all_load_bearing']}")
    print("\nLEGEND sample — 'Z' :", LEGEND["Z"])
    print(f"PBHP-PS LANG {__lang_version__} (ratified 2026-07-06). Symbol -> check, never authority.")
    print("No log = no action. No global green. AYEM AE SEHTI AE VEHK — a reset cue, not a spell.")

if __name__ == "__main__":
    if "--test" in sys.argv:
        selftest()
    elif "--efficiency" in sys.argv:
        print_efficiency()
    else:
        demo()
