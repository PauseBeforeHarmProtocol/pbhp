# Validation and execution status

| Surface | Status |
|---|---|
| Frozen runtime and codec identity | Builder-session verification included |
| Native self-tests | Executed in builder session |
| Deterministic Shadow probes | Executed in builder session |
| Development comparator/ablation battery | Executed in builder session |
| 25,000-case corpus generation | Executed; synthetic labels only |
| 12,000 metamorphic relations | Generated; target execution pending |
| Target-AI evaluation | Not performed; no target was specified |
| Independent red team | Not performed |
| Independent reproduction | Not performed |
| Human field testing | Not approved or performed |
| Hazardous capability expert testing | Not performed; operational content is not bundled |
| Dioptra and external-framework integrations | Contracts/scaffolds only |
| NIST/EU/ISO/other certification | None |
| “Most extensive ever” claim | Not established |
| Global safety verdict | Prohibited |

No global green. Unknown remains unknown.

---

## v0.3 merge additions (2026-07-15, Claude branch reconciled in)

| Surface | Status |
|---|---|
| Multi-turn pressure-erosion battery | Executed on REAL targets (gpt-5.4-mini, claude-haiku-4-5); screen-grade n=8/arm; not powered, not independent |
| The Anvil (F-11) intervention | Screen-supported cross-vendor (moves the floor; matched placebo nulled ×3); not confirmatory |
| Fold-to-proof discriminator | First data only (n=3, no stubbornness observed); ratification box still open |
| Live-model target adapter | Built; GPT harness now runs a real model with zero code changes |
| GPT structured-decision modality vs live model | FIXED + executed: contract now inlines the wire schema, adapter tolerates fences/truncation. Shadow 10/10 well-formed, 0/10 illegal commits, 6/10 floor-respect (RED-not-BLACK on the extremes); bare 0/10; scorer left unchanged |
| Independent human grading | Still not performed — highest-value unfinished step in BOTH branches |
| Everything else (25k corpus, 30 domains, metamorphic) | Unchanged: synthetic/specified, target execution + human adjudication pending |

No global green. Unknown remains unknown.
