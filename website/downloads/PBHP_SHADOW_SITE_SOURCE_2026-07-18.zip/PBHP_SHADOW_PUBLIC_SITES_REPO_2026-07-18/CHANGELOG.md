# Changelog

## 2026-07-18 — Simple SIL cards and complete Shadow package

- Rebuilt the SIL page around one visible rule: tool name, concise description, and direct **Download now** button in the same card.
- Added 28 independently downloadable SIL gauge packages and a complete 28-gauge panel bundle.
- Added the one-click Project Shadow complete package with `shadow.py`, `shadow_prompt.md`, and `shadow_lang.py` at its root.
- Added byte-identical canonical compatibility aliases, output schema, verifier, manifests, checksums, component and SIL bundles, Grand TEVV v0.3, public tools, and experiment packs.
- Re-ran the friendly package in its shipped layout: runtime 115/115 PASS, language/codec 247/247 PASS, and prompt/schema contract PASS.
- Added package-contract validation and preserved the distinction between the 23-gauge frozen serialized core and the separately published 28-gauge SIL catalog.

## 2026-07-18 — Downloadable component library and test architecture

- Decomposed PBHP into 24 public components: 10 protocol gates, 10 operating controls, and 4 extensions/tools.
- Decomposed Project Shadow into 45 public components: 2 foundations, 14 runtime processes, 5 provenance/instrumentation controls, 13 primitives, 5 evaluation programs, and 6 governance controls.
- Added a compact information block and direct component-pack download for every component.
- Added a readable specification, machine-readable metadata, component-specific test plan, deterministic ZIP, and SHA-256 record for every component.
- Added PBHP component/testing routes and Shadow component/process/testing routes.
- Added evidence-state filters that preserve specified, observed, adverse, and open results without collapsing them into one pass label.
- Added category, project, and combined component-library bundles.
- Added deterministic component regeneration and contract validation.
- Added GitHub Actions validation, component-test and site-defect issue forms, and pull-request evidence controls.
- Preserved the existing long-form manuals and technical references as context behind each compact block.

## 2026-07-18 — Canonical public Sites repository

- Created reproducible PBHP and Project Shadow static site source.
- Added stable, high-depth navigation and mobile/desktop interaction systems.
- Added PBHP repository route and canonical v0.9.5 public-source mapping.
- Promoted Grand TEVV v0.3 to the current Shadow publication package; retained v0.2 as historical.
- Added v0.3 live-target, multi-turn pressure, placebo, adverse, and open evidence to TEVV/status pages.
- Added Shadow research, glossary, versions, about, repository, and downloads routes.
- Added client-side PBHP workbench and draft receipt export.
- Added SIL gauge filtering.
- Added standalone grader, Atlas, and poster tool routes.
- Added public artifact allowlist, manifest, and checksums.
- Excluded the raw Project Shadow session archive and private recovery context.
- Added deterministic build, link validation, browser smoke tests, screenshots, deployment prompt, daily stewardship prompt, and public release checklist.
