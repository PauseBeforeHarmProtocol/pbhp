# Scheduled daily maintenance

This is the operating pattern for a living public project without fake activity or uncontrolled publication.

## Recommended schedule

Create a ChatGPT Work Scheduled Task that runs each morning in the maintainer's local time. The task performs a read-only source intake, updates the repository only when evidence supports a change, runs the build and checks, and saves a candidate Site version. Public deployment remains a reviewed action.

Suggested task name: **PBHP + Shadow daily source intake**

Suggested cadence: **Daily at 06:00 America/Indiana/Indianapolis**

## Scheduled-task prompt

```text
Maintain the existing Pause Before Harm and Project Shadow public-site repository and canonical
ChatGPT Sites. Use the attached repository as the publication source. Do not create new Sites.

Begin read-only. Check for changes since the newest dated ledger entry in:

1. the PauseBeforeHarmProtocol/pbhp main branch, VERSION file, tags, releases, changelog, issues,
   tests, documentation, license, and security notices;
2. approved new Project Shadow runtime, SIL, receipt, TEVV, Behavioral Falsifier, governance,
   research, scoring, component specifications, component test plans, and artifact inputs supplied to this project;
3. the two authenticated canonical Sites, including route failures, broken downloads, mobile
   navigation defects, accessibility findings, privacy issues, and discrepancies from repository source.

Classify every observed item as content correction, evidence-state change, release/version change,
navigation/interaction change, artifact/download change, privacy/security change, or no substantive
change. Preserve the distinction between the PBHP main-branch declared version and the latest tagged
GitHub release. Never call a branch version a tagged release unless the tag exists.

If there is no substantive change, write a dated monitoring receipt to the private task log only.
Do not alter the public daily ledger, repository, or Sites.

For substantive changes:
- update the existing stable page rather than creating a duplicate route;
- retain specified, expected, observed, adverse, and open evidence labels;
- preserve model, date, sample, scorer, provenance, and limitation details;
- reject prohibited global-safety, certification, validation, and framework-approval claims;
- update the affected component source entry, specification, metadata, test plan, packs, and checksums;
- regenerate the component-library and allowlisted artifact manifests;
- regenerate the source release and both static Sites;
- run component-library determinism, content, link, JavaScript syntax, static interaction, reproducibility, visual, privacy, and
  available browser checks;
- save a candidate version of each affected existing Site without deploying;
- produce a concise source diff, validation receipt, public effect, rollback path, and open findings.

Do not publish automatically unless the maintainer has separately authorized unattended deployment
and every release gate, including authenticated desktop/mobile interaction and public privacy review,
has passed. Otherwise stop at the saved candidate and request approval.

After an approved deployment, verify the exact production version, canonical URL, route inventory,
audience, and public visitor experience. Only then add a substantive dated public ledger entry.

Architecture is binding: PBHP is the human-readable action protocol; Project Shadow is the technical
deep system; ALMSIVI remains independent; civic Sites are out of scope. No log = no action. No global
green. A clean run is weaker evidence than it feels like.
```

## Daily receipt fields

Record the source window, source identifiers, observed changes, classifications, files changed, claim changes, artifact hashes, checks run, candidate version, deployment decision, production verification, and open findings.

## Publication rule

The scheduled task runs daily. The public Site changes only when there is a substantive, reviewed change. Monitoring frequency and publication frequency are deliberately separate.
