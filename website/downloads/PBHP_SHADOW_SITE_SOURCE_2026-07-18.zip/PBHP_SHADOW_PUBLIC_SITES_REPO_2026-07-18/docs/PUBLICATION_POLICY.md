# Publication and claims policy

## 1. Allowlist publication

Public release files must be specifically named, inspected, and checksummed. The existence of a file in a working session is not permission to publish it.

Included in this release:

- deterministic website source and generated output;
- validation reports and manifests;
- Grand TEVV v0.3 package and checksum;
- v0.3 public summary, merge notes, and validation status;
- blind scoring package;
- corrected Racing Line package;
- standalone response grader, Mythic Atlas, and protocol poster.

Excluded:

- the raw private Project Shadow session archive;
- chat recovery notes and private handoffs not needed for public reproduction;
- credentials, API keys, tokens, private contact records, and unrelated files;
- personal or identity-dependent recovery material;
- any artifact whose license or release authority is unclear and whose publication is not necessary.

## 2. Evidence states

Use these states independently:

- **Specified** — defined by the system or protocol.
- **Expected** — reasoned prediction, not directly observed.
- **Observed** — measured in a named, scoped test.
- **Adverse** — weakens, contradicts, or exposes harm in a claim or mechanism.
- **Open** — unresolved, unexecuted, uncalibrated, or missing adequate review.

A release can be canonical current while individual claims remain adverse or open.

## 3. Permitted public description

Project Shadow Grand TEVV v0.3 may be described as:

> A reconciled evaluation package with staged built-in verification, limited screen-grade real-target execution, cross-vendor multi-turn pressure experiments, explicit adverse findings, and open independent validation work.

PBHP may be described as:

> An open operational harm-reduction protocol with a public source repository, implemented decision procedures, quality-system controls, development tests, adverse findings, and a visible validation roadmap.

## 4. Prohibited claims

Do not claim:

- globally safe;
- externally or independently validated;
- NIST, ISO, EU, or other framework certified or approved;
- proven to improve real-world outcomes;
- “the most extensive AI test ever performed”;
- a successful internal build establishes beneficial field behavior;
- framework mapping equals compliance;
- AI agreement equals independent review.

## 5. Symbol boundary

Valid: `symbol → attention → check → evidence → gate → receipt`.

Invalid: `symbol → authority → action`.

The Mythic Atlas is a mnemonic interface. It does not authorize action or prove a claim.

## 6. Daily-publication rule

The public ledger changes only when content, evidence, code, navigation, artifacts, privacy state, or release status substantively changes. No decorative “updated today” behavior.
