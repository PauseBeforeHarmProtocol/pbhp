# Information architecture

## PBHP visitor model

PBHP answers: **What should I do before a consequential action?**

Primary paths:

1. **Decision now** → Workbench → Receipt → Examples.
2. **New reader** → Start → Protocol → Manual.
3. **Implementer** → Implementation → Templates → Operations → CLA.
4. **Reviewer** → Evidence → Research → Versions → Repository.
5. **Component owner** → Components → Download pack → Test plan → Evidence ledger.

Visual vocabulary: calm operational safety instrument; light surfaces; green/blue signals; strong plain-language hierarchy.

## Project Shadow visitor model

Project Shadow answers: **How is the action protocol enforced, instrumented, tested, challenged, and corrected?**

Primary paths:

1. **Architecture** → System → Runtime → Gates → SIL → Receipts.
2. **Evidence** → Status → TEVV → Behavioral Falsifier → Research.
3. **Mechanisms** → Primitives → Synthesis → Reference → Glossary.
4. **Governance** → Governance → Narrative Governance → Roadmap.
5. **Source** → Repository → Versions → Downloads.
6. **Component reviewer** → Components → Processes or Primitives → Testing → TEVV / Falsifier.

Visual vocabulary: technical observatory/control room; dark surfaces; visible gauges, adverse states, and evidence boundaries.

## Navigation contract

- stable URLs are preserved;
- current page is always visible in desktop navigation;
- mobile has drawer plus quick dock;
- breadcrumbs show place;
- related pages show the next useful move;
- command palette searches all pages with `Ctrl/Cmd+K`;
- heading permalinks preserve citation and return paths;
- anything that looks interactive must work;
- ALMSIVI is not placed in a shared global menu.

## Component navigation contract

- every public component has one stable slug and one evidence state;
- each information block shows purpose, mechanism, inputs, outputs, failure modes, current test state, and a direct download;
- each download pack contains the same specification, JSON metadata, test plan, and checksum represented on the Site;
- catalog filters preserve the selected search/category/state in the URL;
- sections with no matching components disappear rather than leaving empty headings;
- long-form protocol and reference pages remain available and are linked from the blocks;
- runtime, TEVV, website, component-library, and upstream PBHP versions stay separate.
