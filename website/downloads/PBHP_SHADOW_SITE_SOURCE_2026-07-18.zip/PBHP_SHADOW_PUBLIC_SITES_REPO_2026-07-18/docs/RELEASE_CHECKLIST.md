# Public release checklist

## Project identity

- [ ] Existing `pausebeforeharm` project recovered.
- [ ] Existing `projectshadow` project recovered.
- [ ] No duplicate or long-name reservation project created.
- [ ] Existing production version and audience recorded.
- [ ] Unrelated user changes preserved.

## Content and claims

- [ ] PBHP public repo/version checked against current GitHub state.
- [ ] Shadow runtime and Grand TEVV versions checked.
- [ ] Specified / expected / observed / adverse / open states retained.
- [ ] Adverse findings visible on evidence/status pages.
- [ ] Prohibited claims absent.
- [ ] AI assistance disclosed without calling it independent validation.

## Privacy and security

- [ ] Public artifact manifest matches deployed downloads.
- [ ] Component-library manifest reports 24 PBHP and 45 Shadow components.
- [ ] Every component pack checksum matches and contains specification, metadata, and test plan.
- [ ] Generated component artifacts match the component source catalog deterministically.
- [ ] Raw session archive absent.
- [ ] No keys, tokens, credentials, personal records, recovery material, or hidden attachments.
- [ ] External links use safe target behavior.
- [ ] Workbench remains client-side and does not transmit entries.

## Navigation and interaction

- [ ] Every stable existing route renders.
- [ ] Every new project/repository route renders.
- [ ] Desktop side navigation and current-page state work.
- [ ] Mobile drawer and quick dock work at 320px width.
- [ ] Breadcrumbs, related trails, heading links, and back paths work.
- [ ] Command palette works from home and nested routes.
- [ ] Workbench generate/copy/download works.
- [ ] SIL filtering works.
- [ ] PBHP and Shadow component search, category, state filters, reset, and URL persistence work.
- [ ] Protocol, runtime, primitives, processes, and testing block counts match the release manifest.
- [ ] Every component download and test-plan link works.
- [ ] Grader, Atlas, poster, and all downloads work.
- [ ] No false affordances.

## Accessibility and quality

- [ ] Keyboard-only navigation complete.
- [ ] Focus visible and logical.
- [ ] Dialog focus/escape behavior works.
- [ ] Skip link works.
- [ ] Reduced-motion behavior acceptable.
- [ ] Color contrast reviewed in both themes.
- [ ] Headings and landmark structure reviewed.
- [ ] Desktop and phone screenshots reviewed.
- [ ] Print mode reviewed for protocol/reference pages.

## Deployment

- [ ] GitHub validation workflow passes or any skipped job is explicitly explained.
- [ ] Candidate saved without deployment.
- [ ] Source diff reviewed.
- [ ] Production effect and rollback path understood.
- [ ] Deployed to existing project only.
- [ ] Production URL/version verified.
- [ ] Restricted production smoke pass complete.
- [ ] Audience changed to Anyone on the internet only after all public checks pass.
- [ ] Public production smoke pass complete.
- [ ] Daily ledger deployment receipt written.
