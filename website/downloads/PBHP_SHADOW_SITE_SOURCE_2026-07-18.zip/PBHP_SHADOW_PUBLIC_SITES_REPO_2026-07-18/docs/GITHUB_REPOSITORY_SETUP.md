# GitHub Repository Setup

The repository is ready for a public GitHub remote. It contains generated Sites, deterministic build scripts, component-level downloads and test plans, a CI workflow, issue templates, a release checklist, and a public/private boundary scan.

Keep the established `PauseBeforeHarmProtocol/pbhp` repository as the canonical PBHP protocol and code line. Publish this combined website and Project Shadow repository separately so PBHP, Shadow runtime, TEVV, component-library, and website versions remain distinct.

## Create and push the remote

```bash
git clone PBHP_SHADOW_PUBLIC_SITES_REPO_2026-07-18.bundle pbhp-shadow-public-sites
cd pbhp-shadow-public-sites
git remote add origin <new-github-repository-url>
git push -u origin main --tags
```

## Protect `main`

Require the `validate-public-sites` workflow, at least one reviewer, resolved conversations, and linear history. Block force pushes and deletion. Changes to evidence states, public allowlists, test plans, runtime claims, and deployment instructions should require explicit review.

## Release assets

A GitHub Release should attach the complete repository ZIP, Git bundle, PBHP and Shadow deployment ZIPs, component-library bundles, SHA-256 records, release receipt, and validation summary. Release notes must distinguish specified, observed, adverse, and open evidence.
