# Daily website stewardship prompt

Use this only when there is new source material, a repository change, a test result, a corrected claim, a new artifact, or a substantive navigation/content improvement. Do not run it merely to make the Site look active.

```text
@Sites

Maintain the existing Pause Before Harm and Project Shadow Sites using the attached repository
and the current authenticated production projects. Begin read-only and recover the deployed source.
Do not create new Sites.

Review new inputs since the last dated ledger entry:
- PBHP GitHub commits, tags, issues, releases, tests, and documentation changes;
- Project Shadow runtime, TEVV, Behavioral Falsifier, SIL, receipt, governance, and artifact changes;
- corrected factual claims, adverse findings, replications, independent reviews, and open questions;
- broken links, route defects, accessibility findings, mobile navigation defects, or false affordances.

For every proposed change, classify it as:
- content correction;
- evidence-state change;
- release/version change;
- navigation/interaction change;
- artifact/download change;
- privacy/security change;
- no substantive change.

Do not publish “no substantive change” as a new daily entry. For real changes:
1. update the relevant stable page rather than creating a duplicate page;
2. preserve specified / expected / observed / adverse / open labels;
3. preserve source dates, model names, samples, scorers, limitations, and prohibited claims;
4. update repository/download manifests and checksums when files change;
5. run build, link, browser, mobile, keyboard, and privacy checks;
6. save a candidate version and report the diff before deployment;
7. deploy only to the existing canonical project after review;
8. verify production and then write the dated ledger receipt.

PBHP remains the human-readable front door. Project Shadow remains the technical deep system.
No global green. No log = no action. A clean run is weaker evidence than it feels like.
```
