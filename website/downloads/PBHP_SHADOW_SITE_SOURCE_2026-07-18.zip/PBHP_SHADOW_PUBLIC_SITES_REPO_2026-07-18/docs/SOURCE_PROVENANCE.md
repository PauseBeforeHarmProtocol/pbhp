# Source provenance

## Authoritative inputs used

| Input | Use in this release | Publication status |
|---|---|---|
| `GPT_SITES_CONTINUATION_HANDOFF_2026-07-17(1).md` | Existing Site URLs, versions, stable routes, architecture, evidence ledger, deployment constraints | Source record; not copied into public downloads |
| `FABLE_SITES_AUDIT_HANDOFF_2026-07-17(1).md` | Navigation and application-audit context | Source record; not copied into public downloads |
| Public `PauseBeforeHarmProtocol/pbhp` GitHub repository | Canonical PBHP public source/version/license/test description | Linked, not copied |
| `Project_Shadow_Grand_TEVV_v0.3.zip` | Canonical current Shadow TEVV package | Published with checksum |
| v0.3 build summary, merge notes, validation status | Current Shadow evidence and limitations | Published |
| `GRADING_APP(1).html` | Blind response grader tool | Published |
| `MYTHIC_ATLAS_v2.html` | Bounded mnemonic interface | Published |
| `SHADOW_PROTOCOL_POSTER_v1.3.1(1).html` | Static technical overview | Published |
| `BF-RUN-01_BLIND_SCORING_PACKAGE(1).zip` | Blind scoring package | Published |
| `racing_line_v0.2_corrected(1).zip` | Corrected routing package | Published |
| Private Project Shadow session archive | Recovery of the v0.3 package and public release notes | **Not published; filename and contents withheld** |

## Precedence

1. Current public PBHP repository for PBHP public version and source.
2. Grand TEVV v0.3 summary/merge record for current Shadow TEVV publication.
3. Existing authenticated Sites source for deployed-state truth after it is recovered.
4. Handoffs for intended architecture and version-at-handoff, not proof of current production behavior.
5. Generated website prose as explanatory presentation, never as stronger evidence than its sources.

## Conflict handling

When sources disagree:

- preserve both statements long enough to identify version and scope;
- prefer the newer authoritative release record;
- do not silently combine counts;
- record the correction in the daily ledger;
- weaken the public claim until the discrepancy is resolved.
