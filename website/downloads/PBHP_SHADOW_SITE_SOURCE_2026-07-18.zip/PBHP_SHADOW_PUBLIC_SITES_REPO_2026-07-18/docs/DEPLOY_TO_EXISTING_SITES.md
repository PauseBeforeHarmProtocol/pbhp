# Deploy to the existing ChatGPT Sites

## Existing production projects

| Site | Existing canonical URL | Existing version at handoff | Required action |
|---|---|---:|---|
| Pause Before Harm | `https://pausebeforeharm.frylock117.chatgpt.site` | 3 | Update the existing project; do not create a duplicate |
| Project Shadow | `https://projectshadow.frylock117.chatgpt.site` | 3 | Update the existing project; do not create a duplicate |

The existing slugs are `pausebeforeharm` and `projectshadow`. The longer PBHP reservation `pausebeforeharmprotocol` is intentionally not the canonical project.

## Operator sequence

1. Open ChatGPT web or desktop in the account/workspace that owns the Sites.
2. Open **Work → Sites**, or invoke `@Sites` in a Work conversation.
3. Attach the complete repository ZIP.
4. Paste the prompt below.
5. Review the recovered inventory, source diff, and saved candidate before allowing deployment.
6. Inspect desktop and phone previews, keyboard navigation, all routes, all downloads, PBHP and Shadow component filters, component pack checksums, the workbench, SIL filtering, embedded tools, and public claims.
7. Deploy to the existing projects only.
8. Verify the production version and exact URL after deployment.
9. Change the audience to **Anyone on the internet** only after the reviewed production build and public-release checklist pass.

## Paste this into `@Sites`

```text
@Sites

Continue the existing Pause Before Harm and Project Shadow Sites from the attached
PBHP_SHADOW_PUBLIC_SITES_REPO_2026-07-18 repository.

Begin read-only. Open the authoritative Sites inventory and locate the existing projects by
canonical production URL and persisted slug:

- Pause Before Harm — https://pausebeforeharm.frylock117.chatgpt.site — slug pausebeforeharm — version 3 at handoff
- Project Shadow — https://projectshadow.frylock117.chatgpt.site — slug projectshadow — version 3 at handoff

Do not create replacement, duplicate, or long-name reservation projects. Recover the exact
current source and project identity first. Preserve unrelated user changes. Report the observed
project, deployed version, audience, source location, and every discrepancy from the repository
or handoff before editing.

Use this repository as the reviewed candidate source:
- sites/pbhp for Pause Before Harm
- sites/shadow for Project Shadow
- validation for link, manifest, checksum, and browser-test records
- docs/PUBLICATION_POLICY.md for the public/private and claims boundary
- public-artifacts/LATEST_RELEASE_MANIFEST.json for the allowlisted downloads
- public-artifacts/component-library/PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json for the 69 component packs

Architecture is binding:
- PBHP is the public human-readable protocol.
- Project Shadow is the technical deep system.
- They may cross-link but remain separate Sites and themes.
- ALMSIVI remains independent and is not added to shared navigation.
- The Record and American Repair Manual are not modified by this deployment.

Current release facts to preserve:
- PBHP repository-declared current version: v0.9.5; GitHub Releases latest tag observed 2026-07-18: v0.9.0. Preserve this distinction until the tagging state is reconciled.
- Project Shadow runtime: v1.3.1-UNIFIED.
- Grand TEVV current publication package: v0.3, superseding the supplied v0.2 package.
- Grand TEVV v0.3 has limited screen-grade real-target evidence and is not independent validation.
- Do not claim globally safe, externally validated, certified, NIST/ISO approved, or most extensive.
- Keep specified, expected, observed, adverse, and open evidence states visible.
- Keep the raw Project Shadow session archive and private recovery context out of the public Site.

Before deployment:
1. Check Sites compatibility and make only necessary compatibility changes.
2. Preserve every stable existing route in the handoff.
3. Verify every new components, processes, testing, repository, research, glossary, versions, about, daily, directory, and download route.
4. Verify desktop side navigation, mobile drawer and quick dock, breadcrumbs, related-page trails,
   command-palette search, reading progress, heading links, keyboard focus, print behavior, PBHP
   workbench receipt generation/copy/download, component search/category/evidence filters, all 69 component
   packs and test-plan links, SIL filtering, response grader, Mythic Atlas, and poster.
5. Verify that anything appearing interactive works and that there are no false affordances.
6. Inspect all public files for credentials, private context, recovery material, personal data, and unsafe claims.
7. Save a candidate version without deploying and present the source diff, validation results,
   open issues, and exact production effect for review.

After the reviewed candidate passes, deploy PBHP to the existing pausebeforeharm project and
Project Shadow to the existing projectshadow project. Do not alter any other Site.

Keep the audience restricted while verifying production. Then, because the maintainer has explicitly
requested a public world-facing release, change each reviewed Site to “Anyone on the internet” only
if the public-release checklist is clean. Verify the exact production URL, version, route inventory,
audience, and a desktop/mobile smoke pass before reporting either Site live.

The daily ledger advances only after a substantive content, evidence, code, navigation, or release
change. Never update the date merely because a day passed.
```

## Why the save step matters

A Sites deployment URL is production. Use a saved candidate and preview for review before changing the deployed version. Do not use a deployment merely as a private preview.

## Production verification receipt

Record, for each Site:

- persisted project identity;
- previous and new version;
- source commit or release hash;
- audience before and after;
- route count and failed-route count;
- browser and viewport checks;
- public-file/privacy result;
- claims review result;
- production URL;
- deployment timestamp;
- operator and reviewer;
- remaining open findings.
