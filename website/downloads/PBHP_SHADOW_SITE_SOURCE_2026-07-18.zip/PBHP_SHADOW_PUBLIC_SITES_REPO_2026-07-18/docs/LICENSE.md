# Licensing notice

This curated repository does not silently relicense upstream or separately authored material.

- The canonical PBHP repository states that code under `src/` is MIT licensed and protocol/documentation material is CC BY-SA 4.0, subject to the upstream `LICENSE` and any stated non-negotiable clauses.
- The website builder and original website integration code in this package are provided for the maintainer’s use and publication. No broader license is granted here unless the maintainer adds one explicitly.
- Project Shadow runtime, TEVV, experiment packages, poster, Atlas, and grader retain their existing authorship and rights. Their presence in the public-download allowlist permits distribution of these named release artifacts; it does not imply a blanket license for unrelated session content.
- Third-party names, standards, frameworks, fictional characters, quotations, and trademarks remain the property of their respective owners. Mapping or reference does not imply endorsement, certification, or affiliation.

Before accepting outside contributions or encouraging downstream redistribution, the maintainer should select and publish an explicit Project Shadow and website-source license.
