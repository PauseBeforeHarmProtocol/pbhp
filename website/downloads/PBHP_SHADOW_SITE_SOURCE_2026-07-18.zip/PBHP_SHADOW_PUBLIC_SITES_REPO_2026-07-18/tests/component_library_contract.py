#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
ARTIFACTS = ROOT / "public-artifacts" / "component-library"
VALIDATION = ROOT / "validation"
sys.path.insert(0, str(SOURCE))

from component_catalog import (  # noqa: E402
    COMPONENT_LIBRARY_VERSION,
    PBHP_COMPONENTS,
    SHADOW_COMPONENTS,
    component_pack_name,
    write_component_artifacts,
)

REQUIRED_FIELDS = {
    "project", "slug", "title", "category", "kind", "summary", "mechanism", "inputs", "outputs",
    "failure_modes", "evidence_state", "test_status", "next_tests", "route", "version",
}
VALID_STATES = {"specified", "expected", "observed", "adverse", "open"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare_trees(left: Path, right: Path) -> list[str]:
    issues: list[str] = []
    left_files = {str(path.relative_to(left)).replace("\\", "/"): path for path in left.rglob("*") if path.is_file()}
    right_files = {str(path.relative_to(right)).replace("\\", "/"): path for path in right.rglob("*") if path.is_file()}
    if set(left_files) != set(right_files):
        missing = sorted(set(left_files) - set(right_files))
        extra = sorted(set(right_files) - set(left_files))
        if missing:
            issues.append(f"regenerated tree missing files: {missing[:20]}")
        if extra:
            issues.append(f"regenerated tree has extra files: {extra[:20]}")
    for rel in sorted(set(left_files) & set(right_files)):
        if sha(left_files[rel]) != sha(right_files[rel]):
            issues.append(f"non-deterministic component artifact: {rel}")
    return issues


def main() -> int:
    issues: list[str] = []
    details: list[dict] = []
    for project, components, expected_count in (
        ("pbhp", PBHP_COMPONENTS, 24),
        ("shadow", SHADOW_COMPONENTS, 45),
    ):
        if len(components) != expected_count:
            issues.append(f"{project}: expected {expected_count} components, found {len(components)}")
        slugs = [component["slug"] for component in components]
        if len(slugs) != len(set(slugs)):
            issues.append(f"{project}: duplicate component slug")
        for component in components:
            missing = REQUIRED_FIELDS - set(component)
            if missing:
                issues.append(f"{project}/{component.get('slug', '?')}: missing fields {sorted(missing)}")
                continue
            if component["project"] != project:
                issues.append(f"{project}/{component['slug']}: wrong project field")
            if component["evidence_state"] not in VALID_STATES:
                issues.append(f"{project}/{component['slug']}: invalid evidence state {component['evidence_state']}")
            for field in ("inputs", "outputs", "failure_modes", "next_tests"):
                if not component[field] or not all(isinstance(item, str) and item.strip() for item in component[field]):
                    issues.append(f"{project}/{component['slug']}: empty or invalid {field}")
            root = ARTIFACTS / project / component["slug"]
            expected_files = ["README.md", "component.json", "TEST_PLAN.md", component_pack_name(component), component_pack_name(component) + ".sha256"]
            for name in expected_files:
                if not (root / name).is_file():
                    issues.append(f"{project}/{component['slug']}: missing {name}")
            metadata_path = root / "component.json"
            if metadata_path.exists():
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                for key in REQUIRED_FIELDS:
                    if metadata.get(key) != component.get(key):
                        issues.append(f"{project}/{component['slug']}: metadata mismatch for {key}")
            pack_path = root / component_pack_name(component)
            if pack_path.exists():
                with zipfile.ZipFile(pack_path) as archive:
                    names = sorted(name for name in archive.namelist() if not name.endswith("/"))
                    if names != ["README.md", "TEST_PLAN.md", "component.json"]:
                        issues.append(f"{project}/{component['slug']}: unexpected pack contents {names}")
                checksum_path = pack_path.with_name(pack_path.name + ".sha256")
                if checksum_path.exists() and not checksum_path.read_text(encoding="utf-8").startswith(sha(pack_path)):
                    issues.append(f"{project}/{component['slug']}: pack checksum mismatch")
        details.append({
            "project": project,
            "component_count": len(components),
            "categories": sorted({component["category"] for component in components}),
        })

    manifest_path = ARTIFACTS / "PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json"
    if not manifest_path.exists():
        issues.append("component manifest missing")
    else:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("component_library_version") != COMPONENT_LIBRARY_VERSION:
            issues.append("component manifest version mismatch")
        if manifest.get("combined_component_count") != len(PBHP_COMPONENTS) + len(SHADOW_COMPONENTS):
            issues.append("component manifest count mismatch")

    with tempfile.TemporaryDirectory(prefix="component-library-repro-") as tmp:
        regenerated = Path(tmp) / "component-library"
        write_component_artifacts(regenerated)
        issues.extend(compare_trees(ARTIFACTS, regenerated))

    report = {
        "schema": "pbhp-shadow-component-library-contract-v1",
        "status": "PASS" if not issues else "FAIL",
        "component_library_version": COMPONENT_LIBRARY_VERSION,
        "combined_component_count": len(PBHP_COMPONENTS) + len(SHADOW_COMPONENTS),
        "details": details,
        "issues": issues,
        "scope": "Catalog schema, unique slugs, required fields, individual files, pack contents, checksums, manifest counts, and deterministic regeneration.",
    }
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "component-library-contract.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
