#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path

from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
SITES = ROOT / "sites"
VALIDATION = ROOT / "validation"
APP_JS = ROOT / "source" / "static" / "app.js"

REQUIRED_JS_TOKENS = {
    "navigation toggle": "[data-nav-toggle]",
    "search opener": "[data-search-open]",
    "search fetch": "fetch(boot.searchIndex",
    "workbench": '$("#pbhp-workbench")',
    "gauge filtering": '$("#gauge-search")',
    "component filtering": '$("#component-search")',
    "receipt download": 'link.download = `PBHP_receipt_',
    "command shortcut": 'event.key.toLowerCase() === "k"',
}


def require(condition: bool, message: str, issues: list[str]) -> None:
    if not condition:
        issues.append(message)


def parse_boot(text: str) -> dict:
    match = re.search(r"window\.SITE_BOOT=(\{.*?\});", text, flags=re.DOTALL)
    if not match:
        raise ValueError("window.SITE_BOOT object not found")
    return json.loads(match.group(1).replace("<\\/", "</"))


def check_site(site_key: str, issues: list[str], details: list[dict]) -> None:
    site_root = SITES / site_key
    manifest_path = site_root / "site-manifest.json"
    require(manifest_path.exists(), f"{site_key}: missing site-manifest.json", issues)
    if not manifest_path.exists():
        return
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    search_path = site_root / "assets" / "search-index.json"
    require(search_path.exists(), f"{site_key}: missing search-index.json", issues)
    search_index = json.loads(search_path.read_text(encoding="utf-8")) if search_path.exists() else []
    require(len(search_index) == len(manifest["pages"]), f"{site_key}: search index/page count mismatch", issues)

    seen_ids: set[tuple[str, str]] = set()
    for page in manifest["pages"]:
        rel = page["path"]
        path = site_root / rel
        require(path.exists(), f"{site_key}: missing generated page {rel}", issues)
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8")
        soup = BeautifulSoup(text, "html.parser")
        route = page["route"] or "home"
        prefix = f"{site_key}/{route}"

        require(soup.select_one('a.skip-link[href="#main"]') is not None, f"{prefix}: missing skip link", issues)
        require(soup.select_one("main#main") is not None, f"{prefix}: missing main landmark", issues)
        require(soup.select_one("aside.sidebar#site-navigation") is not None, f"{prefix}: missing sidebar navigation", issues)
        require(soup.select_one(".mobile-header [data-nav-toggle]") is not None, f"{prefix}: missing mobile nav toggle", issues)
        require(soup.select_one("nav.mobile-dock") is not None, f"{prefix}: missing mobile quick dock", issues)
        require(len(soup.select("[data-search-open]")) >= 2, f"{prefix}: insufficient search entry points", issues)
        require(soup.select_one("dialog#command-dialog") is not None, f"{prefix}: missing command palette", issues)
        require(soup.select_one("#command-query") is not None, f"{prefix}: missing command query field", issues)
        require(soup.select_one("#command-results") is not None, f"{prefix}: missing command results", issues)
        require(soup.select_one("article[data-article]") is not None, f"{prefix}: missing article body", issues)
        require(soup.select_one('script[src$="assets/app.js"]') is not None or soup.select_one('script[src="../assets/app.js"]') is not None, f"{prefix}: missing app.js", issues)
        require(soup.select_one('link[rel="canonical"]') is not None, f"{prefix}: missing canonical URL", issues)
        require(soup.select_one('script[type="application/ld+json"]') is not None, f"{prefix}: missing JSON-LD", issues)
        require("[[" not in soup.select_one("article[data-article]").get_text(" "), f"{prefix}: unresolved wiki-link token", issues)
        require("&lt;h2" not in text and "&lt;div class=\"hero" not in text, f"{prefix}: escaped content markup detected", issues)

        ids = [node.get("id") for node in soup.select("[id]")]
        duplicates = sorted({value for value in ids if value and ids.count(value) > 1})
        require(not duplicates, f"{prefix}: duplicate ids {duplicates}", issues)
        for value in ids:
            if value:
                seen_ids.add((rel, value))

        try:
            boot = parse_boot(text)
            require(boot.get("site") == site_key, f"{prefix}: wrong boot site", issues)
            require("searchIndex" in boot, f"{prefix}: boot search index missing", issues)
        except Exception as exc:
            issues.append(f"{prefix}: boot JSON invalid: {exc}")

        active = soup.select(".primary-nav a[aria-current='page']")
        require(len(active) == 1, f"{prefix}: expected exactly one active primary-nav item, found {len(active)}", issues)
        for link in soup.select('a[target="_blank"]'):
            rel_tokens = set(link.get("rel", []))
            require({"noopener", "noreferrer"} <= rel_tokens, f"{prefix}: external target lacks noopener/noreferrer", issues)

    details.append({
        "site": site_key,
        "pages_checked": len(manifest["pages"]),
        "search_entries": len(search_index),
        "unique_page_ids": len(seen_ids),
    })


def main() -> int:
    issues: list[str] = []
    details: list[dict] = []
    js = APP_JS.read_text(encoding="utf-8")
    for label, token in REQUIRED_JS_TOKENS.items():
        require(token in js, f"app.js: missing {label} contract token", issues)

    for site_key in ("pbhp", "shadow"):
        check_site(site_key, issues, details)

    pbhp_workbench = BeautifulSoup((SITES / "pbhp" / "workbench" / "index.html").read_text(encoding="utf-8"), "html.parser")
    require(pbhp_workbench.select_one("form#pbhp-workbench") is not None, "PBHP workbench: missing form", issues)
    for name in ("action", "affected", "classification", "who_pays", "power", "reversibility", "harm", "maybe", "therefore"):
        require(pbhp_workbench.select_one(f'[name="{name}"]') is not None, f"PBHP workbench: missing {name} field", issues)
    require(pbhp_workbench.select_one("#receipt-output") is not None, "PBHP workbench: missing receipt output", issues)
    require(pbhp_workbench.select_one("#copy-receipt") is not None, "PBHP workbench: missing receipt copy control", issues)
    require(pbhp_workbench.select_one("#download-receipt") is not None, "PBHP workbench: missing receipt download control", issues)

    sil = BeautifulSoup((SITES / "shadow" / "sil" / "index.html").read_text(encoding="utf-8"), "html.parser")
    gauges = sil.select("[data-gauge]")
    require(len(gauges) == 28, f"Shadow SIL: expected 28 gauges, found {len(gauges)}", issues)
    require(sil.select_one("#gauge-search") is not None, "Shadow SIL: missing search field", issues)
    require(sil.select_one("#gauge-category") is not None, "Shadow SIL: missing category filter", issues)
    gauge_downloads = sil.select('a[download][href*="/sil-tools/gauges/"][href$=".zip"]')
    require(len(gauge_downloads) == 28, f"Shadow SIL: expected 28 individual gauge downloads, found {len(gauge_downloads)}", issues)
    for gauge in gauges:
        require(gauge.select_one(".gauge-card__identity h4") is not None, "Shadow SIL: gauge missing visible name", issues)
        require(gauge.select_one(".gauge-card__identity p") is not None, "Shadow SIL: gauge missing visible description", issues)
        button = gauge.select_one('a.gauge-card__download[download]')
        require(button is not None, "Shadow SIL: gauge missing direct download button", issues)
        if button is not None:
            require(button.get_text(" ", strip=True) == "Download now", "Shadow SIL: direct download button label mismatch", issues)
    time_keeper = next((g for g in gauges if "Time Keeper" in g.get_text(" ", strip=True)), None)
    require(time_keeper is not None, "Shadow SIL: Time Keeper card missing", issues)
    if time_keeper is not None:
        tk_link = time_keeper.select_one('a[download][href*="02-time-keeper"][href$=".zip"]')
        require(tk_link is not None, "Shadow SIL: Time Keeper direct ZIP missing", issues)
    require(sil.select_one('a[download][href*="PROJECT_SHADOW_SIL_PANEL_28_GAUGES"][href$=".zip"]') is not None, "Shadow SIL: full panel download missing", issues)

    sil_download_root = SITES / "shadow" / "downloads" / "sil-tools"
    copied_gauge_packs = list((sil_download_root / "gauges").glob("*/*.zip"))
    require(len(copied_gauge_packs) == 28, f"Shadow SIL: expected 28 copied gauge ZIPs, found {len(copied_gauge_packs)}", issues)
    require((sil_download_root / "SIL_TOOL_LIBRARY_MANIFEST.json").exists(), "Shadow SIL: tool-library manifest not copied", issues)
    require(len(list(sil_download_root.glob("PROJECT_SHADOW_SIL_PANEL_28_GAUGES_*.zip"))) == 1, "Shadow SIL: copied full-panel ZIP missing or duplicated", issues)

    shadow_repo = BeautifulSoup((SITES / "shadow" / "repository" / "index.html").read_text(encoding="utf-8"), "html.parser")
    require(len(shadow_repo.select('a[href*="Project_Shadow_Grand_TEVV_v0.3.zip"]')) >= 1, "Shadow repository: v0.3 release link missing", issues)
    require(len(shadow_repo.select('a[href*="PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip"]')) >= 1, "Shadow repository: source release link missing", issues)

    pbhp_repo = BeautifulSoup((SITES / "pbhp" / "repository" / "index.html").read_text(encoding="utf-8"), "html.parser")
    require(len(pbhp_repo.select('a[href*="PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip"]')) >= 1, "PBHP repository: source release link missing", issues)
    require(len(pbhp_repo.select('a[href*="PBHP_COMPONENT_LIBRARY_2026-07-18.zip"]')) >= 1, "PBHP repository: component-library bundle link missing", issues)

    component_expectations = {
        "pbhp": {"components": 24, "protocol": 10, "testing": 24},
        "shadow": {"components": 45, "runtime": 14, "primitives": 13, "testing": 45},
    }
    for site_key, pages in component_expectations.items():
        for route, expected in pages.items():
            soup = BeautifulSoup((SITES / site_key / route / "index.html").read_text(encoding="utf-8"), "html.parser")
            selector = "[data-component]" if route != "testing" else ".test-matrix__row"
            found = len(soup.select(selector))
            require(found == expected, f"{site_key}/{route}: expected {expected} component/test blocks, found {found}", issues)
            if route == "components":
                require(soup.select_one("#component-search") is not None, f"{site_key}/components: missing component search", issues)
                require(soup.select_one("#component-category") is not None, f"{site_key}/components: missing category filter", issues)
                require(soup.select_one("#component-status") is not None, f"{site_key}/components: missing status filter", issues)
                require(len(soup.select('a[download][href*="_component_pack.zip"]')) == expected, f"{site_key}/components: component pack download count mismatch", issues)

    shadow_repo = BeautifulSoup((SITES / "shadow" / "repository" / "index.html").read_text(encoding="utf-8"), "html.parser")
    require(len(shadow_repo.select('a[href*="PROJECT_SHADOW_COMPONENT_LIBRARY_2026-07-18.zip"]')) >= 1, "Shadow repository: component-library bundle link missing", issues)

    for site_key, prefix, count in (("pbhp", "PBHP_", 24), ("shadow", "SHADOW_", 45)):
        packs = list((SITES / site_key / "downloads" / "component-library" / site_key).glob(f"*/{prefix}*_component_pack.zip"))
        require(len(packs) == count, f"{site_key}: expected {count} copied component packs, found {len(packs)}", issues)
        require((SITES / site_key / "downloads" / "component-library" / "PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json").exists(), f"{site_key}: component manifest not copied", issues)

    result = {
        "schema": "pbhp-shadow-static-interaction-contract-v1",
        "status": "PASS" if not issues else "FAIL",
        "details": details,
        "issues": issues,
        "scope": "Static DOM/selector/event-contract validation. This does not replace authenticated browser, keyboard, assistive-technology, or production-route testing.",
    }
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "static-interaction-contract.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
