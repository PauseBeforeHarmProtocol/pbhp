#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from site_data import PBHP_PAGES, SHADOW_PAGES  # noqa: E402
from component_catalog import PBHP_COMPONENTS, SHADOW_COMPONENTS  # noqa: E402

pbhp = {p["route"]: p for p in PBHP_PAGES}
shadow = {p["route"]: p for p in SHADOW_PAGES}

required_pbhp = {
    "", "manual", "protocol", "workbench", "evidence", "research", "examples", "receipts",
    "implementation", "operations", "risk", "cla", "templates", "foundations", "glossary",
    "versions", "about", "directory", "daily", "repository", "components", "testing",
}
required_shadow = {
    "", "reference", "system", "runtime", "synthesis", "primitives", "gates", "sil", "tevv",
    "behavioral-falsifier", "atlas", "receipts", "governance", "narrative-governance",
    "integrations", "blueprint", "roadmap", "status", "directory", "daily", "research",
    "glossary", "versions", "about", "repository", "components", "processes", "testing",
}
assert required_pbhp <= set(pbhp), required_pbhp - set(pbhp)
assert required_shadow <= set(shadow), required_shadow - set(shadow)
assert len(PBHP_COMPONENTS) == 24
assert len(SHADOW_COMPONENTS) == 45
assert "Download now" in pbhp["components"]["body"]
assert "Download now" in shadow["components"]["body"]
assert "Download now" in shadow["sil"]["body"]
assert "TDA-2 Time Keeper" in shadow["sil"]["body"]
assert "28 individual gauges" in shadow["sil"]["body"]
assert "Component-by-component state" in pbhp["testing"]["body"]
assert "Component-by-component state" in shadow["testing"]["body"]
assert "Runtime and instrumentation processes" in shadow["processes"]["body"]
assert "v0.3" in shadow["tevv"]["body"]
assert "6 / 10" in shadow["tevv"]["body"]
assert "not independent" in shadow["tevv"]["body"].lower()
assert "v0.9.5" in pbhp["repository"]["body"]
combined = "\n".join(page["body"] for page in PBHP_PAGES + SHADOW_PAGES)
for forbidden in [
    "globally safe.</strong>",
    "NIST validated",
]:
    assert forbidden not in combined, forbidden
print(f"content contract: PASS ({len(PBHP_PAGES)} PBHP pages, {len(SHADOW_PAGES)} Shadow pages, {len(PBHP_COMPONENTS) + len(SHADOW_COMPONENTS)} component packs)")
