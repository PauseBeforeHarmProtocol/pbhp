#!/usr/bin/env python3
from __future__ import annotations

import http.server
import json
import socketserver
import threading
from pathlib import Path

from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SITES = ROOT / "sites"
VALIDATION = ROOT / "validation"
PREVIEWS = ROOT / "previews"
PORT = 4174
POLICY_PATHS = [
    Path("/etc/chromium/policies/managed/000_policy_merge.json"),
    Path("/etc/opt/chrome/policies/managed/000_policy_merge.json"),
]


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


def managed_navigation_block() -> dict | None:
    for path in POLICY_PATHS:
        if not path.exists():
            continue
        try:
            policy = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        blocklist = policy.get("URLBlocklist", [])
        if "*" in blocklist:
            return {"policy_path": str(path), "URLBlocklist": blocklist}
    return None


def write_report(report: dict) -> None:
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "browser-smoke.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


def run_server():
    handler = lambda *args, **kwargs: QuietHandler(*args, directory=str(SITES), **kwargs)
    server = socketserver.TCPServer(("127.0.0.1", PORT), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def main() -> int:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    policy = managed_navigation_block()
    if policy:
        write_report(
            {
                "schema": "pbhp-shadow-browser-smoke-v1",
                "status": "BLOCKED_ENVIRONMENT",
                "reason": "Managed Chromium blocks all URL navigation, including localhost and file URLs.",
                "policy": policy,
                "executed": [],
                "required_continuation": [
                    "Run desktop and phone interaction tests in the authenticated ChatGPT Sites workspace.",
                    "Verify keyboard navigation, focus order, command palette, mobile drawer, PBHP receipt workflow, component filters and downloads, SIL filter, and production routes.",
                ],
                "note": "The block was not bypassed. Static interaction contracts and WeasyPrint visual renders provide partial local evidence only.",
            }
        )
        return 0

    results: list[dict] = []
    server = run_server()
    try:
        with sync_playwright() as pw:
            launch_options = {"headless": True, "args": ["--no-sandbox"]}
            system_chromium = Path("/usr/bin/chromium")
            if system_chromium.exists():
                launch_options["executable_path"] = str(system_chromium)
            browser = pw.chromium.launch(**launch_options)

            desktop = browser.new_context(viewport={"width": 1440, "height": 1000})
            page = desktop.new_page()
            errors: list[str] = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.goto(f"http://127.0.0.1:{PORT}/pbhp/", wait_until="networkidle")
            page.screenshot(path=str(PREVIEWS / "pbhp-browser-desktop.png"), full_page=True)
            page.click("[data-search-open]")
            page.fill("#command-query", "workbench")
            page.wait_for_selector("[data-result]")
            page.keyboard.press("Escape")
            page.goto(f"http://127.0.0.1:{PORT}/pbhp/workbench/", wait_until="networkidle")
            page.fill('[name="action"]', "Publish an irreversible decision based on incomplete evidence")
            page.fill('[name="affected"]', "Employees")
            page.select_option('[name="classification"]', label="Gap")
            page.fill('[name="who_pays"]', "Employees bear the first reputational and livelihood cost")
            page.select_option('[name="power"]', "extreme")
            page.select_option('[name="reversibility"]', "irreversible")
            page.select_option('[name="harm"]', "RED")
            page.fill('[name="maybe"]', "The evidence may be incomplete and the subjects cannot appeal before publication.")
            page.fill('[name="therefore"]', "Delay publication, require independent review, and create an appeal path.")
            page.click('button[type="submit"]')
            assert page.locator("#receipt-output").is_visible()
            assert "DELAY" in page.locator("#receipt-state").inner_text()
            page.goto(f"http://127.0.0.1:{PORT}/pbhp/components/", wait_until="networkidle")
            assert page.locator("[data-component]").count() == 24
            page.fill("#component-search", "power inversion")
            assert page.locator("[data-component]:visible").count() == 1
            assert page.locator('a[download][href*="power-inversion"]').count() == 1
            assert not errors, errors
            results.append({"check": "PBHP search, workbench, and component library", "pass": True})
            desktop.close()

            mobile = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=1)
            page = mobile.new_page()
            mobile_errors: list[str] = []
            page.on("pageerror", lambda error: mobile_errors.append(str(error)))
            page.goto(f"http://127.0.0.1:{PORT}/pbhp/", wait_until="networkidle")
            page.click("[data-nav-toggle]")
            assert page.locator("body").evaluate("el => el.classList.contains('nav-open')")
            assert page.locator(".mobile-dock").is_visible()
            assert not mobile_errors, mobile_errors
            results.append({"check": "PBHP mobile navigation", "pass": True})
            mobile.close()

            desktop = browser.new_context(viewport={"width": 1440, "height": 1000})
            page = desktop.new_page()
            shadow_errors: list[str] = []
            page.on("pageerror", lambda error: shadow_errors.append(str(error)))
            page.goto(f"http://127.0.0.1:{PORT}/shadow/", wait_until="networkidle")
            page.screenshot(path=str(PREVIEWS / "shadow-browser-desktop.png"), full_page=True)
            page.goto(f"http://127.0.0.1:{PORT}/shadow/sil/", wait_until="networkidle")
            page.fill("#gauge-search", "provenance")
            visible = page.locator("[data-gauge]:visible").count()
            assert 1 <= visible < 28, visible
            page.goto(f"http://127.0.0.1:{PORT}/shadow/components/", wait_until="networkidle")
            assert page.locator("[data-component]").count() == 45
            page.select_option("#component-category", "primitives")
            assert page.locator("[data-component]:visible").count() == 13
            page.select_option("#component-status", "adverse")
            assert page.locator("[data-component]:visible").count() >= 1
            page.goto(f"http://127.0.0.1:{PORT}/shadow/repository/", wait_until="networkidle")
            assert page.locator('a[href*="Project_Shadow_Grand_TEVV_v0.3.zip"]').count() >= 1
            assert page.locator('a[href*="PROJECT_SHADOW_COMPONENT_LIBRARY_2026-07-18.zip"]').count() >= 1
            assert not shadow_errors, shadow_errors
            results.append({"check": "Shadow components, SIL, and repository", "pass": True})
            desktop.close()

            mobile = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=1)
            page = mobile.new_page()
            page.goto(f"http://127.0.0.1:{PORT}/shadow/", wait_until="networkidle")
            assert page.locator(".mobile-dock").is_visible()
            results.append({"check": "Shadow mobile quick dock", "pass": True})
            mobile.close()
            browser.close()
    except PlaywrightError as exc:
        message = str(exc)
        status = "BLOCKED_ENVIRONMENT" if "ERR_BLOCKED_BY_ADMINISTRATOR" in message else "FAIL"
        report = {
            "schema": "pbhp-shadow-browser-smoke-v1",
            "status": status,
            "reason": message,
            "executed": results,
            "required_continuation": ["Run the complete interaction suite in the authenticated ChatGPT Sites workspace."],
        }
        write_report(report)
        return 0 if status == "BLOCKED_ENVIRONMENT" else 1
    finally:
        server.shutdown()
        server.server_close()

    write_report({"schema": "pbhp-shadow-browser-smoke-v1", "status": "PASS", "executed": results})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
