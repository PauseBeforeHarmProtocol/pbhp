#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
SOURCE_TOOLS = SOURCE / "sil-tools"
ARTIFACTS = ROOT / "public-artifacts" / "sil-tools"
VALIDATION = ROOT / "validation"
sys.path.insert(0, str(SOURCE))

from sil_catalog import (  # noqa: E402
    SIL_LIBRARY_VERSION,
    SIL_TOOLS,
    SOURCE_FOLDERS,
    full_panel_pack_name,
    tool_pack_name,
    write_sil_tool_artifacts,
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_hashes(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): sha(path)
        for path in root.rglob("*")
        if path.is_file()
    }


def main() -> int:
    issues: list[str] = []
    details: list[dict] = []

    if len(SIL_TOOLS) != 28:
        issues.append(f"expected 28 SIL tools, found {len(SIL_TOOLS)}")
    numbers = [tool["number"] for tool in SIL_TOOLS]
    slugs = [tool["slug"] for tool in SIL_TOOLS]
    if numbers != list(range(1, 29)):
        issues.append(f"SIL gauge numbering is not 1..28: {numbers}")
    if len(slugs) != len(set(slugs)):
        issues.append("duplicate SIL slugs")

    for tool in SIL_TOOLS:
        folder = SOURCE_TOOLS / SOURCE_FOLDERS[tool["number"]]
        if not folder.is_dir():
            issues.append(f"#{tool['number']:02d} {tool['slug']}: source folder missing")
            continue
        specs = [path for path in folder.glob("*.md") if "SPEC" in path.name.upper()]
        tests = list(folder.glob("tests/test*.py"))
        package = folder / tool["package"]
        if not specs:
            issues.append(f"#{tool['number']:02d} {tool['slug']}: specification missing")
        if not tests:
            issues.append(f"#{tool['number']:02d} {tool['slug']}: built-in test file missing")
        if not package.is_dir():
            issues.append(f"#{tool['number']:02d} {tool['slug']}: package folder {tool['package']} missing")

        root = ARTIFACTS / "gauges" / f"{tool['number']:02d}-{tool['slug']}"
        pack = root / tool_pack_name(tool)
        checksum = pack.with_name(pack.name + ".sha256")
        if not pack.is_file():
            issues.append(f"#{tool['number']:02d} {tool['slug']}: ZIP missing")
            continue
        if not checksum.is_file() or not checksum.read_text(encoding="utf-8").startswith(sha(pack)):
            issues.append(f"#{tool['number']:02d} {tool['slug']}: ZIP checksum mismatch")
        with zipfile.ZipFile(pack) as archive:
            names = [name for name in archive.namelist() if not name.endswith("/")]
            required = {"DOWNLOAD_README.md", "SHA256SUMS.txt", "tool.json"}
            missing = required - set(names)
            if missing:
                issues.append(f"#{tool['number']:02d} {tool['slug']}: generated files missing from ZIP {sorted(missing)}")
            if not any(name.upper().endswith(".MD") and "SPEC" in Path(name).name.upper() for name in names):
                issues.append(f"#{tool['number']:02d} {tool['slug']}: spec missing from ZIP")
            if not any(name.startswith("tests/test") and name.endswith(".py") for name in names):
                issues.append(f"#{tool['number']:02d} {tool['slug']}: tests missing from ZIP")
            if not any(name.startswith(f"{tool['package']}/") and name.endswith(".py") for name in names):
                issues.append(f"#{tool['number']:02d} {tool['slug']}: implementation package missing from ZIP")
        details.append({
            "number": tool["number"],
            "slug": tool["slug"],
            "version": tool["version"],
            "test_ledger": tool["tests"],
            "zip": pack.relative_to(ROOT).as_posix(),
            "sha256": sha(pack),
        })

    manifest_path = ARTIFACTS / "SIL_TOOL_LIBRARY_MANIFEST.json"
    full_pack = ARTIFACTS / full_panel_pack_name()
    if not manifest_path.is_file():
        issues.append("SIL manifest missing")
    else:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("library_version") != SIL_LIBRARY_VERSION:
            issues.append("SIL manifest version mismatch")
        if manifest.get("gauge_count") != 28 or len(manifest.get("tools", [])) != 28:
            issues.append("SIL manifest gauge count mismatch")
        if full_pack.is_file() and manifest.get("full_panel_sha256") != sha(full_pack):
            issues.append("SIL manifest full-panel hash mismatch")
    if not full_pack.is_file():
        issues.append("full SIL panel ZIP missing")
    else:
        checksum = full_pack.with_name(full_pack.name + ".sha256")
        if not checksum.is_file() or not checksum.read_text(encoding="utf-8").startswith(sha(full_pack)):
            issues.append("full SIL panel checksum mismatch")
        with zipfile.ZipFile(full_pack) as archive:
            top_gauges = {name.split("/", 1)[0] for name in archive.namelist() if "/" in name and name[:2].isdigit()}
            if len(top_gauges) != 28:
                issues.append(f"full SIL panel expected 28 gauge folders, found {len(top_gauges)}")
            if "SIL_TOOL_LIBRARY_MANIFEST.json" not in archive.namelist():
                issues.append("full SIL panel manifest missing inside ZIP")

    with tempfile.TemporaryDirectory(prefix="sil-library-repro-") as tmp:
        regenerated = Path(tmp) / "sil-tools"
        write_sil_tool_artifacts(SOURCE_TOOLS, regenerated)
        expected = tree_hashes(ARTIFACTS)
        observed = tree_hashes(regenerated)
        if expected != observed:
            missing = sorted(set(expected) - set(observed))
            extra = sorted(set(observed) - set(expected))
            changed = sorted(path for path in set(expected) & set(observed) if expected[path] != observed[path])
            issues.append(f"SIL artifacts are not deterministic: missing={missing[:5]}, extra={extra[:5]}, changed={changed[:5]}")

    report = {
        "schema": "project-shadow-sil-tool-library-contract-v1",
        "status": "PASS" if not issues else "FAIL",
        "library_version": SIL_LIBRARY_VERSION,
        "gauge_count": len(SIL_TOOLS),
        "details": details,
        "issues": issues,
        "scope": "SIL metadata, source presence, individual ZIP contents, hashes, full-panel bundle, manifest, and deterministic regeneration. This does not constitute independent validation.",
    }
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "sil-tool-library-contract.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
