#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
SITES = ROOT / "sites"
ARTIFACTS = ROOT / "public-artifacts"
VALIDATION = ROOT / "validation"

SECRET_PATTERNS = {
    "openai_style_key": re.compile(rb"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{20,}"),
    "anthropic_key": re.compile(rb"(?<![A-Za-z0-9])sk-ant-[A-Za-z0-9_-]{16,}"),
    "aws_access_key": re.compile(rb"(?<![A-Z0-9])AKIA[0-9A-Z]{16}(?![A-Z0-9])"),
    "github_token": re.compile(rb"(?<![A-Za-z0-9])gh[pousr]_[A-Za-z0-9]{20,}"),
    "slack_token": re.compile(rb"(?<![A-Za-z0-9])xox[baprs]-[A-Za-z0-9-]{10,}"),
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
}

# Construct these markers so the scanner does not flag its own source or the
# source-release copy of this test. They identify container paths, opaque
# chat-file identifiers, and the withheld raw-session archive family.
PRIVATE_MARKERS = [
    b"/mnt" + b"/data/",
    b"file_" + b"00000000",
    b"PROJECT_" + b"SHADOW_" + b"SESSION_",
]
PRIVATE_ARCHIVE_PREFIX = "PROJECT_" + "SHADOW_" + "SESSION_"

SUSPICIOUS_NAMES = {".env", "id_rsa", "id_ed25519"}
SUSPICIOUS_SUFFIXES = {".pem", ".key", ".p12", ".pfx"}
BINARY_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf", ".woff", ".woff2", ".pyc"}
SKIP_PARTS = {"__pycache__", ".git", ".venv", "node_modules"}


def should_skip_parts(parts: tuple[str, ...]) -> bool:
    return any(part in SKIP_PARTS for part in parts)


def scan_bytes(label: str, data: bytes, issues: list[dict]) -> None:
    for name, pattern in SECRET_PATTERNS.items():
        if pattern.search(data):
            issues.append({"location": label, "type": name})
    for marker in PRIVATE_MARKERS:
        if marker in data:
            issues.append(
                {
                    "location": label,
                    "type": "private_marker",
                    "marker": marker.decode("utf-8", errors="replace"),
                }
            )


def scan_file(path: Path, label: str, issues: list[dict]) -> None:
    if should_skip_parts(path.parts):
        return
    low = path.name.lower()
    if low in SUSPICIOUS_NAMES or path.suffix.lower() in SUSPICIOUS_SUFFIXES:
        issues.append({"location": label, "type": "suspicious_filename"})
    if path.suffix.lower() in BINARY_SUFFIXES:
        return
    try:
        scan_bytes(label, path.read_bytes(), issues)
    except OSError as exc:
        issues.append({"location": label, "type": "read_error", "detail": str(exc)})


def scan_zip(path: Path, issues: list[dict]) -> int:
    count = 0
    try:
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                name_path = PurePosixPath(info.filename)
                if should_skip_parts(name_path.parts):
                    continue
                count += 1
                low = name_path.name.lower()
                suffix = name_path.suffix.lower()
                if low in SUSPICIOUS_NAMES or suffix in SUSPICIOUS_SUFFIXES:
                    issues.append({"location": f"{path.name}!/{info.filename}", "type": "suspicious_filename"})
                if suffix in BINARY_SUFFIXES or suffix == ".zip":
                    continue
                try:
                    data = archive.read(info)
                except Exception as exc:
                    issues.append(
                        {
                            "location": f"{path.name}!/{info.filename}",
                            "type": "read_error",
                            "detail": str(exc),
                        }
                    )
                    continue
                scan_bytes(f"{path.name}!/{info.filename}", data, issues)
    except zipfile.BadZipFile as exc:
        issues.append({"location": path.name, "type": "bad_zip", "detail": str(exc)})
    return count


def main() -> int:
    issues: list[dict] = []
    files_scanned = 0
    zip_entries_scanned = 0

    for root in (ROOT / "source", ROOT / "docs", ROOT / "scripts", ROOT / "tests", SITES):
        for path in root.rglob("*"):
            if not path.is_file() or should_skip_parts(path.parts):
                continue
            files_scanned += 1
            scan_file(path, str(path.relative_to(ROOT)), issues)

    for path in sorted(ARTIFACTS.rglob("*")):
        if not path.is_file() or should_skip_parts(path.parts):
            continue
        files_scanned += 1
        if path.suffix.lower() == ".zip":
            zip_entries_scanned += scan_zip(path, issues)
        else:
            scan_file(path, str(path.relative_to(ROOT)), issues)

    # The public package must never contain a file whose name identifies the
    # withheld raw-session archive family.
    for path in ROOT.rglob("*"):
        if not path.is_file() or should_skip_parts(path.parts):
            continue
        if path.name.startswith(PRIVATE_ARCHIVE_PREFIX):
            issues.append({"location": str(path.relative_to(ROOT)), "type": "private_archive_present"})

    report = {
        "schema": "pbhp-shadow-public-boundary-scan-v1",
        "status": "PASS" if not issues else "FAIL",
        "files_scanned": files_scanned,
        "zip_entries_scanned": zip_entries_scanned,
        "issues": issues,
        "scope": (
            "Allowlisted public repository, generated Sites, and textual entries inside public ZIP artifacts. "
            "Build caches and binary media are excluded. Heuristic secret scanning does not replace a professional "
            "security or privacy review."
        ),
    }
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "public-boundary-scan.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
