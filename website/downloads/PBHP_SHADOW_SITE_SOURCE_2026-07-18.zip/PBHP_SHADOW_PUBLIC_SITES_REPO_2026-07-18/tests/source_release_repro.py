#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ZIP = ROOT / "public-artifacts" / "PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip"
VALIDATION = ROOT / "validation"
EXPECTED_ROOT = "PBHP_SHADOW_PUBLIC_SITES_REPO_2026-07-18"


def run(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    issues: list[str] = []
    original_sha = sha(SOURCE_ZIP)
    with tempfile.TemporaryDirectory(prefix="pbhp-shadow-source-repro-") as tmp:
        temp = Path(tmp)
        with zipfile.ZipFile(SOURCE_ZIP) as archive:
            archive.extractall(temp)
        extracted = temp / EXPECTED_ROOT
        if not extracted.exists():
            issues.append(f"Expected source root {EXPECTED_ROOT} missing")
        else:
            commands = [
                ["python", "scripts/build_component_artifacts.py"],
                ["python", "scripts/build_sil_tool_artifacts.py"],
                ["python", "scripts/build_shadow_complete_package.py"],
                ["python", "scripts/make_source_release.py"],
                ["python", "scripts/update_artifact_manifest.py"],
                ["bash", "scripts/build.sh"],
                ["python", "tests/content_contract.py"],
                ["python", "tests/component_library_contract.py"],
                ["python", "tests/sil_tool_library_contract.py"],
                ["python", "tests/shadow_complete_package_contract.py"],
                ["node", "--check", "source/static/app.js"],
                ["python", "tests/static_interaction_contract.py"],
            ]
            for command in commands:
                try:
                    run(command, extracted)
                except subprocess.CalledProcessError as exc:
                    issues.append(f"Command failed: {' '.join(command)} :: {exc.stderr[-1000:]}")
                    break
            regenerated = extracted / "public-artifacts" / SOURCE_ZIP.name
            if regenerated.exists() and sha(regenerated) != original_sha:
                issues.append("Regenerated source ZIP hash differs from the distributed source ZIP")
            link_report = extracted / "validation" / "link-report.json"
            if link_report.exists():
                rows = json.loads(link_report.read_text(encoding="utf-8"))
                if not all(row.get("pass") for row in rows):
                    issues.append(f"Extracted source link validation failed: {rows}")
            else:
                issues.append("Extracted source did not produce link-report.json")

    report = {
        "schema": "pbhp-shadow-source-release-repro-v1",
        "status": "PASS" if not issues else "FAIL",
        "source_zip": str(SOURCE_ZIP.relative_to(ROOT)),
        "sha256": original_sha,
        "issues": issues,
        "scope": "Clean temporary extraction, deterministic component/SIL/complete-package regeneration, deterministic source ZIP, site build, content and package contracts, JavaScript syntax, static interaction contract, and link validation.",
    }
    VALIDATION.mkdir(parents=True, exist_ok=True)
    (VALIDATION / "source-release-repro.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
