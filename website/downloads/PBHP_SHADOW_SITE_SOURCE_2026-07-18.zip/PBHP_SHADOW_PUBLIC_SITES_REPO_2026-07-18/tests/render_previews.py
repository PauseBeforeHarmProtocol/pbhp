#!/usr/bin/env python3
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from bs4 import BeautifulSoup
from weasyprint import CSS, HTML

ROOT = Path(__file__).resolve().parents[1]
SITES = ROOT / "sites"
PREVIEWS = ROOT / "previews"
VALIDATION = ROOT / "validation"

DESKTOP_CSS = """
@page { size: 1440px 1200px; margin: 0; }
html, body { width: 1440px; min-height: 1200px; }
html[data-theme="shadow"] body { background: #09111a !important; color: #edf5fb !important; }
html[data-theme="shadow"] .sidebar,
html[data-theme="shadow"] .mobile-header,
html[data-theme="shadow"] .hero,
html[data-theme="shadow"] .topline { background: #101b27 !important; }
html[data-theme="shadow"] .hero h1,
html[data-theme="shadow"] .hero strong,
html[data-theme="shadow"] .page-header h1 { color: #edf5fb !important; }
html[data-theme="shadow"] .hero .lede,
html[data-theme="shadow"] .hero p { color: #a7b8c5 !important; }
html[data-theme="shadow"] .hero__signal span { background: #142334 !important; color: #edf5fb !important; }

/* Component pages are sampled for static preview. Full-page content is covered by DOM and link contracts. */
.route-components .component-section:not(:first-of-type) { display: none !important; }
.route-components .component-grid > .component-card:nth-child(n+5) { display: none !important; }
.route-components .related-pages { display: none !important; }

.route-sil .gauge-grid > .gauge-card:nth-child(n+3) { display: none !important; }
.route-sil .related-pages { display: none !important; }

"""

MOBILE_CSS = """
@page { size: 390px 844px; margin: 0; }
html, body { width: 390px !important; min-height: 844px; }
html[data-theme="shadow"] body { background: #09111a !important; color: #edf5fb !important; }
html[data-theme="shadow"] .sidebar,
html[data-theme="shadow"] .mobile-header,
html[data-theme="shadow"] .hero,
html[data-theme="shadow"] .topline { background: #101b27 !important; }
html[data-theme="shadow"] .hero h1,
html[data-theme="shadow"] .hero strong,
html[data-theme="shadow"] .page-header h1 { color: #edf5fb !important; }
html[data-theme="shadow"] .hero .lede,
html[data-theme="shadow"] .hero p { color: #a7b8c5 !important; }
html[data-theme="shadow"] .hero__signal span { background: #142334 !important; color: #edf5fb !important; }

body { padding-bottom: 66px !important; font-size: 15px !important; }
.mobile-header { display: flex !important; position: static !important; height: 64px !important; padding: 0 14px !important; background: var(--surface) !important; }
.mobile-brand { display: block !important; flex: 1 1 auto !important; min-width: 0 !important; text-decoration: none !important; }
.mobile-brand span { display: block !important; font-size: 13px !important; font-weight: 850 !important; }
.mobile-brand small { display: block !important; font-size: 9px !important; }
.mobile-actions { display: flex !important; gap: 6px !important; }
.sidebar, .topline, .page-toc { display: none !important; }
.main-content { margin-left: 0 !important; padding: 0 13px 72px !important; }
.content-grid { display: block !important; }
.page-header { padding: 34px 0 20px !important; }
.mobile-dock { display: none !important; }
.command-dialog { display: none !important; }
.hero { margin-top: 14px !important; padding: 25px 20px !important; border-radius: 18px !important; }
.hero h1 { font-size: 52px !important; }
.status-strip { grid-template-columns: 1fr !important; }
.status-strip div { border-right: 0 !important; border-bottom: 1px solid var(--line) !important; }
.card-grid--2, .card-grid--3, .related-grid, .form-grid, .glossary, .gauge-controls, .gauge-grid, .component-controls, .component-grid, .test-status-summary, .test-matrix__row { grid-template-columns: 1fr !important; }
.component-library-summary, .component-bundle-launch { align-items: flex-start !important; flex-direction: column !important; }
.component-card__facts { grid-template-columns: 1fr !important; }
.project-family { grid-template-columns: 1fr !important; }

/* Component pages are sampled for static preview. Full-page content is covered by DOM and link contracts. */
.route-components .component-section:not(:first-of-type) { display: none !important; }
.route-components .component-grid > .component-card:nth-child(n+5) { display: none !important; }
.route-components .related-pages { display: none !important; }

.route-sil .gauge-grid > .gauge-card:nth-child(n+3) { display: none !important; }
.route-sil .related-pages { display: none !important; }

"""


def render(site: str, mode: str, css_text: str, route: str = "") -> dict:
    html_path = SITES / site / "index.html" if not route else SITES / site / route / "index.html"
    label = site if not route else f"{site}-{route}"
    out_png = PREVIEWS / f"{label}-{mode}.png"
    with tempfile.TemporaryDirectory(prefix="pbhp-shadow-render-") as tmp:
        pdf = Path(tmp) / f"{label}-{mode}.pdf"
        prefix = Path(tmp) / f"{label}-{mode}"
        if route in {"components", "sil"}:
            soup = BeautifulSoup(html_path.read_text(encoding="utf-8"), "html.parser")
            if route == "components":
                sections = soup.select(".component-section")
                for section in sections[1:]:
                    section.decompose()
                cards = soup.select(".component-grid > .component-card")
                for card in cards[1:]:
                    card.decompose()
            else:
                cards = soup.select(".gauge-grid > .gauge-card")
                for card in cards[2:]:
                    card.decompose()
            for related in soup.select(".related-pages"):
                related.decompose()
            document = HTML(string=str(soup), base_url=str(html_path.parent), media_type="screen")
        else:
            document = HTML(filename=str(html_path), base_url=str(html_path.parent), media_type="screen")
        document.write_pdf(str(pdf), stylesheets=[CSS(string=css_text)])
        subprocess.run(
            ["pdftoppm", "-f", "1", "-singlefile", "-png", "-r", "96", str(pdf), str(prefix)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        generated = prefix.with_suffix(".png")
        shutil.copy2(generated, out_png)
    return {"site": site, "route": route or "home", "mode": mode, "path": str(out_png.relative_to(ROOT)), "bytes": out_png.stat().st_size}


def main() -> int:
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    VALIDATION.mkdir(parents=True, exist_ok=True)
    jobs = [
        (site, mode, DESKTOP_CSS if mode == "desktop" else MOBILE_CSS, route)
        for site, routes in (("pbhp", ("", "components")), ("shadow", ("", "components", "sil")))
        for route in routes
        for mode in ("desktop", "mobile")
    ]
    with ProcessPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(render, *job) for job in jobs]
        results = [future.result() for future in futures]
    report = {
        "schema": "pbhp-shadow-visual-render-v1",
        "status": "PASS",
        "renders": results,
        "scope": "Static home and component-library visual render using WeasyPrint. This checks layout presence and legibility, not JavaScript behavior or exact Chromium rendering.",
    }
    (VALIDATION / "visual-render-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
