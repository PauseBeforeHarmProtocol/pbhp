#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "public-artifacts" / "PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip"
SHA = ROOT / "public-artifacts" / "PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip.sha256"

EXCLUDED_ROOTS = {".git", "previews", "releases", "sites", "validation"}
EXCLUDED_NAMES = {OUTPUT.name, SHA.name, "LATEST_RELEASE_MANIFEST.json"}

files: list[Path] = []
for path in ROOT.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT)
    if rel.parts[0] in EXCLUDED_ROOTS:
        continue
    if path.name in EXCLUDED_NAMES or any(part in {"__pycache__", ".pytest_cache"} for part in rel.parts):
        continue
    if path.suffix in {".pyc", ".pyo"}:
        continue
    files.append(path)

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        rel = Path("PBHP_SHADOW_PUBLIC_SITES_REPO_2026-07-18") / path.relative_to(ROOT)
        info = zipfile.ZipInfo(str(rel).replace("\\", "/"), date_time=(2026, 7, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (0o755 if path.suffix in {".sh", ".py"} else 0o644) << 16
        archive.writestr(info, path.read_bytes())

digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
SHA.write_text(f"{digest}  {OUTPUT.name}\n", encoding="utf-8")
print(f"created {OUTPUT} ({OUTPUT.stat().st_size} bytes)")
print(digest)
