#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python "$ROOT/tests/content_contract.py"
python "$ROOT/tests/component_library_contract.py"
python "$ROOT/tests/sil_tool_library_contract.py"
python "$ROOT/tests/shadow_complete_package_contract.py"
node --check "$ROOT/source/static/app.js"
python "$ROOT/tests/static_interaction_contract.py"
python "$ROOT/tests/source_release_repro.py"
python "$ROOT/tests/public_boundary_scan.py"
python "$ROOT/tests/render_previews.py"
python "$ROOT/tests/browser_smoke.py"
python - <<'PY' "$ROOT"
import json, pathlib, sys
root=pathlib.Path(sys.argv[1])
report=json.loads((root/'validation/link-report.json').read_text())
assert all(row['pass'] for row in report), report
components=json.loads((root/'validation/component-library-contract.json').read_text())
sil_tools=json.loads((root/'validation/sil-tool-library-contract.json').read_text())
shadow_package=json.loads((root/'validation/shadow-complete-package-contract.json').read_text())
assert components['status']=='PASS', components
assert sil_tools['status']=='PASS', sil_tools
assert shadow_package['status']=='PASS', shadow_package
static=json.loads((root/'validation/static-interaction-contract.json').read_text())
assert static['status']=='PASS', static
repro=json.loads((root/'validation/source-release-repro.json').read_text())
assert repro['status']=='PASS', repro
boundary=json.loads((root/'validation/public-boundary-scan.json').read_text())
assert boundary['status']=='PASS', boundary
visual=json.loads((root/'validation/visual-render-report.json').read_text())
assert visual['status']=='PASS', visual
browser=json.loads((root/'validation/browser-smoke.json').read_text())
assert browser['status'] in {'PASS','BLOCKED_ENVIRONMENT'}, browser
summary={
  'schema':'pbhp-shadow-release-validation-v1',
  'status':'PASS_WITH_OPEN_BROWSER_GATE' if browser['status']=='BLOCKED_ENVIRONMENT' else 'PASS',
  'link_validation':report,
  'component_library_contract':components['status'],
  'component_count':components['combined_component_count'],
  'sil_tool_library_contract':sil_tools['status'],
  'sil_gauge_count':sil_tools['gauge_count'],
  'shadow_complete_package_contract':shadow_package['status'],
  'static_interaction_contract':static['status'],
  'source_release_reproducibility':repro['status'],
  'public_boundary_scan':boundary['status'],
  'visual_render':visual['status'],
  'browser_smoke':browser['status'],
  'open_release_gates': browser.get('required_continuation',[]) if browser['status']=='BLOCKED_ENVIRONMENT' else [],
}
(root/'validation/release-validation-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
PY
