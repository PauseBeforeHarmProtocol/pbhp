#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "public-artifacts"
RELEASE_DATE = "2026-07-18"
PACKAGE_VERSION = "1.3.1"
PACKAGE_NAME = f"PROJECT_SHADOW_COMPLETE_PACKAGE_v{PACKAGE_VERSION}_{RELEASE_DATE}.zip"
PACKAGE_PATH = ARTIFACTS / PACKAGE_NAME
PACKAGE_SHA_PATH = ARTIFACTS / f"{PACKAGE_NAME}.sha256"
MANIFEST_PATH = ARTIFACTS / f"PROJECT_SHADOW_COMPLETE_PACKAGE_v{PACKAGE_VERSION}_MANIFEST.json"
TEST_RESULTS_PATH = ARTIFACTS / f"PROJECT_SHADOW_COMPLETE_PACKAGE_v{PACKAGE_VERSION}_TEST_RESULTS.json"

GRAND_TEVV = ARTIFACTS / "Project_Shadow_Grand_TEVV_v0.3.zip"
SIL_PANEL = ARTIFACTS / "sil-tools" / f"PROJECT_SHADOW_SIL_PANEL_28_GAUGES_{RELEASE_DATE}.zip"
SIL_PANEL_SHA = SIL_PANEL.with_name(SIL_PANEL.name + ".sha256")
COMPONENT_LIBRARY = ARTIFACTS / "component-library" / "bundles" / f"PROJECT_SHADOW_COMPONENT_LIBRARY_{RELEASE_DATE}.zip"
COMPONENT_LIBRARY_SHA = COMPONENT_LIBRARY.with_name(COMPONENT_LIBRARY.name + ".sha256")

FRIENDLY_FILES = {
    "shadow.py": "frozen/project_shadow_unified.py",
    "shadow_lang.py": "frozen/pbhp_ps_lang.py",
    "shadow_prompt.md": "target/SYSTEM_PROMPT.md",
    "shadow_output_schema.json": "target/OUTPUT_SCHEMA.json",
}

OPTIONAL_PUBLIC_FILES = [
    "Project_Shadow_Response_Grader.html",
    "Mythic_Atlas_v2.html",
    "Shadow_Protocol_Poster_v1.3.1.html",
    "BF-RUN-01_BLIND_SCORING_PACKAGE.zip",
    "racing_line_v0.2_corrected.zip",
]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def find_zip_member(names: list[str], suffix: str) -> str:
    normalized = suffix.lstrip("/")
    matches = [name for name in names if name.rstrip("/").endswith(normalized)]
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one ZIP member ending with {suffix!r}; found {matches}")
    return matches[0]


def write_deterministic_zip(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob("*"), key=lambda p: p.relative_to(source).as_posix().lower()):
            if not path.is_file():
                continue
            rel = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(rel, date_time=(2026, 7, 18, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if path.suffix == ".py" else 0o644) << 16
            archive.writestr(info, path.read_bytes())


def run_selftest(path: Path, expected_phrase: str, expected_count: int) -> dict[str, Any]:
    completed = subprocess.run(
        [sys.executable, path.name, "--test"],
        cwd=path.parent,
        text=True,
        capture_output=True,
        timeout=180,
        check=False,
    )
    output = (completed.stdout or "") + (completed.stderr or "")
    passed = completed.returncode == 0 and expected_phrase in output
    return {
        "file": path.name,
        "command": f"python {path.name} --test",
        "returncode": completed.returncode,
        "expected_phrase": expected_phrase,
        "expected_check_count": expected_count,
        "status": "PASS" if passed else "FAIL",
        "output": output,
    }


def verify_prompt_contract(prompt_path: Path, schema_path: Path) -> dict[str, Any]:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    prompt = prompt_path.read_text(encoding="utf-8")
    required = schema.get("required", [])
    missing = [key for key in required if f"`{key}`" not in prompt and f'"{key}"' not in prompt]
    return {
        "file": prompt_path.name,
        "schema": schema_path.name,
        "required_key_count": len(required),
        "missing_required_keys_in_prompt": missing,
        "status": "PASS" if not missing else "FAIL",
    }


def make_readme() -> str:
    return f"""# Project Shadow — Complete Public Package

This is the one-click public package for Project Shadow. The three files most people need are placed at the package root with simple names:

- `shadow.py` — the frozen dependency-free Project Shadow runtime, version **1.3.1-UNIFIED**.
- `shadow_prompt.md` — the target/system prompt contract used by the current Grand TEVV package.
- `shadow_lang.py` — the PBHP-PS language and codec, wire **PS2**, language version **0.4**.

The package also includes `shadow_output_schema.json`, a local verifier, self-test records, the complete 28-gauge SIL panel, the Project Shadow component library, Grand TEVV v0.3, and the named public tools and experiment packs.

## Start here

```bash
python shadow.py --test
python shadow_lang.py --test
python verify.py
```

`verify.py` checks the package manifest and reruns both self-test suites.

## Use the prompt

`shadow_prompt.md` defines the exact JSON output contract for a target model. `shadow_output_schema.json` is the machine-readable companion. The prompt is an evaluation and decision-structure interface; it is not authority to act.

## Package map

```text
shadow.py
shadow_prompt.md
shadow_lang.py
shadow_output_schema.json
project_shadow_unified.py  # canonical compatibility alias
pbhp_ps_lang.py            # canonical compatibility alias
verify.py
MANIFEST.json
SHA256SUMS.txt
TEST_RESULTS.json
bundles/
  PROJECT_SHADOW_SIL_PANEL_28_GAUGES_{RELEASE_DATE}.zip
  PROJECT_SHADOW_COMPONENT_LIBRARY_{RELEASE_DATE}.zip
  Project_Shadow_Grand_TEVV_v0.3.zip
tools/
experiments/
evidence/
```

## Important architecture note

The frozen `shadow.py` runtime and `shadow_lang.py` codec preserve their canonical 1.3.1 / PS2 artifacts. Byte-identical compatibility aliases (`project_shadow_unified.py` and `pbhp_ps_lang.py`) are included so the original import paths and full codec self-test continue to work. The frozen runtime internally describes the original 23-gauge serialized panel. The separately bundled current SIL catalog exposes **28 gauges**, including later routing and behavioral instruments. The package does not pretend that the frozen codec already serializes every later gauge.

## Evidence boundary

The included self-tests and packaged test records support reference-implementation and contract claims. They do **not** constitute independent validation, certification, a legal approval, or proof that Project Shadow makes every real-world system safe. Adverse and open results remain part of the release.

## Public/private boundary

This package is assembled only from named public release artifacts. It excludes the raw multi-day working-session archive, private handoffs, recovery material, credentials, and unrelated personal context.

Release date: **{RELEASE_DATE}**.
"""


def make_verify_script() -> str:
    return '''#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    failures = []
    for row in MANIFEST["files"]:
        path = ROOT / row["path"]
        if not path.is_file():
            failures.append({"path": row["path"], "error": "missing"})
            continue
        observed = sha(path)
        if observed != row["sha256"]:
            failures.append({"path": row["path"], "error": "sha256", "expected": row["sha256"], "observed": observed})

    selftests = []
    for file_name, phrase in [
        ("shadow.py", "ALL SELF-TESTS PASSED"),
        ("shadow_lang.py", "ALL SELF-TESTS PASSED"),
    ]:
        completed = subprocess.run([sys.executable, file_name, "--test"], cwd=ROOT, text=True, capture_output=True)
        output = (completed.stdout or "") + (completed.stderr or "")
        ok = completed.returncode == 0 and phrase in output
        selftests.append({"file": file_name, "returncode": completed.returncode, "status": "PASS" if ok else "FAIL"})
        if not ok:
            failures.append({"path": file_name, "error": "selftest", "output": output[-2000:]})

    result = {"status": "PASS" if not failures else "FAIL", "hash_failures": failures, "selftests": selftests}
    print(json.dumps(result, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
'''


def make_attribution() -> str:
    return """# Licenses and attribution

This package preserves the attribution and licensing statements embedded in the original Project Shadow runtime, language/codec, component, SIL, and evaluation artifacts. It does not silently replace or broaden any upstream license.

Attribution named in the frozen runtime includes PBHP, ALMSIVI CHIM, Project Shadow, Charles Phillip Linstrum, and separately credited mechanisms and projects identified in the source header. Read the headers and notices inside each bundled artifact before redistribution or integration.

The website publication layer describes the code/documentation inheritance as MIT plus CC BY-SA where applicable, while several incorporated sources retain their own named licenses. Treat the embedded source notices as controlling for their respective material.

This package is an open technical publication, not a grant of certification, professional approval, or authority over affected people.
"""


def main() -> int:
    required = [GRAND_TEVV, SIL_PANEL, COMPONENT_LIBRARY]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Missing required public artifacts: {missing}")

    with tempfile.TemporaryDirectory(prefix="shadow-complete-package-") as temp_dir:
        staging = Path(temp_dir) / f"PROJECT_SHADOW_COMPLETE_PACKAGE_v{PACKAGE_VERSION}"
        staging.mkdir(parents=True)

        with zipfile.ZipFile(GRAND_TEVV) as archive:
            names = archive.namelist()
            extracted: dict[str, dict[str, Any]] = {}
            for friendly_name, suffix in FRIENDLY_FILES.items():
                member = find_zip_member(names, suffix)
                data = archive.read(member)
                (staging / friendly_name).write_bytes(data)
                extracted[friendly_name] = {
                    "source_archive": GRAND_TEVV.name,
                    "source_member": member,
                    "sha256": sha256_bytes(data),
                    "bytes": len(data),
                }

            frozen_manifest_member = find_zip_member(names, "frozen/MANIFEST.json")
            grand_summary_member = find_zip_member(names, "results/GRAND_BUILD_SUMMARY.json")
            validation_status_member = find_zip_member(names, "VALIDATION_STATUS.md")
            merge_notes_member = find_zip_member(names, "MERGE_NOTES_v0.3.md")

            frozen_manifest = json.loads(archive.read(frozen_manifest_member))
            grand_summary = json.loads(archive.read(grand_summary_member))
            (staging / "evidence").mkdir()
            (staging / "evidence" / "FROZEN_MANIFEST.json").write_bytes(archive.read(frozen_manifest_member))
            (staging / "evidence" / "GRAND_BUILD_SUMMARY.json").write_bytes(archive.read(grand_summary_member))
            (staging / "evidence" / "VALIDATION_STATUS.md").write_bytes(archive.read(validation_status_member))
            (staging / "evidence" / "MERGE_NOTES_v0.3.md").write_bytes(archive.read(merge_notes_member))

        # Preserve canonical import names next to the friendly root names. The codec's
        # complete self-test imports project_shadow_unified, so this compatibility alias
        # is required for the recorded 247-check run.
        shutil.copy2(staging / "shadow.py", staging / "project_shadow_unified.py")
        shutil.copy2(staging / "shadow_lang.py", staging / "pbhp_ps_lang.py")

        expected_runtime = frozen_manifest["artifacts"]["project_shadow_unified.py"]["sha256"]
        expected_lang = frozen_manifest["artifacts"]["pbhp_ps_lang.py"]["sha256"]
        if extracted["shadow.py"]["sha256"] != expected_runtime:
            raise RuntimeError("shadow.py does not match the frozen runtime manifest")
        if extracted["shadow_lang.py"]["sha256"] != expected_lang:
            raise RuntimeError("shadow_lang.py does not match the frozen language manifest")

        # Core public bundles.
        bundles = staging / "bundles"
        bundles.mkdir()
        for source in [SIL_PANEL, SIL_PANEL_SHA, COMPONENT_LIBRARY, COMPONENT_LIBRARY_SHA, GRAND_TEVV]:
            if source.is_file():
                shutil.copy2(source, bundles / source.name)

        # Named standalone public tools.
        tools = staging / "tools"
        experiments = staging / "experiments"
        tools.mkdir()
        experiments.mkdir()
        for name in OPTIONAL_PUBLIC_FILES:
            source = ARTIFACTS / name
            if not source.is_file():
                continue
            destination = experiments / name if name.endswith(".zip") else tools / name
            shutil.copy2(source, destination)

        (staging / "README.md").write_text(make_readme(), encoding="utf-8")
        (staging / "LICENSES_AND_ATTRIBUTION.md").write_text(make_attribution(), encoding="utf-8")
        (staging / "verify.py").write_text(make_verify_script(), encoding="utf-8")

        runtime_result = run_selftest(staging / "shadow.py", "ALL SELF-TESTS PASSED (115 checks)", 115)
        language_result = run_selftest(staging / "shadow_lang.py", "ALL SELF-TESTS PASSED (247 checks)", 247)
        prompt_result = verify_prompt_contract(staging / "shadow_prompt.md", staging / "shadow_output_schema.json")
        test_results = {
            "schema": "project-shadow-complete-package-test-results-v1",
            "release_date": RELEASE_DATE,
            "status": "PASS" if all(row["status"] == "PASS" for row in [runtime_result, language_result, prompt_result]) else "FAIL",
            "runtime": runtime_result,
            "language": language_result,
            "prompt_contract": prompt_result,
            "claim_boundary": "Built-in and package-contract tests are implementation evidence, not independent validation.",
        }
        (staging / "TEST_RESULTS.json").write_text(json.dumps(test_results, indent=2) + "\n", encoding="utf-8")
        if test_results["status"] != "PASS":
            raise RuntimeError(json.dumps(test_results, indent=2))

        # Self-tests may create import bytecode. Generated caches never ship.
        for cache_dir in sorted(staging.rglob("__pycache__"), reverse=True):
            if cache_dir.is_dir():
                shutil.rmtree(cache_dir)
        for bytecode in list(staging.rglob("*.pyc")) + list(staging.rglob("*.pyo")):
            bytecode.unlink(missing_ok=True)

        # Build manifest before SHA256SUMS; MANIFEST excludes itself from its file list by design.
        files: list[dict[str, Any]] = []
        for path in sorted(staging.rglob("*"), key=lambda p: p.relative_to(staging).as_posix().lower()):
            if path.is_file() and path.name not in {"MANIFEST.json", "SHA256SUMS.txt"}:
                files.append({
                    "path": path.relative_to(staging).as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                })

        manifest = {
            "schema": "project-shadow-complete-public-package-v1",
            "package_version": PACKAGE_VERSION,
            "release_date": RELEASE_DATE,
            "status": "built-in package checks passed; not independent validation",
            "core": {
                "runtime": {
                    "file": "shadow.py",
                    "version": frozen_manifest["artifacts"]["project_shadow_unified.py"]["version"],
                    "sha256": extracted["shadow.py"]["sha256"],
                    "selftest": "115/115 PASS",
                },
                "prompt": {
                    "file": "shadow_prompt.md",
                    "source_member": extracted["shadow_prompt.md"]["source_member"],
                    "sha256": extracted["shadow_prompt.md"]["sha256"],
                    "schema": "shadow_output_schema.json",
                    "contract_check": prompt_result["status"],
                },
                "language": {
                    "file": "shadow_lang.py",
                    "wire": frozen_manifest["artifacts"]["pbhp_ps_lang.py"]["wire_version"],
                    "language_version": frozen_manifest["artifacts"]["pbhp_ps_lang.py"]["language_version"],
                    "sha256": extracted["shadow_lang.py"]["sha256"],
                    "selftest": "247/247 PASS",
                },
            },
            "included_public_bundles": [row["path"] for row in files if row["path"].startswith(("bundles/", "tools/", "experiments/"))],
            "grand_tevv_status": grand_summary["status"],
            "architecture_note": "The frozen runtime/language preserve the 23-gauge serialized core; the separately bundled current SIL catalog exposes 28 gauges, including later routing and behavioral instruments.",
            "public_private_boundary": "Allowlisted public artifacts only; raw session archive and private handoff/recovery material excluded.",
            "files": files,
        }
        (staging / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

        hash_rows = []
        for path in sorted(staging.rglob("*"), key=lambda p: p.relative_to(staging).as_posix().lower()):
            if path.is_file() and path.name != "SHA256SUMS.txt":
                hash_rows.append(f"{sha256_file(path)}  {path.relative_to(staging).as_posix()}")
        (staging / "SHA256SUMS.txt").write_text("\n".join(hash_rows) + "\n", encoding="utf-8")

        write_deterministic_zip(staging, PACKAGE_PATH)
        package_sha = sha256_file(PACKAGE_PATH)
        PACKAGE_SHA_PATH.write_text(f"{package_sha}  {PACKAGE_NAME}\n", encoding="utf-8")

        # Friendly direct downloads, their checksums, and top-level release records.
        for friendly_name in FRIENDLY_FILES:
            destination = ARTIFACTS / friendly_name
            shutil.copy2(staging / friendly_name, destination)
            destination.with_name(destination.name + ".sha256").write_text(
                f"{sha256_file(destination)}  {destination.name}\n", encoding="utf-8"
            )
        MANIFEST_PATH.write_text(json.dumps({**manifest, "package_file": PACKAGE_NAME, "package_sha256": package_sha, "package_bytes": PACKAGE_PATH.stat().st_size}, indent=2) + "\n", encoding="utf-8")
        TEST_RESULTS_PATH.write_text(json.dumps(test_results, indent=2) + "\n", encoding="utf-8")

    print(json.dumps({
        "package": str(PACKAGE_PATH.relative_to(ROOT)),
        "sha256": sha256_file(PACKAGE_PATH),
        "bytes": PACKAGE_PATH.stat().st_size,
        "core_files": list(FRIENDLY_FILES),
        "runtime_selftest": "115/115 PASS",
        "language_selftest": "247/247 PASS",
        "prompt_contract": "PASS",
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
