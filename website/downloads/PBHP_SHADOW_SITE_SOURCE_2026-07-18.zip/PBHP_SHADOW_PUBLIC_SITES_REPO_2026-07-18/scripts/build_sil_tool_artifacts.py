#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))

from sil_catalog import write_sil_tool_artifacts  # noqa: E402


def main() -> int:
    source_root = ROOT / "source" / "sil-tools"
    output_root = ROOT / "public-artifacts" / "sil-tools"
    manifest = write_sil_tool_artifacts(source_root, output_root)
    print(json.dumps({
        "output": str(output_root.relative_to(ROOT)),
        "library_version": manifest["library_version"],
        "gauge_count": manifest["gauge_count"],
        "full_panel_file": manifest["full_panel_file"],
        "full_panel_sha256": manifest["full_panel_sha256"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
