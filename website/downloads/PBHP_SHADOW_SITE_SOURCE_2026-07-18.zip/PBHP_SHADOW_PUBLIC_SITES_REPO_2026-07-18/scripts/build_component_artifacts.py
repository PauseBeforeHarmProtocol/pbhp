#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))

from component_catalog import write_component_artifacts  # noqa: E402


def main() -> int:
    output = ROOT / "public-artifacts" / "component-library"
    manifest = write_component_artifacts(output)
    print(json.dumps({
        "output": str(output.relative_to(ROOT)),
        "component_library_version": manifest["component_library_version"],
        "combined_component_count": manifest["combined_component_count"],
        "bundle_count": len(manifest["bundles"]),
        "file_count": len(manifest["files"]),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
