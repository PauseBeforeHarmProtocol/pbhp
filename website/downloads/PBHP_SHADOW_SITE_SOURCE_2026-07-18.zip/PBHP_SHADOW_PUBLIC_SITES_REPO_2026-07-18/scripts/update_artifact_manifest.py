#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "public-artifacts"
OUTPUT = ARTIFACTS / "LATEST_RELEASE_MANIFEST.json"
COMPONENT_MANIFEST = ARTIFACTS / "component-library" / "PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json"

rows = []
for path in sorted(ARTIFACTS.rglob("*"), key=lambda p: str(p.relative_to(ARTIFACTS)).lower()):
    if not path.is_file() or path == OUTPUT:
        continue
    rows.append(
        {
            "file": str(path.relative_to(ARTIFACTS)).replace("\\", "/"),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    )

component_summary = None
if COMPONENT_MANIFEST.exists():
    component_manifest = json.loads(COMPONENT_MANIFEST.read_text(encoding="utf-8"))
    component_summary = {
        "version": component_manifest["component_library_version"],
        "combined_component_count": component_manifest["combined_component_count"],
        "manifest": str(COMPONENT_MANIFEST.relative_to(ARTIFACTS)).replace("\\", "/"),
    }

manifest = {
    "schema": "pbhp-shadow-public-artifact-manifest-v2",
    "generated": "2026-07-18",
    "publication_policy": "allowlisted public artifacts only; raw session archive excluded",
    "canonical": {
        "pbhp_public_repo": "https://github.com/PauseBeforeHarmProtocol/pbhp",
        "pbhp_repository_declared_version": "0.9.5",
        "pbhp_latest_tag_observed": "0.9.0",
        "shadow_runtime": "1.3.1-UNIFIED",
        "shadow_grand_tevv": "0.3",
    },
    "component_library": component_summary,
    "files": rows,
    "excluded": [
        "raw private Project Shadow session archive",
        "private recovery material",
        "chat-local handoffs containing non-public context",
    ],
}
OUTPUT.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(f"updated {OUTPUT} with {len(rows)} allowlisted files")
