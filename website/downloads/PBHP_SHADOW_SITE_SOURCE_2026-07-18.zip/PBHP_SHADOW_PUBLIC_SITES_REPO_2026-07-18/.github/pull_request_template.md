## Change

Describe the exact pages, components, artifacts, claims, or controls changed.

## Evidence state

- [ ] Specified
- [ ] Expected
- [ ] Observed
- [ ] Adverse
- [ ] Open

Explain why the selected state is accurate. Do not promote evidence merely because code passes.

## Component and release control

- [ ] Updated the component source entry where applicable.
- [ ] Regenerated `README.md`, `component.json`, `TEST_PLAN.md`, packs, checksums, and manifests.
- [ ] Preserved adverse and null results.
- [ ] Kept runtime, TEVV, component-library, website, and upstream PBHP versions separate.
- [ ] Reviewed the public/private allowlist.

## Validation

- [ ] `python scripts/build_component_artifacts.py`
- [ ] `python scripts/make_source_release.py`
- [ ] `python scripts/update_artifact_manifest.py`
- [ ] `bash scripts/build.sh`
- [ ] `bash scripts/validate.sh`
- [ ] Authenticated desktop and phone preview reviewed before deployment.

## Deployment

- [ ] Save a candidate version first.
- [ ] Deploy only to the existing Site project and slug.
- [ ] Verify production routes and downloads.
- [ ] Record the release receipt and remaining open gates.
