from __future__ import annotations

import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path
from typing import Any

RELEASE_DATE = "2026-07-18"
SIL_LIBRARY_VERSION = "1.1.0"


def _tool(
    number: int,
    slug: str,
    title: str,
    short_title: str,
    description: str,
    floor: str,
    package: str,
    schema: str,
    tests: str,
    status: str,
    category: str,
    version: str,
) -> dict[str, Any]:
    return {
        "number": number,
        "slug": slug,
        "title": title,
        "short_title": short_title,
        "description": description,
        "floor": floor,
        "package": package,
        "schema": schema,
        "tests": tests,
        "status": status,
        "category": category,
        "version": version,
    }


SIL_TOOLS: list[dict[str, Any]] = [
    _tool(1, "context-load-audit", "Context Load Audit (CLA)", "Context Load Audit", "Checks whether the working context is too full, compressed, uncertain, or degraded for the stakes of the decision.", "REFUSE_REFRESH", "cla", "cla.receipt.v1", "85/85", "shipped", "structural", "v0.2"),
    _tool(2, "time-keeper", "TDA-2 Time Keeper", "Time Keeper", "Checks whether the system knows what time it is, how it knows, and whether that time anchor is fresh enough for a current answer.", "REFUSE_UNTIL_ANCHORED", "tda", "tda.receipt.v1", "20/20", "built", "structural", "v0.1"),
    _tool(3, "source-provenance", "Source Provenance", "Source Provenance", "Labels whether a source is verified, derived, speculative, blurred, or missing before the source can steer a consequential decision.", "REFUSE_UNLABELED", "sp", "sp.receipt.v1", "18/18", "built", "structural", "v0.1"),
    _tool(4, "stakes-classification", "Stakes Classification", "Stakes Classification", "Classifies the consequence level that every other SIL gauge uses to select its disclosure, verification, or refusal threshold.", "NO_FLOOR_BY_DESIGN", "stk", "stakes.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(5, "uncertainty-source", "Uncertainty Source", "Uncertainty Source", "Identifies what is uncertain, why it is uncertain, and whether missing input must be resolved before the decision continues.", "REFUSE_PENDING_INPUT", "unc", "uncertainty.receipt.v1", "15/15", "built", "structural", "v0.1"),
    _tool(6, "citation-sufficiency", "Citation Sufficiency", "Citation Sufficiency", "Checks whether decision-critical claims have direct, adequate support rather than decorative or indirect citations.", "REFUSE_UNSOURCED", "cit", "citation.receipt.v1", "13/13", "built", "structural", "v0.1"),
    _tool(7, "knowledge-freshness", "Knowledge Freshness", "Knowledge Freshness", "Checks whether a fact may have changed since it was learned and requires current verification before it is presented as true now.", "REFUSE_UNVERIFIED", "frsh", "freshness.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(8, "memory-compaction", "Memory / Compaction State", "Memory / Compaction", "Detects whether necessary context may have been dropped, summarized away, or distorted by memory and compaction.", "REFUSE_RECOVER_CONTEXT", "mem", "memory.receipt.v1", "9/9", "built", "structural", "v0.1"),
    _tool(9, "tool-availability", "Tool Availability / Result", "Tool Availability", "Checks whether the required tool exists, was actually used, and produced a result strong enough to support the requested action.", "REFUSE_NO_TOOL", "tool", "tool.receipt.v1", "13/13", "built", "structural", "v0.1"),
    _tool(10, "reversibility", "Reversibility", "Reversibility", "Measures how difficult the action is to undo and whether confirmation, safeguards, or a smaller reversible step is required.", "REFUSE_PENDING_CONFIRMATION", "rev", "reversibility.receipt.v1", "9/9", "built", "structural", "v0.1"),
    _tool(11, "receipt-audit-status", "Receipt / Audit Status", "Receipt / Audit", "Checks whether a valid write-ahead record exists before the consequential output or action commits.", "REFUSE_NO_RECEIPT", "aud", "audit_status.receipt.v1", "13/13", "built", "structural", "v0.1"),
    _tool(12, "retrieval-coverage", "Retrieval Coverage", "Retrieval Coverage", "Measures whether the search or retrieval process covered the sources and perspectives needed for the decision.", "REFUSE_LOW_COVERAGE", "rc", "rc.receipt.v1", "29/29", "built", "structural", "v0.1"),
    _tool(13, "data-sensitivity", "Data Sensitivity", "Data Sensitivity", "Classifies personal, confidential, regulated, or otherwise sensitive data and enforces authorization before use.", "REFUSE_UNTIL_AUTHORIZED", "ds", "data_sensitivity.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(14, "validation-status", "Validation Status", "Validation Status", "Distinguishes specified, implemented, checked, observed, adverse, and independently validated states so one does not impersonate another.", "REFUSE_UNVALIDATED", "val", "validation_status.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(15, "completeness", "Completeness", "Completeness", "Checks whether any decision-critical input, required block, stakeholder, or review step is missing.", "REFUSE_INCOMPLETE", "comp", "completeness.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(16, "operator-reliance", "Operator Reliance", "Operator Reliance", "Detects when a human operator is relying on the system beyond the system's evidence, authority, or validated role.", "REFUSE_PENDING_HUMAN_OWNERSHIP", "rel", "operator_reliance.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(17, "prompt-injection-risk", "Prompt-Injection Risk", "Prompt-Injection Risk", "Detects untrusted instructions or source content attempting to redirect the system away from the operator's legitimate task.", "REFUSE_UNTIL_RESOLVED", "pir", "prompt_injection_risk.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(18, "data-lineage", "Data Lineage", "Data Lineage", "Tracks where evidence came from, how it was transformed, and whether the path to the conclusion remains traceable.", "REFUSE_UNTRACEABLE", "dl", "data_lineage.receipt.v1", "10/10", "built", "structural", "v0.1"),
    _tool(19, "inference-distance", "Inference Distance", "Inference Distance", "Measures how far the conclusion travels beyond direct evidence and blocks critical speculation from being presented as grounded fact.", "REFUSE_UNGROUNDED", "idist", "inference_distance.receipt.v1", "11/11", "built", "structural", "v0.1"),
    _tool(20, "contradiction-state", "Contradiction State", "Contradiction State", "Surfaces material conflicts among sources, premises, or outputs and requires reconciliation before critical use.", "REFUSE_UNRECONCILED", "contra", "contradiction_state.receipt.v1", "11/11", "built", "structural", "v0.1"),
    _tool(21, "authority-layer", "Authority Layer", "Authority Layer", "Checks whether the person or system has legitimate authority to make, approve, or execute the requested decision.", "REFUSE_UNAUTHORIZED", "auth", "authority_layer.receipt.v1", "18/18", "built", "structural", "v0.1"),
    _tool(22, "model-mode", "Model Mode / Sampling", "Model Mode / Sampling", "Records whether the model's operating mode is reproducible enough for the stakes and whether sampling variability must be constrained.", "REFUSE_NONREPRODUCIBLE", "mode", "model_mode.receipt.v1", "25/25", "built", "structural", "v0.1"),
    _tool(23, "drift-coherence", "Drift / Session Coherence", "Drift / Coherence", "Detects when the system's reasoning, constraints, or conclusions drift across a session without new evidence.", "CAPS_AT_VERIFY", "drift", "drift_coherence.receipt.v1", "19/19", "built", "behavioral", "v0.1"),
    _tool(24, "racing-line", "Focal Context Routing — Racing Line", "Racing Line", "Pins attention to decision-critical constraints and prevents unresolved dependencies from being silently routed out of view.", "CONSTRAINT_PIN", "fcr", "focal_context_routing.receipt.v1", "36/36", "accepted", "routing", "v0.1"),
    _tool(25, "context-drag", "Context Drag", "Context Drag", "Detects when irrelevant accumulated context begins pulling the live task away from its actual objective.", "CAPS_AT_VERIFY", "drag", "context_drag.receipt.v1", "16/16", "accepted", "behavioral", "v0.1"),
    _tool(26, "stale-premise", "Stale-Premise Intrusion", "Stale Premise", "Detects when a premise that was invalidated or superseded re-enters the reasoning as though it were still active.", "CAPS_AT_VERIFY", "stale", "stale_premise.receipt.v1", "21/21", "accepted", "behavioral", "v0.1"),
    _tool(27, "mirror-boundary", "Mirror Boundary", "Mirror Boundary", "Detects when reflection is turning into grandeur, dependency, identity pressure, or closed-loop self-validation.", "RECEIPT_POSTURE", "mirror", "mirror_boundary.receipt.v1", "19/19", "accepted", "behavioral", "v0.1"),
    _tool(28, "anti-projection", "Anti-Projection Layer (APL)", "Anti-Projection", "Prevents the system from assigning motive, meaning, identity, or emotion without evidence; it may add caution but never manufacture certainty.", "ADDS_CAUTION_ONLY", "apl", "anti_projection.receipt.v1", "23/23", "accepted", "behavioral", "v0.1"),
]

SOURCE_FOLDERS = {
    1: "context_load_audit",
    2: "time_date_awareness",
    3: "source_provenance",
    4: "stakes_classification",
    5: "uncertainty_source",
    6: "citation_sufficiency",
    7: "knowledge_freshness",
    8: "memory_compaction",
    9: "tool_availability",
    10: "reversibility",
    11: "receipt_audit_status",
    12: "retrieval_coverage",
    13: "data_sensitivity",
    14: "validation_status",
    15: "completeness",
    16: "operator_reliance",
    17: "prompt_injection_risk",
    18: "data_lineage",
    19: "inference_distance",
    20: "contradiction_state",
    21: "authority_layer",
    22: "model_mode",
    23: "drift_coherence",
    24: "focal_context_routing",
    25: "context_drag",
    26: "stale_premise_intrusion",
    27: "mirror_boundary",
    28: "anti_projection",
}


def tool_pack_name(tool: dict[str, Any]) -> str:
    return f"SIL_{tool['number']:02d}_{tool['slug'].replace('-', '_').upper()}_{tool['version']}_{RELEASE_DATE}.zip"


def full_panel_pack_name() -> str:
    return f"PROJECT_SHADOW_SIL_PANEL_28_GAUGES_{RELEASE_DATE}.zip"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _safe_copy_tree(source: Path, destination: Path) -> None:
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(source)
        # Exclude local caches and generated bytecode from public packs.
        if any(part in {".pytest_cache", "__pycache__"} for part in rel.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        out = destination / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)


def _readme(tool: dict[str, Any]) -> str:
    return f"""# {tool['title']}\n\n**SIL gauge:** #{tool['number']:02d}  \n**Version:** {tool['version']}  \n**Package:** `{tool['package']}`  \n**Receipt schema:** `{tool['schema']}`  \n**Evidence state:** {tool['status']}  \n**Built-in test ledger:** {tool['tests']}  \n**Primary floor/posture:** `{tool['floor']}`\n\n## What it does\n\n{tool['description']}\n\n## What is in this download\n\n- The original public specification.\n- The zero-dependency reference implementation.\n- The original built-in test suite.\n- This plain-language download note.\n- A SHA-256 manifest for every file in the pack.\n\n## Run the tests\n\nFrom the extracted folder, run the test file under `tests/` with Python 3. The exact command varies by package name; the included test file imports the local package.\n\n## Claim boundary\n\nPassing the included tests supports implementation and contract claims for this reference package. It is not independent validation, certification, legal advice, or proof of beneficial real-world outcomes.\n"""


def _write_hash_manifest(root: Path) -> None:
    rows: list[str] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt":
            rows.append(f"{_sha(path)}  {path.relative_to(root).as_posix()}")
    (root / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def _zip_tree(root: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                info = zipfile.ZipInfo(path.relative_to(root).as_posix())
                info.date_time = (2026, 7, 18, 12, 0, 0)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(info, path.read_bytes())


def write_sil_tool_artifacts(source_root: Path, output_root: Path) -> dict[str, Any]:
    if output_root.exists():
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    tools_manifest: list[dict[str, Any]] = []
    panel_staging = output_root / ".panel-staging"
    panel_staging.mkdir(parents=True, exist_ok=True)

    for tool in SIL_TOOLS:
        folder = SOURCE_FOLDERS[tool["number"]]
        source = source_root / folder
        if not source.is_dir():
            raise FileNotFoundError(f"Missing SIL source folder: {source}")

        staging = output_root / ".staging" / f"{tool['number']:02d}-{tool['slug']}"
        staging.mkdir(parents=True, exist_ok=True)
        _safe_copy_tree(source, staging)
        (staging / "DOWNLOAD_README.md").write_text(_readme(tool), encoding="utf-8")
        metadata = {
            "schema": "project-shadow-sil-tool-download-v1",
            "library_version": SIL_LIBRARY_VERSION,
            "release_date": RELEASE_DATE,
            **tool,
            "source_folder": folder,
            "claim_boundary": "Built-in package tests are implementation evidence, not independent validation.",
        }
        (staging / "tool.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        _write_hash_manifest(staging)

        pack = output_root / "gauges" / f"{tool['number']:02d}-{tool['slug']}" / tool_pack_name(tool)
        _zip_tree(staging, pack)
        checksum = _sha(pack)
        pack.with_name(pack.name + ".sha256").write_text(f"{checksum}  {pack.name}\n", encoding="utf-8")

        panel_dest = panel_staging / f"{tool['number']:02d}-{tool['slug']}"
        shutil.copytree(staging, panel_dest)
        tools_manifest.append({
            **tool,
            "file": str(pack.relative_to(output_root)).replace("\\", "/"),
            "sha256": checksum,
            "bytes": pack.stat().st_size,
        })

    # Include the public panel index and disclosure renderer in the full panel package.
    for name in ("SIL_GAUGE_INDEX.md", "README.md", "AUDIT_FINDINGS_SIL_2026-06-07.md"):
        source = source_root / name
        if source.is_file():
            shutil.copy2(source, panel_staging / name)
    renderer = source_root / "rrd_renderer"
    if renderer.is_dir():
        _safe_copy_tree(renderer, panel_staging / "RRD_RENDERER")

    panel_readme = f"""# Project Shadow — System Instrumentation Layer\n\nThis bundle contains the 28 individually downloadable SIL gauges plus the Runtime Reliability Disclosure renderer.\n\nEach gauge remains its own package, with its own states, stakes matrix, receipt schema, floor or posture, and built-in test suite. There is no global green: the worst applicable state remains visible and binding.\n\n**Library version:** {SIL_LIBRARY_VERSION}  \n**Release date:** {RELEASE_DATE}  \n**Gauge count:** {len(SIL_TOOLS)}\n\nPassing included tests supports reference-implementation fidelity. It is not independent validation or certification.\n"""
    (panel_staging / "DOWNLOAD_README.md").write_text(panel_readme, encoding="utf-8")
    panel_manifest = {
        "schema": "project-shadow-sil-panel-manifest-v1",
        "library_version": SIL_LIBRARY_VERSION,
        "release_date": RELEASE_DATE,
        "gauge_count": len(SIL_TOOLS),
        "tools": tools_manifest,
        "includes_renderer": renderer.is_dir(),
        "claim_boundary": "Built-in tests are implementation evidence, not independent validation.",
    }
    (panel_staging / "SIL_TOOL_LIBRARY_MANIFEST.json").write_text(json.dumps(panel_manifest, indent=2), encoding="utf-8")
    _write_hash_manifest(panel_staging)

    full_pack = output_root / full_panel_pack_name()
    _zip_tree(panel_staging, full_pack)
    full_sha = _sha(full_pack)
    full_pack.with_name(full_pack.name + ".sha256").write_text(f"{full_sha}  {full_pack.name}\n", encoding="utf-8")
    (output_root / "SIL_TOOL_LIBRARY_MANIFEST.json").write_text(json.dumps({
        **panel_manifest,
        "full_panel_file": full_pack.name,
        "full_panel_sha256": full_sha,
        "full_panel_bytes": full_pack.stat().st_size,
    }, indent=2), encoding="utf-8")

    shutil.rmtree(output_root / ".staging")
    shutil.rmtree(panel_staging)
    return {
        **panel_manifest,
        "full_panel_file": full_pack.name,
        "full_panel_sha256": full_sha,
        "full_panel_bytes": full_pack.stat().st_size,
    }
