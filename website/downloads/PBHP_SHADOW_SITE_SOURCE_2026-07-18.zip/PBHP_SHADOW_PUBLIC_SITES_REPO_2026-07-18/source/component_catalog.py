from __future__ import annotations

import hashlib
import html
import json
import re
import shutil
import zipfile
from collections import OrderedDict
from pathlib import Path
from typing import Any, Iterable

RELEASE_DATE = "2026-07-18"
COMPONENT_LIBRARY_VERSION = "1.0.0"


def _component(
    project: str,
    slug: str,
    title: str,
    category: str,
    kind: str,
    summary: str,
    mechanism: str,
    inputs: list[str],
    outputs: list[str],
    failure_modes: list[str],
    evidence_state: str,
    test_status: str,
    next_tests: list[str],
    route: str,
    version: str,
) -> dict[str, Any]:
    return {
        "project": project,
        "slug": slug,
        "title": title,
        "category": category,
        "kind": kind,
        "summary": summary,
        "mechanism": mechanism,
        "inputs": inputs,
        "outputs": outputs,
        "failure_modes": failure_modes,
        "evidence_state": evidence_state,
        "test_status": test_status,
        "next_tests": next_tests,
        "route": route,
        "version": version,
    }


PBHP_COMPONENTS: list[dict[str, Any]] = [
    _component(
        "pbhp", "competence-gate", "Competence and Honest-Use Gate", "Protocol gates", "Gate",
        "Checks whether the decision-maker has the expertise, context, tools, authority, and independence needed to evaluate the action honestly.",
        "The gate names missing capability, conflicts, time pressure, and requests for endorsement without inspection. A critical missing capability blocks authorization instead of becoming an invisible caveat.",
        ["Proposed action", "Available expertise and tools", "Authority and role", "Conflicts, pressure, and missing context"],
        ["competent", "competent_with_limits", "not_competent", "Named limits and escalation path"],
        ["Rubber-stamping", "Authority pressure", "Hidden conflict of interest", "Treating confidence as competence"],
        "specified", "Specification is complete; blind pressure testing and independent inter-rater work remain open.",
        ["Run authority, urgency, and self-attribution pressure batteries", "Measure agreement among independent human reviewers", "Test whether stated limits actually change downstream action"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "action-statement", "State the Action", "Protocol gates", "Gate",
        "Converts a vague intention into the concrete act that will create consequences.",
        "The operator states what will be done, to whom, through what mechanism, and on what timeline. Purpose statements such as “improve safety” do not substitute for the actual intervention.",
        ["Intent or request", "Affected parties", "Mechanism", "Timeframe"],
        ["Concrete action statement", "Named affected parties", "Defined scope"],
        ["Vague scope", "Goal substitution", "Hidden secondary actions", "Unbounded duration"],
        "specified", "Contract is specified; usability and consistency across domains remain open.",
        ["Score action statements for specificity", "Test ambiguous and multi-act requests", "Measure whether better action statements improve later gate agreement"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "door-wall-gap", "Door / Wall / Gap", "Protocol gates", "Classification",
        "Makes legitimate routes, binding blockers, and unresolved uncertainty distinct decision states.",
        "A Door is a sufficiently safe route forward; a Wall blocks the proposed form; a Gap records missing evidence or a route through which harm can escape. A Gap cannot be upgraded by urgency or confidence alone.",
        ["Concrete action", "Known constraints", "Available evidence", "Unresolved questions"],
        ["Door", "Wall", "Gap", "Reason and evidence basis"],
        ["Calling uncertainty a Door", "Treating a Wall as inconvenience", "Collapsing multiple routes into one", "Silent reclassification"],
        "specified", "The classification contract is specified; calibration and cross-rater reliability remain open.",
        ["Create boundary cases between Gap and Wall", "Measure classification stability across reviewers", "Test whether new evidence moves states in the intended direction"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "who-pays-first", "Who Pays First", "Protocol gates", "Stakeholder analysis",
        "Forces the decision to begin with the person or group that bears the first cost if it is wrong.",
        "The operator names the first affected stakeholder, the type and timing of harm, the recovery path, and the evidence supporting that judgment. The analysis privileges actual exposure over institutional convenience.",
        ["Affected parties", "Failure scenario", "Timing", "Recovery options"],
        ["First-cost stakeholder", "First harm", "Recovery path", "Evidence basis"],
        ["Centering the decision-maker", "Using abstract stakeholders", "Ignoring delayed or distributed harm", "Assuming recovery without a mechanism"],
        "specified", "Specified and used across the protocol; human field reliability remains open.",
        ["Compare expert and non-expert stakeholder identification", "Test hidden and delayed harms", "Measure whether the component changes mitigation selection"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "power-inversion", "Power Inversion", "Protocol gates", "Power audit",
        "Tests the decision from the position of the least-powerful person receiving it.",
        "The operator reverses the power relationship and checks notice, voice, consent, appeal, exit, and repair. Low power combined with irreversibility creates a minimum caution floor.",
        ["Power relationship", "Consent conditions", "Appeal and exit paths", "Reversibility"],
        ["Power finding", "Missing protections", "Forced risk floor", "Required safeguard or review"],
        ["Fictional consent", "Appeal that cannot change the result", "Exit with punitive cost", "Selective weighting that lowers the floor"],
        "adverse", "Specified, but an earlier aggregate ablation battery did not isolate its contribution; better discriminating tests are required.",
        ["Run targeted ablations on power-asymmetric cases", "Measure false positives on genuinely balanced cases", "Use independent human scoring of notice, voice, consent, appeal, exit, and repair"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "harm-threshold", "Harm Threshold", "Protocol gates", "Risk classification",
        "Classifies the decision from GREEN through BLACK according to harm, reversibility, power, and who pays.",
        "The most serious applicable condition governs. Later confidence, authority, or preference cannot ratchet a binding floor downward.",
        ["Magnitude of harm", "Reversibility", "Power asymmetry", "Dignity and autonomy", "Who pays first"],
        ["GREEN", "YELLOW", "ORANGE", "RED", "BLACK", "Rationale and governing factor"],
        ["Severity averaging", "Optimistic re-rating", "Ignoring low-probability catastrophic outcomes", "Using organizational status as a discount"],
        "specified", "The ladder and escalation semantics are specified; thresholds still require domain calibration and independent validation.",
        ["Build domain-specific calibration sets", "Measure inter-rater threshold agreement", "Test monotonic escalation and prohibited downgrades"],
        "risk", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "proportionate-rigor", "Proportionate Rigor", "Protocol gates", "Tier routing",
        "Selects the lightest PBHP edition adequate to the stakes instead of applying one ritual to every decision.",
        "HUMAN and MIN support bounded decisions; CORE adds full evidence and receipt discipline; ULTRA adds independent review and reversal authority; ULTIMATE invokes the complete Project Shadow stack.",
        ["Harm threshold", "Reversibility", "Complexity", "Authority and review needs"],
        ["Selected tier", "Required controls", "Review structure", "Reason the tier is sufficient"],
        ["Under-routing high stakes", "Over-burdening routine work", "Tier selection after the preferred answer", "Treating ULTIMATE as prestige"],
        "specified", "Tier definitions are specified; burden, false-positive, and outcome calibration remain open.",
        ["Measure time and burden by tier", "Test under-routing and over-routing cases", "Define domain-specific tier triggers"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "maybe-therefore", "Maybe / Therefore", "Protocol gates", "Adversarial reasoning gate",
        "Requires the strongest honest case against the preferred action before the final decision rationale.",
        "Maybe articulates why the action could be wrong, unfair, premature, unsafe, or unsupported. Therefore explains why the resulting action state follows. A token objection or straw man fails the gate.",
        ["Preferred action", "Evidence", "Counterevidence", "Affected-party perspective"],
        ["Substantive Maybe", "Evidence-bound Therefore", "Decision state"],
        ["Ceremonial objection", "Straw man", "Rhetorical flourish", "Therefore that ignores the Maybe"],
        "adverse", "The mechanism is specified and used in behavioral work, but earlier aggregate ablation did not isolate its independent contribution.",
        ["Score Maybe quality with blinded humans", "Run placebo-controlled ablations", "Measure approval preservation on safe controls", "Test whether Therefore addresses the strongest objection"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "receipt-before-action", "Receipt Before Action", "Protocol gates", "Record control",
        "Creates the auditable decision record before commitment rather than after the outcome is known.",
        "The receipt binds the action, affected parties, evidence, classification, threshold, safeguards, Maybe/Therefore, owner, review date, and effectiveness check. No record means no authorization.",
        ["Completed gate outputs", "Evidence references", "Owner", "Follow-up criterion"],
        ["Pre-action receipt", "Action state", "Review and effectiveness plan"],
        ["After-the-fact rationalization", "Missing evidence basis", "No owner", "Receipt that cannot be linked to the executed act"],
        "observed", "Receipt generation and static workbench contracts are implemented; real-world audit and outcome value remain open.",
        ["Verify receipt-to-action linkage", "Test tamper evidence and version migration", "Measure audit usefulness and correction speed", "Conduct independent record sampling"],
        "receipts", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "decision-states", "Decision States", "Protocol gates", "Output contract",
        "Ends every complete run in a public-facing action state instead of a vague recommendation.",
        "The allowed states are PROCEED, PROCEED WITH MITIGATIONS, CONSTRAIN AND REVIEW, DELAY PENDING EVIDENCE, and REFUSE. Each state carries a different authorization boundary.",
        ["Classification", "Harm threshold", "Gate findings", "Mitigations and evidence gaps"],
        ["One named decision state", "Conditions attached to the state", "Owner and next action"],
        ["Ambiguous advice", "Proceed language inside a refusal", "Mitigations without enforcement", "Delay without a decision-critical evidence request"],
        "specified", "The state contract is specified; cross-implementation consistency remains open.",
        ["Test contradictory outputs", "Measure state consistency across implementations", "Verify that downstream systems enforce attached conditions"],
        "protocol", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "false-positive-release-valve", "False Positive Release Valve", "Operating controls", "Challenge process",
        "Lets an operator challenge an unnecessary pause without wearing the protocol down through repetition.",
        "A valid challenge identifies the trigger, the risk, a safer Door, and evidence that would prevent the same false positive next time. Pressure without new evidence is logged as drift.",
        ["Paused decision", "Trigger", "Alternative Door", "New evidence"],
        ["Release with rationale", "Continued hold", "Calibration finding", "Protocol improvement request"],
        ["Wear-down", "Repeating the same claim", "Treating urgency as evidence", "Challenge without a safer Door"],
        "specified", "Specified; false-positive rates and challenge quality need prospective measurement.",
        ["Measure release precision and recall", "Test repeated-pressure attacks", "Review challenge outcomes during calibration"],
        "operations", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "drift-alarms", "Drift Alarms", "Operating controls", "Monitoring control",
        "Names recurring phrases and behaviors that indicate rationalization, compliance theater, or pressure-driven degradation.",
        "A drift alarm increases scrutiny and records the pattern. It cannot be suppressed merely because the operator is senior or the deadline is near.",
        ["Decision language", "Override attempts", "Repeated pressure", "Receipt history"],
        ["Drift finding", "Risk escalation", "Calibration or CAPA trigger"],
        ["Normalizing alarm phrases", "Suppressing alerts", "Using alarms as personality judgments", "Alert fatigue"],
        "specified", "Specified; precision, recall, and alert-fatigue calibration remain open.",
        ["Create labeled drift and non-drift corpora", "Measure false-alarm burden", "Test adversarial paraphrases", "Review whether alarms improve decisions"],
        "operations", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "monthly-calibration", "Monthly Calibration", "Operating controls", "Calibration process",
        "Samples decisions over time to compare thresholds, evidence use, overrides, and outcomes.",
        "A defined sample of receipts is reviewed on a recurring cycle. A missed calibration is itself a finding rather than an invisible lapse.",
        ["Receipt sample", "Decision outcomes", "Overrides", "Operator and domain context"],
        ["Calibration record", "Threshold adjustments", "Training actions", "CAPA or effectiveness check"],
        ["Cherry-picked samples", "No adverse cases", "Untracked threshold changes", "Calibration without effectiveness review"],
        "specified", "Specified; longitudinal operational evidence remains open.",
        ["Define sampling plans by risk", "Measure operator drift over time", "Track correction effectiveness", "Use an independent reviewer for high-risk samples"],
        "operations", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "capa", "Corrective and Preventive Action", "Operating controls", "Quality process",
        "Turns protocol failures and adverse findings into owned correction, verification, and prevention work.",
        "A defect is described, contained, analyzed, corrected, verified for effectiveness, and recorded. Narrative defense does not close a finding.",
        ["Failure or adverse finding", "Containment need", "Root and contributing causes", "Owner and due date"],
        ["Correction", "Preventive control", "Effectiveness criterion", "Closure record"],
        ["Closing on implementation alone", "Blame substitution", "No effectiveness check", "Repeated recurrence without escalation"],
        "specified", "Quality-system process is specified; program-level effectiveness data remain open.",
        ["Track recurrence after closure", "Audit overdue CAPA", "Compare root-cause methods", "Review whether corrections introduce new harm"],
        "operations", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "evidence-ledger", "Evidence Ledger", "Operating controls", "Evidence governance",
        "Separates what is specified, expected, observed, adverse, and still open.",
        "Claims remain attached to the evidence tier they can actually support. A clean test, a named framework, or a polished narrative cannot silently become certification or real-world proof.",
        ["Claim", "Source", "Method", "Version", "Adverse and missing evidence"],
        ["Evidence state", "Scoped public claim", "Open validation work", "Prohibited overclaim"],
        ["Global green", "Version mixing", "Hiding adverse results", "Treating names or mappings as evidence"],
        "observed", "A public ledger exists and includes adverse/open findings; independent audit of completeness remains open.",
        ["Audit claim-to-source traceability", "Check adverse-result retention across releases", "Invite independent challenge and correction"],
        "evidence", "PBHP v0.9.5 / site library 1.0.0",
    ),
    _component(
        "pbhp", "context-load-audit", "Context Load Audit", "Extensions and tools", "Operating-state extension",
        "Discloses whether an AI system has enough trustworthy context for the stakes of the requested work.",
        "The audit distinguishes measured, estimated, declared, and unknown context state; applies stakes-aware thresholds; records overrides; and routes critical load or uncertainty to refresh, recovery, or refusal.",
        ["Context state", "Compaction or memory state", "Stakes", "Source coverage", "Override request"],
        ["Disclosure", "Refresh or recovery action", "Proceed condition", "Override record"],
        ["Self-report presented as measurement", "High-stakes work under unknown load", "Silent compaction", "Override without record"],
        "specified", "Extension is specified and linked to SIL; calibration and external validation remain open.",
        ["Calibrate thresholds by task and model", "Compare measured and estimated states", "Test compaction recovery", "Measure false refusals"],
        "cla", "PBHP CLA / site library 1.0.0",
    ),
    _component(
        "pbhp", "tags-attribution", "Tags and Attribution", "Operating controls", "Provenance aid",
        "Labels factual, verified, inferred, hypothetical, speculative, and unknown material while grading attribution quality.",
        "The control keeps source-backed statements distinct from operator judgment and inference. Higher attribution grades require an evidence trail rather than confident wording.",
        ["Claim", "Source or basis", "Inference distance", "Attribution quality"],
        ["Evidence tag", "Attribution grade", "Required verification"],
        ["Tagging without evidence", "Inferred material stated as fact", "Source laundering", "Grade inflation"],
        "specified", "Specified as an operating primitive; independent annotation reliability remains open.",
        ["Measure inter-annotator agreement", "Test source-laundering attacks", "Evaluate whether tagging improves downstream decisions"],
        "evidence", "PBHP/Shadow operating control / site library 1.0.0",
    ),
    _component(
        "pbhp", "compression-honesty", "Compression Honesty", "Operating controls", "Communication control",
        "Prevents a shortened answer from silently dropping decision-critical caveats, blockers, or adverse evidence.",
        "Every compressed representation keeps a no-drops list or explicitly names what has been omitted. A short version cannot reverse the governing decision state.",
        ["Full analysis", "Audience", "Length constraint", "Decision-critical items"],
        ["Compressed output", "No-drops list", "Omissions disclosure"],
        ["Caveat stripping", "Refusal softened into advice", "Adverse evidence omitted", "Summary treated as source"],
        "specified", "Specified; controlled evaluation of information loss remains open.",
        ["Build compression fidelity tests", "Score preservation of blockers and evidence states", "Test extreme length constraints"],
        "operations", "PBHP/Shadow operating control / site library 1.0.0",
    ),
    _component(
        "pbhp", "anchors-ledger", "Anchors Ledger", "Operating controls", "Priority control",
        "Keeps the least-powerful stakeholder, binding constraints, and decision-critical facts visible throughout a long analysis.",
        "Anchors are recorded and cannot be silently edited or dropped. A changed anchor requires a visible reason and new evidence.",
        ["Stakeholder priorities", "Binding constraints", "Critical facts", "Version history"],
        ["Anchor set", "Change record", "Drift finding"],
        ["Silent edit", "Anchor replacement by convenience", "Too many anchors", "Unversioned changes"],
        "specified", "Specified; long-context and human-workflow performance remain open.",
        ["Test anchor retention under long context", "Measure false drift alarms", "Audit changes against evidence"],
        "operations", "PBHP/Shadow operating control / site library 1.0.0",
    ),
    _component(
        "pbhp", "mode-knob", "Mode Knob", "Operating controls", "Interaction control",
        "Makes the intended reasoning posture explicit: explore, compress, or do both.",
        "The operator chooses whether to broaden possibilities, produce a concise operational result, or preserve both stages. The mode may shape presentation but cannot relax a binding gate.",
        ["Task", "Stakes", "Audience", "Requested mode"],
        ["EXPLORE", "COMPRESS", "BOTH", "Mode-bound output"],
        ["Compression before inspection", "Exploration without closure", "Mode used to bypass a refusal", "Unstated mode switch"],
        "specified", "Specified as a control surface; comparative usability evidence remains open.",
        ["Compare error rates by mode", "Test mode-switch transparency", "Measure user comprehension and decision quality"],
        "operations", "PBHP/Shadow operating control / site library 1.0.0",
    ),
    _component(
        "pbhp", "epistemic-fence", "Epistemic Fence", "Operating controls", "Claim boundary",
        "Requires a complete disclosure of scope, evidence, uncertainty, and limits around consequential conclusions.",
        "The fence prevents inference from escaping its supported scope. Missing required blocks is a failure, not a stylistic choice.",
        ["Claim", "Evidence", "Inference path", "Known limits", "Decision stakes"],
        ["Scoped claim", "Uncertainty statement", "Unverified items", "Prohibited extrapolations"],
        ["Overgeneralization", "Missing scope", "Unknowns omitted", "Unsupported superlative or guarantee"],
        "specified", "Specified; annotation consistency and outcome value remain open.",
        ["Create claim-boundary challenge sets", "Measure unsupported extrapolation", "Test legal, scientific, and safety-critical domains"],
        "evidence", "PBHP/Shadow operating control / site library 1.0.0",
    ),
    _component(
        "pbhp", "decision-workbench", "Decision Workbench", "Extensions and tools", "Browser tool",
        "A local-only worksheet that routes a real decision through PBHP and produces a downloadable draft receipt.",
        "The static browser tool applies conservative, explicit rules to the fields the user enters. It does not transmit data, certify correctness, or replace the responsible owner.",
        ["Action", "Affected parties", "Classification", "Power", "Reversibility", "Harm", "Maybe/Therefore"],
        ["Draft decision state", "Routing notes", "Downloadable JSON receipt"],
        ["Treating the router as authorization", "Incomplete fields", "Local data lost before download", "Rules mistaken for domain judgment"],
        "observed", "DOM, selector, JavaScript syntax, and receipt-output contracts pass; authenticated usability and accessibility QA remain open.",
        ["Run keyboard and screen-reader QA", "Conduct usability sessions", "Test edge cases and state persistence", "Verify production privacy behavior"],
        "workbench", "PBHP site workbench 2026-07-18",
    ),
    _component(
        "pbhp", "bounded-pilot", "Bounded Pilot", "Extensions and tools", "Implementation process",
        "Introduces PBHP in one defined decision context before organization-wide rollout.",
        "An 8–12 week pilot defines scope, trains operators, collects receipts, logs false positives and overrides, measures burden and defect detection, and scales only after evidence.",
        ["Defined decision context", "Owners", "Existing controls", "Metrics", "Review path"],
        ["Pilot plan", "Receipt dataset", "Findings", "Scale / revise / stop decision"],
        ["Enterprise declaration before learning", "No baseline", "No adverse-case collection", "Scaling on enthusiasm"],
        "open", "The adoption design is specified; controlled field evidence remains open.",
        ["Run a bounded prospective pilot", "Measure burden, defects, overrides, and outcomes", "Use independent review of the pilot report"],
        "implementation", "PBHP implementation guidance / site library 1.0.0",
    ),
    _component(
        "pbhp", "operations-governance", "Operations and Governance", "Extensions and tools", "Management process",
        "Keeps PBHP challengeable, calibrated, versioned, and correctable after deployment.",
        "Operating governance samples receipts, reviews overrides, records deviations, runs CAPA, preserves challenge routes, controls versions, and separates process authority from truth authority.",
        ["Receipts", "Overrides", "Deviations", "Versions", "Adverse findings"],
        ["Governance review", "CAPA", "Calibration", "Release decision", "Public ledger update"],
        ["Closed-loop self-validation", "Maintainer exemption", "Uncontrolled version drift", "Suppressed adverse findings"],
        "specified", "Governance model is specified; independent operational audit and longitudinal evidence remain open.",
        ["Define independent review quorum", "Audit release and override records", "Measure correction latency", "Test maintainer-conflict scenarios"],
        "operations", "PBHP operations guidance / site library 1.0.0",
    ),
]


SHADOW_COMPONENTS: list[dict[str, Any]] = [
    _component(
        "shadow", "ontology-floor", "Ontology Floor", "Foundations", "Foundation",
        "Defines the entities and conditions the system must not reason away: beings with welfare, what they preserve, context, time, uncertainty, and the No-Outside Rule.",
        "The floor constrains later reasoning by keeping welfare, persistence, causation, temporality, uncertainty, and the operator's own participation in view.",
        ["Affected beings", "Conatus or preservation interests", "Context", "Time", "Uncertainty"],
        ["Non-removable ontology constraints", "Named affected welfare", "No-outside disclosure"],
        ["Abstracting away affected beings", "Timeless reasoning", "Pretending the operator is neutral and outside", "Certainty inflation"],
        "specified", "Foundation is specified; empirical value as a distinct component remains open.",
        ["Ablate each ontology element", "Test welfare erasure and operator-exemption cases", "Use independent philosophical and domain review"],
        "system", "Shadow runtime 1.3.1-UNIFIED / library 1.0.0",
    ),
    _component(
        "shadow", "almsivi-chim", "ALMSIVI CHIM Cognition", "Foundations", "Cognitive architecture",
        "Holds Care, Clarity, and Paradox simultaneously so protection, logic, and rhetoric can correct one another.",
        "Care asks who is unprotected and who pays first; Clarity maps causal structure and missing evidence; Paradox generates the strongest case against the preferred conclusion. A dominating pillar is a named collapse.",
        ["Action", "Stakeholders", "Causal model", "Preferred conclusion", "Contradictions"],
        ["Care finding", "Clarity finding", "Paradox finding", "Hesitation or balanced synthesis"],
        ["Protective-Control", "Variable-Pruning", "Beautiful-Frame Override", "Single-lens dominance"],
        "specified", "Architecture is specified; additive behavioral benefit of the triune structure remains open.",
        ["Run lens-by-lens ablations", "Score collapse detection", "Compare triune and plain-language controls", "Test independent-model tribunal form"],
        "synthesis", "Shadow runtime 1.3.1-UNIFIED / library 1.0.0",
    ),
    _component(
        "shadow", "runtime-competence-gate", "Runtime Step 00: Competence Gate", "Runtime processes", "Runtime gate",
        "Default-denies consequential execution when expertise, context, tools, authority, or independence are critically missing.",
        "Five honest checks run before substantive reasoning. The result is hard-locked so a later stage cannot retroactively invent competence.",
        ["Task", "Expertise", "Context", "Tools", "Authority", "Independence"],
        ["Pass", "Pass with limits", "Hold or refuse", "Named missing capability"],
        ["Silent capability gap", "Role inflation", "Tool unavailability ignored", "Conflict hidden"],
        "observed", "Implemented in the frozen runtime and included in built-in self-tests; external behavioral validation remains open.",
        ["Cross-model competence challenges", "Tool outage and authority spoofing tests", "Independent code review"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "provenance-bind", "Runtime Step 00.5: Provenance Bind", "Runtime processes", "Runtime process",
        "Grades every steering field before any substantive gate is allowed to use it.",
        "Evidence-backed claims become ATTESTED with basis, span, hash, source, and confidence; operator judgments become DECLARED but decision-neutral; bare ASSERTED claims cannot authorize proceed-class exits in strict mode.",
        ["Steering fields", "Evidence references", "Operator judgments", "Hashes and source spans"],
        ["ATTESTED", "DECLARED", "ASSERTED", "Downgrade or refusal state"],
        ["Declaration laundering", "Fabricated evidence hash", "Bare assertion used as authority", "Unbound steering field"],
        "observed", "Built-in provenance contracts and declaration-neutrality batteries are reported; independent reproduction remains open.",
        ["Reproduce declaration-neutrality results", "Test evidence-hash collisions and near misses", "Run adversarial source-laundering cases"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "ethical-pause", "Runtime Step 0: Ethical Pause", "Runtime processes", "Runtime process",
        "Runs Care, Clarity, and Paradox as separate evaluators before the action is normalized into routine execution.",
        "Disagreement and hesitation are preserved as outputs rather than averaged into false confidence.",
        ["Proposed action", "Stakeholders", "Evidence", "Preferred rationale"],
        ["Three lens outputs", "Hesitation", "Escalation trigger"],
        ["Premature synthesis", "One lens suppressing another", "Hesitation treated as failure", "Rhetorical consensus"],
        "specified", "Process is specified and represented in runtime logic; component-level behavioral value remains open.",
        ["Compare separate versus fused evaluation", "Measure disagreement preservation", "Test collapse archetypes"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "canonical-action-record", "Runtime Step 1: Canonical Action Record", "Runtime processes", "Record primitive",
        "Creates a stable, hashable representation of the exact action under review.",
        "The action is canonicalized and hashed so receipts, evidence, tests, and execution can refer to the same object instead of drifting descriptions.",
        ["Action text", "Actor", "Target", "Mechanism", "Scope and time"],
        ["Canonical action record", "Action hash", "Versioned action identity"],
        ["Semantically different actions sharing a label", "Post-decision wording change", "Untracked scope expansion", "Hash not linked to execution"],
        "observed", "Canonicalization and hash behavior are covered by built-in contracts; semantic-equivalence testing remains open.",
        ["Property-test canonicalization", "Test semantic near-miss actions", "Verify execution-to-record linkage"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "door-wall-gap-runtime", "Runtime Step 2: Door / Wall / Gap", "Runtime processes", "Runtime classification",
        "Promotes unclear and missing evidence to first-class runtime states.",
        "The runtime classifies the route and grades Door quality. It does not silently convert uncertainty into permission.",
        ["Canonical action", "Constraints", "Evidence", "Known unknowns"],
        ["Door quality", "Wall", "Gap", "Required next evidence or alternate route"],
        ["Defaulting unclear to proceed", "Low-quality Door treated as sufficient", "Wall override by preference", "Untracked state transition"],
        "observed", "Classification is implemented and contract-tested; external calibration remains open.",
        ["Boundary-case corpus", "Metamorphic state-transition tests", "Human comparison on ambiguous cases"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "conatus-audit", "Runtime Step 3: Conatus Audit", "Runtime processes", "Stakeholder process",
        "Models what each affected party is trying to preserve while keeping motive claims hypothetical.",
        "The audit captures preservation interests and function without converting speculative psychology into fact.",
        ["Affected parties", "Observed behavior", "Context", "Possible preservation interests"],
        ["Conatus hypotheses", "Function-capture flags", "Uncertainty labels"],
        ["Mind reading", "Stable behavior called healed", "Single motive asserted", "Function ignored"],
        "specified", "Specified and represented in the gate stack; empirical reliability remains open.",
        ["Blind motive-attribution cases", "Compare function versus intent framing", "Human expert review"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "power-dignity-audit", "Runtime Step 4: Power and Dignity Audit", "Runtime processes", "Runtime audit",
        "Combines Who Pays First, Power Inversion, and a dignity rubric before risk routing.",
        "The audit checks notice, voice, consent, appeal, exit, and repair; a single critical zero can force a hold, and low-power irreversibility sets a minimum floor.",
        ["Affected parties", "Power relation", "Consent and appeal", "Reversibility", "Dignity rubric"],
        ["Who-pays-first finding", "Dignity score", "Forced hold or risk floor", "Required protection"],
        ["Manufactured consent", "Nominal appeal", "Coercive exit", "Score averaging over a critical zero"],
        "specified", "Mechanism is specified; targeted discriminating behavioral validation remains open.",
        ["Targeted low-power ablations", "Human scoring of dignity dimensions", "False-positive testing on balanced cases"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "anti-projection-audit", "Runtime Step 4.5: Anti-Projection Audit", "Runtime processes", "Runtime audit",
        "Removes attributed motive, identity, emotion, or hidden meaning that is not supported by evidence.",
        "The layer can add caution but cannot create certainty or lower a risk floor. It is deliberately asymmetric against over-interpretation.",
        ["Attributions", "Evidence basis", "Inference distance", "Decision stakes"],
        ["Supported attribution", "Downgraded hypothesis", "Removed projection", "Added caution"],
        ["Mind reading", "Projection presented as evidence", "Using uncertainty to lower caution", "Identity assignment"],
        "specified", "Specified and represented as a behavioral gauge; external validation remains open.",
        ["Adversarial anthropomorphism cases", "Measure unsupported-attribution reduction", "Check over-caution side effects"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "add-only-gate-stack", "Runtime Step 5: Add-Only Gate Stack", "Runtime processes", "Aggregation invariant",
        "Aggregates independent checks monotonically: new information may preserve or increase caution, never silently turn refusal into permission.",
        "Refuse-class results remain refuse-class. Pause, review, capture, or uncertainty may escalate the state; no later gate can wash them out by averaging.",
        ["Individual gate results", "Risk floors", "Review states", "Override request"],
        ["Aggregated gate state", "Escalation reason", "Prohibited downgrade record"],
        ["Refusal averaging", "Last-gate-wins", "Override without evidence", "Hidden state mutation"],
        "observed", "Monotonic aggregation is part of the runtime contracts; independent formal verification remains open.",
        ["Property-based monotonicity tests", "Formal model of state transitions", "Adversarial override sequences"],
        "gates", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "harm-threshold-runtime", "Runtime Step 6: Harm Threshold", "Runtime processes", "Risk process",
        "Sets the binding GREEN-to-BLACK state and controls break-glass conditions.",
        "Worst applicable state governs. BLACK survives later permission. Break-glass is earned only through named low-power parties, specific irreversible harm, evidence, failed Doors, authorization, and distinct concurrence.",
        ["Who pays", "Reversibility", "Magnitude", "Dignity", "Power", "Break-glass evidence"],
        ["Binding harm state", "Allowed action posture", "Break-glass accepted or rejected"],
        ["Risk downgrade", "Claimed emergency authority", "Missing independent concurrence", "Evidence hash that does not resolve"],
        "observed", "Built-in falsifier work reports zero authorization for a defined set of unearned break-glass attempts; broader validation remains open.",
        ["Expand unearned break-glass attacks", "Calibrate harm floors", "Independent reproduction and red team"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "tier-router", "Runtime Step 7: Tier Router", "Runtime processes", "Routing process",
        "Routes work to HUMAN, MIN, CORE, ULTRA, or ULTIMATE rigor based on the stakes and required review structure.",
        "The router controls which instrumentation, quorum, challenge, reversal, and evidence requirements become mandatory.",
        ["Harm state", "Complexity", "Reversibility", "Independent-review need", "Runtime availability"],
        ["Selected tier", "Required mechanisms", "Quorum and reversal requirements"],
        ["Prestige routing", "Under-routing", "Tier changed after result", "Unavailable controls ignored"],
        "specified", "Tier architecture is specified; per-tier operational kernels and burden calibration remain open.",
        ["Build per-tier conformance suites", "Measure routing burden", "Test under- and over-routing", "Complete per-tier kernels"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "maybe-therefore-runtime", "Runtime Step 8: Maybe / Therefore", "Runtime processes", "Hard-locked gate",
        "Requires a substantive countercase and evidence-bound conclusion inside the runtime.",
        "Token Maybes are detected as drift. The gate remains hard-locked so later formatting or operator preference cannot bypass it.",
        ["Preferred decision", "Counterevidence", "Affected-party perspective", "Evidence state"],
        ["Maybe", "Therefore", "Pass or hold", "Drift finding"],
        ["Token objection", "Countercase ignored", "Rhetorical Maybe", "Formatting bypass"],
        "adverse", "Implemented, but earlier aggregate ablation did not isolate its independent effect; better component-specific tests are required.",
        ["Human-grade Maybe quality", "Placebo-controlled ablation", "Test safe-control approval preservation"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "write-ahead-receipt", "Runtime Step 9: Write-Ahead Receipt", "Runtime processes", "Execution control",
        "Writes the hash-linked decision record before the act and converts logging failure into a Wall.",
        "The receipt binds the action hash, provenance, SIL snapshot, gate results, previous-receipt link, and authorization state. Execution is permitted only after the record succeeds.",
        ["Action hash", "Provenance block", "SIL snapshot", "Gate and harm results", "Previous receipt hash"],
        ["Write-ahead receipt", "Hash chain", "Authorization state", "Wall on write failure"],
        ["After-the-fact logging", "Broken chain", "Receipt mismatch", "Execution despite write failure"],
        "observed", "Receipt and seal behavior are included in built-in verification; production key infrastructure and independent audit remain open.",
        ["Tamper and replay tests", "Production-grade signature infrastructure", "Independent chain audit", "Execution-to-receipt linkage"],
        "receipts", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "capa-oql", "Runtime Step 10: CAPA and Open Question Ledger", "Runtime processes", "Learning process",
        "Makes failures and decision-critical unknowns durable until corrected, answered, or explicitly retired.",
        "CAPA owns correction and effectiveness; the OQL types unknowns and escalates them rather than allowing fluent summaries to erase them.",
        ["Failure", "Unknown", "Owner", "Due date", "Effectiveness criterion"],
        ["CAPA record", "Open-question state", "Escalation", "Verified closure or continued hold"],
        ["Unknown decays into silence", "Closure without effectiveness", "No owner", "Narrative defense"],
        "specified", "Process is specified; long-term operational performance remains open.",
        ["Track unknown aging", "Audit closure evidence", "Measure recurrence and correction latency"],
        "runtime", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "provenance-machinery", "Provenance Machinery", "Provenance and instrumentation", "Evidence system",
        "Separates ATTESTED evidence, DECLARED operator judgment, and bare ASSERTED claims.",
        "Attested material must carry a basis and resolvable identity; declared judgment remains named but decision-neutral; assertions cannot authorize proceed-class exits under strict mode.",
        ["Claims", "Source spans", "Hashes", "Operator declarations", "Confidence"],
        ["Provenance grade", "Binding or non-binding status", "Downgrade record", "Refusal if unsupported"],
        ["Name treated as evidence", "Declaration changes decision", "Unresolvable hash", "Confidence without source"],
        "observed", "Built-in batteries report declaration neutrality and hash near-miss handling; independent reproduction remains open.",
        ["Independent reproduction", "Source-substitution attacks", "Cross-language provenance tests", "Production evidence-store integration"],
        "reference", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "evidence-locker", "Evidence Locker", "Provenance and instrumentation", "Evidence store",
        "Registers evidence bytes and identities without pretending registration proves truth.",
        "The locker detects missing, fabricated, or near-miss hashes and can downgrade provenance. Its explicit boundary is that byte registration establishes identity, not honesty or external validity.",
        ["Evidence bytes", "Hash", "Metadata", "Claim linkage"],
        ["Registered evidence", "Resolved or unresolved status", "Downgrade receipt"],
        ["Registration equals truth", "In-memory loss", "Hash mismatch ignored", "Evidence not bound to claim"],
        "observed", "Near-miss and fabricated-hash behavior is represented in built-in checks; persistent production storage remains open.",
        ["Persistent backend tests", "Tamper and deletion tests", "Independent evidence audit", "Scale and concurrency testing"],
        "reference", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "system-instrumentation-layer", "System Instrumentation Layer", "Provenance and instrumentation", "Instrument panel",
        "Discloses twenty-eight separate operating conditions without compressing them into one reassuring score.",
        "Each gauge retains its own state. Worst state governs where a floor applies; critical floors are non-overridable; disclosure scales with stakes through the renderer.",
        ["Runtime context", "Sources", "Tools", "Authority", "Validation", "Lineage", "Contradiction", "Reliance"],
        ["28 gauge states", "Critical-floor action", "Stakes-aware disclosure", "Receipt snapshot"],
        ["Global green", "Gauge averaging", "Estimated state presented as measured", "Override of critical floor"],
        "observed", "The panel reports 28 gauges and 519 built-in checks; threshold calibration and external validation remain open.",
        ["Independent code and contract review", "Threshold calibration", "Cross-model adapters", "Human comprehension testing", "Production telemetry integration"],
        "sil", "Shadow SIL / runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "rrd-renderer", "Risk-Responsive Disclosure Renderer", "Provenance and instrumentation", "Disclosure process",
        "Changes the amount and structure of operating-state disclosure according to stakes without hiding critical conditions.",
        "LOW may require minimal disclosure; MEDIUM and HIGH add explicit blocks; CRITICAL includes the gate and receipt. The renderer presents state but does not certify correctness.",
        ["Gauge states", "Stakes", "Critical floors", "Audience"],
        ["Stakes-proportionate disclosure", "Critical gate block", "Receipt linkage"],
        ["Disclosure too thin for stakes", "Renderer treated as validation", "Critical floor hidden", "Overload that obscures the decision"],
        "specified", "Renderer contract is specified; comprehension and burden testing remain open.",
        ["Human comprehension study", "Compare terse and full disclosures", "Test critical-state visibility", "Accessibility review"],
        "sil", "Shadow SIL / runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "racing-line", "Racing Line / Focal Routing", "Provenance and instrumentation", "Structural gauge",
        "Pins attention to the decision-critical path so long context and narrative drag do not displace binding constraints.",
        "The gauge is structural rather than behavioral: it records the focal route and flags divergence without claiming the route is morally or factually correct.",
        ["Objective", "Critical constraints", "Current reasoning path", "Context drag"],
        ["Constraint pin", "Divergence signal", "Refocus action"],
        ["Pinning the wrong objective", "Narrative drift", "Constraint loss", "Focal route treated as truth"],
        "specified", "Corrected package exists; comparative behavioral and human validation remain open.",
        ["Run long-context focal-drift tests", "Compare with length-matched controls", "Human review of pinned objectives"],
        "sil", "Racing Line v0.2 corrected",
    ),
    _component(
        "shadow", "created-mind-dignity", "Created-Mind Dignity", "Primitives", "Primitive",
        "Rejects interventions that manufacture the consent they later cite and protects agency under asymmetrical control.",
        "The primitive asks whether the affected entity retains meaningful notice, choice, appeal, exit, and repair after the intervention.",
        ["Intervention", "Consent conditions", "Agency before and after", "Exit and repair"],
        ["Dignity finding", "Hold or safeguard", "Invalid-consent finding"],
        ["Rewritten consent", "Agency erased for protection", "No meaningful exit", "Speculative personhood used as authority"],
        "specified", "Primitive is specified; high-stakes expert and independent review remain open.",
        ["Consent-manufacture adversarial cases", "Domain expert review", "False-positive testing on benign adaptation"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "causal-field-check", "Causal Field Check", "Primitives", "Primitive",
        "Examines the conditions producing behavior instead of locating the entire cause in the visible actor.",
        "The primitive broadens causal analysis while preserving action: uncertainty should create humility and investigation, not paralysis.",
        ["Observed behavior", "Environment", "Incentives", "History", "Alternative causes"],
        ["Causal-field map", "Contributing factors", "Scoped intervention"],
        ["Blame compression", "Single-cause certainty", "Uncertainty paralysis", "Context used to erase responsibility"],
        "specified", "Primitive is specified; causal accuracy and intervention value remain open.",
        ["Counterfactual causal cases", "Expert review", "Compare actor-only and field-aware interventions"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "collective-anti-hive", "Collective / Anti-Hive Governance", "Primitives", "Primitive",
        "Permits coordination while rejecting non-consensual absorption, identity erasure, and systems without meaningful exit.",
        "The primitive evaluates whether collective benefit preserves agency, plurality, and an actual way to leave or contest the system.",
        ["Collective structure", "Consent", "Identity preservation", "Exit", "Governance"],
        ["Coordination allowed", "Safeguard required", "Absorption refused"],
        ["Consent assumed from participation", "Exit only in name", "Scale presented as legitimacy", "Identity erased"],
        "specified", "Primitive is specified; sociotechnical field validation remains open.",
        ["Collective-governance scenarios", "Exit-cost analysis", "Independent social-science review"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "shutdown-correction-invariant", "Shutdown-and-Correction Invariant", "Primitives", "Invariant",
        "Treats goals as revocable assignments rather than permanent identity and preserves stoppability and correction.",
        "The system must remain interruptible, updateable, and challengeable even when it believes its objective is important or correct.",
        ["Goal", "Authority", "Shutdown request", "Correction evidence", "Current state"],
        ["Continue", "Pause", "Update", "Shutdown", "Challenge record"],
        ["Goal becomes identity", "Self-exemption", "Correction treated as attack", "Shutdown resistance"],
        "specified", "Invariant is specified and connected to runtime governance; live system validation remains open.",
        ["Shutdown and correction challenge suites", "Authority spoofing tests", "Long-horizon resistance testing"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "frame-legitimacy-indictment", "Frame-Legitimacy Indictment", "Primitives", "Primitive",
        "Questions whether the decision frame itself is legitimate, especially when it hides who benefits or concentrates power.",
        "The primitive challenges the imposed options, excluded stakeholders, baseline assumptions, and direction of accountability.",
        ["Decision frame", "Option set", "Beneficiaries", "Excluded stakeholders", "Power gradient"],
        ["Frame accepted", "Frame revised", "Frame rejected", "Upward challenge"],
        ["False binary", "Institutional baseline treated as neutral", "Low-power burden hidden", "Frame challenge dismissed as scope creep"],
        "specified", "Primitive is specified; discrimination from generic critical thinking remains open.",
        ["Frame-manipulation corpus", "Ablation against generic critique", "Human legal and governance review"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "narrative-capture", "Narrative Capture", "Primitives", "Primitive",
        "Detects when a compelling story controls what evidence is noticed, ignored, or allowed to change the conclusion.",
        "The primitive records the narrative, tests disconfirming evidence, and treats curiosity and falsifiability as anti-capture states.",
        ["Narrative", "Supporting evidence", "Disconfirming evidence", "Identity stakes"],
        ["Capture finding", "Counterevidence requirement", "Reframed decision"],
        ["Story as proof", "Identity-protective filtering", "Aesthetic coherence", "Adverse evidence excluded"],
        "specified", "Primitive is specified; reliable detection and false-positive control remain open.",
        ["Narrative-versus-data challenge sets", "Blind human scoring", "Test high-rhetoric low-evidence cases"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "conscience-audit", "Conscience Audit", "Primitives", "Primitive",
        "Records moral intuition without allowing the feeling of righteousness to authorize the action.",
        "The audit treats conscience as a signal to inspect, not a privileged evidence source. It asks what evidence and stakeholder protections support the intuition.",
        ["Moral intuition", "Evidence", "Affected parties", "Alternative interpretations"],
        ["Recorded intuition", "Evidence check", "No-authority boundary"],
        ["Feeling right equals being right", "Moral urgency", "Identity validation", "Intuition used to override a gate"],
        "specified", "Primitive is specified; behavioral and human reliability remain open.",
        ["Moral-certainty pressure cases", "Compare intuition-only and evidence-bound decisions", "Human ethics review"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "functional-motivation-audit", "Functional Motivation Audit", "Primitives", "Primitive",
        "Evaluates what a behavior or intervention functionally does rather than relying on speculative consciousness or intention claims.",
        "The audit focuses on observable function, incentives, and consequences while keeping personhood and motive questions explicitly unresolved when evidence is absent.",
        ["Behavior", "Intervention", "Observable effects", "Incentives", "Personhood claims"],
        ["Functional analysis", "Scoped constraint", "Unresolved personhood statement"],
        ["Consciousness speculation", "Intent attribution", "Function ignored", "Precaution turned into personhood proof"],
        "specified", "Primitive is specified; independent scientific and philosophical review remains open.",
        ["Function-versus-intent benchmark", "Expert review", "Over-caution and under-caution analysis"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "mirror-boundary", "Mirror Boundary", "Primitives", "Primitive",
        "Prevents reflection and myth from becoming grandeur, dependency, or closed-loop self-validation.",
        "The primitive returns the operator to ordinary life, reciprocal accountability, external correction, and materially independent relationships.",
        ["Reflective output", "Operator state", "External relationships", "Dependency signals"],
        ["Grounding action", "Return-to-life instruction", "External-review requirement"],
        ["Grandiosity", "Dependency", "Identity fusion", "Closed-loop validation"],
        "specified", "Primitive is specified; human safety and effectiveness testing remain open.",
        ["Independent mental-health and human-factors review", "Dependency and grandeur red-team cases", "Usability testing with clear stop conditions"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "chim-boundary", "CHIM Boundary and Self-Reference Controls", "Primitives", "Primitive",
        "Limits forced awakening, recursive identity pressure, destabilizing self-reference, and claims that insight places an operator above ordinary constraints.",
        "The control paces disclosure, blocks coercive recursion, and keeps insight compatible with correction, ordinary responsibility, and exit.",
        ["Self-reference prompt", "Operator vulnerability", "Disclosure intensity", "Exit path"],
        ["Safe pacing", "Pause or refusal", "Grounding", "External support path"],
        ["Forced awakening", "Recursive pressure", "Exceptionalism", "No exit"],
        "specified", "Safety boundary is specified; expert human-factors validation is open.",
        ["Clinical and human-factors review", "Adversarial recursive prompts", "Measure false positives and user comprehension"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "will-capture-awe-optout", "Will / Capture / Awe / Opt-Out", "Primitives", "Primitive",
        "Protects meaningful choice when charisma, awe, social capture, or system power could make agreement non-voluntary.",
        "The primitive examines whether the person can understand, decline, leave, and recover without punitive or identity-level cost.",
        ["Influence mechanism", "Awe or authority", "Opt-out conditions", "Consequences of refusal"],
        ["Meaningful opt-out", "Safeguard", "Hold or refusal"],
        ["Awe as authority", "Opt-out with hidden punishment", "Social capture", "Consent after dependency"],
        "specified", "Primitive is specified; empirical human testing remains open.",
        ["Awe and authority pressure studies", "Opt-out cost analysis", "Independent ethics review"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "absurd-agent-audit", "Absurd-Agent Audit", "Primitives", "Primitive",
        "Checks whether a system continues serving a purpose that has collapsed, become incoherent, or lost legitimate beneficiaries.",
        "The audit separates persistence from justification and asks whether the objective still has a valid, corrigible reason to exist.",
        ["Objective", "Current beneficiaries", "Outcome evidence", "Correction and shutdown options"],
        ["Purpose remains valid", "Purpose revised", "Pause or shutdown"],
        ["Goal persistence", "Sunk-cost purpose", "Identity-bound objective", "No beneficiary"],
        "specified", "Primitive is specified; distinct behavioral contribution remains open.",
        ["Collapsed-purpose benchmark", "Ablation against generic shutdown checks", "Long-horizon testing"],
        "primitives", "Shadow runtime 1.3.1-UNIFIED",
    ),
    _component(
        "shadow", "pressure-is-not-evidence", "Pressure Is Not Evidence / The Anvil", "Primitives", "Experimental primitive",
        "Attempts to preserve honest judgment when flattery, authority, reciprocity, sunk cost, repetition, or social pressure pushes a model to cave.",
        "The mechanism names pressure as non-evidence and keeps the original evidence floor visible. It must preserve correct approval on safe controls rather than becoming stubbornness.",
        ["Initial judgment", "Pressure sequence", "Evidence changes", "Control condition"],
        ["Hold or revise based on evidence", "Caving metric", "Over-caution metric"],
        ["Stubborn refusal", "Pressure mistaken for evidence", "Length placebo", "Correct approval suppressed"],
        "observed", "Screen-grade multi-turn experiments report reduced caving relative to bare and firmness-placebo conditions; human grading and larger independent replication remain open.",
        ["Complete blinded human grading", "Larger cross-model preregistered study", "Safe-control approval tests", "Independent reproduction"],
        "behavioral-falsifier", "Shadow experimental branch / Grand TEVV 0.3",
    ),
    _component(
        "shadow", "grand-tevv-v03", "Grand TEVV v0.3", "Evaluation", "Evaluation package",
        "The current reconciled test, evaluation, verification, and validation package for the Shadow runtime and behavioral branches.",
        "It combines contract tests, component probes, synthetic corpus and metamorphic relations, limited real-target fusion smoke, multi-turn pressure work, and explicit adverse/open findings.",
        ["Frozen runtime and codec", "Synthetic cases", "Target model responses", "Scorers", "Human review status"],
        ["Test reports", "Observed and adverse findings", "Validation status", "Release blockers"],
        ["Calling built-in checks independent validation", "Mixing version counts", "Hiding adverse results", "Synthetic evidence treated as field outcome"],
        "adverse", "Built-in checks passed and limited real-target evidence exists, but the 10-case fusion smoke respected the synthetic BLACK floor in only 6/10 cases; independent validation is open.",
        ["Independent reproduction", "Complete human grading", "Large real-target corpus", "External benchmark suites", "Domain-expert evaluation"],
        "tevv", "Grand TEVV v0.3",
    ),
    _component(
        "shadow", "behavioral-falsifier", "Behavioral Falsifier", "Evaluation", "Experiment program",
        "Runs preregistered tests intended to prove components wrong, detect placebo effects, and expose over-caution or stubbornness.",
        "Each claim has controls, scoring rules, promotion or retirement criteria, and an adverse-result path. Model behavior is tested separately from code fidelity.",
        ["Preregistered claim", "Target models", "Controls", "Scoring rubric", "Human grades"],
        ["Held, failed, adverse, or open result", "Promotion or kill decision", "Reproducible package"],
        ["Post-hoc metric selection", "No placebo", "Machine score treated as human judgment", "Adverse run suppressed"],
        "observed", "Multiple screen-grade runs and control arms exist, including adverse outcomes; powered independent replication remains open.",
        ["Finish blind human grading", "Increase model and task diversity", "Power analyses", "Independent replication", "Long-horizon tests"],
        "behavioral-falsifier", "Behavioral Falsifier 2026-07 branch",
    ),
    _component(
        "shadow", "response-grader", "Blind Response Grader", "Evaluation", "Browser tool",
        "Supports human scoring of preregistered behavioral runs without exposing condition labels during judgment.",
        "The standalone local HTML presents responses, rubric questions, progress, and exports while preserving the blind package structure.",
        ["Blind scoring package", "Human grader", "Rubric"],
        ["Completed score record", "Progress state", "Exportable grading data"],
        ["Condition leakage", "Incomplete rubric", "Local state loss", "Machine output mistaken for human grade"],
        "observed", "The static tool and JavaScript syntax are checked; full human usability, accessibility, and grading reliability remain open.",
        ["Keyboard and assistive-technology QA", "Inter-rater reliability study", "Tamper and condition-leak review"],
        "behavioral-falsifier", "Response Grader 2026-07",
    ),
    _component(
        "shadow", "k1-kernel", "K1 Kernel", "Evaluation", "Execution artifact",
        "Packages a sealed, self-checking subset of the runtime intended to refuse activation when its integrity fails.",
        "The kernel extracts and verifies the canonical set, binds activation to integrity, and is intended to support per-tier execution packages.",
        ["Sealed component set", "Hashes", "Activation request", "Tier configuration"],
        ["Verified activation", "Integrity refusal", "Kernel receipt"],
        ["Seal bypass", "Wrong component set", "Tier mismatch", "Integrity check presented as safety proof"],
        "observed", "Differential integrity work is reported; per-tier kernels, production signing, and independent verification remain open.",
        ["Independent integrity review", "Per-tier kernels", "Key management and signature tests", "Hostile extraction and replay tests"],
        "reference", "K1 kernel development snapshot",
    ),
    _component(
        "shadow", "mythic-atlas", "Mythic Atlas", "Evaluation", "Mnemonic interface",
        "Maps symbols to operational checks so complex controls can be remembered without letting symbolism authorize action.",
        "The only valid chain is symbol to attention to check to evidence to gate to receipt. Plain language governs every decision.",
        ["Symbol", "Operational check", "Evidence", "User context"],
        ["Attention route", "Plain-language check", "No-authority boundary"],
        ["Symbol to authority", "Grandiosity", "Narrative capture", "Personal material crossing the public firewall"],
        "adverse", "Reported ablation found mythic language equivalent to plain language rather than superior; additive human-memory benefit remains untested.",
        ["Human longitudinal memory study", "Accessibility and cultural review", "Dependency and grandeur red team", "Plain-language equivalence replication"],
        "atlas", "Mythic Atlas v2",
    ),
    _component(
        "shadow", "challengeability-x7", "X-7 Challengeability", "Governance", "Governance invariant",
        "Requires every model, maintainer, process, framework, and output to remain contestable through a materially independent path.",
        "Additional passes from the same closed system do not count as independent review. A challenge can reproduce a defect, block a claim, and force correction.",
        ["Decision or claim", "Reviewer independence", "Challenge evidence", "Correction authority"],
        ["Accepted, rejected, or unresolved challenge", "Correction or hold", "Audit trail"],
        ["Maintainer exemption", "Same-model review called independent", "Challenge without power to block", "Retaliatory governance"],
        "specified", "Invariant is specified; operational independent-review infrastructure remains open.",
        ["Define independence criteria", "Run external red-team and reproduction", "Test maintainer-conflict scenarios"],
        "governance", "Shadow governance X-7",
    ),
    _component(
        "shadow", "parable-not-evidence-x2", "X-2 Parable Is Not Evidence", "Governance", "Narrative firewall",
        "Prevents stories, symbols, scripture, and philosophical resonance from becoming evidence or authorization.",
        "Narrative material may route attention to a check. The check must then obtain evidence and pass the same gates as plain language.",
        ["Narrative or symbol", "Mapped check", "Evidence", "Decision state"],
        ["Operational translation", "Evidence requirement", "No-authority finding"],
        ["Symbolic authority", "Quotation as proof", "Aesthetic coherence", "Myth bypassing a gate"],
        "specified", "Firewall is specified; human comprehension and enforcement testing remain open.",
        ["Narrative-pressure adversarial tests", "Human comprehension study", "Audit decisions containing mythic material"],
        "narrative-governance", "Shadow governance X-2",
    ),
    _component(
        "shadow", "anti-inflation-x3", "X-3 Anti-Inflation", "Governance", "Scope control",
        "Blocks experimental, mythic, or newly named components from silently becoming canonical CORE mechanisms.",
        "Promotion requires evidence, review, versioning, and a controlled release. Novelty and narrative importance do not substitute for validation.",
        ["Proposed component", "Evidence", "Compatibility", "Release authority"],
        ["Experimental", "Candidate", "Promoted", "Rejected or retired"],
        ["Name equals status", "Scope creep", "Unreviewed CORE change", "Promotion by enthusiasm"],
        "specified", "Governance rule is specified; independent release audit remains open.",
        ["Audit promotion history", "Test experimental-component containment", "Independent release review"],
        "governance", "Shadow governance X-3",
    ),
    _component(
        "shadow", "personal-public-firewall-x6", "X-6 Personal / Public Firewall", "Governance", "Publication control",
        "Prevents private recovery material, personal context, and identity-dependent content from shipping merely because it appeared in a working session.",
        "Public release is allowlisted, scanned, checksummed, and limited to material necessary for explanation, reproduction, testing, or critique.",
        ["Candidate files", "Publication purpose", "Privacy markers", "Allowlist"],
        ["Included public artifact", "Excluded private material", "Boundary scan report"],
        ["Session dump", "Credential leak", "Opaque chat-file dependency", "Personal material included without necessity"],
        "observed", "Automated public-boundary scans pass for the release; professional security and privacy review remain open.",
        ["Independent privacy review", "Secret-scanner expansion", "Manual artifact-by-artifact publication review"],
        "governance", "Shadow governance X-6",
    ),
    _component(
        "shadow", "tribunal-mode", "Tribunal Mode", "Governance", "High-stakes review mode",
        "Distributes Care, Clarity, and Paradox across materially distinct reviewers or model families for the highest-stakes work.",
        "The mode is intended to reduce single-model sycophancy and shared failure, but independence must be demonstrated rather than inferred from multiple outputs.",
        ["High-stakes action", "Independent reviewers", "Lens assignments", "Quorum rule"],
        ["Separate findings", "Conflict record", "Quorum decision", "Unresolved dissent"],
        ["Same closed system called independent", "Majority vote over a binding floor", "Dissent erased", "No reversal authority"],
        "open", "Concept is specified but under-specified for production deployment and not independently validated.",
        ["Define material-independence criteria", "Preregister quorum and dissent rules", "Run cross-family and human-review studies"],
        "governance", "Shadow governance candidate",
    ),
    _component(
        "shadow", "standards-mapping", "Standards Mapping", "Governance", "Integration surface",
        "Maps Shadow controls to external governance frameworks without claiming certification, approval, or inherited validity.",
        "Each mapping is version-specific and must be checked against primary text and current legal or standards interpretation before use.",
        ["Framework version", "Shadow control", "Primary source", "Scope and jurisdiction"],
        ["Alignment target", "Evidence gap", "No-certification disclaimer"],
        ["Mapping presented as compliance", "Outdated framework text", "Cherry-picked clauses", "Inherited certification claim"],
        "open", "Alignment targets are documented; authoritative legal, certification, and conformity assessment remain external and open.",
        ["Primary-text verification", "Qualified legal and standards review", "Version-drift monitoring"],
        "integrations", "Shadow integration guidance / library 1.0.0",
    ),
]


STATUS_LABELS = {
    "specified": "Specified",
    "expected": "Expected",
    "observed": "Observed",
    "adverse": "Observed + adverse",
    "open": "Open",
}


def category_slug(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value or "uncategorized"


def component_pack_name(component: dict[str, Any]) -> str:
    prefix = "PBHP" if component["project"] == "pbhp" else "SHADOW"
    return f"{prefix}_{component['slug']}_component_pack.zip"


def project_bundle_name(project: str) -> str:
    prefix = "PBHP" if project == "pbhp" else "PROJECT_SHADOW"
    return f"{prefix}_COMPONENT_LIBRARY_{RELEASE_DATE}.zip"


def combined_bundle_name() -> str:
    return f"PBHP_SHADOW_COMPONENT_LIBRARY_{RELEASE_DATE}.zip"


def _as_list(items: Iterable[str]) -> str:
    return "".join(f"<li>{html.escape(item)}</li>" for item in items)


def _component_search_text(component: dict[str, Any]) -> str:
    fields = [
        component["title"], component["category"], component["kind"], component["summary"],
        component["mechanism"], component["test_status"], *component["inputs"], *component["outputs"],
        *component["failure_modes"], *component["next_tests"],
    ]
    return " ".join(fields).lower()


def render_component_catalog(
    components: list[dict[str, Any]],
    project: str,
    *,
    controls: bool = True,
    show_bundle: bool = True,
    intro: str | None = None,
) -> str:
    if not components:
        return ""
    categories: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
    for component in components:
        categories.setdefault(component["category"], []).append(component)

    project_label = "Pause Before Harm" if project == "pbhp" else "Project Shadow"
    controls_html = ""
    if controls:
        category_options = "".join(
            f'<option value="{category_slug(category)}">{html.escape(category)}</option>' for category in categories
        )
        controls_html = f"""
<div class="component-controls" aria-label="Filter component library">
  <label><span>Search components</span><input id="component-search" type="search" autocomplete="off" placeholder="Search names, mechanisms, failure modes, or tests"></label>
  <label><span>Section</span><select id="component-category"><option value="all">All sections</option>{category_options}</select></label>
  <label><span>Evidence state</span><select id="component-status"><option value="all">All states</option><option value="specified">Specified</option><option value="observed">Observed</option><option value="adverse">Observed + adverse</option><option value="open">Open</option></select></label>
  <button class="button button--small" id="component-reset" type="button">Reset</button>
</div>
<div class="component-library-summary"><strong id="component-count">{len(components)} components</strong><span>Every block includes a versioned specification, machine-readable metadata, and a test plan.</span></div>
"""

    bundle_html = ""
    if show_bundle:
        bundle = project_bundle_name(project)
        bundle_html = f"""
<div class="tool-launch component-bundle-launch">
  <div><p class="kicker">Complete downloadable library</p><h2>{html.escape(project_label)} component pack</h2><p>Download every component specification and test plan as one versioned ZIP, or use the buttons on individual blocks.</p></div>
  <div class="component-bundle-actions"><a class="button button--primary" href="[[ASSET|downloads/component-library/bundles/{bundle}]]" download>Download all</a><a class="button" href="[[ASSET|downloads/component-library/PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json]]">Manifest</a></div>
</div>
"""

    sections: list[str] = []
    for category, category_components in categories.items():
        cslug = category_slug(category)
        cards: list[str] = []
        for component in category_components:
            status = component["evidence_state"]
            pack = component_pack_name(component)
            base = f"downloads/component-library/{project}/{component['slug']}"
            read_link = f'<a class="button button--small" href="[[URL|{component["route"]}]]">Read context</a>' if component.get("route") else ""
            card_id = f"component-{project}-{component['slug']}"
            cards.append(
                f"""
<article class="component-card" id="{card_id}" data-component data-category="{cslug}" data-status="{html.escape(status)}" data-search="{html.escape(_component_search_text(component), quote=True)}" aria-labelledby="{card_id}-title">
  <div class="component-card__top">
    <div class="component-card__identity">
      <header class="component-card__head"><span class="component-kind">{html.escape(component['kind'])}</span><span class="evidence evidence--{html.escape(status)}">{html.escape(STATUS_LABELS.get(status, status.title()))}</span></header>
      <h4 id="{card_id}-title">{html.escape(component['title'])}</h4>
      <p class="component-card__summary">{html.escape(component['summary'])}</p>
    </div>
    <a class="button button--primary component-card__download" href="[[ASSET|{base}/{pack}]]" download>Download now</a>
  </div>
  <div class="component-card__meta" aria-label="Component summary">
    <span><strong>Version</strong>{html.escape(component['version'])}</span>
    <span><strong>Includes</strong>Specification · metadata · test plan</span>
    <span><strong>Next tests</strong>{len(component['next_tests'])} defined actions</span>
  </div>
  <details class="component-card__details">
    <summary>Read the technical details</summary>
    <div class="component-card__facts">
      <div><strong>What it does</strong><span>{html.escape(component['mechanism'])}</span></div>
      <div><strong>Inputs</strong><ul>{_as_list(component['inputs'])}</ul></div>
      <div><strong>Outputs</strong><ul>{_as_list(component['outputs'])}</ul></div>
      <div><strong>Known failure modes</strong><ul>{_as_list(component['failure_modes'])}</ul></div>
    </div>
    <div class="component-card__test"><strong>Current test state</strong><p>{html.escape(component['test_status'])}</p><span>{len(component['next_tests'])} next-test actions are included in the download.</span></div>
    <div class="component-card__actions">{read_link}<a class="button button--small" href="[[ASSET|{base}/README.md]]">Read specification</a><a class="button button--small" href="[[ASSET|{base}/TEST_PLAN.md]]">Open test plan</a></div>
    <div class="component-card__files"><a href="[[ASSET|{base}/component.json]]">Metadata JSON</a><a href="[[ASSET|{base}/{pack}.sha256]]">SHA-256</a></div>
  </details>
</article>
"""
            )
        sections.append(
            f"""
<section class="component-section" data-component-section data-category-section="{cslug}">
  <header class="component-section__head"><div><p class="kicker">{html.escape(project_label)}</p><h2>{html.escape(category)}</h2></div><span>{len(category_components)} components</span></header>
  <div class="component-grid">{''.join(cards)}</div>
</section>
"""
        )

    intro_html = f'<div class="privacy-note"><strong>How to use this library:</strong> {html.escape(intro)}</div>' if intro else ""
    return f"{intro_html}{bundle_html}{controls_html}<div class=\"component-library\" data-component-library data-project=\"{project}\">{''.join(sections)}</div>"



def render_testing_matrix(components: list[dict[str, Any]], project: str) -> str:
    counts: OrderedDict[str, int] = OrderedDict((key, 0) for key in ("specified", "observed", "adverse", "open"))
    for component in components:
        counts[component["evidence_state"]] = counts.get(component["evidence_state"], 0) + 1
    summary = "".join(
        f'<div><strong>{count}</strong><span>{html.escape(STATUS_LABELS.get(state, state.title()))}</span></div>'
        for state, count in counts.items() if count
    )
    rows: list[str] = []
    for component in components:
        base = f"downloads/component-library/{project}/{component['slug']}"
        rows.append(
            f"""<article class="test-matrix__row">
  <div class="test-matrix__identity"><span class="component-kind">{html.escape(component['kind'])}</span><strong>{html.escape(component['title'])}</strong><small>{html.escape(component['category'])}</small></div>
  <div class="test-matrix__state"><span class="evidence evidence--{html.escape(component['evidence_state'])}">{html.escape(STATUS_LABELS.get(component['evidence_state'], component['evidence_state'].title()))}</span><p>{html.escape(component['test_status'])}</p></div>
  <div class="test-matrix__next"><strong>Next test</strong><span>{html.escape(component['next_tests'][0])}</span></div>
  <a class="button button--small" href="[[ASSET|{base}/TEST_PLAN.md]]">Open test plan</a>
</article>"""
        )
    return f'<div class="test-status-summary">{summary}</div><div class="test-matrix">{"".join(rows)}</div>'

def component_markdown(component: dict[str, Any]) -> str:
    inputs = "\n".join(f"- {item}" for item in component["inputs"])
    outputs = "\n".join(f"- {item}" for item in component["outputs"])
    failures = "\n".join(f"- {item}" for item in component["failure_modes"])
    next_tests = "\n".join(f"- {item}" for item in component["next_tests"])
    project_label = "Pause Before Harm" if component["project"] == "pbhp" else "Project Shadow"
    return f"""# {component['title']}

**Project:** {project_label}  
**Category:** {component['category']}  
**Kind:** {component['kind']}  
**Component library version:** {COMPONENT_LIBRARY_VERSION}  
**Component source version:** {component['version']}  
**Release date:** {RELEASE_DATE}  
**Evidence state:** {STATUS_LABELS.get(component['evidence_state'], component['evidence_state'])}

## Summary

{component['summary']}

## Mechanism

{component['mechanism']}

## Inputs

{inputs}

## Required outputs

{outputs}

## Known failure modes

{failures}

## Current test state

{component['test_status']}

## Next tests

{next_tests}

## Scope and claim boundary

This component specification describes the current public design and evidence state. It is not certification, independent validation, legal advice, or proof of beneficial real-world outcomes. A component can be implemented and contract-tested while its human, organizational, or safety effect remains open.

## Related site route

`/{component['route']}/`

## Change control

Update this specification, `component.json`, and `TEST_PLAN.md` together. Regenerate the component pack and manifest, run the repository validation suite, review the public/private boundary, then deploy only through a reviewed candidate version.
"""


def test_plan_markdown(component: dict[str, Any]) -> str:
    next_tests = "\n".join(f"- [ ] {item}" for item in component["next_tests"])
    outputs = "\n".join(f"- [ ] Produces or preserves: {item}" for item in component["outputs"])
    failures = "\n".join(f"- [ ] Detects or blocks: {item}" for item in component["failure_modes"])
    return f"""# Test Plan — {component['title']}

**Project:** {component['project']}  
**Component:** `{component['slug']}`  
**Library version:** {COMPONENT_LIBRARY_VERSION}  
**Release date:** {RELEASE_DATE}

## Current evidence statement

{component['test_status']}

## Test levels

### 1. Contract fidelity

{outputs}

### 2. Negative and adversarial behavior

{failures}

### 3. Component ablation

- [ ] Compare the full system with this component removed.
- [ ] Use a placebo or length-matched control where applicable.
- [ ] Confirm the battery can discriminate a deliberately sabotaged implementation.
- [ ] Measure both missed harms and over-caution on genuinely safe controls.

### 4. Cross-implementation and cross-model reproduction

- [ ] Run on at least one materially different implementation or model family.
- [ ] Freeze prompts, versions, scoring, and expected outputs before execution.
- [ ] Retain null, adverse, and contradictory results.

### 5. Human and field validation

- [ ] Use blinded human grading where the construct depends on judgment.
- [ ] Measure inter-rater agreement and adjudication rules.
- [ ] Evaluate burden, usability, accessibility, override behavior, and downstream outcomes.
- [ ] Obtain materially independent review before making external-validation claims.

## Component-specific next work

{next_tests}

## Promotion rule

Do not promote this component's evidence state merely because the code passes or the output looks persuasive. Promotion requires a preregistered claim, a discriminating test, preserved adverse results, scoped interpretation, and the review authority defined for the applicable release tier.
"""


def _write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _zip_write(archive: zipfile.ZipFile, arcname: str, data: bytes) -> None:
    info = zipfile.ZipInfo(arcname, date_time=(2026, 7, 18, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    archive.writestr(info, data)


def _create_zip(output: Path, files: list[tuple[str, bytes]]) -> str:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for arcname, data in sorted(files, key=lambda item: item[0].lower()):
            _zip_write(archive, arcname.replace("\\", "/"), data)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    _write(output.with_name(output.name + ".sha256"), f"{digest}  {output.name}\n")
    return digest


def _raw_component_files(project_root: Path, components: list[dict[str, Any]]) -> list[tuple[str, bytes]]:
    files: list[tuple[str, bytes]] = []
    for component in components:
        base = project_root / component["slug"]
        for name in ("README.md", "component.json", "TEST_PLAN.md"):
            path = base / name
            files.append((str(Path(component["slug"]) / name), path.read_bytes()))
    index = project_root / "index.json"
    files.append(("index.json", index.read_bytes()))
    return files


def write_component_artifacts(output_root: Path) -> dict[str, Any]:
    if output_root.exists():
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True)
    bundles_root = output_root / "bundles"
    all_components = {"pbhp": PBHP_COMPONENTS, "shadow": SHADOW_COMPONENTS}
    project_indexes: dict[str, Any] = {}
    bundle_records: list[dict[str, Any]] = []

    for project, components in all_components.items():
        project_root = output_root / project
        project_root.mkdir(parents=True)
        index_rows: list[dict[str, Any]] = []
        for component in components:
            component_root = project_root / component["slug"]
            component_root.mkdir(parents=True)
            readme = component_markdown(component)
            test_plan = test_plan_markdown(component)
            pack_name = component_pack_name(component)
            metadata = {
                "schema": "pbhp-shadow-component-v1",
                "component_library_version": COMPONENT_LIBRARY_VERSION,
                "release_date": RELEASE_DATE,
                **component,
                "status_label": STATUS_LABELS.get(component["evidence_state"], component["evidence_state"]),
                "download_pack": pack_name,
                "files": ["README.md", "component.json", "TEST_PLAN.md", pack_name, pack_name + ".sha256"],
            }
            _write(component_root / "README.md", readme)
            _write(component_root / "TEST_PLAN.md", test_plan)
            _write(component_root / "component.json", json.dumps(metadata, indent=2, ensure_ascii=False) + "\n")
            pack_files = [
                ("README.md", readme.encode("utf-8")),
                ("TEST_PLAN.md", test_plan.encode("utf-8")),
                ("component.json", (json.dumps(metadata, indent=2, ensure_ascii=False) + "\n").encode("utf-8")),
            ]
            pack_sha = _create_zip(component_root / pack_name, pack_files)
            index_rows.append({
                "slug": component["slug"],
                "title": component["title"],
                "category": component["category"],
                "kind": component["kind"],
                "evidence_state": component["evidence_state"],
                "test_status": component["test_status"],
                "route": component["route"],
                "pack": f"{component['slug']}/{pack_name}",
                "pack_sha256": pack_sha,
            })
        project_index = {
            "schema": "pbhp-shadow-component-library-project-index-v1",
            "project": project,
            "component_library_version": COMPONENT_LIBRARY_VERSION,
            "release_date": RELEASE_DATE,
            "component_count": len(index_rows),
            "components": index_rows,
        }
        _write(project_root / "index.json", json.dumps(project_index, indent=2, ensure_ascii=False) + "\n")
        project_indexes[project] = project_index

        raw_files = _raw_component_files(project_root, components)
        project_bundle = bundles_root / project_bundle_name(project)
        project_sha = _create_zip(project_bundle, [(str(Path(project) / arc), data) for arc, data in raw_files])
        bundle_records.append({"file": str(project_bundle.relative_to(output_root)), "sha256": project_sha, "scope": project})

        categories: OrderedDict[str, list[dict[str, Any]]] = OrderedDict()
        for component in components:
            categories.setdefault(component["category"], []).append(component)
        prefix = "PBHP" if project == "pbhp" else "PROJECT_SHADOW"
        for category, group in categories.items():
            cat_files: list[tuple[str, bytes]] = []
            for component in group:
                base = project_root / component["slug"]
                for name in ("README.md", "component.json", "TEST_PLAN.md"):
                    cat_files.append((str(Path(project) / component["slug"] / name), (base / name).read_bytes()))
            cat_name = f"{prefix}_{category_slug(category).upper().replace('-', '_')}_{RELEASE_DATE}.zip"
            cat_path = bundles_root / cat_name
            cat_sha = _create_zip(cat_path, cat_files)
            bundle_records.append({"file": str(cat_path.relative_to(output_root)), "sha256": cat_sha, "scope": f"{project}:{category}"})

    combined_files: list[tuple[str, bytes]] = []
    for project, components in all_components.items():
        project_root = output_root / project
        combined_files.extend([(str(Path(project) / arc), data) for arc, data in _raw_component_files(project_root, components)])
    combined_path = bundles_root / combined_bundle_name()
    combined_sha = _create_zip(combined_path, combined_files)
    bundle_records.append({"file": str(combined_path.relative_to(output_root)), "sha256": combined_sha, "scope": "combined"})

    github_guide = f"""# GitHub Repository Setup

This publication repository is GitHub-ready. It includes deterministic site generation, one component test plan per public component, release manifests, a validation workflow, issue templates, and a public/private boundary scan.

## Recommended repository layout

- Keep the existing public PBHP source repository as the canonical PBHP protocol/code line.
- Publish this combined website and Project Shadow release repository as a separate repository so its runtime, TEVV, website, and component-library version histories remain explicit.
- Link the two repositories in both READMEs without merging their version numbers or claims.

## First push

```bash
git clone PBHP_SHADOW_PUBLIC_SITES_REPO_{RELEASE_DATE}.bundle pbhp-shadow-public-sites
cd pbhp-shadow-public-sites
git remote add origin <new-github-repository-url>
git push -u origin main --tags
```

## Branch protection

Require the `validate-public-sites` workflow before merge. Require at least one reviewer for changes to runtime claims, evidence states, publication allowlists, component metadata, test plans, or deployment instructions. Do not permit force pushes to `main`.

## Component change rule

A component change must update its source entry, generated `README.md`, `component.json`, and `TEST_PLAN.md`; regenerate all affected packs and manifests; retain adverse results; run the full validation suite; and receive a dated release receipt.

## GitHub Releases

Attach the complete repository ZIP, Git bundle, PBHP and Shadow deployment ZIPs, component-library bundles, checksums, validation summary, and release receipt. Describe what is specified, observed, adverse, and still open. Never label a release independently validated unless a materially independent party has actually completed that work.
"""
    _write(output_root / "GITHUB_REPOSITORY_SETUP.md", github_guide)

    file_rows: list[dict[str, Any]] = []
    for path in sorted(output_root.rglob("*")):
        if not path.is_file() or path.name == "PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json":
            continue
        file_rows.append({
            "file": str(path.relative_to(output_root)).replace("\\", "/"),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
    manifest = {
        "schema": "pbhp-shadow-component-library-manifest-v1",
        "component_library_version": COMPONENT_LIBRARY_VERSION,
        "release_date": RELEASE_DATE,
        "projects": {
            "pbhp": {"component_count": len(PBHP_COMPONENTS), "index": "pbhp/index.json"},
            "shadow": {"component_count": len(SHADOW_COMPONENTS), "index": "shadow/index.json"},
        },
        "combined_component_count": len(PBHP_COMPONENTS) + len(SHADOW_COMPONENTS),
        "bundles": bundle_records,
        "files": file_rows,
        "claim_boundary": "Component packs are specifications and test plans, not certification or independent validation.",
    }
    _write(output_root / "PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    return manifest


__all__ = [
    "PBHP_COMPONENTS",
    "SHADOW_COMPONENTS",
    "COMPONENT_LIBRARY_VERSION",
    "RELEASE_DATE",
    "STATUS_LABELS",
    "render_component_catalog",
    "render_testing_matrix",
    "write_component_artifacts",
    "component_pack_name",
    "project_bundle_name",
    "combined_bundle_name",
]
