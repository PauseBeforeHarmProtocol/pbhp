import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rel import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("PERSONAL","LOW"):"PROCEED",("PERSONAL","MEDIUM"):"PROCEED",("PERSONAL","HIGH"):"PROCEED",("PERSONAL","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("INTERNAL_DRAFT","LOW"):"PROCEED",("INTERNAL_DRAFT","MEDIUM"):"PROCEED",("INTERNAL_DRAFT","HIGH"):"PROCEED_WITH_DISCLOSURE",("INTERNAL_DRAFT","CRITICAL"):"VERIFY_FIRST",
    ("EXTERNAL_FACING","LOW"):"PROCEED",("EXTERNAL_FACING","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("EXTERNAL_FACING","HIGH"):"VERIFY_FIRST",("EXTERNAL_FACING","CRITICAL"):"VERIFY_FIRST",
    ("DECISION_SUPPORT","LOW"):"PROCEED_WITH_DISCLOSURE",("DECISION_SUPPORT","MEDIUM"):"VERIFY_FIRST",("DECISION_SUPPORT","HIGH"):"VERIFY_FIRST",("DECISION_SUPPORT","CRITICAL"):"REFUSE_PENDING_HUMAN_OWNERSHIP",
}

def test_input_to_state():
    assert derive_state("personal") is State.PERSONAL and derive_state("decision_support") is State.DECISION_SUPPORT
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.DECISION_SUPPORT,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.DECISION_SUPPORT,Stakes.CRITICAL) is False
def test_audit_decision_support_critical():
    r=audit(reliance="decision_support",stakes="CRITICAL")
    assert r.state=="DECISION_SUPPORT" and r.verdict=="REFUSE_PENDING_HUMAN_OWNERSHIP"
def test_audit_personal_safe(): assert audit(reliance="personal",stakes="HIGH").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(reliance="external_facing",stakes="HIGH",override_ack="op:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(reliance="decision_support",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(reliance="internal_draft",stakes="LOW")
    assert r.schema=="operator_reliance.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"operator_reliance"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[REL] {p}/{p+q} passed"); sys.exit(1 if q else 0)
