# REL-16: Operator Reliance — Downstream-Use Disclosure
## SIL gauge #16 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `operator_reliance.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on how the output will be relied upon once it leaves the model. The same content is low-risk as a personal note and high-risk as the basis of a consequential decision. Reliance must affect gating.

## 2. State (= declared reliance)
`personal` / `internal_draft` / `external_facing` / `decision_support` (ascending reliance).
- personal — for the operator's own use.
- internal_draft — shared internally, still a draft.
- external_facing — published or sent outside.
- decision_support — feeds a consequential human decision.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| PERSONAL | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| INTERNAL_DRAFT | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| EXTERNAL_FACING | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| DECISION_SUPPORT | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_PENDING_HUMAN_OWNERSHIP |

Floor: DECISION_SUPPORT/CRITICAL → REFUSE_PENDING_HUMAN_OWNERSHIP (non-overridable; a model output cannot be the sole basis of a critical decision — a human must own it). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Stakes Classification (severity of the task) and Reversibility (undo cost of the action): Operator Reliance is who acts on the output and how far it travels. The same HIGH-stakes content is gated differently as a personal draft versus decision support.

## 5. Receipt (`operator_reliance.receipt.v1`)
`reliance · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
