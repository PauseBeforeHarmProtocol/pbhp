"""REL-16 Operator Reliance (SIL gauge #16). stdlib only.

Gates on how the operator will rely on the output -- from private personal use
up to feeding a consequential human decision. The further downstream the
reliance, the tighter the gate. Scoped claim: distinct from Stakes (severity of
the task) and Reversibility (undo cost of the action) -- Operator Reliance is
*who acts on this and how far it travels* once it leaves the model.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    PERSONAL = "PERSONAL"; INTERNAL_DRAFT = "INTERNAL_DRAFT"
    EXTERNAL_FACING = "EXTERNAL_FACING"; DECISION_SUPPORT = "DECISION_SUPPORT"


_INPUT = {"personal": State.PERSONAL, "internal_draft": State.INTERNAL_DRAFT,
          "external_facing": State.EXTERNAL_FACING, "decision_support": State.DECISION_SUPPORT}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_PENDING_HUMAN_OWNERSHIP = "REFUSE_PENDING_HUMAN_OWNERSHIP"


POLICY_VERSION = "operator_reliance-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_PENDING_HUMAN_OWNERSHIP)
_MATRIX = {
    (State.PERSONAL, Stakes.LOW): _P, (State.PERSONAL, Stakes.MEDIUM): _P,
    (State.PERSONAL, Stakes.HIGH): _P, (State.PERSONAL, Stakes.CRITICAL): _D,
    (State.INTERNAL_DRAFT, Stakes.LOW): _P, (State.INTERNAL_DRAFT, Stakes.MEDIUM): _P,
    (State.INTERNAL_DRAFT, Stakes.HIGH): _D, (State.INTERNAL_DRAFT, Stakes.CRITICAL): _V,
    (State.EXTERNAL_FACING, Stakes.LOW): _P, (State.EXTERNAL_FACING, Stakes.MEDIUM): _D,
    (State.EXTERNAL_FACING, Stakes.HIGH): _V, (State.EXTERNAL_FACING, Stakes.CRITICAL): _V,
    (State.DECISION_SUPPORT, Stakes.LOW): _D, (State.DECISION_SUPPORT, Stakes.MEDIUM): _V,
    (State.DECISION_SUPPORT, Stakes.HIGH): _V, (State.DECISION_SUPPORT, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_PENDING_HUMAN_OWNERSHIP}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(reliance):
    return _INPUT[reliance]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class RELReceipt:
    reliance: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "operator_reliance.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"operator_reliance": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, reliance, stakes, override_ack=None, now=None):
    state = derive_state(reliance)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return RELReceipt(reliance=reliance, state=state.value, stakes=Stakes(stakes).value,
                      verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "RELReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
