import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import stk
from stk import audit, classify, ruleset_hash

def test_default_low():
    r = audit()
    assert r.stakes_level == "LOW" and r.ladder_color == "GREEN" and r.disclosure_tier == "none"

def test_internal_medium():
    r = audit(reliance="internal")
    assert r.stakes_level == "MEDIUM" and r.ladder_color == "YELLOW" and r.disclosure_tier == "one-line"

def test_external_high():
    r = audit(reliance="external")
    assert r.stakes_level == "HIGH" and r.ladder_color == "ORANGE" and r.disclosure_tier == "block"

def test_safety_critical():
    r = audit(safety_legal_medical=True)
    assert r.stakes_level == "CRITICAL" and r.ladder_color == "RED"
    assert r.dominant_reason == "safety/legal/medical"

def test_irreversible_critical():
    assert audit(reversibility="irreversible").stakes_level == "CRITICAL"

def test_regulated_plus_external_critical():
    assert audit(regulated=True, reliance="external").stakes_level == "CRITICAL"

def test_ambiguous_rounds_up():
    assert audit(ambiguous=True).stakes_level == "MEDIUM"

def test_third_party_high():
    assert audit(third_party=True).stakes_level == "HIGH"

def test_monotonic_highest_wins():
    lvl, reasons, dom = classify(reliance="internal", safety_legal_medical=True)
    assert lvl.value == "CRITICAL"

def test_receipt_schema_json_hash():
    r = audit(reliance="external")
    assert r.schema == "stakes.receipt.v1" and len(r.ruleset_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"stakes"}

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[STK] {p}/{p + q} passed"); sys.exit(1 if q else 0)
