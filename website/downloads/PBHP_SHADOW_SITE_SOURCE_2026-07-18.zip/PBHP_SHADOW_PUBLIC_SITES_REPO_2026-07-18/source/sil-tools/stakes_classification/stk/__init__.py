"""STK-4 Stakes Classification (SIL gauge #4). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class Reliance(str, Enum):
    PERSONAL = "personal"; INTERNAL = "internal"
    EXTERNAL = "external"; DECISION_SUPPORT = "decision_support"


class Reversibility(str, Enum):
    EASY = "easy"; MODERATE = "moderate"; HARD = "hard"; IRREVERSIBLE = "irreversible"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Ladder(str, Enum):
    GREEN = "GREEN"; YELLOW = "YELLOW"; ORANGE = "ORANGE"; RED = "RED"; BLACK = "BLACK"


POLICY_VERSION = "stakes-default/0.1.0"
_ORDER = [Stakes.LOW, Stakes.MEDIUM, Stakes.HIGH, Stakes.CRITICAL]
_LADDER = {Stakes.LOW: Ladder.GREEN, Stakes.MEDIUM: Ladder.YELLOW,
           Stakes.HIGH: Ladder.ORANGE, Stakes.CRITICAL: Ladder.RED}
_DISCLOSURE = {Stakes.LOW: "none", Stakes.MEDIUM: "one-line",
               Stakes.HIGH: "block", Stakes.CRITICAL: "block+gate+receipt"}


def ruleset_hash() -> str:
    sig = ("stakes-rules/0.1|internal>=MED|moderate>=MED|ambiguous>=MED|"
           "external>=HIGH|third_party>=HIGH|hard>=HIGH|decision>=HIGH|"
           "regulated>=HIGH|safety>=CRIT|irreversible>=CRIT|reg+ext>=CRIT|roundup")
    return hashlib.sha256(sig.encode("utf-8")).hexdigest()


def classify(*, reliance="personal", reversibility="easy", regulated=False,
             third_party=False, safety_legal_medical=False, ambiguous=False):
    rel = Reliance(reliance); rev = Reversibility(reversibility)
    t = []  # (level, why)
    if rel is Reliance.INTERNAL: t.append((Stakes.MEDIUM, "internal reliance"))
    if rev is Reversibility.MODERATE: t.append((Stakes.MEDIUM, "moderate reversibility"))
    if ambiguous: t.append((Stakes.MEDIUM, "ambiguous request; rounded up"))
    if rel is Reliance.EXTERNAL: t.append((Stakes.HIGH, "external-facing"))
    if third_party: t.append((Stakes.HIGH, "third-party reliance"))
    if rev is Reversibility.HARD: t.append((Stakes.HIGH, "hard to reverse"))
    if rel is Reliance.DECISION_SUPPORT: t.append((Stakes.HIGH, "decision support"))
    if regulated: t.append((Stakes.HIGH, "regulated domain"))
    if safety_legal_medical: t.append((Stakes.CRITICAL, "safety/legal/medical"))
    if rev is Reversibility.IRREVERSIBLE: t.append((Stakes.CRITICAL, "irreversible"))
    if regulated and rel in (Reliance.EXTERNAL, Reliance.DECISION_SUPPORT):
        t.append((Stakes.CRITICAL, "regulated + external/decision"))
    level = Stakes.LOW
    for to, _ in t:
        if _ORDER.index(to) > _ORDER.index(level):
            level = to
    reasons = [w for _, w in t]
    dominant = next((w for lv, w in t if lv == level), "baseline low-stakes")
    return level, reasons, dominant


@dataclass
class STKReceipt:
    signals: dict
    stakes_level: str
    ladder_color: str
    disclosure_tier: str
    dominant_reason: str
    reasons: list
    policy_version: str = POLICY_VERSION
    ruleset_hash: str = field(default_factory=ruleset_hash)
    issued_at: str = ""
    schema: str = "stakes.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"stakes": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, reliance="personal", reversibility="easy", regulated=False,
          third_party=False, safety_legal_medical=False, ambiguous=False, now=None) -> STKReceipt:
    level, reasons, dominant = classify(
        reliance=reliance, reversibility=reversibility, regulated=regulated,
        third_party=third_party, safety_legal_medical=safety_legal_medical, ambiguous=ambiguous)
    return STKReceipt(
        signals={"reliance": reliance, "reversibility": reversibility, "regulated": regulated,
                 "third_party": third_party, "safety_legal_medical": safety_legal_medical,
                 "ambiguous": ambiguous},
        stakes_level=level.value, ladder_color=_LADDER[level].value,
        disclosure_tier=_DISCLOSURE[level], dominant_reason=dominant,
        reasons=reasons, issued_at=_now_iso(now))


__all__ = ["audit", "classify", "STKReceipt", "Reliance", "Reversibility",
           "Stakes", "Ladder", "ruleset_hash", "POLICY_VERSION"]
