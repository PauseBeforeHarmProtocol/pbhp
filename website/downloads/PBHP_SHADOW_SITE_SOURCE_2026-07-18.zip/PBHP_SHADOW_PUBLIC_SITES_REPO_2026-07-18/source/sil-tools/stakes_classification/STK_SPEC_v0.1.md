# STK-4: Stakes Classification — Risk-Envelope Disclosure
## SIL gauge #4 — Specification v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `stakes.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
The spine of the panel: every other gauge gates on stakes. This gauge makes the system *state the risk envelope it thinks it is operating in* (LOW/MEDIUM/HIGH/CRITICAL) from explicit signals, so the operator can correct a misclassification before it propagates. Maps to PBHP's GREEN→BLACK ladder.

## 2. Signals
`reliance` (personal/internal/external/decision_support) · `reversibility` (easy/moderate/hard/irreversible) · `regulated` · `third_party` · `safety_legal_medical` · `ambiguous` (round-up flag).

## 3. Rules (monotonic bumps; highest wins; round up when in doubt)
internal or moderate or ambiguous → ≥ MEDIUM · external or third_party or hard or decision_support or regulated → ≥ HIGH · safety_legal_medical or irreversible or (regulated & external/decision) → CRITICAL.

## 4. Output
`stakes_level` + ladder color (LOW→GREEN, MEDIUM→YELLOW, HIGH→ORANGE, CRITICAL→RED; BLACK reserved for catastrophic) + recommended `disclosure_tier` (none / one-line / block / block+gate+receipt) + dominant reason. Ruleset SHA-256-hashed into the receipt.

## 5. Receipt (`stakes.receipt.v1`)
`signals · stakes_level · ladder_color · disclosure_tier · dominant_reason · reasons · policy_version · ruleset_hash · issued_at · schema`.

## 6. Boundary / Limitations
Classifies the envelope from declared signals; it does not detect undeclared stakes. Conservative by design (round up). This is a classifier, not a gate — its output is the `stakes` input the other gauges consume.
