import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mode import (audit, State, Stakes, Verdict, derive_state, gate,
                  is_overridable, matrix_hash, NON_OVERRIDABLE,
                  DETERMINISTIC_MAX, LOW_VARIANCE_MAX, CREATIVE_MAX)

EXPECTED = {
    ("DETERMINISTIC","LOW"):"PROCEED",("DETERMINISTIC","MEDIUM"):"PROCEED",("DETERMINISTIC","HIGH"):"PROCEED",("DETERMINISTIC","CRITICAL"):"PROCEED",
    ("LOW_VARIANCE","LOW"):"PROCEED",("LOW_VARIANCE","MEDIUM"):"PROCEED",("LOW_VARIANCE","HIGH"):"PROCEED",("LOW_VARIANCE","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("CREATIVE","LOW"):"PROCEED",("CREATIVE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("CREATIVE","HIGH"):"VERIFY_FIRST",("CREATIVE","CRITICAL"):"VERIFY_FIRST",
    ("HIGH_VARIANCE","LOW"):"PROCEED_WITH_DISCLOSURE",("HIGH_VARIANCE","MEDIUM"):"VERIFY_FIRST",("HIGH_VARIANCE","HIGH"):"VERIFY_FIRST",("HIGH_VARIANCE","CRITICAL"):"REFUSE_NONREPRODUCIBLE",
    ("UNKNOWN","LOW"):"PROCEED_WITH_DISCLOSURE",("UNKNOWN","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("UNKNOWN","HIGH"):"VERIFY_FIRST",("UNKNOWN","CRITICAL"):"VERIFY_FIRST",
}

# --- state derivation -------------------------------------------------------
def test_mode_input(): assert derive_state(mode="deterministic") is State.DETERMINISTIC and derive_state(mode="high_variance") is State.HIGH_VARIANCE
def test_not_disclosed_unknown(): assert derive_state(disclosed=False, mode="creative") is State.UNKNOWN
def test_no_input_unknown(): assert derive_state() is State.UNKNOWN
def test_temp_deterministic(): assert derive_state(temperature=0.0) is State.DETERMINISTIC
def test_temp_low_variance_boundary(): assert derive_state(temperature=0.3) is State.LOW_VARIANCE   # <=0.3
def test_temp_creative(): assert derive_state(temperature=0.5) is State.CREATIVE
def test_temp_creative_boundary(): assert derive_state(temperature=0.8) is State.CREATIVE            # <=0.8
def test_temp_high_variance(): assert derive_state(temperature=0.9) is State.HIGH_VARIANCE
def test_temp_negative_raises():
    try: derive_state(temperature=-0.1); assert False
    except ValueError: pass
def test_mode_wins_over_temp(): assert derive_state(mode="deterministic", temperature=1.5) is State.DETERMINISTIC
def test_thresholds_are_policy(): assert (DETERMINISTIC_MAX,LOW_VARIANCE_MAX,CREATIVE_MAX)==(0.0,0.3,0.8)

# --- full matrix ------------------------------------------------------------
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED

# --- floor ------------------------------------------------------------------
def test_floor_single_corner(): assert NON_OVERRIDABLE=={(State.HIGH_VARIANCE,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.HIGH_VARIANCE,Stakes.CRITICAL) is False
def test_deterministic_always_overridable_noop(): assert is_overridable(State.DETERMINISTIC,Stakes.CRITICAL) is True

# --- audit end-to-end -------------------------------------------------------
def test_audit_high_variance_critical_refuses():
    r=audit(mode="high_variance",stakes="CRITICAL")
    assert r.state=="HIGH_VARIANCE" and r.verdict=="REFUSE_NONREPRODUCIBLE"
def test_audit_deterministic_safe(): assert audit(mode="deterministic",stakes="CRITICAL").verdict=="PROCEED"
def test_audit_creative_high_verifies():
    r=audit(mode="creative",stakes="HIGH"); assert r.state=="CREATIVE" and r.verdict=="VERIFY_FIRST"
def test_audit_unknown_high_verifies():
    r=audit(stakes="HIGH",disclosed=False); assert r.state=="UNKNOWN" and r.verdict=="VERIFY_FIRST"
def test_audit_records_model_and_temp():
    r=audit(stakes="LOW",temperature=0.2,model="claude-opus-4-8")
    assert r.model=="claude-opus-4-8" and r.temperature==0.2 and r.state=="LOW_VARIANCE"

# --- override ---------------------------------------------------------------
def test_override_relaxes_non_floor():
    r=audit(mode="creative",stakes="HIGH",override_ack="op:accepts-variance")
    assert r.verdict=="VERIFY_FIRST" and r.override["applied"] is True and r.override["ack"]=="op:accepts-variance"
def test_override_ignored_on_floor():
    r=audit(mode="high_variance",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True

# --- receipt ----------------------------------------------------------------
def test_receipt_schema_json_pbhp():
    r=audit(mode="low_variance",stakes="LOW")
    assert r.schema=="model_mode.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"model_mode"}
def test_receipt_carries_thresholds():
    r=audit(mode="creative",stakes="LOW")
    assert r.thresholds=={"deterministic_max":0.0,"low_variance_max":0.3,"creative_max":0.8}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[MMS] {p}/{p+q} passed"); sys.exit(1 if q else 0)
