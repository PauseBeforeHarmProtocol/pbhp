# MMS-22: Model Mode / Sampling — Reproducibility Disclosure
## SIL gauge #22 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `model_mode.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on the reproducibility / variability regime of the generation itself — whether the output came from a deterministic decode or a high-variance sample that would differ on rerun — and record model + version. The same task is acceptable from a deterministic decode and a reliability risk from a high-variance sample. Sampling mode must affect gating.

## 2. State (= sampling regime of the generation)
`deterministic` / `low_variance` / `creative` / `high_variance` (ascending variance), plus `unknown`.
- deterministic — greedy / temperature ≈ 0; reproducible.
- low_variance — low temperature; largely stable run-to-run.
- creative — moderate temperature; intentionally varied (brainstorming, drafting).
- high_variance — high temperature / top-p; low reproducibility, output can swing.
- unknown — sampling parameters not disclosed. Escalates to verification; not the hard floor.

Derivable from a declared mode, or from a `temperature` via versioned policy thresholds (`deterministic_max=0.0`, `low_variance_max=0.3`, `creative_max=0.8`; thresholds are policy, recorded in every receipt — not physics).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| DETERMINISTIC | PROCEED | PROCEED | PROCEED | PROCEED |
| LOW_VARIANCE | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| CREATIVE | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| HIGH_VARIANCE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_NONREPRODUCIBLE |
| UNKNOWN | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |

Floor: HIGH_VARIANCE/CRITICAL → REFUSE_NONREPRODUCIBLE (non-overridable; a critical, hard-to-reverse decision must not rest on a single non-reproducible draw — pin the sampling or get human verification). Override relaxes only DISCLOSE / VERIFY cells. UNKNOWN mirrors RC's UNKNOWN: undisclosed sampling escalates to VERIFY but is not an absolute refuse.

## 4. Scoped claim
Distinct from Validation Status (#14), Uncertainty Source (#5), and Context Load (CLA). Validation Status is whether the output was *checked*; Model Mode is whether it is *reproducible* in the first place — a validated answer can still be one unstable sample. Uncertainty Source is the kind of uncertainty in the *content*; Model Mode is uncertainty introduced by the *sampling process*, independent of content. Context Load is window fill; sampling variance is orthogonal to load. This gauge instruments the non-reproducibility failure mode.

## 5. Receipt (`model_mode.receipt.v1`)
`mode · temperature · model · disclosed · state · stakes · verdict · thresholds · policy_version · matrix_hash · override · issued_at · schema`.
