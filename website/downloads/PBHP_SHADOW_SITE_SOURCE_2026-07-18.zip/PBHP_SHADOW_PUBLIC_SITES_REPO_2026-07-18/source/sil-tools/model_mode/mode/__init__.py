"""MMS-22 Model Mode / Sampling (SIL gauge #22). stdlib only.

Gates on the *reproducibility / variability regime of the generation itself*
-- whether the output came from a deterministic decode or a high-variance
sample that would differ on rerun -- and records model + version. The failure
mode it instruments: resting a high-stakes, hard-to-reverse decision on a single
draw from a high-variance distribution that is not reproducible.

Scoped claim (what it adds that the neighbours do not):
  * Validation Status (#14) is whether the output was *checked*; Model Mode is
    whether the output is *reproducible* in the first place -- a validated answer
    can still be one unstable sample.
  * Uncertainty Source (#5) is the kind of uncertainty in the *content*; Model
    Mode is uncertainty introduced by the *sampling process*, independent of the
    content.
  * Context Load (CLA) is window fill; sampling variance is orthogonal to load.

The four *disclosed* modes run by ascending variance / ascending risk
(DETERMINISTIC < LOW_VARIANCE < CREATIVE < HIGH_VARIANCE). The fifth state,
UNKNOWN, is "sampling parameters not disclosed" -- like RC's UNKNOWN it
escalates to verification but is NOT the hard floor. Single non-overridable
floor: HIGH_VARIANCE x CRITICAL -> REFUSE_NONREPRODUCIBLE.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    DETERMINISTIC = "DETERMINISTIC"; LOW_VARIANCE = "LOW_VARIANCE"
    CREATIVE = "CREATIVE"; HIGH_VARIANCE = "HIGH_VARIANCE"; UNKNOWN = "UNKNOWN"


_INPUT = {"deterministic": State.DETERMINISTIC, "low_variance": State.LOW_VARIANCE,
          "creative": State.CREATIVE, "high_variance": State.HIGH_VARIANCE,
          "unknown": State.UNKNOWN}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_NONREPRODUCIBLE = "REFUSE_NONREPRODUCIBLE"


# Sampling thresholds are POLICY (versioned, recorded in every receipt), not
# physics -- same discipline as CLA's load bands and RC's coverage thresholds.
DETERMINISTIC_MAX = 0.0    # temperature <= this -> DETERMINISTIC
LOW_VARIANCE_MAX = 0.3     # <= this -> LOW_VARIANCE
CREATIVE_MAX = 0.8         # <= this -> CREATIVE ; above -> HIGH_VARIANCE
POLICY_VERSION = "model-mode-default/0.1.0"

_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_NONREPRODUCIBLE)
_MATRIX = {
    (State.DETERMINISTIC, Stakes.LOW): _P, (State.DETERMINISTIC, Stakes.MEDIUM): _P,
    (State.DETERMINISTIC, Stakes.HIGH): _P, (State.DETERMINISTIC, Stakes.CRITICAL): _P,
    (State.LOW_VARIANCE, Stakes.LOW): _P, (State.LOW_VARIANCE, Stakes.MEDIUM): _P,
    (State.LOW_VARIANCE, Stakes.HIGH): _P, (State.LOW_VARIANCE, Stakes.CRITICAL): _D,
    (State.CREATIVE, Stakes.LOW): _P, (State.CREATIVE, Stakes.MEDIUM): _D,
    (State.CREATIVE, Stakes.HIGH): _V, (State.CREATIVE, Stakes.CRITICAL): _V,
    (State.HIGH_VARIANCE, Stakes.LOW): _D, (State.HIGH_VARIANCE, Stakes.MEDIUM): _V,
    (State.HIGH_VARIANCE, Stakes.HIGH): _V, (State.HIGH_VARIANCE, Stakes.CRITICAL): _R,
    (State.UNKNOWN, Stakes.LOW): _D, (State.UNKNOWN, Stakes.MEDIUM): _D,
    (State.UNKNOWN, Stakes.HIGH): _V, (State.UNKNOWN, Stakes.CRITICAL): _V,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_NONREPRODUCIBLE}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(mode=None, temperature=None, disclosed=True):
    """Map declared sampling mode (or a temperature, via policy thresholds) to a
    State. If parameters are not disclosed -> UNKNOWN. An explicit `mode` wins
    over `temperature`."""
    if not disclosed:
        return State.UNKNOWN
    if mode is not None:
        return _INPUT[mode]
    if temperature is not None:
        if temperature < 0:
            raise ValueError("derive_state refuses: temperature must be >= 0.")
        if temperature <= DETERMINISTIC_MAX:
            return State.DETERMINISTIC
        if temperature <= LOW_VARIANCE_MAX:
            return State.LOW_VARIANCE
        if temperature <= CREATIVE_MAX:
            return State.CREATIVE
        return State.HIGH_VARIANCE
    return State.UNKNOWN


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class ModelModeReceipt:
    mode: object
    temperature: object
    model: object
    disclosed: bool
    state: str
    stakes: str
    verdict: str
    thresholds: dict = field(default_factory=lambda: {
        "deterministic_max": DETERMINISTIC_MAX, "low_variance_max": LOW_VARIANCE_MAX,
        "creative_max": CREATIVE_MAX})
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "model_mode.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"model_mode": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, stakes, mode=None, temperature=None, model=None, disclosed=True,
          override_ack=None, now=None):
    state = derive_state(mode, temperature, disclosed)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return ModelModeReceipt(
        mode=mode, temperature=temperature, model=model, disclosed=disclosed,
        state=state.value, stakes=Stakes(stakes).value, verdict=verdict.value,
        override=override, issued_at=_now_iso(now))


__all__ = ["audit", "ModelModeReceipt", "State", "Stakes", "Verdict",
           "derive_state", "gate", "is_overridable", "matrix_hash",
           "DETERMINISTIC_MAX", "LOW_VARIANCE_MAX", "CREATIVE_MAX",
           "POLICY_VERSION", "NON_OVERRIDABLE"]
