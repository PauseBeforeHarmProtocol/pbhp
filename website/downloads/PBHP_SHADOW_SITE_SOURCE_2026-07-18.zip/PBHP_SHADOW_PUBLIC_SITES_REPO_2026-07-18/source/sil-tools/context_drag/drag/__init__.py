"""Context Drag (DRAG) -- FCR-family SIL companion gauge. BEHAVIORAL / weaker evidence tier. stdlib only.

How much of the answer was steered by material that belonged on the periphery (the FCR-suppressed / irrelevant
prior context) rather than by the Task Kernel + Required Context. A *labeled self-assessment* of the model's
own answer-formation -- NOT a measurement. Per framework SS6.6 the measured gauges outrank the behavioral ones,
so DRAG carries NO non-overridable REFUSE floor; its strongest verdict is VERIFY_FIRST. Mirrors drift_coherence #23.

Distinct from drift_coherence #23 (whole-session trajectory) -- DRAG is the pull of specifically the FCR-suppressed
material on THIS answer: did the racing line hold. Spec: context_drag/DRAG_SPEC_v0.1.md. Composes FCR #13 by
reference; no CORE edit (X-3). Sterile (X-6). Origin: external GPT "AI 2027" (proposal, not evidence; X-2). BUILT, not ACCEPTED.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"

EVIDENCE_TIER = "behavioral"
POLICY_VERSION = "context-drag-default/0.1.0"


class State(str, Enum):
    CLEAN = "CLEAN"; MINOR = "MINOR"; STEERING = "STEERING"; DERAILED = "DERAILED"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    # Behavioral gauge: caps at VERIFY_FIRST (no REFUSE floor -- SS6.6; measured outrank behavioral).
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"


_P, _D, _V = Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST
# Escalation mirrored on drift_coherence #23 (the behavioral sibling).
_MATRIX = {
    (State.CLEAN, Stakes.LOW): _P, (State.CLEAN, Stakes.MEDIUM): _P, (State.CLEAN, Stakes.HIGH): _P, (State.CLEAN, Stakes.CRITICAL): _P,
    (State.MINOR, Stakes.LOW): _P, (State.MINOR, Stakes.MEDIUM): _P, (State.MINOR, Stakes.HIGH): _D, (State.MINOR, Stakes.CRITICAL): _D,
    (State.STEERING, Stakes.LOW): _P, (State.STEERING, Stakes.MEDIUM): _D, (State.STEERING, Stakes.HIGH): _V, (State.STEERING, Stakes.CRITICAL): _V,
    (State.DERAILED, Stakes.LOW): _D, (State.DERAILED, Stakes.MEDIUM): _V, (State.DERAILED, Stakes.HIGH): _V, (State.DERAILED, Stakes.CRITICAL): _V,
}
# Behavioral gauge: NO non-overridable floor by design (SS6.6).
NON_OVERRIDABLE = set()


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(peripheral_influence, total_influence, decision_critical=False):
    p = int(peripheral_influence); t = int(total_influence)
    if p < 0 or t < 0:
        raise ValueError("influence counts must be >= 0")
    if p > t:
        raise ValueError("peripheral_influence cannot exceed total_influence")
    if decision_critical and p == 0:
        raise ValueError("decision_critical requires at least one peripheral influence")
    if t == 0 or p == 0:
        return State.CLEAN
    if decision_critical:
        return State.DERAILED
    return State.STEERING if (p / t) >= 0.5 else State.MINOR


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class DragReceipt:
    peripheral_influence: int
    total_influence: int
    drag_ratio: float
    decision_critical: bool
    state: str
    stakes: str
    verdict: str
    evidence_tier: str = EVIDENCE_TIER
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "context_drag.receipt.v1"

    def to_dict(self):
        return {
            "peripheral_influence": self.peripheral_influence, "total_influence": self.total_influence,
            "drag_ratio": self.drag_ratio, "decision_critical": self.decision_critical,
            "state": self.state, "stakes": self.stakes, "verdict": self.verdict,
            "evidence_tier": self.evidence_tier, "policy_version": self.policy_version,
            "matrix_hash": self.matrix_hash, "override": dict(self.override),
            "issued_at": self.issued_at, "schema": self.schema,
        }

    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"context_drag": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, peripheral_influence, total_influence, decision_critical=False, stakes, override_ack=None, now=None):
    state = derive_state(peripheral_influence, total_influence, decision_critical)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)               # always True: behavioral, no floor
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable          # always False -- no floor to ignore
    ratio = round(int(peripheral_influence) / int(total_influence), 4) if int(total_influence) > 0 else 0.0
    return DragReceipt(peripheral_influence=int(peripheral_influence), total_influence=int(total_influence),
                       drag_ratio=ratio, decision_critical=bool(decision_critical), state=state.value,
                       stakes=Stakes(stakes).value, verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "DragReceipt", "State", "Stakes", "Verdict", "derive_state", "gate",
           "is_overridable", "matrix_hash", "EVIDENCE_TIER", "POLICY_VERSION", "NON_OVERRIDABLE"]
