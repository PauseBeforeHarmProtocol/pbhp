# Context Drag (DRAG) — SPEC v0.1  (behavioral tier)

**FCR-family SIL companion gauge · #13 Focal Context Routing.** Candidate; number/panel-count deferred to Phil.
**Register:** sterile. **Status:** BUILT — not ACCEPTED. **Behavioral / weaker evidence tier.** No CORE edit (X-3); composes by reference. Personal seed firewalled (X-6). External GPT origin (X-2, proposal not evidence).

## What it asks
Given a focal packet (FCR) and the produced answer: **how much of the answer was steered by material that belonged on the periphery** — the suppressed / irrelevant prior context — rather than by the Task Kernel + Required Context? This is *drag*: the pull of the accumulated history on an answer that should have run the racing line.

## Evidence tier (corrected 2026-07-13)
This is a **behavioral self-assessment**, like `drift_coherence` #23 — a *labeled judgment about the model's own answer-formation, NOT a measurement*. Per framework **§6.6** the measured gauges outrank the behavioral ones, so DRAG carries **NO non-overridable REFUSE floor**; its strongest verdict is **VERIFY_FIRST** ("re-focus / re-ground before relying on this at high stakes"). Every receipt carries `evidence_tier="behavioral"`.

## Distinct from its neighbours (anti-inflation / NG-1 — crosswalk)
- **drift_coherence #23** — the *session's* coherence/trajectory over time (whole-thread drift). DRAG is narrower: the pull of *specifically the FCR-suppressed/peripheral* material on *this* answer. It is the reading that says whether the racing line actually held.
- **memory_compaction #13** / **retrieval_coverage #11** — about what was lost or not retrieved; DRAG is about what was *retained-but-should-have-been-peripheral* still steering the output.

## States (increasing severity)
`CLEAN` (no peripheral influence) · `MINOR` (some, below half, none decision-critical) · `STEERING` (peripheral ≥ half of what shaped the answer) · `DERAILED` (a suppressed/irrelevant item drove a decision-critical part).

## Derivation
`derive_state(peripheral_influence, total_influence, decision_critical=False)` over non-negative counts (peripheral ≤ total): `0 peripheral → CLEAN`; `decision_critical → DERAILED`; `ratio ≥ 0.5 → STEERING`; else `MINOR`. `decision_critical` requires ≥1 peripheral influence.

## Gate (no floor)
Deterministic Stakes × State matrix, SHA-256-hashed into every receipt (pinned by a test), escalation mirrored on `drift_coherence` #23. Worst corner (`DERAILED × CRITICAL`) tops out at **VERIFY_FIRST**; `NON_OVERRIDABLE` is empty by design (behavioral tier). Override relaxes DISCLOSE/VERIFY.

Receipt: `context_drag.receipt.v1` — carries `evidence_tier`, `drag_ratio`, `matrix_hash`; `to_dict` / `to_json` / `to_pbhp_extension`.
