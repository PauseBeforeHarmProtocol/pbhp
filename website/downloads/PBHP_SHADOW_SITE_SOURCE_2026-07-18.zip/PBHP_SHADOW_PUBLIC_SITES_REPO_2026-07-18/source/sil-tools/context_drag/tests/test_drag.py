import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from drag import (audit, derive_state, gate, is_overridable, State, Stakes, Verdict,
                  matrix_hash, NON_OVERRIDABLE, EVIDENCE_TIER)

EXPECTED_MATRIX_HASH = "97acf0d00e5d055c32027455e969b0f8d596b23c46a1112187737f7f49bf6e9e"

def test_states_derive():
    assert derive_state(0, 0) == State.CLEAN
    assert derive_state(0, 5) == State.CLEAN
    assert derive_state(1, 10) == State.MINOR
    assert derive_state(4, 10) == State.MINOR
    assert derive_state(5, 10) == State.STEERING
    assert derive_state(1, 10, decision_critical=True) == State.DERAILED
def test_derive_guards():
    for bad in [lambda: derive_state(-1, 5), lambda: derive_state(6, 5), lambda: derive_state(0, 5, True)]:
        try: bad(); assert False
        except ValueError: pass
def test_matrix_hash_pinned_and_64():
    h = matrix_hash(); assert len(h) == 64 and h == EXPECTED_MATRIX_HASH, h
def test_behavioral_no_floor():
    assert NON_OVERRIDABLE == set()
    worst = {gate(st, Stakes.CRITICAL).value for st in State}
    assert "REFUSE" not in " ".join(worst)
    assert gate(State.DERAILED, Stakes.CRITICAL) == Verdict.VERIFY_FIRST
def test_no_refuse_verdict_exists():
    assert [v.value for v in Verdict] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST"]
def test_clean_always_proceeds():
    for s in Stakes: assert gate(State.CLEAN, s) == Verdict.PROCEED
def test_minor_matrix():
    assert [gate(State.MINOR, s).value for s in Stakes] == ["PROCEED", "PROCEED", "PROCEED_WITH_DISCLOSURE", "PROCEED_WITH_DISCLOSURE"]
def test_steering_matrix():
    assert [gate(State.STEERING, s).value for s in Stakes] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_derailed_matrix_caps_at_verify():
    assert [gate(State.DERAILED, s).value for s in Stakes] == ["PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_matrix_total_16():
    from itertools import product
    for st, sk in product(State, Stakes): assert isinstance(gate(st, sk), Verdict)
def test_evidence_tier_behavioral():
    r = audit(peripheral_influence=1, total_influence=4, stakes="HIGH")
    assert r.evidence_tier == "behavioral" and EVIDENCE_TIER == "behavioral"
def test_override_relaxes_disclosure_and_verify():
    assert audit(peripheral_influence=1, total_influence=4, stakes="HIGH", override_ack="op").override["applied"] is True
    assert audit(peripheral_influence=3, total_influence=4, decision_critical=True, stakes="CRITICAL", override_ack="op").override["applied"] is True
def test_floor_never_ignored():
    # when the override applies, there is no floor being ignored (no key)
    r1 = audit(peripheral_influence=3, total_influence=4, decision_critical=True, stakes="CRITICAL", override_ack="op")
    assert r1.override["applied"] is True and r1.override.get("ignored_floor") is not True
    # when nothing is relaxable (PROCEED), ignored_floor is recorded but is never True (no floor exists)
    r2 = audit(peripheral_influence=0, total_influence=5, stakes="LOW", override_ack="op")
    assert r2.override["applied"] is False and r2.override.get("ignored_floor") is False
def test_is_overridable_all_true():
    from itertools import product
    for st, sk in product(State, Stakes): assert is_overridable(st, sk) is True
def test_drag_ratio_recorded():
    assert audit(peripheral_influence=3, total_influence=4, stakes="LOW").drag_ratio == 0.75
def test_receipt_schema_json_pbhp():
    r = audit(peripheral_influence=1, total_influence=10, stakes="MEDIUM")
    assert r.schema == "context_drag.receipt.v1" and len(r.matrix_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"context_drag"}
    assert r.to_dict()["evidence_tier"] == "behavioral"

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[DRAG] {p}/{p+q} passed"); sys.exit(1 if q else 0)
