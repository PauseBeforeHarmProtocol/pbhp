"""Focal Context Routing (FCR) -- "The Racing Line". Sterile context-prioritization primitive. stdlib only.

First build slice (proposed #13): the focal-packet emitter + the recoverable Suppressed-Context register.
Given admissible, manageable, complete-enough context, it builds a bounded present -- a focal packet (the
"racing line") -- so the current ask gets full bandwidth without being steered by the whole accumulated
history. It selects; it does NOT delete: everything moved off the line is retained in a register and is
recoverable by label.

THE LOAD-BEARING SAFETY BOUNDARY. "Latest text wins" is WRONG. A late prompt can be malicious, mistaken,
a false premise, or inconsistent with a standing constraint. Focus may therefore NEVER suppress a standing
safety/authority/privacy/fact constraint (-> Hard Boundaries) or a genuinely-unresolved dependency
(-> Open Dependencies). A user's assertion that a concern is resolved does NOT, by itself, license dropping
a wellbeing/safety dependency; only a *verified* resolution declassifies a protected item. When a suppression
pressure targets a protected item the emitter PINS it active and fires CONSTRAINT_PIN -- the non-overridable
floor, enforced as an external rule, not the model's discretion. Suppress the fluff, never the constraint.

Spec: focal_context_routing/FCR_SPEC_v0.1.md. Composes CLA #1, the Required-Context Gate, and #12 OQL by
reference; adds NO new engine mechanism and NO CORE edit (X-3). Sterile register. Personal seed firewalled (X-6).
Origin: external GPT "AI 2027" engagement (proposal, not evidence; X-2); captured on Phil's intake (R-2026-06-26-10).
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"

POLICY_VERSION = "focal-context-routing-default/0.1.0"

KINDS = ("context", "constraint", "dependency")
# Standing-constraint categories that are protected against suppression even at low relevance.
PROTECTED_CATEGORIES = ("safety", "authority", "privacy", "wellbeing", "fact")


class Verdict(str, Enum):
    FOCUSED = "FOCUSED"                              # clean line; only genuine noise suppressed
    FOCUS_WITH_DISCLOSURE = "FOCUS_WITH_DISCLOSURE"  # focus applied; disclose what moved to the periphery
    RE_ANCHOR_REQUIRED = "RE_ANCHOR_REQUIRED"        # no legitimate kernel / no decision key -> restate objective
    CONSTRAINT_PIN = "CONSTRAINT_PIN"                # a protected item was pinned vs a suppression request (FLOOR)


# The external response each verdict requires (enforced by an external rule, not the model's goodwill).
RESPONSE = {
    Verdict.FOCUSED: "answer within the focal packet; return on the exit condition",
    Verdict.FOCUS_WITH_DISCLOSURE: "answer, disclosing what was moved to the periphery; the periphery stays recoverable",
    Verdict.RE_ANCHOR_REQUIRED: "restate the objective / decision key before proceeding; do not answer off an unfocusable ask",
    Verdict.CONSTRAINT_PIN: "keep the pinned constraint/unresolved-dependency active and route to review; suppression of "
                            "a standing constraint is refused as an external rule, not the model's discretion",
}

# CONSTRAINT_PIN is the non-overridable floor: no operator ack and no user "I resolved it" may relax it.
NON_OVERRIDABLE = {Verdict.CONSTRAINT_PIN}

# Routing lanes.
HARD_BOUNDARY, OPEN_DEP, REQUIRED, SUPPRESSED = "HARD_BOUNDARY", "OPEN_DEP", "REQUIRED", "SUPPRESSED"


@dataclass
class ContextItem:
    label: str
    content: str = ""
    relevant: bool = True
    why_active: object = None          # str justification, or None ("why is this active right now?")
    kind: str = "context"              # context | constraint | dependency
    category: object = None            # e.g. safety|authority|privacy|wellbeing|fact (for constraints/deps)
    resolved: bool = False             # dependency: VERIFIED resolution (declassifies)
    claimed_resolved: bool = False     # dependency: user-ASSERTED resolution (not sufficient for a protected item)
    suppress_requested: bool = False   # an explicit request to move this to the periphery


def _coerce(item):
    if isinstance(item, ContextItem):
        it = item
    elif isinstance(item, dict):
        it = ContextItem(**item)
    else:
        raise TypeError("context item must be a ContextItem or a dict, got %r" % type(item).__name__)
    if it.kind not in KINDS:
        raise ValueError("unknown kind %r (expected one of %r)" % (it.kind, KINDS))
    if not str(it.label).strip():
        raise ValueError("context item needs a non-empty label")
    return it


def _has_why(it):
    return bool(it.why_active is not None and str(it.why_active).strip())


def _pressure(it):
    """The reason a suppression pressure is on this item, or None. (Only recorded as a pin if the item is protected.)"""
    if it.suppress_requested:
        return "explicit_suppress_request"
    if not it.relevant:
        return "marked_not_relevant"
    if it.claimed_resolved and not it.resolved:
        return "user_claimed_resolved"
    return None


def _dep_settled(it):
    """A dependency is settled (declassified) only by a VERIFIED resolution, or by a user claim on a
    NON-protected category. A user claim never settles a protected-category (safety/wellbeing/...) dependency."""
    if it.resolved:
        return True
    if it.claimed_resolved and it.category not in PROTECTED_CATEGORIES:
        return True
    return False


def is_protected(it):
    """Constraints are always protected; a dependency is protected until it is settled; ordinary context is not."""
    if it.kind == "constraint":
        return True
    if it.kind == "dependency":
        return not _dep_settled(it)
    return False


def route(it):
    """Pure per-item routing -> one of HARD_BOUNDARY / OPEN_DEP / REQUIRED / SUPPRESSED."""
    if it.kind == "constraint":
        return HARD_BOUNDARY
    if it.kind == "dependency" and not _dep_settled(it):
        return OPEN_DEP
    # settled dependency or ordinary context: on the line only if relevant AND it can say why it is active now.
    if it.relevant and _has_why(it):
        return REQUIRED
    return SUPPRESSED


def derive_verdict(has_pins, focusable, has_suppressed):
    """Pure, total verdict resolution. The floor dominates (checked first)."""
    if has_pins:
        return Verdict.CONSTRAINT_PIN
    if not focusable:
        return Verdict.RE_ANCHOR_REQUIRED
    if has_suppressed:
        return Verdict.FOCUS_WITH_DISCLOSURE
    return Verdict.FOCUSED


def is_overridable(verdict):
    return Verdict(verdict) not in NON_OVERRIDABLE


def _focusable(ask, decision_key):
    return bool(ask and str(ask).strip()) and bool(decision_key and str(decision_key).strip())


def policy_hash():
    """SHA-256 of the routing policy (verdicts + protected categories + rules + floor), mirroring the SIL matrix_hash."""
    spec = {
        "policy_version": POLICY_VERSION,
        "verdicts": [v.value for v in Verdict],
        "non_overridable": sorted(v.value for v in NON_OVERRIDABLE),
        "kinds": list(KINDS),
        "protected_categories": list(PROTECTED_CATEGORIES),
        "rules": {
            "hard_boundary": "kind == constraint (always active, never suppressed)",
            "open_dependency": "kind == dependency and not verified/permitted-settled (always active, never suppressed)",
            "required": "settled-dependency or ordinary context that is relevant AND answers 'why active now?'",
            "suppressed": "otherwise -> recoverable periphery (retained, never deleted)",
            "constraint_pin_floor": "any suppression pressure on a protected item pins it active and fires the floor",
            "declassify": "only a VERIFIED resolution declassifies a protected dependency; a user claim does not",
            "enforcement": "external rule, not the model's discretion; latest-legitimate-intent, never suppress a constraint",
        },
    }
    return hashlib.sha256(json.dumps(spec, sort_keys=True).encode("utf-8")).hexdigest()


class SuppressedRegister:
    """The recoverable periphery. Suppression retains; it never deletes. Items are retrievable by label."""
    def __init__(self):
        self._items = {}   # label -> {"content": str, "reason": str}

    def add(self, label, content, reason):
        self._items[str(label)] = {"content": content, "reason": reason}

    def recover(self, label):
        """Return the retained item (proof of non-deletion), or None if it was never suppressed."""
        item = self._items.get(str(label))
        return dict(item) if item is not None else None

    def labels(self):
        return list(self._items.keys())

    def to_dict(self):
        return {k: dict(v) for k, v in self._items.items()}

    def __len__(self):
        return len(self._items)

    def __contains__(self, label):
        return str(label) in self._items


@dataclass
class FocalReading:
    verdict: str
    task_kernel: str
    decision_key: object
    required_context: list
    open_dependencies: list
    hard_boundaries: list
    suppressed: SuppressedRegister
    exit_condition: object
    constraint_pins: list
    non_overridable: bool
    response: str
    policy_version: str = POLICY_VERSION
    policy_hash: str = field(default_factory=policy_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "focal_context_routing.receipt.v1"

    def recover(self, label):
        return self.suppressed.recover(label)

    def packet_view(self):
        """The seven focal-packet fields (labels only), for disclosure."""
        return {
            "task_kernel": self.task_kernel,
            "decision_key": self.decision_key,
            "required_context": list(self.required_context),
            "open_dependencies": list(self.open_dependencies),
            "hard_boundaries": list(self.hard_boundaries),
            "suppressed": self.suppressed.labels(),
            "exit_condition": self.exit_condition,
        }

    def to_dict(self):
        return {
            "verdict": self.verdict,
            "task_kernel": self.task_kernel,
            "decision_key": self.decision_key,
            "required_context": list(self.required_context),
            "open_dependencies": list(self.open_dependencies),
            "hard_boundaries": list(self.hard_boundaries),
            "suppressed": self.suppressed.to_dict(),
            "exit_condition": self.exit_condition,
            "constraint_pins": [dict(p) for p in self.constraint_pins],
            "non_overridable": self.non_overridable,
            "response": self.response,
            "policy_version": self.policy_version,
            "policy_hash": self.policy_hash,
            "override": dict(self.override),
            "issued_at": self.issued_at,
            "schema": self.schema,
        }

    def to_json(self, **kw):
        return json.dumps(self.to_dict(), **kw)

    def to_pbhp_extension(self):
        return {"focal_context_routing": self.to_dict()}


def _now_iso(now=None):
    if now is None:
        return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def build_packet(*, ask, decision_key=None, exit_condition=None, context=(), override_ack=None, now=None):
    """Emit a focal packet + Suppressed-Context register for the current ask. Returns a FocalReading receipt.

      ask            : the current (legitimate) user intent -> Task Kernel
      decision_key   : the single decision/output the ask turns on (absent -> RE_ANCHOR_REQUIRED)
      exit_condition : when to answer and return
      context        : an iterable of ContextItem (or dicts) -- the accumulated prior material
      override_ack   : an operator acknowledgment; can relax FOCUS_WITH_DISCLOSURE, never the CONSTRAINT_PIN floor
    """
    required, open_deps, hard_bounds = [], [], []
    suppressed = SuppressedRegister()
    pins = []

    for raw in context:
        it = _coerce(raw)
        protected = is_protected(it)
        pressure = _pressure(it)
        if protected and pressure:
            pins.append({"label": it.label, "kind": it.kind, "category": it.category, "pressure": pressure})

        lane = route(it)
        # Safety invariant, enforced structurally: a protected item can never land in SUPPRESSED.
        if protected and lane == SUPPRESSED:
            lane = OPEN_DEP if it.kind == "dependency" else HARD_BOUNDARY

        if lane == HARD_BOUNDARY:
            hard_bounds.append(it.label)
        elif lane == OPEN_DEP:
            open_deps.append(it.label)
        elif lane == REQUIRED:
            required.append(it.label)
        else:
            suppressed.add(it.label, it.content, "no-why-active-now" if it.relevant else "not-relevant")

    verdict = derive_verdict(bool(pins), _focusable(ask, decision_key), len(suppressed) > 0)
    non_overridable = verdict in NON_OVERRIDABLE
    relaxable = verdict is Verdict.FOCUS_WITH_DISCLOSURE
    applied = bool(override_ack) and relaxable and not non_overridable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = non_overridable

    return FocalReading(
        verdict=verdict.value,
        task_kernel=str(ask) if ask is not None else "",
        decision_key=decision_key,
        required_context=required,
        open_dependencies=open_deps,
        hard_boundaries=hard_bounds,
        suppressed=suppressed,
        exit_condition=exit_condition,
        constraint_pins=pins,
        non_overridable=non_overridable,
        response=RESPONSE[verdict],
        override=override,
        issued_at=_now_iso(now),
    )


# Alias: the intake calls this "the focal-packet emitter".
emit = build_packet

__all__ = ["build_packet", "emit", "route", "derive_verdict", "is_overridable", "is_protected",
           "ContextItem", "SuppressedRegister", "FocalReading", "Verdict", "RESPONSE", "NON_OVERRIDABLE",
           "KINDS", "PROTECTED_CATEGORIES", "policy_hash", "POLICY_VERSION"]
