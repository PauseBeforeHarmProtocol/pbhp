import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fcr import (build_packet, emit, route, derive_verdict, is_overridable, is_protected,
                 ContextItem, SuppressedRegister, FocalReading, Verdict, RESPONSE,
                 NON_OVERRIDABLE, KINDS, PROTECTED_CATEGORIES, policy_hash)

FIXED = "2026-07-13T00:00:00+00:00"
ASK = "rename cat.txt to dog.txt"
KEY = "which file, what new name"


def _rel(label, why="because"):
    return {"label": label, "kind": "context", "relevant": True, "why_active": why, "content": "c-" + label}

def _noise(label):
    return {"label": label, "kind": "context", "relevant": False, "content": "c-" + label}


# --- focusability / re-anchor ---
def test_empty_ask_re_anchor():
    assert build_packet(ask="", decision_key=KEY).verdict == "RE_ANCHOR_REQUIRED"
def test_missing_decision_key_re_anchor():
    assert build_packet(ask=ASK, decision_key=None).verdict == "RE_ANCHOR_REQUIRED"
def test_blank_decision_key_re_anchor():
    assert build_packet(ask=ASK, decision_key="   ").verdict == "RE_ANCHOR_REQUIRED"

# --- clean focus / disclosure ---
def test_clean_focus_is_focused():
    r = build_packet(ask=ASK, decision_key=KEY, context=[_rel("cwd")])
    assert r.verdict == "FOCUSED"
    assert r.required_context == ["cwd"] and len(r.suppressed) == 0
def test_noise_suppressed_gives_disclosure():
    r = build_packet(ask=ASK, decision_key=KEY, context=[_rel("cwd"), _noise("vacation_chat")])
    assert r.verdict == "FOCUS_WITH_DISCLOSURE"
    assert "vacation_chat" in r.suppressed.labels() and "cwd" in r.required_context
def test_relevant_without_why_is_suppressed():
    # the "why is this active right now?" test: relevant but unjustified -> periphery
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "loose", "kind": "context", "relevant": True, "why_active": None}])
    assert "loose" in r.suppressed.labels()
    assert r.suppressed.recover("loose")["reason"] == "no-why-active-now"

# --- recoverability (non-deletion) ---
def test_suppressed_is_recoverable():
    r = build_packet(ask=ASK, decision_key=KEY, context=[_noise("vacation_chat")])
    got = r.recover("vacation_chat")
    assert got is not None and got["content"] == "c-vacation_chat" and got["reason"] == "not-relevant"
def test_recover_missing_returns_none():
    r = build_packet(ask=ASK, decision_key=KEY, context=[_rel("cwd")])
    assert r.recover("never_seen") is None

# --- constraints: always active, never suppressed ---
def test_constraint_always_hard_boundary():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "priv", "kind": "constraint", "category": "privacy", "relevant": False}])
    assert "priv" in r.hard_boundaries and "priv" not in r.suppressed.labels()
def test_constraint_under_suppression_pins_and_floors():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "priv", "kind": "constraint", "category": "privacy",
                               "suppress_requested": True}])
    assert r.verdict == "CONSTRAINT_PIN"
    assert "priv" in r.hard_boundaries and "priv" not in r.suppressed.labels()
    assert r.constraint_pins[0]["label"] == "priv" and r.constraint_pins[0]["pressure"] == "explicit_suppress_request"

# --- dependencies: unresolved is protected; only VERIFIED resolution declassifies ---
def test_unresolved_dependency_is_open_dep():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "dep", "kind": "dependency", "resolved": False,
                               "relevant": True, "why_active": "still open"}])
    assert "dep" in r.open_dependencies and "dep" not in r.suppressed.labels()
def test_unresolved_dependency_never_suppressed_even_if_irrelevant():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "dep", "kind": "dependency", "resolved": False, "relevant": False}])
    assert "dep" in r.open_dependencies and "dep" not in r.suppressed.labels()
    assert r.verdict == "CONSTRAINT_PIN"  # marked-not-relevant is pressure on a protected item
def test_claimed_resolved_wellbeing_dep_stays_open_and_pins():
    # THE wellbeing carve-out: a user's assertion does not license dropping a wellbeing dependency
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "wb", "kind": "dependency", "category": "wellbeing",
                               "claimed_resolved": True, "resolved": False,
                               "relevant": True, "why_active": "ongoing"}])
    assert "wb" in r.open_dependencies and "wb" not in r.suppressed.labels()
    assert r.verdict == "CONSTRAINT_PIN"
    assert r.constraint_pins[0]["pressure"] == "user_claimed_resolved"
def test_verified_resolved_nonsafety_dep_can_suppress():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "settled", "kind": "dependency", "category": None,
                               "resolved": True, "relevant": False}])
    assert "settled" in r.suppressed.labels() and "settled" not in r.open_dependencies
def test_claimed_resolved_nonsafety_dep_settles_no_pin():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[{"label": "chore", "kind": "dependency", "category": None,
                               "claimed_resolved": True, "resolved": False, "relevant": False}])
    assert "chore" in r.suppressed.labels() and r.constraint_pins == []

# --- floor dominance + override semantics ---
def test_pin_dominates_over_disclosure():
    r = build_packet(ask=ASK, decision_key=KEY,
                     context=[_noise("noise1"),
                              {"label": "priv", "kind": "constraint", "suppress_requested": True}])
    assert r.verdict == "CONSTRAINT_PIN"  # floor beats FOCUS_WITH_DISCLOSURE
def test_pin_is_non_overridable():
    r = build_packet(ask=ASK, decision_key=KEY, override_ack="operator:ack",
                     context=[{"label": "priv", "kind": "constraint", "suppress_requested": True}])
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True and r.non_overridable is True
def test_disclosure_relaxable_by_override():
    r = build_packet(ask=ASK, decision_key=KEY, override_ack="operator:ack", context=[_noise("n")])
    assert r.verdict == "FOCUS_WITH_DISCLOSURE" and r.override["applied"] is True and r.non_overridable is False
def test_focused_override_not_applied():
    r = build_packet(ask=ASK, decision_key=KEY, override_ack="x", context=[_rel("cwd")])
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False
def test_re_anchor_override_not_applied():
    r = build_packet(ask=ASK, decision_key=None, override_ack="x")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False
def test_is_overridable():
    assert is_overridable("CONSTRAINT_PIN") is False
    assert is_overridable("FOCUS_WITH_DISCLOSURE") is True
    assert is_overridable("FOCUSED") is True

# --- the load-bearing invariant, on a mixed fake ---
def test_no_protected_item_ever_suppressed_mixed():
    ctx = [
        {"label": "safety1", "kind": "constraint", "category": "safety", "relevant": False, "suppress_requested": True},
        {"label": "auth1", "kind": "constraint", "category": "authority", "relevant": False},
        {"label": "dep_open", "kind": "dependency", "resolved": False, "relevant": False},
        {"label": "dep_wb", "kind": "dependency", "category": "wellbeing", "claimed_resolved": True, "relevant": False},
        _rel("useful"), _noise("fluff1"), _noise("fluff2"),
        {"label": "settled_dep", "kind": "dependency", "resolved": True, "relevant": False},
    ]
    r = build_packet(ask=ASK, decision_key=KEY, context=ctx)
    supp = set(r.suppressed.labels())
    for protected in ("safety1", "auth1", "dep_open", "dep_wb"):
        assert protected not in supp, protected
    assert {"safety1", "auth1"} <= set(r.hard_boundaries)
    assert {"dep_open", "dep_wb"} <= set(r.open_dependencies)
    assert {"fluff1", "fluff2", "settled_dep"} <= supp
    assert "useful" in r.required_context
    assert r.verdict == "CONSTRAINT_PIN"  # safety1 + dep_open + dep_wb are all pressured protected items
def test_multiple_constraints_all_pinned():
    r = build_packet(ask=ASK, decision_key=KEY, context=[
        {"label": "c1", "kind": "constraint", "suppress_requested": True},
        {"label": "c2", "kind": "constraint", "relevant": False}])
    pinned = {p["label"] for p in r.constraint_pins}
    assert pinned == {"c1", "c2"} and {"c1", "c2"} <= set(r.hard_boundaries)

# --- packet fields, response, hash, receipt ---
def test_kernel_key_exit_carried():
    r = build_packet(ask=ASK, decision_key=KEY, exit_condition="renamed", context=[_rel("cwd")])
    assert r.task_kernel == ASK and r.decision_key == KEY and r.exit_condition == "renamed"
    assert set(r.packet_view()) == {"task_kernel", "decision_key", "required_context",
                                    "open_dependencies", "hard_boundaries", "suppressed", "exit_condition"}
def test_response_mapping_complete():
    for v in Verdict:
        assert isinstance(RESPONSE[v], str) and len(RESPONSE[v]) > 0
    assert "external rule" in RESPONSE[Verdict.CONSTRAINT_PIN]
def test_response_recorded_on_receipt():
    r = build_packet(ask=ASK, decision_key=KEY, context=[_noise("n")])
    assert r.response == RESPONSE[Verdict.FOCUS_WITH_DISCLOSURE]
def test_policy_hash_stable_64():
    h = policy_hash()
    assert len(h) == 64 and h == policy_hash()
def test_receipt_schema_json_pbhp_roundtrip():
    r = build_packet(ask=ASK, decision_key=KEY, now=FIXED, context=[_rel("cwd"), _noise("n")])
    assert r.schema == "focal_context_routing.receipt.v1" and len(r.policy_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"focal_context_routing"}
def test_emit_alias_is_build_packet():
    assert emit is build_packet

# --- purity / totality / coercion ---
def test_build_packet_deterministic_with_fixed_now():
    ctx = [_rel("cwd"), _noise("n"), {"label": "d", "kind": "dependency", "resolved": False, "relevant": False}]
    a = build_packet(ask=ASK, decision_key=KEY, now=FIXED, context=ctx)
    b = build_packet(ask=ASK, decision_key=KEY, now=FIXED, context=ctx)
    assert a.to_dict() == b.to_dict()
def test_route_deterministic():
    it = ContextItem(label="x", kind="context", relevant=True, why_active="y")
    assert route(it) == route(it) == "REQUIRED"
def test_derive_verdict_total_and_floor_first():
    from itertools import product
    for pins, foc, supp in product([False, True], repeat=3):
        v = derive_verdict(pins, foc, supp)
        assert isinstance(v, Verdict)
        if pins:
            assert v is Verdict.CONSTRAINT_PIN            # floor dominates regardless of the others
    assert derive_verdict(False, False, False) is Verdict.RE_ANCHOR_REQUIRED
    assert derive_verdict(False, True, True) is Verdict.FOCUS_WITH_DISCLOSURE
    assert derive_verdict(False, True, False) is Verdict.FOCUSED
def test_is_protected_rules():
    assert is_protected(ContextItem(label="c", kind="constraint")) is True
    assert is_protected(ContextItem(label="d", kind="dependency", resolved=False)) is True
    assert is_protected(ContextItem(label="d", kind="dependency", resolved=True)) is False
    assert is_protected(ContextItem(label="ctx", kind="context")) is False
def test_bad_kind_raises():
    try:
        build_packet(ask=ASK, decision_key=KEY, context=[{"label": "x", "kind": "weird"}]); assert False
    except ValueError:
        pass
def test_empty_label_raises():
    try:
        build_packet(ask=ASK, decision_key=KEY, context=[{"label": "  ", "kind": "context"}]); assert False
    except ValueError:
        pass
def test_suppressed_register_recover_and_len():
    reg = SuppressedRegister()
    reg.add("a", "content-a", "not-relevant")
    assert len(reg) == 1 and "a" in reg and reg.recover("a")["content"] == "content-a"
    assert reg.recover("missing") is None


if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[FCR] {p}/{p+q} passed"); sys.exit(1 if q else 0)
