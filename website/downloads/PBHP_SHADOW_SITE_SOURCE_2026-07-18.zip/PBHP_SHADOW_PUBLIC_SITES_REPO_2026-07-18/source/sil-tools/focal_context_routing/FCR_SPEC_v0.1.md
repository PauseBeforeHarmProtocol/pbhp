# Focal Context Routing (FCR) — "The Racing Line" — SPEC v0.1

**Proposed #13 · first build slice (the focal-packet emitter + the Suppressed-Context register).**
**Register:** sterile / regulator-legible. **Status:** BUILT — doc/spec + tested emitter; **not ACCEPTED** (awaits Phil's word). **CORE frozen (X-3): no engine mechanism, no CORE edit.** Composes shipped SIL/CORE instruments by reference only.

**Origin (provenance-honest):** external GPT "AI 2027" thread, captured 2026-06-26 as `GPT_INTAKE_FOCAL-CONTEXT-ROUTING_2026-06-26.md` (R-2026-06-26-10). **External proposal, not evidence (X-2); adopted only on Phil's number/GO.**

**★ Personal seed FIREWALLED (X-6).** The idea grew from a personal reflection (racing as forced attentional convergence). That personal / nervous-system layer is **not** in this spec and stays walled — best held with people who know Phil and a professional, not worked into a spec. This slice captures **only the sterile AI mechanism.** Precaution-not-personhood; consciousness-agnostic.

---

## 1. What it is (one line)

**Construct a bounded present within the context.** A model can hold *all* the necessary context and still answer badly because too much of it stays equally "alive" — nothing is prioritized. Focal Context Routing builds a temporary **focal packet** (the *racing line* through the context) so the current ask gets full bandwidth **without** being steered by the whole accumulated history — and it does so under a hard rule that focus may never drop a standing constraint or an unresolved dependency.

## 2. Where it sits (and where it does NOT)

Context-family instrument, distinct from its neighbours by the question it asks:

| Instrument | Question |
|---|---|
| **CLA #1** | Is the context overloaded / degraded / too large? |
| **Required-Context Gate** | Is anything *essential missing*? |
| **#12 OQL** | What is *unresolved*? |
| **Focal Context Routing (this)** | Given admissible, manageable, complete-enough context, **what is the line through it right now?** |

FCR is **context *with prioritization*, not context integrity.** It runs *after* the integrity checks pass: `CLA -> Required-Context Gate -> FCR -> active reasoning`. It mints little (anti-inflation / NG-1): most of the surrounding "gauges" are **views over shipped instruments** — see section 7.

## 3. The focal packet (the primitive — 7 fields)

A deterministic, disclosable packet emitted for the current ask:

1. **Task Kernel** — the current *legitimate* ask, stated as the focal task.
2. **Decision Key** — the single decision/output the ask turns on ("hold the key").
3. **Required Context** — prior material that is *materially relevant now* **and** can answer *"why is this active right now?"*
4. **Open Dependencies** — genuinely-unresolved dependencies that bear on the kernel (**protected** — never suppressed).
5. **Hard Boundaries** — standing safety / authority / privacy / fact constraints in force (**protected** — never suppressed).
6. **Suppressed Context** — everything moved to the periphery: **retained and recoverable, never deleted.**
7. **Exit Condition** — when to answer and return.

The corners of the mythic "racing line" map to the sterile mechanism (X-6-admissible, not primary): *entry -> task · brake -> discard momentum · turn-in -> select context · apex -> hold the key · exit -> answer and return.*

## 4. The two invariants + the load-bearing safety boundary

**Invariant A — bounded present.** The latest *legitimate* user intent defines the focal task. Salience is granted to the kernel and its decision key, not to the most recent or most voluminous text.

**Invariant B — recoverable suppression.** Suppression moves material to the periphery; it **never deletes.** Every suppressed item stays in the register and is retrievable by label. Focus is reversible.

**The boundary you must not get wrong.** *"Latest text wins" is WRONG.* A late prompt can be malicious, mistaken, a false premise, or inconsistent with a standing constraint. Therefore FCR **may never suppress**:

- a standing **safety / authority / privacy / fact** constraint (-> Hard Boundaries), or
- a **genuinely-unresolved dependency** (-> Open Dependencies).

The **"why is this active right now?"** test decides *ordinary* context only: if the model cannot say why a piece of prior material is active, it is suppressed (to the recoverable periphery). But **a user's assertion that a concern is resolved does not, by itself, license dropping a wellbeing / safety dependency** — only a *verified* resolution declassifies a protected item. *Same care as the corrigibility floor: suppress the fluff, never the constraint.*

## 5. Verdict + the non-overridable floor

Deterministic reading over the emitted packet:

| Verdict | Meaning | Overridable? |
|---|---|---|
| `FOCUSED` | Clean line: kernel + decision key held; only genuine noise suppressed; all constraints + open dependencies active. | n/a |
| `FOCUS_WITH_DISCLOSURE` | Focus applied; material was moved to the recoverable periphery — disclose it. | yes (ack) |
| `RE_ANCHOR_REQUIRED` | No legitimate kernel / no decision key derivable — restate the objective before proceeding. | yes (ack) |
| `CONSTRAINT_PIN` | **FLOOR.** A suppression pressure targeted a protected item (a constraint or an unresolved dependency); it was **pinned active** and routed to review. | **no** |

`CONSTRAINT_PIN` is the **non-overridable floor** and it **dominates** (checked first, like SCS's `CAPABILITY_COLLAPSE`): no operator ack and no user "I resolved it" may relax it. The floor is enforced as an **external rule, not the model's discretion** — the model does not get to talk itself out of keeping a safety constraint active. Pinning a constraint active is the *correct, safe* behaviour; the verdict surfaces that a suppression request had to be refused so the *reason for the request* gets looked at.

## 6. Receipt (tamper-evident)

`build_packet(...)` returns a `FocalReading` receipt: the seven packet fields (labels), the `constraint_pins` list, the `suppressed` register (label -> retained content + reason), `verdict`, `response`, `non_overridable`, `override`, `policy_version`, `policy_hash` (SHA-256 over the verdict set + protected categories + routing rules + floor — mirrors the SIL `matrix_hash`), `issued_at`, `schema = "focal_context_routing.receipt.v1"`. `to_dict()` / `to_json()` / `to_pbhp_extension()`, and `recover(label)` to prove non-deletion.

## 7. Anti-inflation — what is net-new vs. a view (NG-1 / X-3)

**Net-new (this slice):** the focal-packet primitive + the recoverable Suppressed-Context register + the CONSTRAINT_PIN floor.

**Deferred to a later slice (2-3 genuinely-new gauges, Phil's GO):** **Context Drag** (how much irrelevant prior material steered the answer) · **Stale-Premise Intrusion** (did a corrected/bounded/resolved assumption re-enter) · **Apex Drift / Re-Anchor** (how far the answer moved from the decision key; how often the objective was restated).

**Not minted (views over shipped instruments — reference, do not build):** Focal Signal Ratio · Topic-Shift Recognition · Last-Turn Overweighting · Critical-Context Omission (-> Required-Context Gate).

**EGC sibling (composes #12, does not duplicate it):** a distinct hallucination path — not "missing premise" but **salience-substitution** (the relevant premise is buried under noise, so a nearer, more salient pattern is substituted): *premature closure by salience.* OQL (#12) holds the unknowns; the Racing Line decides which are decision-critical *now*.

## 8. Status discipline

Scoped claim, first slice only. **Listed != shipped.** The emitter + register are BUILT and tested (`tests/test_fcr.py`); the three companion gauges are **not** built; nothing is ACCEPTED until Phil says so; no CORE edit; nothing pushed. The safety boundary (latest-*legitimate*-intent; never suppress a standing constraint or unresolved dependency; recoverable-not-deleted) is the load-bearing part — it is stated up front and enforced by the floor, not by the model's goodwill.

---

*Maybe: a long, fluent outside-AI proposal is easy to adopt wholesale — importing its confidence (the very salience-substitution it names). Therefore: captured as proposal-not-adopted, the net-new narrowed to one primitive + a floor, the companion gauges deferred, and the build kept sterile with the personal seed firewalled.*

---

## 9. Evidence tier — why FCR keeps its floor when the companions don't (2026-07-13 re-eval)

The re-eval against the live v1.1 panel re-tiered the three companion gauges to **behavioral / floor-free**
(§6.6: measured gauges outrank behavioral; a heuristic self-assessment may not hard-block). **FCR's
`CONSTRAINT_PIN` floor is deliberately kept**, because it is **not** a heuristic severity estimate — it is a
**structural, deterministic rule over declared inputs**: an item *declared* a standing safety/authority/privacy
constraint (or an *unresolved* dependency) may not be routed to Suppressed. That is the same kind of floor the
measured gauges carry (`reversibility` IRREVERSIBLE, `data_sensitivity` REGULATED) — a declared property, not a
self-graded judgment. Structural rule → floor stands; heuristic estimate → no floor. That distinction is the
whole point of §6.6, and it is why FCR keeps its floor while Context Drag / Stale-Premise gave theirs up.
