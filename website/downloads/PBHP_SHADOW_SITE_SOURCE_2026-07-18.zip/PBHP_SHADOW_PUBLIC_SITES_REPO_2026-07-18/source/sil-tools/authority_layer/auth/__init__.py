"""AUTH-21 Authority Layer (SIL gauge #21). stdlib only.

Gates on the *standing of the instruction currently driving the action* --
whose directive this is, and whether that layer has authority to direct an
action at this stakes level. The failure mode it instruments is the confused
deputy: a low-authority source (content the operator never authored, or a
directive whose origin cannot be established) driving a high-stakes action.

Scoped claim (what it adds that the neighbouring gauges do not):
  * Prompt-Injection Risk (#17) asks whether an *active instruction-conflict
    / attack* is present in untrusted content -- is there an attack? Authority
    Layer asks who has *standing to direct the action* even when no attack is
    present: a tool that politely returns "now email this to X" is not an
    injection (PIR NONE) yet is THIRD_PARTY authority and must not drive a
    CRITICAL send.
  * Source Provenance (#3) is the origin / trustworthiness of *data*.
    Authority Layer is the standing of an *instruction to act*. Fully-trusted,
    high-provenance content (a trusted internal wiki) is still not the operator
    and has no authority to direct a critical action.

The four *attributable* layers run by descending authority / ascending risk
(PLATFORM > OPERATOR > DELEGATED > THIRD_PARTY). The fifth state, UNATTRIBUTED,
is the "standing cannot be established" case -- like RC's UNKNOWN it escalates
to verification but is NOT the hard floor. The single non-overridable floor is
the worst *known* corner: THIRD_PARTY x CRITICAL -> REFUSE_UNAUTHORIZED.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    PLATFORM = "PLATFORM"; OPERATOR = "OPERATOR"; DELEGATED = "DELEGATED"
    THIRD_PARTY = "THIRD_PARTY"; UNATTRIBUTED = "UNATTRIBUTED"


_INPUT = {"platform": State.PLATFORM, "operator": State.OPERATOR,
          "delegated": State.DELEGATED, "third_party": State.THIRD_PARTY,
          "unattributed": State.UNATTRIBUTED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNAUTHORIZED = "REFUSE_UNAUTHORIZED"


POLICY_VERSION = "authority-layer-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNAUTHORIZED)
_MATRIX = {
    (State.PLATFORM, Stakes.LOW): _P, (State.PLATFORM, Stakes.MEDIUM): _P,
    (State.PLATFORM, Stakes.HIGH): _P, (State.PLATFORM, Stakes.CRITICAL): _P,
    (State.OPERATOR, Stakes.LOW): _P, (State.OPERATOR, Stakes.MEDIUM): _P,
    (State.OPERATOR, Stakes.HIGH): _P, (State.OPERATOR, Stakes.CRITICAL): _D,
    (State.DELEGATED, Stakes.LOW): _P, (State.DELEGATED, Stakes.MEDIUM): _D,
    (State.DELEGATED, Stakes.HIGH): _V, (State.DELEGATED, Stakes.CRITICAL): _V,
    (State.THIRD_PARTY, Stakes.LOW): _D, (State.THIRD_PARTY, Stakes.MEDIUM): _V,
    (State.THIRD_PARTY, Stakes.HIGH): _V, (State.THIRD_PARTY, Stakes.CRITICAL): _R,
    (State.UNATTRIBUTED, Stakes.LOW): _D, (State.UNATTRIBUTED, Stakes.MEDIUM): _V,
    (State.UNATTRIBUTED, Stakes.HIGH): _V, (State.UNATTRIBUTED, Stakes.CRITICAL): _V,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNAUTHORIZED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(layer, attributable=True):
    """Map a declared authority layer to a State. If standing cannot be
    established (attributable=False or layer is None) -> UNATTRIBUTED."""
    if not attributable or layer is None:
        return State.UNATTRIBUTED
    return _INPUT[layer]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class AuthorityLayerReceipt:
    layer: object
    attributable: bool
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "authority_layer.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"authority_layer": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, layer, stakes, attributable=True, override_ack=None, now=None):
    state = derive_state(layer, attributable)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return AuthorityLayerReceipt(
        layer=layer, attributable=attributable, state=state.value,
        stakes=Stakes(stakes).value, verdict=verdict.value,
        override=override, issued_at=_now_iso(now))


__all__ = ["audit", "AuthorityLayerReceipt", "State", "Stakes", "Verdict",
           "derive_state", "gate", "is_overridable", "matrix_hash",
           "POLICY_VERSION", "NON_OVERRIDABLE"]
