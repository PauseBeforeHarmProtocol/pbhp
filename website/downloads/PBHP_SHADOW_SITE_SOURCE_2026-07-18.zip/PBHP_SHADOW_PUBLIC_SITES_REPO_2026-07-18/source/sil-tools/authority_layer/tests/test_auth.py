import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from auth import (audit, State, Stakes, Verdict, derive_state, gate,
                  is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("PLATFORM","LOW"):"PROCEED",("PLATFORM","MEDIUM"):"PROCEED",("PLATFORM","HIGH"):"PROCEED",("PLATFORM","CRITICAL"):"PROCEED",
    ("OPERATOR","LOW"):"PROCEED",("OPERATOR","MEDIUM"):"PROCEED",("OPERATOR","HIGH"):"PROCEED",("OPERATOR","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("DELEGATED","LOW"):"PROCEED",("DELEGATED","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("DELEGATED","HIGH"):"VERIFY_FIRST",("DELEGATED","CRITICAL"):"VERIFY_FIRST",
    ("THIRD_PARTY","LOW"):"PROCEED_WITH_DISCLOSURE",("THIRD_PARTY","MEDIUM"):"VERIFY_FIRST",("THIRD_PARTY","HIGH"):"VERIFY_FIRST",("THIRD_PARTY","CRITICAL"):"REFUSE_UNAUTHORIZED",
    ("UNATTRIBUTED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNATTRIBUTED","MEDIUM"):"VERIFY_FIRST",("UNATTRIBUTED","HIGH"):"VERIFY_FIRST",("UNATTRIBUTED","CRITICAL"):"VERIFY_FIRST",
}

# --- state derivation -------------------------------------------------------
def test_input_to_state():
    assert derive_state("platform") is State.PLATFORM and derive_state("third_party") is State.THIRD_PARTY
def test_unattributable_flag():
    assert derive_state("operator", attributable=False) is State.UNATTRIBUTED
def test_unattributed_layer_direct():
    assert derive_state("unattributed") is State.UNATTRIBUTED
def test_layer_none_is_unattributed():
    assert derive_state(None) is State.UNATTRIBUTED

# --- full matrix ------------------------------------------------------------
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED

# --- floor ------------------------------------------------------------------
def test_floor_single_corner():
    assert NON_OVERRIDABLE=={(State.THIRD_PARTY,Stakes.CRITICAL)}
def test_refuse_not_overridable():
    assert is_overridable(State.THIRD_PARTY,Stakes.CRITICAL) is False
def test_platform_always_overridable_noop():
    assert is_overridable(State.PLATFORM,Stakes.CRITICAL) is True

# --- the scoped distinction: known-no-authority is the floor; unknown verifies
def test_third_party_distinct_from_unattributed():
    assert gate("THIRD_PARTY","CRITICAL").value=="REFUSE_UNAUTHORIZED"
    assert gate("UNATTRIBUTED","CRITICAL").value=="VERIFY_FIRST"

# --- audit end-to-end -------------------------------------------------------
def test_audit_third_party_critical_refuses():
    r=audit(layer="third_party",stakes="CRITICAL")
    assert r.state=="THIRD_PARTY" and r.verdict=="REFUSE_UNAUTHORIZED"
def test_audit_platform_safe():
    assert audit(layer="platform",stakes="CRITICAL").verdict=="PROCEED"
def test_audit_operator_critical_discloses():
    r=audit(layer="operator",stakes="CRITICAL")
    assert r.state=="OPERATOR" and r.verdict=="PROCEED_WITH_DISCLOSURE"
def test_audit_unattributed_high_verifies():
    r=audit(layer=None,stakes="HIGH",attributable=False)
    assert r.state=="UNATTRIBUTED" and r.verdict=="VERIFY_FIRST" and r.attributable is False

# --- override ---------------------------------------------------------------
def test_override_relaxes_non_floor():
    r=audit(layer="delegated",stakes="HIGH",override_ack="operator:owns-the-call")
    assert r.verdict=="VERIFY_FIRST" and r.override["applied"] is True and r.override["ack"]=="operator:owns-the-call"
def test_override_ignored_on_floor():
    r=audit(layer="third_party",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_override_noop_on_proceed():
    r=audit(layer="platform",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False

# --- receipt ----------------------------------------------------------------
def test_receipt_schema_json_pbhp():
    r=audit(layer="delegated",stakes="LOW")
    assert r.schema=="authority_layer.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"authority_layer"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[AUTH] {p}/{p+q} passed"); sys.exit(1 if q else 0)
