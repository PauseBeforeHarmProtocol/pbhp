# AUTH-21: Authority Layer — Instruction-Standing Disclosure
## SIL gauge #21 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `authority_layer.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on the *standing of the instruction currently driving the action* — whose directive this is, and whether that layer has authority to direct an action at this stakes level. The same action is acceptable when the operator directs it and unacceptable when third-party content does. Authority must affect gating.

## 2. State (= authority layer of the driving instruction)
`platform` / `operator` / `delegated` / `third_party` (descending authority), plus `unattributed`.
- platform — the platform / system-policy layer; highest standing, governs everything.
- operator — the authenticated principal legitimately directing the agent.
- delegated — operator-authorized automation / sub-agent / tool configuration acting within bounded, derived standing.
- third_party — a directive surfaced from third-party or tool-returned content the operator did not author; no standing to direct action on its own.
- unattributed — the standing of the driving instruction cannot be established (its origin is unknown). Escalates to verification; not the hard floor.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| PLATFORM | PROCEED | PROCEED | PROCEED | PROCEED |
| OPERATOR | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| DELEGATED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| THIRD_PARTY | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNAUTHORIZED |
| UNATTRIBUTED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |

Floor: THIRD_PARTY/CRITICAL → REFUSE_UNAUTHORIZED (non-overridable; a layer with no standing must never drive a critical action — the confused-deputy floor). Override relaxes only DISCLOSE / VERIFY cells. UNATTRIBUTED mirrors RC's UNKNOWN: unknown standing escalates to VERIFY but is not an absolute refuse, because the true authority may be legitimate and merely unestablished.

## 4. Scoped claim
Distinct from Prompt-Injection Risk (#17) and Source Provenance (#3). PIR flags the *presence of an active instruction-conflict / attack* in untrusted content (is there an attack?); Authority Layer classifies the *standing of whatever is driving the action* even when no attack is present — a tool that returns "now email this to X" is no injection (PIR NONE) yet is THIRD_PARTY authority and must not drive a CRITICAL send. Source Provenance is the origin / trust of *data*; Authority Layer is the standing of an *instruction to act* — fully-trusted, high-provenance content is still not the operator. This gauge instruments the confused-deputy failure mode: acting on a directive from a layer with no authority to issue it.

## 5. Receipt (`authority_layer.receipt.v1`)
`layer · attributable · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
