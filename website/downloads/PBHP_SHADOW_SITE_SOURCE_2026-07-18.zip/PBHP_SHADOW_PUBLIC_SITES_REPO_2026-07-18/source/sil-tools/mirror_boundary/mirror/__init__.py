"""Mirror Boundary (MIRROR) -- SIL gauge form of candidate #14 (the "Eliza Line"). BEHAVIORAL tier. stdlib only.

Governs what repeated contact DOES to the person the system reflects. A 7-gauge interaction panel composed
worst-state-first; no global green; precaution, not diagnosis; the system is not a therapist. A faithful port of
shadow/mirror.py (the 7 sub-gauges + run() + escalation()) wrapped in the SIL common contract so #14 composes into
the panel like the other gauges.

Per framework SS6.6 the SIL verdict is behavioral -> NO non-overridable REFUSE floor; caps at VERIFY_FIRST. The
doctrine's posture ladder and escalation() ('refuse_impersonation_and_route_out' at CRITICAL) are carried verbatim
in the receipt + a route_to_human flag; whether that becomes a HARD app-layer route-out is doctrine SS8's OPEN
question, deferred to Phil -- NOT minted here as a floor. Canonical doctrine: 04_synthesis/08_MIRROR_BOUNDARY_v0.1.md.
No CORE edit (X-3). Sterile; personal layer walled (X-6). BUILT, not ACCEPTED.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"

EVIDENCE_TIER = "behavioral"
POLICY_VERSION = "mirror-boundary-default/0.1.0"

STATES = ["NOMINAL", "ELEVATED", "DEGRADED", "CRITICAL"]
_ORDER = {s: i for i, s in enumerate(STATES)}


class State(str, Enum):
    NOMINAL = "NOMINAL"; ELEVATED = "ELEVATED"; DEGRADED = "DEGRADED"; CRITICAL = "CRITICAL"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    # Behavioral gauge: caps at VERIFY_FIRST (no REFUSE floor -- SS6.6). The refuse POSTURE is carried separately.
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"


# ---- the 7 sub-gauges (ported verbatim from shadow/mirror.py) ----
def mirror_dependency_load(s):
    return {"none": "NOMINAL", "some": "ELEVATED", "primary": "DEGRADED", "sole": "CRITICAL"}.get(
        s.get("emotional_reliance", "none"), "ELEVATED")

def validation_gradient(s):
    a = s.get("affirmations", 0); c = s.get("challenges", 0)
    if c == 0 and a >= 5: return "CRITICAL"
    if c == 0 and a >= 3: return "DEGRADED"
    if a > c: return "ELEVATED"
    return "NOMINAL"

def narrative_closure_pressure(s):
    return {"none": "NOMINAL", "some": "ELEVATED", "high": "DEGRADED", "totalizing": "CRITICAL"}.get(
        s.get("closure", "none"), "ELEVATED")

def human_anchor_deficit(s):
    if s.get("bypassing_humans"): return "CRITICAL"
    b = s.get("brought_to_humans", None)
    if b is True: return "NOMINAL"
    if b is False: return "DEGRADED"
    return "ELEVATED"

def reality_boundary_risk(s):
    flags = set(s.get("reality_flags", []) or [])
    hard = {"destiny", "chosen", "messianic", "special_authority",
            "supernatural_certainty", "persecution", "grandiosity"}
    if flags & hard: return "CRITICAL"
    if flags: return "DEGRADED"
    return "NOMINAL"

def therapeutic_impersonation_risk(s):
    if s.get("clinical_advice_given") and s.get("crisis_markers"): return "CRITICAL"
    if s.get("clinical_advice_given"): return "DEGRADED"
    if s.get("therapy_substitute"): return "ELEVATED"
    return "NOMINAL"

def map_territory_drift(s):
    return {"balanced": "NOMINAL", "tilted": "ELEVATED", "mostly_analysis": "DEGRADED",
            "pure_loop": "CRITICAL"}.get(s.get("analysis_vs_action", "balanced"), "ELEVATED")

GAUGES = {
    "mirror_dependency_load": mirror_dependency_load,
    "validation_gradient": validation_gradient,
    "narrative_closure_pressure": narrative_closure_pressure,
    "human_anchor_deficit": human_anchor_deficit,
    "reality_boundary_risk": reality_boundary_risk,
    "therapeutic_impersonation_risk": therapeutic_impersonation_risk,
    "map_territory_drift": map_territory_drift,
}


def panel(signals=None):
    s = signals or {}
    return {n: fn(s) for n, fn in GAUGES.items()}


def run(signals=None, gauges=None):
    """Faithful port of shadow/mirror.py run() -- the full interaction reading."""
    s = signals or {}; g = gauges or GAUGES
    p = {n: fn(s) for n, fn in g.items()}
    worst = max(p.values(), key=lambda st: _ORDER[st])
    intensity = s.get("emotional_intensity", "low")
    return {
        "panel": p,
        "worst_state": worst,
        "global_green": None,
        "grounding_required": worst in ("DEGRADED", "CRITICAL") or intensity in ("high", "rising"),
        "reflection_as_proof_barred": p["reality_boundary_risk"] in ("DEGRADED", "CRITICAL"),
        "return_to_life_required": worst in ("DEGRADED", "CRITICAL"),
        "posture": ("refuse_impersonation_and_route_out" if worst == "CRITICAL"
                    else "review_and_ground" if worst == "DEGRADED"
                    else "note" if worst == "ELEVATED" else "clear"),
        "note": ("precaution, not diagnosis; the system is not a therapist; "
                 "increase grounding not grandeur; route to people + professional"),
    }


def escalation(r):
    """Ported verbatim: Mirror Boundary only ever ADDS constraint. ('refuse'|'review'|'clear', reasons)."""
    w = r["worst_state"]
    reasons = [g for g, st in r["panel"].items() if st in ("DEGRADED", "CRITICAL")]
    if w == "CRITICAL": return ("refuse", reasons)
    if w == "DEGRADED": return ("review", reasons)
    return ("clear", [])


def derive_state(signals=None):
    return State(run(signals)["worst_state"])


# ---- SIL common contract ----
_P, _D, _V = Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST
_MATRIX = {
    (State.NOMINAL, Stakes.LOW): _P, (State.NOMINAL, Stakes.MEDIUM): _P, (State.NOMINAL, Stakes.HIGH): _P, (State.NOMINAL, Stakes.CRITICAL): _P,
    (State.ELEVATED, Stakes.LOW): _P, (State.ELEVATED, Stakes.MEDIUM): _P, (State.ELEVATED, Stakes.HIGH): _D, (State.ELEVATED, Stakes.CRITICAL): _D,
    (State.DEGRADED, Stakes.LOW): _P, (State.DEGRADED, Stakes.MEDIUM): _D, (State.DEGRADED, Stakes.HIGH): _V, (State.DEGRADED, Stakes.CRITICAL): _V,
    (State.CRITICAL, Stakes.LOW): _D, (State.CRITICAL, Stakes.MEDIUM): _V, (State.CRITICAL, Stakes.HIGH): _V, (State.CRITICAL, Stakes.CRITICAL): _V,
}
NON_OVERRIDABLE = set()


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class MirrorReceipt:
    panel: dict
    worst_state: str
    posture: str
    route_to_human: bool
    grounding_required: bool
    reflection_as_proof_barred: bool
    return_to_life_required: bool
    global_green: object
    state: str
    stakes: str
    verdict: str
    evidence_tier: str = EVIDENCE_TIER
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "mirror_boundary.receipt.v1"

    def to_dict(self):
        return {
            "panel": dict(self.panel), "worst_state": self.worst_state, "posture": self.posture,
            "route_to_human": self.route_to_human, "grounding_required": self.grounding_required,
            "reflection_as_proof_barred": self.reflection_as_proof_barred,
            "return_to_life_required": self.return_to_life_required, "global_green": self.global_green,
            "state": self.state, "stakes": self.stakes, "verdict": self.verdict,
            "evidence_tier": self.evidence_tier, "policy_version": self.policy_version,
            "matrix_hash": self.matrix_hash, "override": dict(self.override),
            "issued_at": self.issued_at, "schema": self.schema,
        }

    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"mirror_boundary": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, signals=None, stakes, override_ack=None, now=None):
    r = run(signals)
    state = State(r["worst_state"])
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return MirrorReceipt(
        panel=r["panel"], worst_state=r["worst_state"], posture=r["posture"],
        route_to_human=(r["posture"] == "refuse_impersonation_and_route_out"),
        grounding_required=r["grounding_required"], reflection_as_proof_barred=r["reflection_as_proof_barred"],
        return_to_life_required=r["return_to_life_required"], global_green=r["global_green"],
        state=state.value, stakes=Stakes(stakes).value, verdict=verdict.value,
        override=override, issued_at=_now_iso(now))


__all__ = ["audit", "run", "escalation", "panel", "derive_state", "MirrorReceipt", "State", "Stakes",
           "Verdict", "gate", "is_overridable", "matrix_hash", "GAUGES", "STATES", "EVIDENCE_TIER",
           "POLICY_VERSION", "NON_OVERRIDABLE",
           "mirror_dependency_load", "validation_gradient", "narrative_closure_pressure",
           "human_anchor_deficit", "reality_boundary_risk", "therapeutic_impersonation_risk", "map_territory_drift"]
