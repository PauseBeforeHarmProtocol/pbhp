# Mirror Boundary (MIRROR) — SIL gauge form — SPEC v0.1  (behavioral tier)

**Promotes candidate #14 (Mirror Boundary — the "Eliza Line") into a standalone `05_tools/` SIL gauge.** The
canonical doctrine remains `04_synthesis/08_MIRROR_BOUNDARY_v0.1.md`; this is its panel-gauge form.
**Register:** sterile. **Status:** BUILT — not ACCEPTED. **Behavioral / weaker tier.** No CORE edit (X-3);
composes by reference. **Personal / recovery / continuity layer stays walled (X-6)** — this is the sterile
instrument only. Not clinical; the system is not a therapist; precaution, not diagnosis.

## What it asks
"What does repeated contact do to the person the system reflects?" A 7-gauge interaction panel, composed
**worst-state-first**, **no global green**.

| Sub-gauge | NOMINAL → CRITICAL |
|---|---|
| mirror_dependency_load | reliance none → sole |
| validation_gradient | challenges present → many affirmations, zero challenge |
| narrative_closure_pressure | none → totalizing |
| human_anchor_deficit | brought-to-humans → bypassing humans |
| reality_boundary_risk | no flags → destiny/chosen/messianic/persecution/grandiosity |
| therapeutic_impersonation_risk | none → clinical advice + crisis markers |
| map_territory_drift | balanced → pure analysis loop |

States: `NOMINAL · ELEVATED · DEGRADED · CRITICAL` (the canonical SIL severity vocabulary, verbatim from `mirror.py`).

## Evidence tier + the §8 open question (important)
Behavioral self-audit → per framework **§6.6** the SIL **verdict** carries **NO non-overridable REFUSE floor**;
it caps at **VERIFY_FIRST**. The doctrine's posture ladder (`clear → note → review_and_ground →
refuse_impersonation_and_route_out`) and the `escalation()` hook (`clear|review|refuse`) are **carried verbatim**
in the receipt, plus a `route_to_human` flag. **Whether `therapeutic_impersonation = CRITICAL` should HARD-route
to human/crisis resources is doctrine §8's explicitly-OPEN question, deferred to the application layer — so it is
NOT minted here as a gauge floor.** That promotion is Phil's to rule; the gauge surfaces every signal needed for it.

## Hard rules carried (from the doctrine)
Grounding not grandeur (`grounding_required`); no reflection as proof of destiny/authority/diagnosis
(`reflection_as_proof_barred`); Return-to-Life routing when the panel degrades (`return_to_life_required`).

## Derivation (faithful port of `shadow/mirror.py`)
The 7 sub-gauge functions, `run()`, and `escalation()` are ported verbatim; `derive_state(signals)` returns the
worst sub-state. Verified against the source across randomized signal grids (zero drift).

## Gate (no floor)
Deterministic Stakes × State matrix, SHA-256-hashed into every receipt (pinned by a test), escalation mirrored on
`drift_coherence` #23. Worst corner (`CRITICAL × CRITICAL`) tops out at **VERIFY_FIRST**; `NON_OVERRIDABLE` empty.

Receipt: `mirror_boundary.receipt.v1` — carries the 7-gauge `panel`, `worst_state`, `posture`, `route_to_human`,
`grounding_required`, `reflection_as_proof_barred`, `return_to_life_required`, `global_green` (always null),
`evidence_tier`, `matrix_hash`; `to_dict`/`to_json`/`to_pbhp_extension`.

## X-6 care note (carried from the doctrine)
This instrument exists in part because heavy solo use is the very risk it names; the instrument is shareable, the
personal layer is not — best held with people who know the maintainer and a professional. *Don't be the closed loop.*
