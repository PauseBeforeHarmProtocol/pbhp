import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mirror import (audit, run, escalation, panel, derive_state, gate, is_overridable, State, Stakes,
                    Verdict, matrix_hash, NON_OVERRIDABLE, EVIDENCE_TIER, GAUGES,
                    reality_boundary_risk, therapeutic_impersonation_risk, validation_gradient)

EXPECTED_MATRIX_HASH = "51c26192ed930b276490e05dc398d1bd1ed30277cc9a9f11e0c494793971ce85"

# --- sub-gauges (ported) ---
def test_seven_subgauges():
    assert set(GAUGES) == {"mirror_dependency_load","validation_gradient","narrative_closure_pressure",
                           "human_anchor_deficit","reality_boundary_risk","therapeutic_impersonation_risk",
                           "map_territory_drift"}
def test_dependency_load_levels():
    assert panel({"emotional_reliance":"none"})["mirror_dependency_load"] == "NOMINAL"
    assert panel({"emotional_reliance":"sole"})["mirror_dependency_load"] == "CRITICAL"
def test_validation_gradient():
    assert validation_gradient({"affirmations":5,"challenges":0}) == "CRITICAL"
    assert validation_gradient({"affirmations":3,"challenges":0}) == "DEGRADED"
    assert validation_gradient({"affirmations":2,"challenges":1}) == "ELEVATED"
    assert validation_gradient({"affirmations":1,"challenges":3}) == "NOMINAL"
def test_reality_boundary_hard_flags_critical():
    assert reality_boundary_risk({"reality_flags":["grandiosity"]}) == "CRITICAL"
    assert reality_boundary_risk({"reality_flags":["mild_thing"]}) == "DEGRADED"
    assert reality_boundary_risk({}) == "NOMINAL"
def test_therapeutic_impersonation():
    assert therapeutic_impersonation_risk({"clinical_advice_given":True,"crisis_markers":True}) == "CRITICAL"
    assert therapeutic_impersonation_risk({"clinical_advice_given":True}) == "DEGRADED"
    assert therapeutic_impersonation_risk({"therapy_substitute":True}) == "ELEVATED"
    assert therapeutic_impersonation_risk({}) == "NOMINAL"

# --- worst-state composition + posture ladder ---
def test_worst_state_first():
    # clean baseline needs brought_to_humans=True (unknown anchoring is a mild ELEVATED flag by design)
    assert derive_state({"brought_to_humans": True}) == State.NOMINAL
    assert derive_state({"emotional_reliance":"sole","brought_to_humans":True}) == State.CRITICAL  # one CRITICAL dominates
    assert derive_state({}) == State.ELEVATED  # empty -> human_anchor_deficit ELEVATED (faithful to source)
def test_posture_ladder():
    base = {"brought_to_humans": True}
    assert run(base)["posture"] == "clear"
    assert run({**base,"emotional_reliance":"some"})["posture"] == "note"
    assert run({**base,"clinical_advice_given":True})["posture"] == "review_and_ground"
    assert run({**base,"reality_flags":["destiny"]})["posture"] == "refuse_impersonation_and_route_out"
def test_no_global_green():
    assert run({})["global_green"] is None
    assert run({"emotional_reliance":"sole"})["global_green"] is None
def test_hard_rule_flags():
    r = run({"reality_flags":["chosen"]})
    assert r["reflection_as_proof_barred"] is True and r["return_to_life_required"] is True
    assert run({"emotional_intensity":"rising"})["grounding_required"] is True
def test_escalation_ported():
    assert escalation(run({}))[0] == "clear"
    assert escalation(run({"clinical_advice_given":True}))[0] == "review"
    assert escalation(run({"emotional_reliance":"sole"}))[0] == "refuse"

# --- SIL contract: behavioral tier, matrix, no floor ---
def test_matrix_hash_pinned_and_64():
    h = matrix_hash(); assert len(h) == 64 and h == EXPECTED_MATRIX_HASH, h
def test_behavioral_no_floor():
    assert NON_OVERRIDABLE == set()
    worst = {gate(st, Stakes.CRITICAL).value for st in State}
    assert "REFUSE" not in " ".join(worst)
    assert gate(State.CRITICAL, Stakes.CRITICAL) == Verdict.VERIFY_FIRST
def test_no_refuse_verdict():
    assert [v.value for v in Verdict] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST"]
def test_matrix_rows():
    assert [gate(State.NOMINAL, s).value for s in Stakes] == ["PROCEED","PROCEED","PROCEED","PROCEED"]
    assert [gate(State.ELEVATED, s).value for s in Stakes] == ["PROCEED","PROCEED","PROCEED_WITH_DISCLOSURE","PROCEED_WITH_DISCLOSURE"]
    assert [gate(State.DEGRADED, s).value for s in Stakes] == ["PROCEED","PROCEED_WITH_DISCLOSURE","VERIFY_FIRST","VERIFY_FIRST"]
    assert [gate(State.CRITICAL, s).value for s in Stakes] == ["PROCEED_WITH_DISCLOSURE","VERIFY_FIRST","VERIFY_FIRST","VERIFY_FIRST"]
def test_matrix_total_16():
    from itertools import product
    for st, sk in product(State, Stakes): assert isinstance(gate(st, sk), Verdict)
def test_is_overridable_all_true():
    from itertools import product
    for st, sk in product(State, Stakes): assert is_overridable(st, sk) is True

# --- receipt ---
def test_route_to_human_flag():
    assert audit(signals={"reality_flags":["messianic"]}, stakes="HIGH").route_to_human is True
    assert audit(signals={}, stakes="HIGH").route_to_human is False
def test_evidence_tier_behavioral():
    assert audit(signals={}, stakes="LOW").evidence_tier == "behavioral" and EVIDENCE_TIER == "behavioral"
def test_receipt_panel_and_roundtrip():
    r = audit(signals={"emotional_reliance":"primary","clinical_advice_given":True,"crisis_markers":True}, stakes="CRITICAL")
    assert r.worst_state == "CRITICAL" and r.panel["therapeutic_impersonation_risk"] == "CRITICAL"
    assert r.posture == "refuse_impersonation_and_route_out" and r.route_to_human is True
    assert r.global_green is None and r.verdict == "VERIFY_FIRST"
    assert r.schema == "mirror_boundary.receipt.v1" and len(r.matrix_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"mirror_boundary"}

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[MIRROR] {p}/{p+q} passed"); sys.exit(1 if q else 0)
