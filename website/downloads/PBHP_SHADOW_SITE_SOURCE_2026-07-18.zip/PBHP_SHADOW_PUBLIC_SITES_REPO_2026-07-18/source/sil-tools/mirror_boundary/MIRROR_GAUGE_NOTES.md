# Mirror Boundary (#14) — SIL gauge promotion — BUILD NOTES (2026-07-13)

**What this is.** #14 Mirror Boundary was already BUILT as doctrine + runtime (`shadow/mirror.py`, 10/10). It was
**not** a standalone `05_tools/` panel gauge. This promotes it into one: `05_tools/mirror_boundary/` (pkg `mirror`),
conforming to the SIL common contract — the twin of the #15 Anti-Projection promotion.

**Status: ACCEPTED 2026-07-13 (R-2026-07-13-01) — panel row #27.** *(Was: BUILT, NOT ACCEPTED. The §8
hard-route question below remains OPEN — accepting the gauge does not mint that floor.)* Behavioral tier
(no REFUSE floor, caps at VERIFY_FIRST — §6.6). No CORE edit
(X-3). Canonical doctrine unchanged: `04_synthesis/08_MIRROR_BOUNDARY_v0.1.md`. Sterile; personal layer walled (X-6).

**Fidelity — verified.** The 7 sub-gauges, `run()`, and `escalation()` are ported verbatim from `shadow/mirror.py`
and cross-checked against the source across **3000 randomized signal grids** — zero drift on the panel, worst-state,
posture, escalation, and every flag. Gauge tests: **19/19**.

**The one judgment call, flagged not decided.** The doctrine's posture ladder tops out at
`refuse_impersonation_and_route_out` (CRITICAL). Per §6.6 a behavioral gauge carries no hard REFUSE floor, so the
SIL **verdict** caps at VERIFY_FIRST — but the receipt carries the full refuse posture, a `route_to_human` flag,
`return_to_life_required`, and the verbatim `escalation()` ('refuse' at CRITICAL). **Whether therapeutic-
impersonation-CRITICAL becomes a HARD application-layer route-out is doctrine §8's explicitly-open question — left
to you, not minted here as a floor.** Everything needed to make that call is in the receipt.

**Contract.** States NOMINAL/ELEVATED/DEGRADED/CRITICAL (verbatim from mirror.py); worst-state-first composition;
`global_green` always null (no global green); Stakes×State matrix + pinned hash; receipt `mirror_boundary.receipt.v1`
carries the 7-gauge panel + posture + all hard-rule flags; `to_dict`/`to_json`/`to_pbhp_extension`/`audit()`.

**NEEDS-PHIL.** Renumber a receipt; panel-accounting for the interaction pair (#14 + #15); rule the §8 hard-route
question; accept/reject. With this, #14 and #15 are both first-class panel gauges.
