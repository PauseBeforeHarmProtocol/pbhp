# PBHP-SIL — Runtime Reliability Disclosure panel

**What this is.** A panel of small, standalone reference gauges that disclose the *operating state* of an AI system at the moment it produces consequential output — and gate that output on it. Today an operator gets one disclosure: *"AI can make mistakes."* That is a liability sticker. A pilot doesn't fly on "flying can be dangerous"; a pilot gets airspeed, altitude, fuel, oil pressure — the operating state, continuously. **This panel is that instrument cluster for AI work.**

The class is specified in [`../04_synthesis/02_SIL_FRAMEWORK_v0.1.md`](../04_synthesis/02_SIL_FRAMEWORK_v0.1.md). This folder is the working code.

- **23 gauges + 1 composition layer.** Gauge #1 is the Context Load Audit (CLA); #2–#23 follow its template.
- **404 tests, all green, exit 0.** Every gate matrix is SHA-256-hashed and pinned by a test. *(393 → 394 on 2026-06-12: CLA v0.2 added one test for the provenance-aware self-report floor; N1/N11, R-2026-06-12-11. 394 → 404 on 2026-06-24: CLA handoff fact-verify mode, 75 → 85 CLA tests, R-2026-06-24-06.)*
- **Zero required dependencies.** Pure Python standard library. Each gauge is a self-contained package you can lift out on its own.
- **Independently audited** (2026-06-07): **PASS-WITH-CONCERNS** — see [`AUDIT_FINDINGS_SIL_2026-06-07.md`](AUDIT_FINDINGS_SIL_2026-06-07.md).
- **No global green / "verified" verdict.** The panel discloses *per-gauge* operating state (`PROCEED` / `PROCEED_WITH_DISCLOSURE` / `VERIFY_FIRST` / `REFUSE_*`) and surfaces the worst unresolved reading first — never a single pass-badge. A green test suite means the *code* is sound; it never means a *decision* was right. Cryptographic integrity (signatures, hash chain) proves a record was **not altered**, not that it was **correct**. *(EGC honesty rule, R-2026-06-26-06.)*

Per-gauge build & test status is the board: **[`SIL_GAUGE_INDEX.md`](SIL_GAUGE_INDEX.md)** (ground truth).

---

## Two ways to use it

### 1. One gauge, standalone
Every gauge is a zero-dependency package. Copy its folder and call `audit()` — that's the whole integration.

```python
import sys; sys.path.insert(0, "data_sensitivity")
from ds import audit

r = audit(sensitivity="regulated", stakes="CRITICAL")
print(r.verdict)      # REFUSE_UNTIL_AUTHORIZED
print(r.to_json())    # full receipt: state, stakes, verdict, matrix_hash, override, issued_at, schema
```

`audit()` returns a **receipt** — a dataclass with `to_dict()`, `to_json()`, and `to_pbhp_extension()`. The verdict is one of `PROCEED` / `PROCEED_WITH_DISCLOSURE` / `VERIFY_FIRST` / `REFUSE_*`. Operator override can relax a DISCLOSE or VERIFY verdict (with a logged acknowledgment); it **cannot** relax a non-overridable REFUSE floor (the receipt records `ignored_floor`).

### 2. The whole panel, composed
The composition layer (`rrd_renderer/`, package `rrd`) takes any set of gauge receipts and renders the single tiered disclosure from framework §4. It imports **no** gauge package — it consumes the common receipt contract by duck typing, so every gauge (present or future) composes without changing the renderer.

```python
import sys
for p in ("context_load_audit", "data_sensitivity", "retrieval_coverage", "rrd_renderer"):
    sys.path.insert(0, p)
from rrd import normalize, render

readings = [normalize(rec) for rec in my_receipts]      # rec = any gauge's audit() output
disclosure = render(readings, stakes="CRITICAL")
print(disclosure.text)        # the Runtime Reliability Disclosure block (gated + receipt-required at CRITICAL)
```

A full worked example — real receipts across CLA + several gauges, both the HIGH (ungated) and CRITICAL (gated) tiers, plus a behavioral reading at the weaker tier — is in [`rrd_renderer/examples/panel_disclosure_example.py`](rrd_renderer/examples/panel_disclosure_example.py) (15/15 self-checks).

---

## The common contract (every gauge)
- A `State` enum (the gauge's reading) and `Stakes` (LOW / MEDIUM / HIGH / CRITICAL).
- A deterministic **Stakes × State matrix**, SHA-256-hashed into every receipt (tamper-evident; baselines registered in the audit doc).
- `derive_state(...)`, `gate(state, stakes)`, `is_overridable(state, stakes)`.
- A receipt dataclass (`to_dict` / `to_json` / `to_pbhp_extension`, with a `schema` string) and a one-call `audit()`.
- Stakes maps to the PBHP GREEN→BLACK harm ladder. Override relaxes only DISCLOSE/VERIFY; REFUSE floors are non-overridable.

## Tiered disclosure by stakes (the renderer)
- **LOW** — no disclosure unless asked.
- **MEDIUM** — one compact line.
- **HIGH** — a Runtime Reliability Disclosure block.
- **CRITICAL** — block + gate + receipt requirement. Any single REFUSE across the panel gates the whole disclosure.

## Floor policy
Most gauges lock a single worst-corner REFUSE cell. Documented exceptions (audited 2026-06-07): **Time/Date #2** and **Source Provenance #3** intentionally lock multiple cells (stricter on temporal blindness / unlabeled blur — rationale in their specs and the audit doc, F1). **Stakes #4** (a classifier that feeds the others) and **Drift/Session-Coherence #23** (behavioral, weaker evidence tier) carry **no** floor by design — a heuristic self-assessment never hard-blocks what the measured gauges gate (framework §6.6).

---

## Running the tests
Each gauge has a self-contained runner:

```bash
python3 <gauge_folder>/tests/test_*.py        # prints "[TAG] N/N passed", exits 0 on green
```

Sweep them all by looping the `*/tests/test_*.py` files (skip `context_load_audit/` — it uses pytest — and `pbhp_v1_core/`, which is the PBHP v1.0 CORE, not an SIL gauge). CLA runs under pytest:

```bash
pip install pytest --break-system-packages
BT=$(mktemp -d); rm -rf "$BT"
python3 -c "import sys; sys.setrecursionlimit(1000000); import pytest; \
  raise SystemExit(pytest.main(['context_load_audit/tests/test_cla.py','--basetemp=$BT','-q']))"
```

(The unique basetemp avoids a known 9p-filesystem teardown collision; CLA is 75/75.)

**Current totals (re-derived 2026-06-12):** 22 script-style gauges 303 + CLA 75 + RRD renderer 16 = **394, all exit 0.** *(CLA 74 → 75 with v0.2: provenance-aware self-report floor + record-don't-rewrite override, N1/N11.)*

## Validation status (honest)
The tests prove the gates behave **deterministically**; they do not prove the gauges classify correctly in the wild. CLA's two validation experiments are executed as **reference runs** (`context_load_audit/experiments/`): §13.1 (differential disclosure vs a sticker-only baseline) and §13.2 (threshold-calibration *method* + a reference policy from a stylized literature-shaped curve — **not** validated bands). Real-model calibration on a maintainer's `eval_fn` and in-the-wild human audit remain open. The eval loop is closed; v1.0 CORE is untouched.

## Where things live
- **Board / status:** `SIL_GAUGE_INDEX.md` · **Umbrella spec:** `../04_synthesis/02_SIL_FRAMEWORK_v0.1.md` · **Decision ledger:** `../04_synthesis/CHANGELOG.md`
- **Audit:** `AUDIT_FINDINGS_SIL_2026-06-07.md` · **Per-gauge spec:** `<gauge_folder>/*_SPEC_v0.1.md`
- **CLA (gauge #1):** `context_load_audit/` (its own README, spec, operator guide, PBHP integration, experiments).

## License & register
Open, attribution required, no single owner — same terms as PBHP. Concept: Phillip Linstrum. Register: **sterile** (regulator-legible); the project's mythic/foundations layer lives elsewhere by the wall-off rule.
