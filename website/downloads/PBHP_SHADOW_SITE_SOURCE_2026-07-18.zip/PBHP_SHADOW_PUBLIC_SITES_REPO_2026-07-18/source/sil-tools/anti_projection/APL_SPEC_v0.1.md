# Anti-Projection (APL) — SIL gauge form — SPEC v0.1  (behavioral tier)

**Promotes candidate #15 (Anti-Projection Layer) into a standalone `05_tools/` SIL gauge.** The canonical
doctrine remains `04_synthesis/09_ANTI_PROJECTION_LAYER_v0.1.md`; this is its panel-gauge form.
**Register:** sterile. **Status:** BUILT — not ACCEPTED. **Behavioral / weaker tier.** No CORE edit (X-3);
composes by reference. Personal seed firewalled (X-6). Runtime placement: **Step 4.5** (after Who-Pays-First,
before the gate stack).

## What it asks
"Am I responding to what the user actually said, or to an inferred version I created?" It audits the system's
**attributions to the user** — the projection_risk. It only ever **ADDS** attribution-caution (quote-anchor /
conditional framing / repair); it never licenses an unsupported attribution and never turns a refuse into a proceed.

## Evidence tier
A **behavioral self-audit** (like `drift_coherence` #23 / Mirror Boundary #14). Per §6.6 it carries **NO
non-overridable REFUSE floor**; strongest verdict is **VERIFY_FIRST** (= "slow down, lead with quote anchors").
Inference-here-is-itself-a-risk, so signals should be host/self-reported, not inferred-and-asserted.

## States (= the doctrine's projection_risk levels)
`NONE` (no inference voiced) · `LOW` (inference, high confidence) · `MEDIUM` (inference, medium confidence) ·
`HIGH` (low-confidence inference, OR answering an inference as if stated, OR a prohibited identity/intent/
belief/clinical/dependency attribution without behavioral evidence).

## Derivation (faithful port of `shadow/apl.py`)
`derive_state(signals)` reproduces `apl.run(...)`'s `projection_risk` exactly. Auxiliary receipt fields
(`boundary_needed`, `boundary_framed_as`, `must_quote_anchor`, `repair_required`, `posture`,
`prohibited_attribution`) are ported verbatim. Posture ladder: `clear → answer_with_labels →
steelman_then_conditional → quote_anchor_and_conditional → repair` (repair when the user flags a projection).

## Gate (no floor)
Deterministic Stakes × State matrix, SHA-256-hashed into every receipt (pinned by a test), escalation mirrored
on `drift_coherence` #23. Worst corner (`HIGH × CRITICAL`) tops out at **VERIFY_FIRST**; `NON_OVERRIDABLE` empty.

Receipt: `anti_projection.receipt.v1` — carries the doctrine's `anti_projection` block (spec §5) + `posture`,
`prohibited_attribution`, `must_quote_anchor`, `evidence_tier`, `matrix_hash`; `to_dict`/`to_json`/`to_pbhp_extension`.

*Maxim: Reflect what is present. Label what is inferred. Contain what is risky. Do not accuse by caution.*
