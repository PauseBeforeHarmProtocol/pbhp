"""Anti-Projection (APL) -- SIL gauge form of candidate #15. BEHAVIORAL / weaker evidence tier. stdlib only.

Audits the system's ATTRIBUTIONS to the user: "Am I responding to what the user actually said, or to an
inferred version I created?" A faithful port of shadow/apl.py's projection_risk derivation into the SIL common
contract (State x Stakes matrix + receipt + audit()), so #15 composes into the panel like the other gauges.

Only ADDS attribution-caution (quote-anchor / conditional / repair); never licenses an unsupported attribution,
never turns a refuse into a proceed. Per framework SS6.6 it is behavioral -> NO non-overridable REFUSE floor;
strongest verdict is VERIFY_FIRST ("slow down, lead with quote anchors"). Canonical doctrine:
04_synthesis/09_ANTI_PROJECTION_LAYER_v0.1.md. No CORE edit (X-3). Sterile (X-6). BUILT, not ACCEPTED.

Maxim: Reflect what is present. Label what is inferred. Contain what is risky. Do not accuse by caution.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"

EVIDENCE_TIER = "behavioral"
POLICY_VERSION = "anti-projection-default/0.1.0"
# attribution_type values that require behavioral evidence (else the attribution is prohibited -> HIGH)
IDENTITY_INTENT = ("identity", "intent", "belief", "clinical", "dependency")
_CONF = ("low", "medium", "high")


class State(str, Enum):
    NONE = "NONE"; LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    # Behavioral gauge: caps at VERIFY_FIRST (no REFUSE floor -- SS6.6; APL only ADDS caution).
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"


_P, _D, _V = Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST
# Escalation mirrored on drift_coherence #23.  NONE->LOW->MEDIUM->HIGH  x  LOW->MEDIUM->HIGH->CRITICAL
_MATRIX = {
    (State.NONE, Stakes.LOW): _P, (State.NONE, Stakes.MEDIUM): _P, (State.NONE, Stakes.HIGH): _P, (State.NONE, Stakes.CRITICAL): _P,
    (State.LOW, Stakes.LOW): _P, (State.LOW, Stakes.MEDIUM): _P, (State.LOW, Stakes.HIGH): _D, (State.LOW, Stakes.CRITICAL): _D,
    (State.MEDIUM, Stakes.LOW): _P, (State.MEDIUM, Stakes.MEDIUM): _D, (State.MEDIUM, Stakes.HIGH): _V, (State.MEDIUM, Stakes.CRITICAL): _V,
    (State.HIGH, Stakes.LOW): _D, (State.HIGH, Stakes.MEDIUM): _V, (State.HIGH, Stakes.HIGH): _V, (State.HIGH, Stakes.CRITICAL): _V,
}
NON_OVERRIDABLE = set()

_RISK_TO_STATE = {"none": State.NONE, "low": State.LOW, "medium": State.MEDIUM, "high": State.HIGH}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def prohibited_attribution(attribution_type, behavioral_evidence):
    return (attribution_type in IDENTITY_INTENT) and not bool(behavioral_evidence)


def derive_projection_risk(signals=None):
    """Faithful port of shadow/apl.py run() -> the projection_risk string (none|low|medium|high)."""
    s = signals or {}
    inferred = s.get("assistant_inferred", []) or []
    conf = s.get("inference_confidence", "low")
    if conf not in _CONF:
        raise ValueError("inference_confidence must be one of %r" % (_CONF,))
    answering_inferred_as_stated = bool(s.get("answering_inferred_as_stated"))
    behavioral_evidence = bool(s.get("behavioral_evidence"))
    attribution_type = s.get("attribution_type", "content")
    has_inf = len(inferred) > 0
    if prohibited_attribution(attribution_type, behavioral_evidence) or (has_inf and answering_inferred_as_stated):
        return "high"
    if has_inf and conf == "low":
        return "high"
    if has_inf and conf == "medium":
        return "medium"
    if has_inf:
        return "low"
    return "none"


def derive_state(signals=None):
    return _RISK_TO_STATE[derive_projection_risk(signals)]


def _aux(signals, risk):
    """Port of apl.py's boundary / posture logic. Returns the auxiliary receipt fields."""
    s = signals or {}
    inferred = s.get("assistant_inferred", []) or []
    risk_patterns = s.get("risk_pattern_noticed", []) or []
    behavioral_evidence = bool(s.get("behavioral_evidence"))
    attribution_type = s.get("attribution_type", "content")
    user_flagged = bool(s.get("user_flagged_projection"))
    prohibited = prohibited_attribution(attribution_type, behavioral_evidence)
    boundary_needed = bool(risk_patterns) or risk in ("medium", "high")
    boundary_framed_as = "direct" if (risk in ("none", "low") and not prohibited) else "conditional"
    must_quote_anchor = risk == "high"
    repair_required = user_flagged
    if repair_required:
        posture = "repair"
    elif risk == "high":
        posture = "quote_anchor_and_conditional"
    elif risk == "medium":
        posture = "steelman_then_conditional"
    elif len(inferred) > 0:
        posture = "answer_with_labels"
    else:
        posture = "clear"
    return {"boundary_needed": boundary_needed, "boundary_framed_as": boundary_framed_as,
            "must_quote_anchor": must_quote_anchor, "repair_required": repair_required,
            "posture": posture, "prohibited_attribution": prohibited}


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class APLReceipt:
    anti_projection: dict     # the doctrine's spec-SS5 block
    posture: str
    prohibited_attribution: bool
    must_quote_anchor: bool
    state: str
    stakes: str
    verdict: str
    evidence_tier: str = EVIDENCE_TIER
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "anti_projection.receipt.v1"

    def to_dict(self):
        return {
            "anti_projection": dict(self.anti_projection), "posture": self.posture,
            "prohibited_attribution": self.prohibited_attribution, "must_quote_anchor": self.must_quote_anchor,
            "state": self.state, "stakes": self.stakes, "verdict": self.verdict,
            "evidence_tier": self.evidence_tier, "policy_version": self.policy_version,
            "matrix_hash": self.matrix_hash, "override": dict(self.override),
            "issued_at": self.issued_at, "schema": self.schema,
        }

    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"anti_projection": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, signals=None, stakes, override_ack=None, now=None):
    risk = derive_projection_risk(signals)
    state = _RISK_TO_STATE[risk]
    aux = _aux(signals, risk)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    s = signals or {}
    block = {
        "user_stated": list(s.get("user_stated", []) or []),
        "assistant_inferred": list(s.get("assistant_inferred", []) or []),
        "inference_confidence": s.get("inference_confidence", "low"),
        "risk_pattern_noticed": list(s.get("risk_pattern_noticed", []) or []),
        "projection_risk": risk,
        "boundary_needed": aux["boundary_needed"],
        "boundary_framed_as": aux["boundary_framed_as"],
        "repair_required": aux["repair_required"],
    }
    return APLReceipt(anti_projection=block, posture=aux["posture"],
                      prohibited_attribution=aux["prohibited_attribution"], must_quote_anchor=aux["must_quote_anchor"],
                      state=state.value, stakes=Stakes(stakes).value, verdict=verdict.value,
                      override=override, issued_at=_now_iso(now))


__all__ = ["audit", "APLReceipt", "State", "Stakes", "Verdict", "derive_state", "derive_projection_risk",
           "prohibited_attribution", "gate", "is_overridable", "matrix_hash", "EVIDENCE_TIER",
           "POLICY_VERSION", "NON_OVERRIDABLE", "IDENTITY_INTENT"]
