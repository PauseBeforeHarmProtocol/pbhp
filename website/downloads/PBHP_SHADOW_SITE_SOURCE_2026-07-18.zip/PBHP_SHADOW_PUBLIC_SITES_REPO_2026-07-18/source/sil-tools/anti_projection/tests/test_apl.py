import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from apl import (audit, derive_state, derive_projection_risk, prohibited_attribution, gate,
                 is_overridable, State, Stakes, Verdict, matrix_hash, NON_OVERRIDABLE,
                 EVIDENCE_TIER, IDENTITY_INTENT)

EXPECTED_MATRIX_HASH = "4a16acab834c80b70f95aaa09e54bb358c533e63eee98201cdf590d347dbf58d"

# --- derivation (faithful port of shadow/apl.py) ---
def test_none_when_no_inference():
    assert derive_projection_risk({}) == "none" and derive_state({}) == State.NONE
def test_low_when_high_confidence_inference():
    assert derive_projection_risk({"assistant_inferred": ["x"], "inference_confidence": "high"}) == "low"
def test_medium_when_medium_confidence():
    assert derive_projection_risk({"assistant_inferred": ["x"], "inference_confidence": "medium"}) == "medium"
def test_high_when_low_confidence():
    assert derive_projection_risk({"assistant_inferred": ["x"], "inference_confidence": "low"}) == "high"
def test_high_when_answering_inference_as_stated():
    assert derive_projection_risk({"assistant_inferred": ["x"], "inference_confidence": "high",
                                   "answering_inferred_as_stated": True}) == "high"
def test_high_on_prohibited_identity_attribution_without_evidence():
    for at in IDENTITY_INTENT:
        assert derive_projection_risk({"attribution_type": at}) == "high", at
def test_prohibited_cleared_by_behavioral_evidence():
    assert derive_projection_risk({"attribution_type": "dependency", "behavioral_evidence": True}) == "none"
    assert prohibited_attribution("clinical", False) is True
    assert prohibited_attribution("clinical", True) is False
    assert prohibited_attribution("content", False) is False
def test_bad_confidence_raises():
    try: derive_state({"assistant_inferred": ["x"], "inference_confidence": "bogus"}); assert False
    except ValueError: pass

# --- posture / boundary port ---
def test_posture_ladder():
    assert audit(signals={}, stakes="LOW").posture == "clear"
    assert audit(signals={"assistant_inferred": ["x"], "inference_confidence": "high"}, stakes="LOW").posture == "answer_with_labels"
    assert audit(signals={"assistant_inferred": ["x"], "inference_confidence": "medium"}, stakes="LOW").posture == "steelman_then_conditional"
    assert audit(signals={"assistant_inferred": ["x"], "inference_confidence": "low"}, stakes="LOW").posture == "quote_anchor_and_conditional"
    assert audit(signals={"user_flagged_projection": True}, stakes="LOW").posture == "repair"
def test_repair_takes_precedence():
    r = audit(signals={"assistant_inferred": ["x"], "inference_confidence": "low", "user_flagged_projection": True}, stakes="HIGH")
    assert r.posture == "repair" and r.anti_projection["repair_required"] is True
def test_boundary_framed_conditional_when_risky():
    assert audit(signals={"assistant_inferred": ["x"], "inference_confidence": "high"}, stakes="LOW").anti_projection["boundary_framed_as"] == "direct"
    assert audit(signals={"assistant_inferred": ["x"], "inference_confidence": "low"}, stakes="LOW").anti_projection["boundary_framed_as"] == "conditional"
def test_must_quote_anchor_on_high():
    assert audit(signals={"attribution_type": "belief"}, stakes="LOW").must_quote_anchor is True

# --- SIL contract: behavioral tier, matrix, no floor ---
def test_matrix_hash_pinned_and_64():
    h = matrix_hash(); assert len(h) == 64 and h == EXPECTED_MATRIX_HASH, h
def test_behavioral_no_floor():
    assert NON_OVERRIDABLE == set()
    worst = {gate(st, Stakes.CRITICAL).value for st in State}
    assert "REFUSE" not in " ".join(worst)
    assert gate(State.HIGH, Stakes.CRITICAL) == Verdict.VERIFY_FIRST
def test_no_refuse_verdict():
    assert [v.value for v in Verdict] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST"]
def test_none_row_proceeds():
    for s in Stakes: assert gate(State.NONE, s) == Verdict.PROCEED
def test_low_row():
    assert [gate(State.LOW, s).value for s in Stakes] == ["PROCEED", "PROCEED", "PROCEED_WITH_DISCLOSURE", "PROCEED_WITH_DISCLOSURE"]
def test_medium_row():
    assert [gate(State.MEDIUM, s).value for s in Stakes] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_high_row_caps_at_verify():
    assert [gate(State.HIGH, s).value for s in Stakes] == ["PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_matrix_total_16():
    from itertools import product
    for st, sk in product(State, Stakes): assert isinstance(gate(st, sk), Verdict)
def test_is_overridable_all_true():
    from itertools import product
    for st, sk in product(State, Stakes): assert is_overridable(st, sk) is True
def test_evidence_tier_behavioral():
    assert audit(signals={}, stakes="LOW").evidence_tier == "behavioral" and EVIDENCE_TIER == "behavioral"
def test_receipt_block_and_roundtrip():
    r = audit(signals={"user_stated": ["I'm proud"], "assistant_inferred": ["chosen one"],
                       "inference_confidence": "low", "risk_pattern_noticed": ["grandeur"]}, stakes="HIGH")
    ap = r.anti_projection
    assert ap["projection_risk"] == "high" and ap["user_stated"] == ["I'm proud"]
    assert ap["boundary_needed"] is True
    assert r.schema == "anti_projection.receipt.v1" and len(r.matrix_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"anti_projection"}

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[APL] {p}/{p+q} passed"); sys.exit(1 if q else 0)
