# Anti-Projection (#15) — SIL gauge promotion — BUILD NOTES (2026-07-13)

**What this is.** #15 Anti-Projection was already BUILT as doctrine + runtime (`shadow/apl.py`, tests 7/7). It
was **not** a standalone `05_tools/` panel gauge. This promotes it into one: `05_tools/anti_projection/`
(pkg `apl`), conforming to the SIL common contract so it composes into the panel like the other gauges.

**Status: ACCEPTED 2026-07-13 (R-2026-07-13-01) — panel row #28.** *(Was: BUILT, NOT ACCEPTED.)* Behavioral
tier (no REFUSE floor, caps at VERIFY_FIRST — §6.6). No CORE edit
(X-3). Canonical doctrine unchanged: `04_synthesis/09_ANTI_PROJECTION_LAYER_v0.1.md`. Sterile (X-6).

**Fidelity — verified.** `derive_projection_risk` is a faithful port of `shadow/apl.py run()`. Cross-checked
against the original across **576/576 signal combinations** — zero drift on projection_risk, posture, and the
boundary/aux fields. Gauge tests: **23/23**.

**Contract.** States NONE/LOW/MEDIUM/HIGH (= the doctrine's `projection_risk`); Stakes×State matrix,
SHA-256 `matrix_hash` pinned by a test; receipt `anti_projection.receipt.v1` carries the doctrine's §5
`anti_projection` block + `posture` / `prohibited_attribution` / `must_quote_anchor` / `evidence_tier`;
`to_dict` / `to_json` / `to_pbhp_extension` / `audit()`.

**NEEDS-PHIL.** Renumber a CHANGELOG receipt against the live ledger; panel-accounting for the promoted
interaction gauges (#14 Mirror + #15 APL as candidate panel entries, or FCR-family-outside-the-count); accept/
reject. Note #14 Mirror Boundary is the obvious twin promotion (same situation — built in `shadow/`, not yet a
standalone gauge) if you want the pair done.
