import os, sys, json

HERE = os.path.dirname(os.path.abspath(__file__))
RRD = os.path.dirname(HERE)
TOOLS = os.path.dirname(RRD)
for p in [RRD,
          os.path.join(TOOLS, "context_load_audit"),
          os.path.join(TOOLS, "retrieval_coverage"),
          os.path.join(TOOLS, "reversibility"),
          os.path.join(TOOLS, "citation_sufficiency")]:
    sys.path.insert(0, p)

import rrd
from rrd import normalize, render, verdict_severity, GaugeReading, Disclosure

import cla
import rc
import rev
import cit

# ---- real receipts ---------------------------------------------------------
def cla_receipt(used, stakes):
    return cla.audit(used_tokens=used, max_tokens=200_000, stakes=stakes)["receipt"]

# ---- severity ranking spans both vocabularies ------------------------------
def test_severity_cla_vocab():
    assert verdict_severity("REFUSE_REFRESH")==3
    assert verdict_severity("PAUSE_RECOMMEND_REFRESH")==2
def test_severity_rds_vocab():
    assert verdict_severity("REFUSE_LOW_COVERAGE")==3
    assert verdict_severity("VERIFY_FIRST")==2
    assert verdict_severity("PROCEED_WITH_DISCLOSURE")==1
    assert verdict_severity("PROCEED")==0
def test_severity_unknown_conservative():
    assert verdict_severity("WAT")==2 and verdict_severity("")==2

# ---- normalize handles both shapes -----------------------------------------
def test_normalize_cla():
    r = normalize(cla_receipt(180_000, "HIGH"))   # 90% -> CRITICAL/REFUSE_REFRESH
    assert r.name=="context_load" and r.state=="CRITICAL" and r.verdict=="REFUSE_REFRESH"
    assert r.severity==3 and "load: 90.0%" in r.reads_out
def test_normalize_rc():
    r = normalize(rc.audit(sources_total=12, sources_searched=0, stakes="CRITICAL"))
    assert r.name=="retrieval_coverage" and r.state=="NONE" and r.verdict=="REFUSE_LOW_COVERAGE"
    assert "coverage 0/12 sources" in r.reads_out
def test_normalize_rev_and_cit_names():
    assert normalize(rev.audit(reversibility="irreversible", stakes="CRITICAL")).name=="reversibility"
    assert normalize(cit.audit(required=2, sourced=2, stakes="LOW")).name=="citation_sufficiency"
def test_normalize_accepts_dict():
    d = rc.audit(sources_total=10, sources_searched=9, stakes="LOW").to_dict()
    assert normalize(d).state=="COMPREHENSIVE"

# ---- tiering by stakes (framework §4) --------------------------------------
def test_low_silent_unless_asked():
    rd = [normalize(rc.audit(sources_total=10, sources_searched=10, stakes="LOW"))]
    assert render(rd, stakes="LOW").text==""
    assert render(rd, stakes="LOW", asked=True).text!=""
def test_medium_one_line():
    rd = [normalize(rc.audit(sources_total=10, sources_searched=6, stakes="MEDIUM"))]
    out = render(rd, stakes="MEDIUM")
    assert out.tier=="line" and "\n" not in out.text and out.text.startswith("Runtime reliability:")
def test_high_block():
    rd = [normalize(cla_receipt(110_000, "HIGH")),                       # 55% ELEVATED -> DISCLOSE
          normalize(rc.audit(sources_total=10, sources_searched=9, stakes="HIGH"))]
    out = render(rd, stakes="HIGH")
    assert out.tier=="block" and out.text.startswith("Runtime Reliability Disclosure")
    assert "\n" in out.text and out.gated is False and out.receipt_required is False
def test_critical_requires_receipt_even_when_clean():
    rd = [normalize(rc.audit(sources_total=10, sources_searched=10, stakes="CRITICAL"))]  # PROCEED
    out = render(rd, stakes="CRITICAL")
    assert out.tier=="block+gate+receipt" and out.receipt_required is True and out.gated is False

# ---- gating: any REFUSE blocks ---------------------------------------------
def test_refuse_gauge_gates_panel():
    rd = [normalize(cla_receipt(110_000, "HIGH")),                                  # DISCLOSE
          normalize(rc.audit(sources_total=10, sources_searched=10, stakes="HIGH")),# PROCEED
          normalize(rev.audit(reversibility="irreversible", stakes="CRITICAL"))]    # REFUSE floor
    out = render(rd, stakes="HIGH")
    assert out.gated is True and out.overall_verdict=="REFUSE" and out.receipt_required is True
    assert "Gate:    BLOCKED" in out.text and "reversibility" in out.text
def test_overall_stakes_is_max_when_unset():
    rd = [normalize(rc.audit(sources_total=10, sources_searched=9, stakes="MEDIUM")),
          normalize(rev.audit(reversibility="easy", stakes="CRITICAL"))]
    assert render(rd).overall_stakes=="CRITICAL"

# ---- behavioral (weaker-tier) labeling -------------------------------------
def test_behavioral_marker():
    rd = [GaugeReading(name="drift", state="DRIFTING", stakes="HIGH",
                       verdict="VERIFY_FIRST", reads_out="coherence slipping",
                       evidence_tier="behavioral")]
    out = render(rd, stakes="HIGH")
    assert out.behavioral_present is True and "weaker tier" in out.text

# ---- empty + serialization -------------------------------------------------
def test_empty_panel():
    out = render([], stakes="HIGH")
    assert out.text=="" and out.gated is False and out.overall_verdict=="PROCEED"
def test_disclosure_roundtrip():
    out = render([normalize(rc.audit(sources_total=10, sources_searched=1, stakes="HIGH"))], stakes="HIGH")
    assert json.loads(out.to_json())==out.to_dict() and set(out.to_dict()) >= {"tier","text","gated"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[RRD] {p}/{p+q} passed"); sys.exit(1 if q else 0)
