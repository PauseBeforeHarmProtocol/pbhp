"""Worked example: the SIL panel + CLA rendered as ONE disclosure surface.

Demonstrates, against REAL receipts (no mocks):
  1. The RRD renderer composing receipts from CLA + several SIL gauges,
     including gauges built after the renderer (Data Sensitivity #13,
     Validation Status #14, Data Lineage #18) — which compose "for free"
     because the renderer imports NO gauge package (it duck-types the
     common receipt contract).
  2. Tiering by stakes per SIL framework §4: HIGH -> block,
     CRITICAL -> block + gate + receipt; any single REFUSE gates the panel.
  3. The same CLA reading rendered through CLA's OWN disclosure formatters
     (compact line == MIN tier; block == CORE/ULTRA tier) so the operator
     sees SIL and CLA as one system, not two — same band, same verdict.
  4. A behavioral reading (Drift) carried at the weaker evidence tier (§6.6).

Run:  python3 rrd_renderer/examples/panel_disclosure_example.py
It is self-checking (asserts at the end); it is an EXAMPLE, not part of
the gauge test count.
"""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
RRD = os.path.dirname(HERE)
TOOLS = os.path.dirname(RRD)
for p in [RRD,
          os.path.join(TOOLS, "context_load_audit"),
          os.path.join(TOOLS, "retrieval_coverage"),
          os.path.join(TOOLS, "citation_sufficiency"),
          os.path.join(TOOLS, "validation_status"),
          os.path.join(TOOLS, "data_sensitivity"),
          os.path.join(TOOLS, "data_lineage")]:
    sys.path.insert(0, p)

import rrd
from rrd import normalize, render, GaugeReading
import cla
from cla import format_disclosure_line, format_disclosure_block
import rc, cit, val, ds, dl


def hr(title):
    print("\n" + "=" * 72 + "\n" + title + "\n" + "=" * 72)


# ---------------------------------------------------------------------------
# SCENARIO A — HIGH stakes, internal analysis draft. Ungated block.
# CLA elevated (disclose), coverage good, citations complete, validation
# tool-checked — but the data's transformation history is only PARTIAL, so
# Data Lineage (#18) drives the panel to VERIFY_FIRST without gating it.
# ---------------------------------------------------------------------------
hr("SCENARIO A · HIGH stakes · internal analysis draft")

readings_a = [
    normalize(cla.audit(used_tokens=110_000, max_tokens=200_000, stakes="HIGH")["receipt"]),
    normalize(rc.audit(sources_total=10, sources_searched=9, stakes="HIGH")),
    normalize(cit.audit(required=3, sourced=3, stakes="HIGH")),
    normalize(val.audit(validation="tool", stakes="HIGH")),
    normalize(dl.audit(lineage="partial", stakes="HIGH")),   # gauge #18, composes for free
]
disc_a = render(readings_a, stakes="HIGH")
print(disc_a.text)
print("\n[overall] verdict={} gated={} verify_required={} receipt_required={}".format(
    disc_a.overall_verdict, disc_a.gated, disc_a.verify_required, disc_a.receipt_required))


# ---------------------------------------------------------------------------
# SCENARIO B — CRITICAL stakes, FDA 510(k) substantial-equivalence section.
# Regulated data, not yet validated, high context load. Three non-overridable
# floors fire (context_load, data_sensitivity, validation_status); the panel
# gates and a receipt is required. Data Lineage is clean here (traced) — a new
# gauge passing as well as, in A, failing.
# ---------------------------------------------------------------------------
hr("SCENARIO B · CRITICAL stakes · FDA 510(k) submission section")

cla_b = cla.audit(used_tokens=150_000, max_tokens=200_000, stakes="CRITICAL")
readings_b = [
    normalize(cla_b["receipt"]),
    normalize(ds.audit(sensitivity="regulated", stakes="CRITICAL")),   # #13
    normalize(val.audit(validation="unchecked", stakes="CRITICAL")),   # #14
    normalize(rc.audit(sources_total=12, sources_searched=12, stakes="CRITICAL")),
    normalize(dl.audit(lineage="traced", stakes="CRITICAL")),          # #18, clean
]
disc_b = render(readings_b, stakes="CRITICAL")
print(disc_b.text)
print("\n[overall] verdict={} gated={} verify_required={} receipt_required={}".format(
    disc_b.overall_verdict, disc_b.gated, disc_b.verify_required, disc_b.receipt_required))


# ---------------------------------------------------------------------------
# The SAME CLA reading from Scenario B, through CLA's own formatters.
# MIN tier == compact line; CORE/ULTRA tier == block. SIL composed the very
# same receipt above — same band, same verdict — so the two render as one.
# ---------------------------------------------------------------------------
hr("CLA native disclosure (same Scenario-B reading) · MIN line / CORE-ULTRA block")
print("MIN  (line):\n  " + cla_b["disclosure"])
print("\nCORE/ULTRA (block):")
print(format_disclosure_block(cla_b["reading"], cla_b["band"], cla_b["gate"]))


# ---------------------------------------------------------------------------
# Behavioral reading carried at the weaker evidence tier (§6.6).
# ---------------------------------------------------------------------------
hr("Behavioral reading · weaker-tier marker (§6.6)")
drift = GaugeReading(name="drift", state="DRIFTING", stakes="HIGH",
                     verdict="VERIFY_FIRST", reads_out="session coherence slipping",
                     evidence_tier="behavioral")
disc_c = render(readings_a + [drift], stakes="HIGH")
print(disc_c.text)


# ---------------------------------------------------------------------------
# Self-checks
# ---------------------------------------------------------------------------
def run_checks():
    checks = []
    def ok(label, cond): checks.append((label, bool(cond)))

    # A: ungated HIGH block driven to VERIFY_FIRST by Data Lineage #18
    ok("A tier is block", disc_a.tier == "block")
    ok("A ungated", disc_a.gated is False)
    ok("A overall VERIFY_FIRST", disc_a.overall_verdict == "VERIFY_FIRST")
    ok("A no receipt required (HIGH, ungated)", disc_a.receipt_required is False)
    ok("A includes data_lineage reading", "data_lineage" in [r.name for r in disc_a.readings])

    # compose-for-free: renderer names gauges it never imported, via schema prefix
    ok("ds composes for free (name=data_sensitivity)",
       normalize(ds.audit(sensitivity="regulated", stakes="CRITICAL")).name == "data_sensitivity")
    ok("dl composes for free (name=data_lineage)",
       normalize(dl.audit(lineage="broken", stakes="CRITICAL")).name == "data_lineage")

    # B: gated CRITICAL, receipt required, floors named
    ok("B tier is block+gate+receipt", disc_b.tier == "block+gate+receipt")
    ok("B gated", disc_b.gated is True)
    ok("B overall REFUSE", disc_b.overall_verdict == "REFUSE")
    ok("B receipt required", disc_b.receipt_required is True)
    ok("B gate names data_sensitivity", "data_sensitivity" in disc_b.text and "Gate:" in disc_b.text)

    # one system: SIL-composed CLA reading agrees with CLA's own gate verdict
    cla_reading = normalize(cla_b["receipt"])
    ok("CLA reading verdict == CLA gate verdict",
       cla_reading.verdict == str(cla_b["gate"].verdict))
    ok("CLA native block carries the audit + verdict",
       "CONTEXT LOAD AUDIT" in format_disclosure_block(cla_b["reading"], cla_b["band"], cla_b["gate"])
       and "Verdict:" in format_disclosure_block(cla_b["reading"], cla_b["band"], cla_b["gate"]))

    # behavioral weaker-tier marker
    ok("behavioral present + marked", disc_c.behavioral_present is True and "weaker tier" in disc_c.text)

    hr("SELF-CHECKS")
    p = sum(1 for _, c in checks if c)
    for label, c in checks:
        print(("  ok  " if c else "  XX  ") + label)
    print("\n[RRD-EXAMPLE] {}/{} checks passed".format(p, len(checks)))
    return p == len(checks)


if __name__ == "__main__":
    sys.exit(0 if run_checks() else 1)
