"""RRD — Runtime Reliability Disclosure renderer (composition layer). stdlib only.

NOT a gauge. This composes the receipts that gauges already produce into
the single tiered disclosure block described in SIL framework §4:

  LOW       -> none (unless explicitly asked)
  MEDIUM    -> one compact line
  HIGH      -> a Runtime Reliability Disclosure block
  CRITICAL  -> block + gate + receipt requirement

Design rule: it depends on NO gauge package. It consumes the *common
gauge contract* (a receipt dict/obj exposing state-or-band, stakes, and
a verdict) by duck typing, so any present or future SIL gauge composes
without the renderer importing it. Verdict vocabularies differ across
gauges (PROCEED/PROCEED_WITH_DISCLOSURE/VERIFY_FIRST/REFUSE_* for the
SIL gauges; PROCEED/PROCEED_WITH_DISCLOSURE/PAUSE_RECOMMEND_REFRESH/
REFUSE_REFRESH for CLA), so severity is ranked by prefix, not by an
enum, and the worst across the panel drives the overall verdict.

Numeric gauges outrank behavioral ones (framework §6.6): a reading
flagged evidence_tier="behavioral" is rendered with a weaker-tier
marker and never silently averaged in with measured instruments.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import json

__version__ = "0.1.0"

# -- ordering ---------------------------------------------------------------

_STAKES_RANK = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}
_RANK_STAKES = {v: k for k, v in _STAKES_RANK.items()}

# canonical overall verdict by severity
_SEVERITY_LABEL = {0: "PROCEED", 1: "PROCEED_WITH_DISCLOSURE",
                   2: "VERIFY_FIRST", 3: "REFUSE"}

# tier by overall stakes
_TIER = {"LOW": "none", "MEDIUM": "line", "HIGH": "block", "CRITICAL": "block+gate+receipt"}

# friendly gauge names by receipt schema prefix
_SCHEMA_NAME = {
    "cla": "context_load", "rc": "retrieval_coverage", "tda": "time_date",
    "sp": "source_provenance", "stakes": "stakes", "uncertainty": "uncertainty_source",
    "citation": "citation_sufficiency", "freshness": "knowledge_freshness",
    "memory": "memory_compaction", "tool": "tool_availability",
    "reversibility": "reversibility", "audit_status": "receipt_audit_status",
}


def stakes_rank(stakes):
    if stakes not in _STAKES_RANK:
        raise ValueError(f"rrd: unknown stakes {stakes!r}; expected LOW/MEDIUM/HIGH/CRITICAL.")
    return _STAKES_RANK[stakes]


def verdict_severity(verdict):
    """Severity by prefix — spans every gauge's verdict vocabulary.
    REFUSE_* -> 3 ; VERIFY_*/PAUSE_* -> 2 ; PROCEED_WITH_* -> 1 ; PROCEED -> 0.
    Unknown verdicts are treated as 2 (conservative: stop and check)."""
    if not verdict:
        return 2
    v = str(verdict).upper()
    if v.startswith("REFUSE"):
        return 3
    if v.startswith("VERIFY") or v.startswith("PAUSE"):
        return 2
    if v.startswith("PROCEED_WITH"):
        return 1
    if v == "PROCEED":
        return 0
    return 2


# -- normalized reading -----------------------------------------------------

@dataclass
class GaugeReading:
    name: str
    state: str
    stakes: str
    verdict: str
    reads_out: str = ""
    evidence_tier: str = "numeric"   # or "behavioral" (weaker)

    @property
    def severity(self):
        return verdict_severity(self.verdict)


def _get(receipt, key, default=None):
    if isinstance(receipt, dict):
        return receipt.get(key, default)
    return getattr(receipt, key, default)


def normalize(receipt, *, name=None, reads_out=None, evidence_tier="numeric"):
    """Map any gauge receipt (dict or object) onto a GaugeReading.

    Handles both the SIL-gauge shape (state/stakes/verdict) and the CLA
    shape (band + gate.verdict + reading.percent) without importing either.
    """
    d = receipt.to_dict() if hasattr(receipt, "to_dict") else receipt
    gate = _get(d, "gate") or {}
    if not isinstance(gate, dict):
        gate = {}
    state = _get(d, "state") or _get(d, "band") or "UNKNOWN"
    verdict = _get(d, "verdict") or gate.get("verdict") or ""
    stakes = _get(d, "stakes") or gate.get("stakes") or "LOW"

    if name is None:
        schema = _get(d, "schema", "") or ""
        prefix = schema.split(".")[0]
        name = _SCHEMA_NAME.get(prefix, prefix or "gauge")

    if reads_out is None:
        reading = _get(d, "reading") or {}
        if isinstance(reading, dict) and reading.get("percent") is not None:
            reads_out = "load: {}% ({})".format(reading.get("percent"), reading.get("provenance"))
        elif _get(d, "sources_total") is not None:
            reads_out = "coverage {}/{} sources".format(
                _get(d, "sources_searched"), _get(d, "sources_total"))
        elif _get(d, "coverage_ratio") is not None:
            reads_out = "coverage ratio {}".format(_get(d, "coverage_ratio"))
        else:
            reads_out = str(state).lower()

    return GaugeReading(name=name, state=str(state), stakes=str(stakes),
                        verdict=str(verdict), reads_out=reads_out,
                        evidence_tier=evidence_tier)


# -- composition ------------------------------------------------------------

@dataclass
class Disclosure:
    tier: str
    overall_stakes: str
    overall_verdict: str
    gated: bool
    verify_required: bool
    receipt_required: bool
    behavioral_present: bool
    readings: list = field(default_factory=list)
    text: str = ""

    def to_dict(self):
        return {
            "tier": self.tier, "overall_stakes": self.overall_stakes,
            "overall_verdict": self.overall_verdict, "gated": self.gated,
            "verify_required": self.verify_required,
            "receipt_required": self.receipt_required,
            "behavioral_present": self.behavioral_present,
            "readings": [r.__dict__ for r in self.readings], "text": self.text,
        }

    def to_json(self, **kw):
        return json.dumps(self.to_dict(), **kw)


def _worst(readings):
    return max(readings, key=lambda r: (r.severity, _STAKES_RANK.get(r.stakes, 0)))


def render(readings, *, stakes=None, asked=False):
    """Compose readings into the tiered Runtime Reliability Disclosure.

    `stakes` (optional) is the operator-declared task stakes; it sets the
    disclosure tier. If omitted, the tier follows the worst stakes any
    gauge was evaluated at. `asked=True` forces a disclosure even at LOW
    (the operator explicitly asked for the reliability state).
    """
    readings = list(readings)
    if stakes is not None and stakes not in _STAKES_RANK:
        raise ValueError(f"rrd.render: unknown stakes {stakes!r}.")

    if not readings:
        overall_stakes = stakes or "LOW"
        text = "Runtime reliability: no gauges reported." if asked else ""
        return Disclosure(tier=_TIER[overall_stakes], overall_stakes=overall_stakes,
                          overall_verdict="PROCEED", gated=False, verify_required=False,
                          receipt_required=False, behavioral_present=False,
                          readings=[], text=text)

    overall_stakes = stakes or _RANK_STAKES[max(_STAKES_RANK.get(r.stakes, 0) for r in readings)]
    severity = max(r.severity for r in readings)
    overall_verdict = _SEVERITY_LABEL[severity]
    gated = severity >= 3
    verify_required = severity >= 2
    tier = _TIER[overall_stakes]
    receipt_required = gated or tier == "block+gate+receipt"
    behavioral_present = any(r.evidence_tier == "behavioral" for r in readings)

    text = _render_text(readings, overall_stakes, overall_verdict, gated,
                        receipt_required, tier, asked)
    return Disclosure(tier=tier, overall_stakes=overall_stakes,
                      overall_verdict=overall_verdict, gated=gated,
                      verify_required=verify_required, receipt_required=receipt_required,
                      behavioral_present=behavioral_present, readings=readings, text=text)


def _line_for(r):
    tag = "  (weaker tier — behavioral)" if r.evidence_tier == "behavioral" else ""
    return "  {}: {} / {}{}".format(r.name, r.reads_out, r.state, tag)


def _render_text(readings, overall_stakes, overall_verdict, gated,
                 receipt_required, tier, asked):
    # LOW: silent unless asked; when asked, fall through to a compact line.
    if tier == "none" and not asked:
        return ""
    if tier == "none" or tier == "line":
        w = _worst(readings)
        return ("Runtime reliability: {} gauge(s) · worst: {} {} ({}) · {}".format(
            len(readings), w.name, w.state, w.verdict, overall_verdict))

    # HIGH / CRITICAL: full block
    lines = ["Runtime Reliability Disclosure"]
    for r in readings:
        lines.append(_line_for(r))
    lines.append("  Stakes:  {}".format(overall_stakes))
    lines.append("  Verdict: {}".format(overall_verdict))
    if gated:
        floors = [r for r in readings if r.severity >= 3]
        names = ", ".join("{} ({})".format(r.name, r.verdict) for r in floors)
        lines.append("  Gate:    BLOCKED by {} — resolve and re-enter as a new action.".format(names))
    if receipt_required:
        lines.append("  Receipt: REQUIRED (no log = no action).")
    return "\n".join(lines)


__all__ = ["GaugeReading", "Disclosure", "normalize", "render",
           "verdict_severity", "stakes_rank"]
