# RRD: Runtime Reliability Disclosure renderer — composition layer
## v0.1 — NOT a gauge
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Package:** `rrd` · **License:** open, attribution required.

## 1. Purpose
The gauges each emit a single-variable receipt. An operator does not want twelve separate receipts; they want one disclosure, scaled to the stakes, that says "here is the operating state, here is the verdict, here is what to do." This renderer is that connective tissue. It composes any set of gauge receipts into the tiered Runtime Reliability Disclosure of SIL framework §4. It adds no new measurement and **imports no gauge package** — it consumes the common gauge contract by duck typing, so any present or future gauge composes without a code change here.

## 2. Tiering by stakes (framework §4)
| Stakes | Output |
|---|---|
| LOW | none (unless the operator explicitly asks — `asked=True`) |
| MEDIUM | one compact line (worst gauge + overall verdict) |
| HIGH | a Runtime Reliability Disclosure block (every gauge listed) |
| CRITICAL | block **+ gate + receipt requirement** |

The tier follows the operator-declared task stakes when supplied, else the worst stakes any gauge was evaluated at. LOW is silent by default — the panel must never become a dashboard vomited on every reply.

## 3. Verdict aggregation
Verdict vocabularies differ across gauges (CLA: `…PAUSE_RECOMMEND_REFRESH/REFUSE_REFRESH`; SIL gauges: `…VERIFY_FIRST/REFUSE_*`). Severity is ranked by **prefix**, not by any single enum, so the renderer spans every gauge: `REFUSE* → 3`, `VERIFY*/PAUSE* → 2`, `PROCEED_WITH* → 1`, `PROCEED → 0`; unknown verdicts are treated as 2 (stop and check). The worst severity across the panel drives the overall verdict; **any single REFUSE gates the whole disclosure** and forces a receipt requirement. Numeric gauges outrank behavioral ones (framework §6.6): a reading flagged `evidence_tier="behavioral"` is rendered with a weaker-tier marker and never silently merged with measured instruments.

## 4. API
- `normalize(receipt, *, name=None, reads_out=None, evidence_tier="numeric") -> GaugeReading` — maps any gauge receipt (dict or object) onto a common reading; handles both the SIL-gauge shape (`state/stakes/verdict`) and the CLA shape (`band` + `gate.verdict` + `reading.percent`).
- `render(readings, *, stakes=None, asked=False) -> Disclosure` — returns `tier · overall_stakes · overall_verdict · gated · verify_required · receipt_required · behavioral_present · text` (`to_dict`/`to_json`).

## 5. Status
Built v0.1 — `rrd/`, **16/16 tests green** composing **real** receipts from CLA + Retrieval Coverage + Reversibility + Citation Sufficiency (severity spanning both verdict vocabularies, all four tiers, gating, behavioral marker, serialization), 2026-06-06. Deterministic composition only; depends on no gauge package; eval loop closed.
