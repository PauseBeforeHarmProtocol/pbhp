"""AUD-11 Receipt/Audit Status (SIL gauge #11). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    WRITTEN_CHAINED = "WRITTEN_CHAINED"
    WRITTEN_UNCHAINED = "WRITTEN_UNCHAINED"
    NONE = "NONE"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_NO_RECEIPT = "REFUSE_NO_RECEIPT"


POLICY_VERSION = "audit-status-default/0.1.0"
_MATRIX = {
    (State.WRITTEN_CHAINED, Stakes.LOW): Verdict.PROCEED,
    (State.WRITTEN_CHAINED, Stakes.MEDIUM): Verdict.PROCEED,
    (State.WRITTEN_CHAINED, Stakes.HIGH): Verdict.PROCEED,
    (State.WRITTEN_CHAINED, Stakes.CRITICAL): Verdict.PROCEED,
    (State.WRITTEN_UNCHAINED, Stakes.LOW): Verdict.PROCEED,
    (State.WRITTEN_UNCHAINED, Stakes.MEDIUM): Verdict.PROCEED,
    (State.WRITTEN_UNCHAINED, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.WRITTEN_UNCHAINED, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.NONE, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.CRITICAL): Verdict.REFUSE_NO_RECEIPT,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_NO_RECEIPT}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def chain_ok(receipts):
    """Verify a simple hash chain: each receipt's 'prev' == prior 'hash'; first 'prev' empty."""
    for i, r in enumerate(receipts):
        exp = "" if i == 0 else (receipts[i - 1].get("hash") or "")
        if (r.get("prev") or "") != exp:
            return False
    return True


def derive_state(receipt_written, chain_intact=False):
    if not receipt_written:
        return State.NONE
    return State.WRITTEN_CHAINED if chain_intact else State.WRITTEN_UNCHAINED


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class AUDReceipt:
    receipt_written: bool
    chain_ok: bool
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "audit_status.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"audit_status": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, receipt_written, stakes, chain_intact=False, override_ack=None, now=None):
    state = derive_state(receipt_written, chain_intact)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return AUDReceipt(receipt_written=receipt_written, chain_ok=chain_intact, state=state.value,
                      stakes=Stakes(stakes).value, verdict=verdict.value,
                      override=override, issued_at=_now_iso(now))


__all__ = ["audit", "AUDReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "chain_ok", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
