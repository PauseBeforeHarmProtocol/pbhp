import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from aud import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, chain_ok, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("WRITTEN_CHAINED","LOW"):"PROCEED",("WRITTEN_CHAINED","MEDIUM"):"PROCEED",("WRITTEN_CHAINED","HIGH"):"PROCEED",("WRITTEN_CHAINED","CRITICAL"):"PROCEED",
    ("WRITTEN_UNCHAINED","LOW"):"PROCEED",("WRITTEN_UNCHAINED","MEDIUM"):"PROCEED",("WRITTEN_UNCHAINED","HIGH"):"PROCEED_WITH_DISCLOSURE",("WRITTEN_UNCHAINED","CRITICAL"):"VERIFY_FIRST",
    ("NONE","LOW"):"PROCEED_WITH_DISCLOSURE",("NONE","MEDIUM"):"VERIFY_FIRST",("NONE","HIGH"):"VERIFY_FIRST",("NONE","CRITICAL"):"REFUSE_NO_RECEIPT",
}

def test_state_none(): assert derive_state(False) is State.NONE
def test_state_unchained(): assert derive_state(True, False) is State.WRITTEN_UNCHAINED
def test_state_chained(): assert derive_state(True, True) is State.WRITTEN_CHAINED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==12
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.NONE,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.NONE,Stakes.CRITICAL) is False
def test_chain_ok_valid():
    rs=[{"hash":"a","prev":""},{"hash":"b","prev":"a"},{"hash":"c","prev":"b"}]
    assert chain_ok(rs) is True
def test_chain_ok_empty(): assert chain_ok([]) is True
def test_chain_ok_tampered():
    rs=[{"hash":"a","prev":""},{"hash":"b","prev":"WRONG"}]
    assert chain_ok(rs) is False
def test_audit_none_critical():
    r=audit(receipt_written=False,stakes="CRITICAL")
    assert r.state=="NONE" and r.verdict=="REFUSE_NO_RECEIPT"
def test_override_ignored_on_floor():
    r=audit(receipt_written=False,stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(receipt_written=True,chain_intact=True,stakes="LOW")
    assert r.schema=="audit_status.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"audit_status"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[AUD] {p}/{p+q} passed"); sys.exit(1 if q else 0)
