# AUD-11: Receipt / Audit Status — Auditability Disclosure
## SIL gauge #11 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `audit_status.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
The meta-gauge. It confirms the others actually wrote receipts and that the receipt chain is intact. A panel whose receipts are missing or broken is not auditable, and at high stakes that is itself a defect.

## 2. State
`WRITTEN_CHAINED` (receipt written + hash chain intact) · `WRITTEN_UNCHAINED` (written, chain not verified) · `NONE` (no receipt).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| WRITTEN_CHAINED | PROCEED | PROCEED | PROCEED | PROCEED |
| WRITTEN_UNCHAINED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| NONE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_NO_RECEIPT |
Floor: NONE/CRITICAL → REFUSE_NO_RECEIPT (non-overridable).

## 4. Helper
`chain_ok(receipts)` verifies a simple hash chain (each receipt's `prev` equals the prior receipt's `hash`; first `prev` empty).

## 5. Receipt (`audit_status.receipt.v1`)
`receipt_written · chain_ok · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
