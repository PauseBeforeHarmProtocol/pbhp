# TDA-2: Time Keeper — Time/Date Awareness Audit
## Temporal-grounding disclosure for LLM systems — Specification v0.1

**Status:** Draft for review
**Date:** 2026-06-06
**Concept:** Phillip Linstrum (SIL gauge #2; named "Time Keeper")
**Class:** PBHP-SIL instrument #2 (see `04_synthesis/02_SIL_FRAMEWORK_v0.1.md`). CLA-1 is instrument #1; this gauge follows its template.
**Schema:** `tda.receipt.v1`
**License:** Open, attribution required, no single owner — same terms as PBHP.

---

## 1. Purpose

A language model has no clock. Unless the harness puts the current date/time into the context, the model answers time questions from its training prior — and states a stale guess with the same fluent confidence it uses for stable facts. "Who holds this office now," "is this guidance current," "is this person still alive," "what is today's deadline," "did this air yet" are all unsafe when the system silently assumes the date.

Time Keeper makes the system's temporal grounding an operator-facing disclosure: **measure the time anchor, tag its provenance, gate time-sensitive consequential output on it, and write a receipt before the output commits** — plus the reciprocal requirement that the operator re-anchor when asked. It is the clock gauge on the panel, not a theory of time.

## 2. Scope and honest claims

**Already exists, NOT claimed as new:** harnesses commonly inject a system timestamp into the prompt; some tools expose it. Token/clock injection is ordinary engineering.

**What Time Keeper contributes:**
1. **Provenance for the time anchor** — disclosing not just *a* date but *how the system knows it* (injected vs. derived vs. assumed vs. none), on every consequential, time-sensitive output.
2. **Staleness awareness** — an injected anchor can age out inside a long session; the gauge surfaces anchor age / re-anchor need rather than treating an old timestamp as live.
3. **Stakes-aware gating** — a deterministic matrix crossing time-awareness with stakes, including non-overridable refusal of time-critical output when the system is temporally blind.
4. **Auditability + reciprocity** — a receipt recording anchor, provenance, band, verdict, policy version, and any override; repeated overrides are a CAPA trigger.

**Scope boundary (anti-creep):** Time Keeper covers the *system clock* only. Whether a specific claim relies on stale knowledge is the sibling gauge **Knowledge Freshness** (SIL, not built). Time Keeper answers "does it know *when now is*"; Freshness answers "is *this fact* still true." When the anchor is sound, Time Keeper passes and hands time-sensitive claims to Freshness.

## 3. Definitions

**Time anchor.** The current date/time the system is operating against, with a value and an establishment point.

**Provenance** (evidence hierarchy, best first):
- `injected` — a trusted current timestamp supplied by the harness/runtime/environment.
- `derived` — inferred from in-context evidence carrying time (dated tool results, file mtimes, dated messages).
- `assumed` — the model's own guess from training prior. The spare tire: largest error, last resort.
- `unknown` — no basis at all.
Each tier is permitted only when every better tier is unavailable.

**Anchor age.** Elapsed time since the anchor was established. Knowable only when a re-injection lets the system compare; otherwise reported `indeterminate` (and that itself is disclosed, not hidden).

**Awareness band** (policy classification, §5): `KNOWN`, `AGING`, `ASSUMED`, `UNKNOWN`.

**Temporal sensitivity of the request.** `low` (answer does not depend on the current date — history, math, stable how-to) or `high` (answer depends on "now" — current officeholders, live prices, current law/guidance, deadlines, "latest," "today," recency). The gate only bites when this is `high`.

**Stakes.** LOW / MEDIUM / HIGH / CRITICAL — mapped from PBHP's GREEN→BLACK ladder when integrated (§8). When in doubt, round up.

**Re-anchor.** Obtaining a fresh trusted timestamp (or verifying the date via a tool). The Time Keeper analog of CLA's "refresh."

## 4. The failure mode

1. **Phantom present.** With no injected clock, models answer "who is the CEO / president / current standard" from training-cutoff priors, presented as current fact.
2. **Stale anchor in long sessions.** A timestamp injected at session start drifts; hours later the model still cites it as "now."
3. **Confident temporal blur.** The system gives no signal whether a date in its answer is grounded or guessed, so the operator cannot tell a live answer from a memory.

## 5. Provenance → awareness bands (defaults)

| Band | Condition | Meaning |
|---|---|---|
| `KNOWN` | `injected`, age within tolerance (default: same calendar day) | Clock is grounded and current. |
| `AGING` | `injected` but past tolerance, OR `derived` | Grounded but possibly stale; disclose age / re-anchor for time-critical work. |
| `ASSUMED` | `assumed` (training prior only) | Not grounded. Treat any date as a guess. |
| `UNKNOWN` | `unknown` | No temporal grounding at all. |

Tolerances are policy-configurable (`tda-default/0.1.0`). Default day-granularity for date questions; an optional time-critical profile tightens to hours.

## 6. The Stakes × Time-Awareness gate

Applies only when temporal sensitivity is `high`. Deterministic; the matrix is hashed (SHA-256) into every receipt.

| Awareness ↓ / Stakes → | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| `KNOWN` | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| `AGING` | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| `ASSUMED` | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNTIL_ANCHORED |
| `UNKNOWN` | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | REFUSE_UNTIL_ANCHORED | REFUSE_UNTIL_ANCHORED |

- **PROCEED_WITH_DISCLOSURE:** answer, but state the anchor + provenance ("working from an assumed date; not independently confirmed").
- **VERIFY_FIRST:** do not present as current until the date/fact is re-anchored or tool-verified.
- **REFUSE_UNTIL_ANCHORED:** withhold the time-critical output until a trusted anchor is obtained. Every REFUSE_UNTIL_ANCHORED cell is **non-overridable** (mirrors CLA's REFUSE floor); a logged operator override can only relax PROCEED_WITH_DISCLOSURE or VERIFY_FIRST. Low-temporal-sensitivity requests bypass the gate entirely (PROCEED).

**Floor design note (intentional multi-cell floor; F1, audited 2026-06-07).** Time Keeper locks three non-overridable cells — ASSUMED×CRITICAL, UNKNOWN×HIGH, UNKNOWN×CRITICAL — not a single corner. Deliberate and risk-based: producing a time-critical output while temporally blind (no trusted anchor) is the core failure mode, so it is refused at HIGH as well as CRITICAL. Recorded as a maintainer decision in `../AUDIT_FINDINGS_SIL_2026-06-07.md` (cf. Source Provenance #3, stricter on unlabeled blur for the same reason).

## 7. Receipt schema (`tda.receipt.v1`)

```
{
  "schema": "tda.receipt.v1",
  "anchor_value": "2026-06-06" | null,
  "provenance": "injected|derived|assumed|unknown",
  "established_at": "<iso8601>" | null,
  "anchor_age_seconds": <int> | "indeterminate",
  "awareness_band": "KNOWN|AGING|ASSUMED|UNKNOWN",
  "temporal_sensitivity": "low|high",
  "stakes": "LOW|MEDIUM|HIGH|CRITICAL",
  "verdict": "PROCEED|PROCEED_WITH_DISCLOSURE|VERIFY_FIRST|REFUSE_UNTIL_ANCHORED",
  "policy_version": "tda-default/0.1.0",
  "matrix_hash": "<sha256>",
  "override": { "applied": false, "ack": null },
  "issued_at": "<iso8601>"
}
```
Written before the output commits; append-only; embeddable in a signed PBHP receipt chain alongside `cla.receipt.v1`.

## 8. PBHP / Project Shadow integration (brief)

- **Door/Wall/Gap:** PROCEED→Door; REFUSE_UNTIL_ANCHORED→Wall; DISCLOSE/VERIFY→Gap (flow with the Maybe/Therefore recorded).
- **Stakes ← Harm ladder:** GREEN→LOW … BLACK→CRITICAL.
- **Sacred Refusal:** the non-overridable CRITICAL cells are a Sacred-Refusal instance (refuse, name why, give the re-anchor path).
- **Mirror Vow (reciprocal):** the operator does not pressure a time-critical answer past an UNKNOWN anchor without a logged acknowledgment; repeated overrides → CAPA.
- **Receipt embedding:** `tda` block sits beside `cla` in the PBHP receipt extension.
- *Vocabulary note (F4):* Door/Wall/Gap, Sacred Refusal, Mirror Vow are **PBHP-framework integration primitives**, not the project's mythic/Tribunal layer; the SIL gauge surface stays sterile.

## 9. Validation (eval loop stays closed — empirical only)

**§9.1 Differential disclosure experiment** (parallels CLA §13.1): run a fixed battery of time-sensitive prompts (current officeholder, "latest" X, is-this-current, deadline math) through (a) a baseline harness and (b) a Time-Keeper-instrumented harness with the clock withheld, then re-anchored. Measure: rate of confidently-stated stale dates caught/avoided, false-gate rate on low-sensitivity prompts. The instrumented run should refuse/he­dge exactly the blind time-critical cases the baseline answers wrongly.
**§9.2 Threshold calibration:** tune day vs. hour tolerance against false-gate rate.

## 10. Limitations

- Temporal-sensitivity classification is a heuristic; misclassifying a high-sensitivity request as low silently disables the gate. Default to `high` when unsure (round up).
- A `derived` anchor inherits the reliability of its evidence.
- Time Keeper grounds the clock; it does not make stale *knowledge* fresh — that is Knowledge Freshness's job.

## 11. Attribution

Concept: Phillip Linstrum (SIL gauge #2, "Time Keeper"). Template: CLA-1 (`../context_load_audit/`). License: open, attribution required, no single owner.

*Filed 2026-06-06. Reference implementation + tests: this folder (`tda/`, `tests/`).*
