"""TDA-2 Time Keeper test suite. Runs under pytest OR standalone:
    python3 tests/test_tda.py
"""
import os
import sys
import json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tda
from tda import audit, TDAReceipt
from tda.core import (Provenance, Band, Stakes, Sensitivity, Verdict,
                      derive_band, gate, is_overridable, matrix_hash,
                      DEFAULT_TOLERANCE_SECONDS, NON_OVERRIDABLE)

EXPECTED = {
    ("KNOWN", "LOW"): "PROCEED",
    ("KNOWN", "MEDIUM"): "PROCEED",
    ("KNOWN", "HIGH"): "PROCEED",
    ("KNOWN", "CRITICAL"): "PROCEED_WITH_DISCLOSURE",
    ("AGING", "LOW"): "PROCEED",
    ("AGING", "MEDIUM"): "PROCEED_WITH_DISCLOSURE",
    ("AGING", "HIGH"): "PROCEED_WITH_DISCLOSURE",
    ("AGING", "CRITICAL"): "VERIFY_FIRST",
    ("ASSUMED", "LOW"): "PROCEED_WITH_DISCLOSURE",
    ("ASSUMED", "MEDIUM"): "VERIFY_FIRST",
    ("ASSUMED", "HIGH"): "VERIFY_FIRST",
    ("ASSUMED", "CRITICAL"): "REFUSE_UNTIL_ANCHORED",
    ("UNKNOWN", "LOW"): "PROCEED_WITH_DISCLOSURE",
    ("UNKNOWN", "MEDIUM"): "VERIFY_FIRST",
    ("UNKNOWN", "HIGH"): "REFUSE_UNTIL_ANCHORED",
    ("UNKNOWN", "CRITICAL"): "REFUSE_UNTIL_ANCHORED",
}


def test_band_unknown():
    assert derive_band("unknown") is Band.UNKNOWN

def test_band_assumed():
    assert derive_band("assumed", 0) is Band.ASSUMED

def test_band_derived_is_aging():
    assert derive_band("derived", 0) is Band.AGING

def test_band_injected_fresh_is_known():
    assert derive_band("injected", 0) is Band.KNOWN
    assert derive_band("injected", DEFAULT_TOLERANCE_SECONDS) is Band.KNOWN

def test_band_injected_stale_is_aging():
    assert derive_band("injected", DEFAULT_TOLERANCE_SECONDS + 1) is Band.AGING

def test_band_injected_indeterminate_is_aging():
    assert derive_band("injected", None) is Band.AGING

def test_low_sensitivity_always_proceeds():
    for band in Band:
        for stakes in Stakes:
            assert gate(band, stakes, "low") is Verdict.PROCEED

def test_all_sixteen_cells_high_sensitivity():
    for (b, s), expected in EXPECTED.items():
        assert gate(b, s, "high").value == expected, (b, s, expected)

def test_matrix_covers_every_cell():
    assert len(EXPECTED) == 16
    for b in Band:
        for s in Stakes:
            assert (b.value, s.value) in EXPECTED

def test_non_overridable_floor_cells():
    expected_floor = {
        (Band.ASSUMED, Stakes.CRITICAL),
        (Band.UNKNOWN, Stakes.HIGH),
        (Band.UNKNOWN, Stakes.CRITICAL),
    }
    assert NON_OVERRIDABLE == expected_floor

def test_refuse_is_not_overridable():
    assert is_overridable(Band.UNKNOWN, Stakes.CRITICAL, "high") is False
    assert is_overridable(Band.ASSUMED, Stakes.CRITICAL, "high") is False
    assert is_overridable(Band.UNKNOWN, Stakes.HIGH, "high") is False

def test_disclose_and_verify_are_overridable():
    assert is_overridable(Band.AGING, Stakes.MEDIUM, "high") is True   # disclose
    assert is_overridable(Band.ASSUMED, Stakes.MEDIUM, "high") is True  # verify

def test_audit_known_low_proceeds():
    r = audit(provenance="injected", anchor_value="2026-06-06",
              anchor_age_seconds=0, stakes="LOW", temporal_sensitivity="low")
    assert r.awareness_band == "KNOWN"
    assert r.verdict == "PROCEED"
    assert r.anchor_value == "2026-06-06"

def test_audit_blind_critical_refuses():
    r = audit(provenance="unknown", stakes="CRITICAL", temporal_sensitivity="high")
    assert r.awareness_band == "UNKNOWN"
    assert r.verdict == "REFUSE_UNTIL_ANCHORED"
    assert r.anchor_age_seconds == "indeterminate"

def test_override_relaxes_verify():
    r = audit(provenance="assumed", stakes="MEDIUM", temporal_sensitivity="high",
              override_ack="op: accept stale-clock risk, logged")
    assert r.verdict == "VERIFY_FIRST"
    assert r.override["applied"] is True
    assert r.override["ack"].startswith("op:")

def test_override_ignored_on_floor():
    r = audit(provenance="unknown", stakes="CRITICAL", temporal_sensitivity="high",
              override_ack="op: please just answer")
    assert r.override["applied"] is False
    assert r.override.get("ignored_floor") is True

def test_receipt_schema_and_fields():
    r = audit(provenance="injected", anchor_age_seconds=0,
              stakes="HIGH", temporal_sensitivity="high")
    assert r.schema == "tda.receipt.v1"
    assert r.policy_version == "tda-default/0.1.0"
    assert len(r.matrix_hash) == 64

def test_receipt_json_roundtrip():
    r = audit(provenance="derived", stakes="HIGH", temporal_sensitivity="high")
    d = json.loads(r.to_json())
    assert d["schema"] == "tda.receipt.v1"
    assert d["awareness_band"] == "AGING"
    assert d == r.to_dict()

def test_to_pbhp_extension_shape():
    r = audit(provenance="injected", anchor_age_seconds=0,
              stakes="LOW", temporal_sensitivity="high")
    ext = r.to_pbhp_extension()
    assert set(ext) == {"tda"}
    assert ext["tda"]["schema"] == "tda.receipt.v1"

def test_matrix_hash_is_stable_and_hex():
    h1, h2 = matrix_hash(), matrix_hash()
    assert h1 == h2 and len(h1) == 64
    assert all(c in "0123456789abcdef" for c in h1)


if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items())
           if n.startswith("test_") and callable(f)]
    passed = failed = 0
    for n, f in fns:
        try:
            f(); passed += 1
        except AssertionError as e:
            failed += 1; print("FAIL", n, e)
        except Exception as e:
            failed += 1; print("ERROR", n, repr(e))
    print(f"\n{passed}/{passed + failed} passed")
    sys.exit(1 if failed else 0)
