"""TDA-2 Time Keeper — core logic.

Provenance -> awareness band, and a deterministic Stakes x Awareness gate.
Zero required dependencies (stdlib only). Mirrors the CLA-1 pattern.
"""
from __future__ import annotations
from enum import Enum
import hashlib


class Provenance(str, Enum):
    INJECTED = "injected"   # trusted current timestamp from harness/runtime
    DERIVED = "derived"     # inferred from dated in-context evidence
    ASSUMED = "assumed"     # model's training-prior guess (the spare tire)
    UNKNOWN = "unknown"     # no basis at all


class Band(str, Enum):
    KNOWN = "KNOWN"
    AGING = "AGING"
    ASSUMED = "ASSUMED"
    UNKNOWN = "UNKNOWN"


class Stakes(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Sensitivity(str, Enum):
    LOW = "low"
    HIGH = "high"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNTIL_ANCHORED = "REFUSE_UNTIL_ANCHORED"


POLICY_VERSION = "tda-default/0.1.0"
DEFAULT_TOLERANCE_SECONDS = 86400  # same-calendar-day granularity

# Stakes x Awareness matrix. Applies ONLY when temporal sensitivity is high.
_MATRIX = {
    (Band.KNOWN,   Stakes.LOW):      Verdict.PROCEED,
    (Band.KNOWN,   Stakes.MEDIUM):   Verdict.PROCEED,
    (Band.KNOWN,   Stakes.HIGH):     Verdict.PROCEED,
    (Band.KNOWN,   Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.AGING,   Stakes.LOW):      Verdict.PROCEED,
    (Band.AGING,   Stakes.MEDIUM):   Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.AGING,   Stakes.HIGH):     Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.AGING,   Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (Band.ASSUMED, Stakes.LOW):      Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.ASSUMED, Stakes.MEDIUM):   Verdict.VERIFY_FIRST,
    (Band.ASSUMED, Stakes.HIGH):     Verdict.VERIFY_FIRST,
    (Band.ASSUMED, Stakes.CRITICAL): Verdict.REFUSE_UNTIL_ANCHORED,
    (Band.UNKNOWN, Stakes.LOW):      Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.UNKNOWN, Stakes.MEDIUM):   Verdict.VERIFY_FIRST,
    (Band.UNKNOWN, Stakes.HIGH):     Verdict.REFUSE_UNTIL_ANCHORED,
    (Band.UNKNOWN, Stakes.CRITICAL): Verdict.REFUSE_UNTIL_ANCHORED,
}

# Every REFUSE cell is a non-overridable floor (mirrors CLA's REFUSE_REFRESH).
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNTIL_ANCHORED}


def matrix_hash() -> str:
    """Deterministic SHA-256 over the canonical matrix serialization."""
    items = sorted(f"{b.value}|{s.value}={v.value}" for (b, s), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_band(provenance, anchor_age_seconds=None,
                tolerance_seconds=DEFAULT_TOLERANCE_SECONDS) -> Band:
    p = Provenance(provenance)
    if p is Provenance.UNKNOWN:
        return Band.UNKNOWN
    if p is Provenance.ASSUMED:
        return Band.ASSUMED
    if p is Provenance.DERIVED:
        return Band.AGING
    # injected
    if anchor_age_seconds is None:
        return Band.AGING  # injected but freshness cannot be proven
    return Band.KNOWN if anchor_age_seconds <= tolerance_seconds else Band.AGING


def gate(band, stakes, sensitivity) -> Verdict:
    if Sensitivity(sensitivity) is Sensitivity.LOW:
        return Verdict.PROCEED  # non-time-sensitive requests bypass the gate
    return _MATRIX[(Band(band), Stakes(stakes))]


def is_overridable(band, stakes, sensitivity) -> bool:
    if Sensitivity(sensitivity) is Sensitivity.LOW:
        return True
    return (Band(band), Stakes(stakes)) not in NON_OVERRIDABLE
