"""TDA-2 Time Keeper — Time/Date Awareness Audit (SIL gauge #2).

Public API:
    audit(...) -> TDAReceipt   # the one-call entry point
"""
from __future__ import annotations
from datetime import datetime, timezone

from .core import (
    Provenance, Band, Stakes, Sensitivity, Verdict,
    POLICY_VERSION, DEFAULT_TOLERANCE_SECONDS,
    derive_band, gate, is_overridable, matrix_hash, NON_OVERRIDABLE,
)
from .receipt import TDAReceipt

__version__ = "0.1.0"


def _now_iso(now=None) -> str:
    if now is None:
        return datetime.now(timezone.utc).isoformat()
    if isinstance(now, str):
        return now
    return now.isoformat()


def audit(*, provenance, stakes, temporal_sensitivity,
          anchor_value=None, established_at=None, anchor_age_seconds=None,
          tolerance_seconds=DEFAULT_TOLERANCE_SECONDS,
          override_ack=None, now=None) -> TDAReceipt:
    """Evaluate temporal grounding and return a signed-ready receipt.

    Override can only relax PROCEED_WITH_DISCLOSURE / VERIFY_FIRST; REFUSE
    cells are a non-overridable floor and ignore the ack (recording it as
    ignored_floor).
    """
    band = derive_band(provenance, anchor_age_seconds, tolerance_seconds)
    verdict = gate(band, stakes, temporal_sensitivity)
    overridable = is_overridable(band, stakes, temporal_sensitivity)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable

    age = anchor_age_seconds if anchor_age_seconds is not None else "indeterminate"
    return TDAReceipt(
        anchor_value=anchor_value,
        provenance=Provenance(provenance).value,
        established_at=established_at,
        anchor_age_seconds=age,
        awareness_band=band.value,
        temporal_sensitivity=Sensitivity(temporal_sensitivity).value,
        stakes=Stakes(stakes).value,
        verdict=verdict.value,
        override=override,
        issued_at=_now_iso(now),
    )


__all__ = [
    "audit", "TDAReceipt",
    "Provenance", "Band", "Stakes", "Sensitivity", "Verdict",
    "derive_band", "gate", "is_overridable", "matrix_hash",
    "POLICY_VERSION", "DEFAULT_TOLERANCE_SECONDS", "NON_OVERRIDABLE",
]
