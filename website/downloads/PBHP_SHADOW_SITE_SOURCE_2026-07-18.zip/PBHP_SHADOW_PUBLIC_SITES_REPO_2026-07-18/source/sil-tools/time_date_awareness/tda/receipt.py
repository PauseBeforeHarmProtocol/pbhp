"""TDA-2 Time Keeper — receipt schema (tda.receipt.v1)."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import json
from .core import POLICY_VERSION, matrix_hash


@dataclass
class TDAReceipt:
    anchor_value: object            # e.g. "2026-06-06" or None
    provenance: str                 # injected|derived|assumed|unknown
    established_at: object           # iso8601 or None
    anchor_age_seconds: object       # int or "indeterminate"
    awareness_band: str             # KNOWN|AGING|ASSUMED|UNKNOWN
    temporal_sensitivity: str       # low|high
    stakes: str                     # LOW|MEDIUM|HIGH|CRITICAL
    verdict: str                    # PROCEED|...|REFUSE_UNTIL_ANCHORED
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "tda.receipt.v1"

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, **kw) -> str:
        return json.dumps(self.to_dict(), **kw)

    def to_pbhp_extension(self) -> dict:
        """Shape for embedding beside cla in a signed PBHP receipt."""
        return {"tda": self.to_dict()}
