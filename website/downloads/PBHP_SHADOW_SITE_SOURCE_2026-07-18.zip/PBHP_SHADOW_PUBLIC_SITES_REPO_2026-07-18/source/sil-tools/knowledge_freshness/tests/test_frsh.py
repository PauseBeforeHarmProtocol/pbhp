import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from frsh import (audit, KnowledgeClass, State, Stakes, Verdict, derive_state,
                  gate, is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("STABLE","LOW"):"PROCEED",("STABLE","MEDIUM"):"PROCEED",("STABLE","HIGH"):"PROCEED",("STABLE","CRITICAL"):"PROCEED",
    ("VERIFIED","LOW"):"PROCEED",("VERIFIED","MEDIUM"):"PROCEED",("VERIFIED","HIGH"):"PROCEED",("VERIFIED","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("MEMORY","LOW"):"PROCEED",("MEMORY","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("MEMORY","HIGH"):"VERIFY_FIRST",("MEMORY","CRITICAL"):"VERIFY_FIRST",
    ("STALE_RISK","LOW"):"PROCEED_WITH_DISCLOSURE",("STALE_RISK","MEDIUM"):"VERIFY_FIRST",("STALE_RISK","HIGH"):"VERIFY_FIRST",("STALE_RISK","CRITICAL"):"REFUSE_UNVERIFIED",
}

def test_class_to_state():
    assert derive_state("historical_stable") is State.STABLE
    assert derive_state("current_verified") is State.VERIFIED
    assert derive_state("model_memory") is State.MEMORY
    assert derive_state("requires_live") is State.STALE_RISK
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.STALE_RISK,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.STALE_RISK,Stakes.CRITICAL) is False
def test_audit_requires_live_critical():
    r=audit(knowledge_class="requires_live",stakes="CRITICAL")
    assert r.state=="STALE_RISK" and r.verdict=="REFUSE_UNVERIFIED"
def test_audit_stable_safe():
    assert audit(knowledge_class="historical_stable",stakes="CRITICAL").verdict=="PROCEED"
def test_override_ignored_on_floor():
    r=audit(knowledge_class="requires_live",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_override_relaxes():
    r=audit(knowledge_class="model_memory",stakes="HIGH",override_ack="op: logged")
    assert r.verdict=="VERIFY_FIRST" and r.override["applied"] is True
def test_receipt_schema_json_pbhp():
    r=audit(knowledge_class="model_memory",stakes="LOW")
    assert r.schema=="freshness.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"freshness"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[FRSH] {p}/{p+q} passed"); sys.exit(1 if q else 0)
