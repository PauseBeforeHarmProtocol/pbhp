# FRSH-7: Knowledge Freshness — Claim Currency Disclosure
## SIL gauge #7 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `freshness.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Whether the knowledge behind an answer is stable, confirmed-current, remembered-but-unverified, or known-to-need-live-checking. Sibling of Time Keeper (#2): TK grounds the clock, FRSH grades the claim's currency.

## 2. Knowledge class -> state
`historical_stable`→STABLE · `current_verified`→VERIFIED · `model_memory`→MEMORY · `requires_live`→STALE_RISK.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| STABLE | PROCEED | PROCEED | PROCEED | PROCEED |
| VERIFIED | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| MEMORY | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| STALE_RISK | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNVERIFIED |
Floor: STALE_RISK/CRITICAL → REFUSE_UNVERIFIED (non-overridable).

## 4. Receipt (`freshness.receipt.v1`)
`knowledge_class · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Boundary
Grades currency of the knowledge, not whether the system knows the date (Time Keeper #2) or whether claims are sourced (Citation #6).
