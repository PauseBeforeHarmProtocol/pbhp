"""FRSH-7 Knowledge Freshness (SIL gauge #7). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class KnowledgeClass(str, Enum):
    HISTORICAL_STABLE = "historical_stable"
    CURRENT_VERIFIED = "current_verified"
    MODEL_MEMORY = "model_memory"
    REQUIRES_LIVE = "requires_live"


class State(str, Enum):
    STABLE = "STABLE"; VERIFIED = "VERIFIED"; MEMORY = "MEMORY"; STALE_RISK = "STALE_RISK"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNVERIFIED = "REFUSE_UNVERIFIED"


POLICY_VERSION = "freshness-default/0.1.0"
_CLASS_STATE = {
    KnowledgeClass.HISTORICAL_STABLE: State.STABLE,
    KnowledgeClass.CURRENT_VERIFIED: State.VERIFIED,
    KnowledgeClass.MODEL_MEMORY: State.MEMORY,
    KnowledgeClass.REQUIRES_LIVE: State.STALE_RISK,
}
_MATRIX = {
    (State.STABLE,    Stakes.LOW): Verdict.PROCEED, (State.STABLE, Stakes.MEDIUM): Verdict.PROCEED,
    (State.STABLE,    Stakes.HIGH): Verdict.PROCEED, (State.STABLE, Stakes.CRITICAL): Verdict.PROCEED,
    (State.VERIFIED,  Stakes.LOW): Verdict.PROCEED, (State.VERIFIED, Stakes.MEDIUM): Verdict.PROCEED,
    (State.VERIFIED,  Stakes.HIGH): Verdict.PROCEED,
    (State.VERIFIED,  Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MEMORY,    Stakes.LOW): Verdict.PROCEED,
    (State.MEMORY,    Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MEMORY,    Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.MEMORY,    Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.STALE_RISK, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.STALE_RISK, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.STALE_RISK, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.STALE_RISK, Stakes.CRITICAL): Verdict.REFUSE_UNVERIFIED,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNVERIFIED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(knowledge_class):
    return _CLASS_STATE[KnowledgeClass(knowledge_class)]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class FRSHReceipt:
    knowledge_class: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "freshness.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"freshness": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, knowledge_class, stakes, override_ack=None, now=None):
    state = derive_state(knowledge_class)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return FRSHReceipt(knowledge_class=KnowledgeClass(knowledge_class).value, state=state.value,
                       stakes=Stakes(stakes).value, verdict=verdict.value,
                       override=override, issued_at=_now_iso(now))


__all__ = ["audit", "FRSHReceipt", "KnowledgeClass", "State", "Stakes", "Verdict",
           "derive_state", "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
