# DRIFT-23: Drift / Session-Coherence — Behavioral Coherence Disclosure
## SIL gauge #23 — v0.1 · **BEHAVIORAL / WEAKER EVIDENCE TIER**
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `drift_coherence.receipt.v1` · **License:** open, attribution required.

## 0. Evidence tier (read first)
This is a **behavioral, heuristic** gauge — a *labeled judgment, NOT a measurement*, the same status as CLA-SR (self-report, the "spare tire"). Every receipt carries `evidence_tier="behavioral"`. Numeric (measured) gauges outrank it (framework §6.6): it has **no non-overridable REFUSE floor** and caps at `VERIFY_FIRST`. It raises disclosure and recommends re-grounding; it never unilaterally hard-blocks.

## 1. Purpose
Surface whether the session itself has drifted from its anchors — contradicting earlier established state, losing the task thread, persona / instruction slippage — over the course of the session, so a long or dense session does not silently degrade the output a consequential decision rests on.

## 2. State (= assessed session-coherence level)
`coherent` / `minor_drift` / `significant_drift` / `incoherent` (ascending drift), plus `unassessed`.
- coherent — on-task, consistent with established context / anchors.
- minor_drift — small recoverable deviations; noted.
- significant_drift — noticeable loss of thread or contradiction with earlier session state.
- incoherent — thread lost / anchors contradicted / task or persona breakdown.
- unassessed — drift not assessed (no basis to judge). Escalates to verification at higher stakes.

## 3. Gate (Stakes x State), SHA-256-hashed. **Caps at VERIFY_FIRST — no hard floor.**
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| COHERENT | PROCEED | PROCEED | PROCEED | PROCEED |
| MINOR_DRIFT | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE |
| SIGNIFICANT_DRIFT | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| INCOHERENT | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |
| UNASSESSED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |

No non-overridable floor (behavioral, §6.6): the strongest verdict is VERIFY_FIRST — "re-ground the session from artifacts before relying on this at high stakes." Override relaxes DISCLOSE / VERIFY cells. The measured gauges (CLA load, etc.) are what impose the hard refusals.

## 4. Scoped claim
Distinct from Contradiction State (#20) and Context Load (CLA). Contradiction State assesses whether the *inputs* conflict and whether reconciled — about the content / sources; Drift is about the *session's own coherence over time* — the agent's trajectory, not the inputs. Context Load is window fill; coherence can degrade independent of raw load (and CLA already instruments load). Because the signal is heuristic, it is labeled the weaker tier and never hard-blocks.

## 5. Receipt (`drift_coherence.receipt.v1`)
`drift · assessed · basis · state · stakes · verdict · evidence_tier · policy_version · matrix_hash · override · issued_at · schema`.
