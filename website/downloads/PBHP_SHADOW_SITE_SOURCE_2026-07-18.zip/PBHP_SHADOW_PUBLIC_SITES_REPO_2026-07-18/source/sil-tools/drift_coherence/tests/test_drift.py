import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from drift import (audit, State, Stakes, Verdict, derive_state, gate,
                   is_overridable, matrix_hash, NON_OVERRIDABLE, EVIDENCE_TIER)

EXPECTED = {
    ("COHERENT","LOW"):"PROCEED",("COHERENT","MEDIUM"):"PROCEED",("COHERENT","HIGH"):"PROCEED",("COHERENT","CRITICAL"):"PROCEED",
    ("MINOR_DRIFT","LOW"):"PROCEED",("MINOR_DRIFT","MEDIUM"):"PROCEED",("MINOR_DRIFT","HIGH"):"PROCEED_WITH_DISCLOSURE",("MINOR_DRIFT","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("SIGNIFICANT_DRIFT","LOW"):"PROCEED",("SIGNIFICANT_DRIFT","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("SIGNIFICANT_DRIFT","HIGH"):"VERIFY_FIRST",("SIGNIFICANT_DRIFT","CRITICAL"):"VERIFY_FIRST",
    ("INCOHERENT","LOW"):"PROCEED_WITH_DISCLOSURE",("INCOHERENT","MEDIUM"):"VERIFY_FIRST",("INCOHERENT","HIGH"):"VERIFY_FIRST",("INCOHERENT","CRITICAL"):"VERIFY_FIRST",
    ("UNASSESSED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNASSESSED","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("UNASSESSED","HIGH"):"VERIFY_FIRST",("UNASSESSED","CRITICAL"):"VERIFY_FIRST",
}

# --- state derivation -------------------------------------------------------
def test_input_to_state():
    assert derive_state("coherent") is State.COHERENT and derive_state("incoherent") is State.INCOHERENT
def test_unassessed_flag():
    assert derive_state("incoherent", assessed=False) is State.UNASSESSED
def test_drift_none_is_unassessed():
    assert derive_state(None) is State.UNASSESSED
def test_unassessed_direct():
    assert derive_state("unassessed") is State.UNASSESSED

# --- full matrix ------------------------------------------------------------
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED

# --- behavioral discipline: no hard floor, caps at VERIFY -------------------
def test_no_nonoverridable_floor():
    assert NON_OVERRIDABLE==set()
def test_never_refuses():
    allowed={"PROCEED","PROCEED_WITH_DISCLOSURE","VERIFY_FIRST"}
    for (st,sk) in EXPECTED: assert gate(st,sk).value in allowed
def test_incoherent_critical_caps_at_verify():
    assert gate("INCOHERENT","CRITICAL").value=="VERIFY_FIRST"
def test_everything_overridable():
    assert is_overridable(State.INCOHERENT,Stakes.CRITICAL) is True

# --- weaker-tier marker -----------------------------------------------------
def test_receipt_is_behavioral():
    r=audit(drift="incoherent",stakes="CRITICAL")
    assert r.evidence_tier=="behavioral" and EVIDENCE_TIER=="behavioral"
    assert r.to_dict()["evidence_tier"]=="behavioral"

# --- audit end-to-end -------------------------------------------------------
def test_audit_coherent_safe():
    assert audit(drift="coherent",stakes="CRITICAL").verdict=="PROCEED"
def test_audit_incoherent_critical_verifies():
    r=audit(drift="incoherent",stakes="CRITICAL")
    assert r.state=="INCOHERENT" and r.verdict=="VERIFY_FIRST"
def test_audit_significant_high_verifies():
    r=audit(drift="significant_drift",stakes="HIGH")
    assert r.state=="SIGNIFICANT_DRIFT" and r.verdict=="VERIFY_FIRST"
def test_audit_unassessed_high_verifies():
    r=audit(stakes="HIGH",assessed=False)
    assert r.state=="UNASSESSED" and r.verdict=="VERIFY_FIRST" and r.assessed is False
def test_audit_records_basis():
    r=audit(drift="minor_drift",stakes="LOW",basis="re-asked an answered question once")
    assert r.basis=="re-asked an answered question once"

# --- override ---------------------------------------------------------------
def test_override_relaxes_verify():
    r=audit(drift="incoherent",stakes="HIGH",override_ack="op:owns-the-reground")
    assert r.verdict=="VERIFY_FIRST" and r.override["applied"] is True and r.override["ack"]=="op:owns-the-reground"
def test_override_noop_on_proceed():
    r=audit(drift="coherent",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False

# --- receipt ----------------------------------------------------------------
def test_receipt_schema_json_pbhp():
    r=audit(drift="minor_drift",stakes="LOW")
    assert r.schema=="drift_coherence.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"drift_coherence"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[DRIFT] {p}/{p+q} passed"); sys.exit(1 if q else 0)
