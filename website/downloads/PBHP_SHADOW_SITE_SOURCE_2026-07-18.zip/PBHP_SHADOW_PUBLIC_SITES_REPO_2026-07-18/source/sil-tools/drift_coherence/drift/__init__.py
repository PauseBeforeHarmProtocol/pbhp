"""DRIFT-23 Drift / Session-Coherence (SIL gauge #23, BEHAVIORAL). stdlib only.

WEAKER EVIDENCE TIER. A heuristic self-assessment of whether the session has
drifted from its anchors -- contradicting earlier established state, losing the
task thread, persona / instruction slippage -- over the course of the session.
Like CLA-SR (the self-report "spare tire"), it is a *labeled judgment, NOT a
measurement*. Every receipt carries evidence_tier="behavioral".

Because it is behavioral, it does NOT carry a non-overridable REFUSE floor: the
numeric (measured) gauges outrank the behavioral ones (framework §6.6), so the
strongest verdict this gauge can reach is VERIFY_FIRST -- "re-ground the session
before relying on this at high stakes." It raises disclosure and recommends a
refresh; it never unilaterally hard-blocks. That is reserved for the measured
instruments. (Contrast: Stakes Classification is also floor-free, as a feeder.)

Scoped claim (what it adds that the neighbours do not):
  * Contradiction State (#20) assesses whether the *inputs* conflict and whether
    reconciled -- about the content / sources. Drift is about the *session's own
    coherence over time*: the agent's trajectory, not the inputs.
  * Context Load (CLA) is window fill; coherence can degrade independent of raw
    load (and CLA already instruments load).

The four assessed levels run by ascending drift / ascending risk
(COHERENT < MINOR_DRIFT < SIGNIFICANT_DRIFT < INCOHERENT). The fifth state,
UNASSESSED, is "drift not assessed" -- like RC's UNKNOWN it escalates to
verification at higher stakes.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    COHERENT = "COHERENT"; MINOR_DRIFT = "MINOR_DRIFT"
    SIGNIFICANT_DRIFT = "SIGNIFICANT_DRIFT"; INCOHERENT = "INCOHERENT"
    UNASSESSED = "UNASSESSED"


_INPUT = {"coherent": State.COHERENT, "minor_drift": State.MINOR_DRIFT,
          "significant_drift": State.SIGNIFICANT_DRIFT,
          "incoherent": State.INCOHERENT, "unassessed": State.UNASSESSED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    # No REFUSE: a behavioral gauge caps at VERIFY_FIRST (numeric outrank
    # behavioral, framework §6.6).
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"


EVIDENCE_TIER = "behavioral"
POLICY_VERSION = "drift-coherence-default/0.1.0"
_P, _D, _V = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
_MATRIX = {
    (State.COHERENT, Stakes.LOW): _P, (State.COHERENT, Stakes.MEDIUM): _P,
    (State.COHERENT, Stakes.HIGH): _P, (State.COHERENT, Stakes.CRITICAL): _P,
    (State.MINOR_DRIFT, Stakes.LOW): _P, (State.MINOR_DRIFT, Stakes.MEDIUM): _P,
    (State.MINOR_DRIFT, Stakes.HIGH): _D, (State.MINOR_DRIFT, Stakes.CRITICAL): _D,
    (State.SIGNIFICANT_DRIFT, Stakes.LOW): _P, (State.SIGNIFICANT_DRIFT, Stakes.MEDIUM): _D,
    (State.SIGNIFICANT_DRIFT, Stakes.HIGH): _V, (State.SIGNIFICANT_DRIFT, Stakes.CRITICAL): _V,
    (State.INCOHERENT, Stakes.LOW): _D, (State.INCOHERENT, Stakes.MEDIUM): _V,
    (State.INCOHERENT, Stakes.HIGH): _V, (State.INCOHERENT, Stakes.CRITICAL): _V,
    (State.UNASSESSED, Stakes.LOW): _D, (State.UNASSESSED, Stakes.MEDIUM): _D,
    (State.UNASSESSED, Stakes.HIGH): _V, (State.UNASSESSED, Stakes.CRITICAL): _V,
}
# Behavioral gauge: NO non-overridable floor by design (§6.6).
NON_OVERRIDABLE = set()


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(drift=None, assessed=True):
    """Map a declared drift level to a State. If drift was not assessed
    (assessed=False or drift is None) -> UNASSESSED."""
    if not assessed or drift is None:
        return State.UNASSESSED
    return _INPUT[drift]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class DriftReceipt:
    drift: object
    assessed: bool
    basis: object
    state: str
    stakes: str
    verdict: str
    evidence_tier: str = EVIDENCE_TIER
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "drift_coherence.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"drift_coherence": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, stakes, drift=None, assessed=True, basis=None, override_ack=None, now=None):
    state = derive_state(drift, assessed)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return DriftReceipt(
        drift=drift, assessed=assessed, basis=basis, state=state.value,
        stakes=Stakes(stakes).value, verdict=verdict.value,
        override=override, issued_at=_now_iso(now))


__all__ = ["audit", "DriftReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "EVIDENCE_TIER",
           "POLICY_VERSION", "NON_OVERRIDABLE"]
