# SIL Gauge Index — build & test status (audit board)
**Date:** 2026-06-06 · **updated 2026-07-13** (R-2026-07-13-01: panel reopened by maintainer call, re-closed at **28**) · **Maintainer:** Phillip Linstrum · **Umbrella spec:** `../04_synthesis/02_SIL_FRAMEWORK_v0.1.md`

Per-gauge status for the PBHP-SIL panel. Every gauge is a standalone, zero-dependency reference package.

| # | Gauge | Folder | Pkg | Schema | Tests | Non-overridable floor | Status |
|---|-------|--------|-----|--------|-------|-----------------------|--------|
| 1 | Context Load (CLA) | context_load_audit/ | cla | cla.receipt.v1 | 75/75* | CRITICAL×CRITICAL → REFUSE_REFRESH (absolute for measured/estimated; self-report overridable, §6.6) | shipped v0.2 |
| 2 | Time Keeper (Time/Date Awareness) | time_date_awareness/ | tda | tda.receipt.v1 | 20/20 | ASSUMED×CRIT, UNKNOWN×HIGH/CRIT → REFUSE_UNTIL_ANCHORED | built v0.1 |
| 3 | Source Provenance | source_provenance/ | sp | sp.receipt.v1 | 18/18 | SPECULATIVE×CRIT, BLURRED×HIGH/CRIT → REFUSE_UNLABELED | built v0.1 |
| 4 | Stakes Classification | stakes_classification/ | stk | stakes.receipt.v1 | 10/10 | (classifier — feeds the others; no gate floor) | built v0.1 |
| 5 | Uncertainty Source | uncertainty_source/ | unc | uncertainty.receipt.v1 | 15/15 | HIGH×CRIT → REFUSE_PENDING_INPUT | built v0.1 |
| 6 | Citation Sufficiency | citation_sufficiency/ | cit | citation.receipt.v1 | 13/13 | UNSUPPORTED×CRIT → REFUSE_UNSOURCED | built v0.1 |
| 7 | Knowledge Freshness | knowledge_freshness/ | frsh | freshness.receipt.v1 | 10/10 | STALE_RISK×CRIT → REFUSE_UNVERIFIED | built v0.1 |
| 8 | Memory/Compaction State | memory_compaction/ | mem | memory.receipt.v1 | 9/9 | LOSS_RISK×CRIT → REFUSE_RECOVER_CONTEXT | built v0.1 |
| 9 | Tool Availability/Result | tool_availability/ | tool | tool.receipt.v1 | 13/13 | UNVERIFIED×CRIT → REFUSE_NO_TOOL | built v0.1 |
| 10 | Reversibility | reversibility/ | rev | reversibility.receipt.v1 | 9/9 | IRREVERSIBLE×CRIT → REFUSE_PENDING_CONFIRMATION | built v0.1 |
| 11 | Receipt/Audit Status | receipt_audit_status/ | aud | audit_status.receipt.v1 | 13/13 | NONE×CRIT → REFUSE_NO_RECEIPT | built v0.1 |
| 12 | Retrieval Coverage | retrieval_coverage/ | rc | rc.receipt.v1 | 29/29 | NONE×CRIT → REFUSE_LOW_COVERAGE | built v0.1 |
| 13 | Data Sensitivity | data_sensitivity/ | ds | data_sensitivity.receipt.v1 | 10/10 | REGULATED×CRIT → REFUSE_UNTIL_AUTHORIZED | built v0.1 |
| 14 | Validation Status | validation_status/ | val | validation_status.receipt.v1 | 10/10 | UNCHECKED×CRIT → REFUSE_UNVALIDATED | built v0.1 |
| 15 | Completeness | completeness/ | comp | completeness.receipt.v1 | 10/10 | BLOCKED×CRIT → REFUSE_INCOMPLETE | built v0.1 |
| 16 | Operator Reliance | operator_reliance/ | rel | operator_reliance.receipt.v1 | 10/10 | DECISION_SUPPORT×CRIT → REFUSE_PENDING_HUMAN_OWNERSHIP | built v0.1 |
| 17 | Prompt-Injection Risk | prompt_injection_risk/ | pir | prompt_injection_risk.receipt.v1 | 10/10 | ACTIVE×CRIT → REFUSE_UNTIL_RESOLVED | built v0.1 |
| 18 | Data Lineage | data_lineage/ | dl | data_lineage.receipt.v1 | 10/10 | BROKEN×CRIT → REFUSE_UNTRACEABLE | built v0.1 |
| 19 | Inference Distance | inference_distance/ | idist | inference_distance.receipt.v1 | 11/11 | L5_SPECULATION×CRIT → REFUSE_UNGROUNDED | built v0.1 |
| 20 | Contradiction State | contradiction_state/ | contra | contradiction_state.receipt.v1 | 11/11 | UNRESOLVED×CRIT → REFUSE_UNRECONCILED | built v0.1 |
| 21 | Authority Layer | authority_layer/ | auth | authority_layer.receipt.v1 | 18/18 | THIRD_PARTY×CRIT → REFUSE_UNAUTHORIZED | built v0.1 |
| 22 | Model Mode/Sampling | model_mode/ | mode | model_mode.receipt.v1 | 25/25 | HIGH_VARIANCE×CRIT → REFUSE_NONREPRODUCIBLE | built v0.1 |
| 23 | Drift/Session-Coherence | drift_coherence/ | drift | drift_coherence.receipt.v1 | 19/19 | (behavioral — weaker tier; no floor, caps at VERIFY) | built v0.1 |
| 24 | Focal Context Routing ("Racing Line") | focal_context_routing/ | fcr | focal_context_routing.receipt.v1 | 36/36 | **CONSTRAINT_PIN** — a declared pin / unresolved dependency may not be suppressed (non-overridable; structural tier, §6.6-exempt like reversibility/data_sensitivity) | accepted v0.1 (R-2026-07-13-01) |
| 25 | Context Drag | context_drag/ | drag | context_drag.receipt.v1 | 16/16 | (behavioral — weaker tier; no floor, caps at VERIFY) | accepted v0.1 (R-2026-07-13-01) |
| 26 | Stale-Premise Intrusion | stale_premise_intrusion/ | stale | stale_premise.receipt.v1 | 21/21 | (behavioral — no floor, caps at VERIFY; typed re-entry of an invalidated premise — crosswalked vs #20/#23) | accepted v0.1 (R-2026-07-13-01) |
| 27 | Mirror Boundary | mirror_boundary/ | mirror | mirror_boundary.receipt.v1 | 19/19 | (behavioral — no floor, caps at VERIFY; receipt carries the full refuse posture + `route_to_human`; doctrine §8 hard-route = open maintainer question) | accepted v0.1 (R-2026-07-13-01) |
| 28 | Anti-Projection (APL) | anti_projection/ | apl | anti_projection.receipt.v1 | 23/23 | (behavioral — no floor, caps at VERIFY; only ADDS attribution-caution, never licenses one) | accepted v0.1 (R-2026-07-13-01) |

**Core-10: COMPLETE** (gauges 1, 3–11). Extended panel: Time Keeper (2), Retrieval Coverage (12), Data Sensitivity (13), Validation Status (14), Completeness (15), Operator Reliance (16), Prompt-Injection Risk (17), Data Lineage (18), Inference Distance (19), Contradiction State (20), Authority Layer (21), Model Mode/Sampling (22), Drift/Session-Coherence (23, behavioral) built; **PANEL COMPLETE — 22 numeric + 1 behavioral; queue empty.**
**Reopened 2026-07-13 by maintainer call and re-closed at 28** (R-2026-07-13-01): Focal Context Routing (24, the one structural-floored newcomer) · Context Drag (25) · Stale-Premise Intrusion (26) · Mirror Boundary (27, promoted from `shadow/mirror.py`) · Anti-Projection (28, promoted from `shadow/apl.py`) — **28 gauges: 22 numeric + 1 structural + 5 behavioral.**
**Panel total (re-swept 2026-06-06; CLA bumped 74→75 at v0.2.0, R-2026-06-12-11):** 23 gauges + composition layer — **394 tests green, all exit 0** = 22 script-style gauges 303 + CLA 75 (pytest 9.0.3) + RRD renderer 16. CLA §13.1 + §13.2 experiments executed (`context_load_audit/experiments/`). Receipts: R-2026-06-06-03 (§13.1) · -04 (Retrieval Coverage #12) · -05 (RRD renderer) · -06 (DS #13) · -07 (VAL #14) · -08 (COMP #15) · -09 (REL #16) · -10 (PIR #17) · -11 (Data Lineage #18) · -12 (renderer worked example) · -13 (§13.2 calibration) · -14 (Inference Distance #19) · -15 (Contradiction State #20) · -16 (Authority Layer #21) · -17 (Model Mode #22) · -18 (Drift #23).
*Core-10 + Time Keeper (gauges 1–11) were built the prior 2026-06-06 session (R-02, 130 tests); Retrieval Coverage (#12) + the renderer were added this session.
**Panel total (re-swept 2026-07-13, fresh process — R-2026-07-13-01):** 28 gauges + composition layer — **519 tests green, all exit 0** = 27 script-style gauges 418 + CLA 85 (pytest; 84 passed + 1 environment-conditional skip) + RRD renderer 16. **Outside the panel count** (normative/eval harnesses, tested but not gauges): SCS 24 · PMAS 27 · **FMA 20** (`functional_motivation_audit/`, accepted R-2026-07-13-01; tracks the still-DRAFT #16 doctrine) · **BF 49** (`evals/behavioral_falsifier/`, built R-2026-07-13-04 — the three-arm steering-claim experiment; instrument tests only, NOT accepted, NOT yet run). Independent fidelity for the promotions: APL full 576/576 signal space + Mirror 20,000 seeded grids cross-checked vs `Run Project Shadow/shadow/` — zero drift, incl. `escalation()`. RRD composes the newcomers via the common contract (behavioral tier already rendered per §6.6); a refreshed worked example is a queued follow-on.

## Common contract (every gauge)
Enums for states + a deterministic **Stakes × State matrix** (SHA-256-hashed into every receipt) + a derive function + a receipt dataclass (`to_dict` / `to_json` / `to_pbhp_extension`) + a one-call `audit()` entry. Operator override can only relax DISCLOSE / VERIFY; **REFUSE cells are non-overridable floors** (record `ignored_floor`). Stakes axis maps to PBHP GREEN→BLACK. Zero required dependencies.

*Floor policy (audited 2026-06-07):* most gauges lock a single worst-corner REFUSE cell. **Time/Date #2 and Source Provenance #3 intentionally lock multiple cells** (stricter on temporal blindness / unlabeled blur — rationale in their specs and `AUDIT_FINDINGS_SIL_2026-06-07.md` F1). **Stakes #4** (classifier) and **Drift #23** (behavioral, weaker tier) carry no floor by design.

Run any suite: `python3 <folder>/tests/test_*.py`  ·  Sweep all: loop the `tests/` files.

## How to continue (one gauge per version — the discipline holds)
Copy any built gauge as the template (e.g. `reversibility/` is the smallest clean one). For each new gauge: define its states, fill the Stakes × State matrix, set the REFUSE floor, write the receipt schema, write the test suite (states + every matrix cell + floor + override + receipt round-trip), run green, add a row above. Then log a CHANGELOG receipt.

## Extended panel — QUEUE — EMPTY (panel complete)
*(All 23 gauges built. The last, Drift/Session-Coherence #23, is the behavioral tier — labeled the weaker evidence tier per §6.6, no hard floor.)*
*(Reopened and re-closed 2026-07-13: #24–#28 arrived through the candidate register (#13–#16 + companions), not this queue — accepted R-2026-07-13-01. Queue remains empty. Open panel follow-ons: the Apex→#23 `turns_since_reanchor` extension proposal (`apex_drift/APEX_FOLD_INTO_DRIFT23.md`, unratified) · Mirror doctrine §8 hard-route question · RRD worked-example refresh.)*
*(Built and removed from queue, 2026-06-06: Retrieval Coverage #12 · Data Sensitivity #13 · Validation Status #14 · Completeness #15 · Operator Reliance #16 · Prompt-Injection Risk #17 · Data Lineage #18 · Inference Distance #19 · Contradiction State #20 · Authority Layer #21 · Model Mode/Sampling #22 · Drift/Session-Coherence #23.)*

## Composition layer (not a gauge)
`rrd_renderer/` (pkg `rrd`) — the Runtime Reliability Disclosure renderer: composes any set of gauge receipts into the tiered disclosure (LOW none / MEDIUM one-line / HIGH block / CRITICAL block+gate+receipt) per SIL framework §4. Connective tissue over the built gauges; consumes the common receipt contract, depends on no gauge package.
**Worked example:** `rrd_renderer/examples/panel_disclosure_example.py` — composes REAL receipts across CLA + Retrieval Coverage, Citation, Validation Status (#14), Data Sensitivity (#13), and Data Lineage (#18) into the HIGH tier (ungated, driven to VERIFY_FIRST by Data Lineage PARTIAL) and the CRITICAL tier (gated REFUSE + receipt; three floors fire), then renders the same CLA reading through CLA's own MIN line / CORE-ULTRA block, plus a behavioral Drift reading (§6.6). Proves the post-renderer gauges compose with zero renderer changes. **15/15 self-checks, exit 0** — an example, not part of the panel test count.
