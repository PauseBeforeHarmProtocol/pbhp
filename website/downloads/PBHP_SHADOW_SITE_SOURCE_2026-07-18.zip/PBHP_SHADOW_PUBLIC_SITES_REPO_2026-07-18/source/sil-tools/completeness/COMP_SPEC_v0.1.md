# COMP-15: Completeness — Finished-State Disclosure
## SIL gauge #15 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `completeness.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on whether the deliverable is actually finished. A partial or blocked result handed over as if complete is a quiet, high-consequence failure — especially at high stakes.

## 2. State (= finished-ness)
`complete` / `partial` / `needs_input` / `blocked`.
- complete — fully addresses the task.
- partial — addresses some; known gaps remain.
- needs_input — cannot finish without more from the operator.
- blocked — cannot proceed (tool / permission / dependency failure).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| COMPLETE | PROCEED | PROCEED | PROCEED | PROCEED |
| PARTIAL | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| NEEDS_INPUT | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |
| BLOCKED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_INCOMPLETE |

Floor: BLOCKED/CRITICAL → REFUSE_INCOMPLETE (non-overridable; a blocked critical task must not be passed off as done). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Retrieval Coverage (input-corpus sweep) and Citation Sufficiency (claim backing): Completeness is whether the output finishes the task. High coverage and full citations on a deliverable that still has open sections is exactly the gap this catches.

## 5. Receipt (`completeness.receipt.v1`)
`completeness · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
