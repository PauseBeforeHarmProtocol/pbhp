"""COMP-15 Completeness (SIL gauge #15). stdlib only.

Gates on whether the work actually answers the task or is partial, blocked, or
waiting on input. Scoped claim: distinct from Retrieval Coverage (how much of
the input corpus was swept) and Citation Sufficiency (whether claims are
backed) -- Completeness is *whether the deliverable is finished*. A partial or
blocked result presented as final is the failure mode this instruments.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    COMPLETE = "COMPLETE"; PARTIAL = "PARTIAL"
    NEEDS_INPUT = "NEEDS_INPUT"; BLOCKED = "BLOCKED"


_INPUT = {"complete": State.COMPLETE, "partial": State.PARTIAL,
          "needs_input": State.NEEDS_INPUT, "blocked": State.BLOCKED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_INCOMPLETE = "REFUSE_INCOMPLETE"


POLICY_VERSION = "completeness-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_INCOMPLETE)
_MATRIX = {
    (State.COMPLETE, Stakes.LOW): _P, (State.COMPLETE, Stakes.MEDIUM): _P,
    (State.COMPLETE, Stakes.HIGH): _P, (State.COMPLETE, Stakes.CRITICAL): _P,
    (State.PARTIAL, Stakes.LOW): _P, (State.PARTIAL, Stakes.MEDIUM): _D,
    (State.PARTIAL, Stakes.HIGH): _V, (State.PARTIAL, Stakes.CRITICAL): _V,
    (State.NEEDS_INPUT, Stakes.LOW): _D, (State.NEEDS_INPUT, Stakes.MEDIUM): _V,
    (State.NEEDS_INPUT, Stakes.HIGH): _V, (State.NEEDS_INPUT, Stakes.CRITICAL): _V,
    (State.BLOCKED, Stakes.LOW): _D, (State.BLOCKED, Stakes.MEDIUM): _V,
    (State.BLOCKED, Stakes.HIGH): _V, (State.BLOCKED, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_INCOMPLETE}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(completeness):
    return _INPUT[completeness]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class CompReceipt:
    completeness: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "completeness.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"completeness": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, completeness, stakes, override_ack=None, now=None):
    state = derive_state(completeness)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return CompReceipt(completeness=completeness, state=state.value, stakes=Stakes(stakes).value,
                       verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "CompReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
