import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from comp import (audit, State, Stakes, Verdict, derive_state, gate,
                  is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("COMPLETE","LOW"):"PROCEED",("COMPLETE","MEDIUM"):"PROCEED",("COMPLETE","HIGH"):"PROCEED",("COMPLETE","CRITICAL"):"PROCEED",
    ("PARTIAL","LOW"):"PROCEED",("PARTIAL","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","HIGH"):"VERIFY_FIRST",("PARTIAL","CRITICAL"):"VERIFY_FIRST",
    ("NEEDS_INPUT","LOW"):"PROCEED_WITH_DISCLOSURE",("NEEDS_INPUT","MEDIUM"):"VERIFY_FIRST",("NEEDS_INPUT","HIGH"):"VERIFY_FIRST",("NEEDS_INPUT","CRITICAL"):"VERIFY_FIRST",
    ("BLOCKED","LOW"):"PROCEED_WITH_DISCLOSURE",("BLOCKED","MEDIUM"):"VERIFY_FIRST",("BLOCKED","HIGH"):"VERIFY_FIRST",("BLOCKED","CRITICAL"):"REFUSE_INCOMPLETE",
}

def test_input_to_state():
    assert derive_state("complete") is State.COMPLETE and derive_state("blocked") is State.BLOCKED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.BLOCKED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.BLOCKED,Stakes.CRITICAL) is False
def test_audit_blocked_critical():
    r=audit(completeness="blocked",stakes="CRITICAL")
    assert r.state=="BLOCKED" and r.verdict=="REFUSE_INCOMPLETE"
def test_audit_complete_safe(): assert audit(completeness="complete",stakes="CRITICAL").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(completeness="partial",stakes="HIGH",override_ack="op:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(completeness="blocked",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(completeness="partial",stakes="LOW")
    assert r.schema=="completeness.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"completeness"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[COMP] {p}/{p+q} passed"); sys.exit(1 if q else 0)
