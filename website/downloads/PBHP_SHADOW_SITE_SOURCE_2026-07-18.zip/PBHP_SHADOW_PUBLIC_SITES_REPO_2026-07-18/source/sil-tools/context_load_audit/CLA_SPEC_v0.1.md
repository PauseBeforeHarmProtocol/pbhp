# CLA-1: Context Load Audit

## Cognitive Load Disclosure for LLM Systems — Specification v0.1

**Status:** Draft for review
**Date:** 2026-06-05 (v0.2 semantics amendment 2026-06-12)
**Concept:** Phillip Linstrum (proposed 2026-06-02)
**Schema:** `cla.receipt.v1`
**Reference implementation:** `cla/` (Python, zero required dependencies — `cryptography` optional for standalone signing only, 75/75 tests passing)

> **v0.2 amendment (2026-06-12, R-2026-06-12-11; audit findings N1/N11).** Two gate semantics changed; the verdict matrix and band thresholds did not. **(1) Provenance-aware floor (N1):** the CRITICAL×CRITICAL absolute (non-overridable) floor now applies only to MEASURED/ESTIMATED readings. A SELF_REPORTED (CLA-SR) reading carries no non-overridable floor, satisfying SIL framework §6.6 (the heuristic tier must never hard-block what the instruments gate). See CLA-R5/R7 below. **(2) Record-don't-rewrite override (N11):** `apply_override` no longer mutates `verdict`; it records the acknowledgment plus an `effective_verdict`, matching the common SIL gauge contract. A floor attempt is recorded (`applied=false, ignored_floor=true`), not raised. `GATE_POLICY_VERSION` → `0.2.0`; `gate_matrix_hash` is unchanged (matrix identical), so the 2026-06-07 tamper-evidence baseline still holds.
**License:** Open, attribution required, no single owner — same terms as PBHP

---

## 1. Purpose

Every serious machine has gauges. Every serious process has limits. Every serious operator needs to know whether the system is still operating inside the envelope it was qualified for.

Large language model output quality degrades as the context window fills. This is documented, measurable, and reproducible (§4). The provider's infrastructure knows the context utilization exactly — it is metered for billing. The person relying on the output is told nothing. No gauge, no warning, no quality-state indicator. The operator is flying blind on a variable that materially affects every output, while the counterparty holding the measurement stays silent.

CLA-1 closes that gap. It is the requirement that an AI system **measure context-window load at the harness level, disclose it to the operator with its provenance, gate high-stakes output behind load thresholds, and write an audit receipt before the output commits** — plus the reciprocal requirement that the operator take the warnings seriously.

It is a quality-systems control, not a theory of cognition. The closest analogies are line clearance, calibration status, and equipment-qualification envelopes in regulated manufacturing: before consequential work, confirm the equipment is in a qualified state, and record that you confirmed it.

## 2. Scope and Honest Claims

What already exists, and is **not** claimed as new here:

- **The degradation research.** Long-context performance loss is an established literature (§4). CLA consumes it; it did not discover it.
- **Raw context meters.** Some developer tools already display context utilization (Claude Code's context indicator and `/context` breakdown; various IDE extensions). Token counts are available in most provider APIs.

What CLA-1 contributes:

1. **Treating context load as a safety-disclosure requirement** rather than a developer convenience — load, provenance, and a quality-state band disclosed to the operator at every consequential output, on every surface, for every class of user, not just engineers who know to look.
2. **Stakes-aware gating.** A deterministic matrix crossing load band with the stakes of the output, including mandatory refusal of high-stakes output at critical load with a defined refresh-and-re-enter path.
3. **Auditability.** A receipt schema recording load, band, verdict, policy version, and any operator override — written before the action commits, append-only, embeddable in a signed PBHP receipt chain.
4. **Reciprocity.** A documented operator obligation: a warning pressured through without a logged acknowledgment is a control that has been disabled, and repeated overrides are a CAPA trigger.

Based on a public prior-art review as of 2026-06-05 (Appendix C), no AI safety or governance framework known to the authors — Constitutional AI, NIST AI RMF, ISO/IEC 42001, the EU AI Act's Article 15 implementing guidance, OMB M-24-10 — addresses context-window load as an operator-facing disclosure and gating requirement. They address training, deployment governance, drift, and robustness in general terms; none names this specific, measurable, billable-but-undisclosed variable as a control point.

## 3. Definitions

**Context load.** Tokens currently occupying the model's context window divided by the window's maximum, expressed as a fraction or percentage. May exceed 100% where a harness overruns into compaction; the overrun is preserved, not clamped.

**Provenance.** The evidentiary status of the load number: `measured` (exact counts from the provider API or harness), `estimated` (tokenizer or character heuristic, with a declared error margin — a real tokenizer carries 10%, the chars/4 heuristic 30%), `self-reported` (the model's own estimate under the CLA-SR fallback, §8.1 — last resort, largest error margin), or `unknown` (no measurement available). Evidence hierarchy: measured > estimated > self-reported > unknown. Each tier is permitted only when every better tier is unavailable.

**Load band.** A policy-defined classification of load: NOMINAL, ELEVATED, DEGRADED, CRITICAL, or UNKNOWN (§7).

**Stakes.** The consequence class of the requested output: LOW, MEDIUM, HIGH, CRITICAL — mapped from PBHP's GREEN→BLACK harm-threshold ladder when integrated (§12.2). Working anchors for standalone use: LOW = the actor's own recoverable rework (typo fixes, format conversion); MEDIUM = internally relied-upon but recoverable (drafts, analysis for discussion); HIGH = relied upon by third parties or hard to reverse (published content, customer-facing output, code shipped to others); CRITICAL = safety-, legal-, or compliance-relevant, or practically irreversible (regulatory submissions, medical/legal guidance, public statements of record). When in doubt, round stakes up — same rule as load.

**Harness.** The software layer that calls the model: the application, agent framework, or wrapper. CLA lives here — outside the model.

**Refresh.** Ending the loaded session and re-entering the task in a fresh context, typically via a summary handoff. Under CLA the re-entered task is a new action with a new receipt. **Handoff caution (cascading-degradation trap):** a handoff summary produced inside a DEGRADED or CRITICAL session is itself output of a degraded session and can carry the very omissions and confabulations the refresh exists to escape. Where possible the handoff SHOULD be assembled from programmatic extraction (receipts, logged artifacts, verbatim quotes) rather than free recall, and any model-generated handoff from a DEGRADED+ session MUST be labeled as compiled under degraded conditions, so the fresh session inherits the caution along with the content.

## 4. The Failure Mode

Three findings from the long-context literature define the problem:

1. **Position sensitivity.** Liu et al., "Lost in the Middle: How Language Models Use Long Contexts" (TACL 12:157–173, 2024; arXiv:2307.03172), showed that model performance on retrieval and QA tasks degrades significantly when relevant information sits in the middle of a long context, with a characteristic U-shaped attention profile. Performance can fall below the same model's closed-book baseline.

2. **Advertised versus effective context.** NVIDIA's RULER benchmark (arXiv:2404.06654) found that despite near-perfect scores on simple needle-in-a-haystack tests, nearly all evaluated models showed large performance drops as context grew, with only about half maintaining satisfactory performance at 32K tokens despite claiming windows of 32K or more. NoLiMa (arXiv:2502.05167), which removes literal keyword overlap so the model must reason rather than pattern-match, found 10 of 12 evaluated models dropped to half or less of their short-context baseline by 32K tokens.

3. **Degradation well below the limit, worsened by distractors.** Chroma's 2025 context-rot evaluation of 18 frontier models found every model degraded as input length grew, that degradation appears far below the advertised window limit, and that semantically similar but irrelevant content actively misleads models beyond what length alone explains.

The operational consequence: an operator eight hours into a heavy session is receiving measurably less reliable output than they received in hour one, from an interface that looks identical, with no indication that anything has changed. The provider's infrastructure holds the one variable that predicts this — and does not surface it. That asymmetry is the harm vector. It is structurally the same defect as selling a measuring instrument with no calibration status: the failure is not that drift exists, it is that the drift is known to one party and invisible to the party bearing the risk.

A second-order effect compounds it: degraded sessions produce degraded artifacts (specs, decisions, code, analyses) that are then trusted downstream precisely because nothing marked them as produced under degraded conditions. CLA's receipt exists to mark them.

## 5. Design Principles

**P1 — Harness-first; self-report only as a labeled last-resort fallback.** A model's introspective report of its own context state is generated text, subject to the same failure modes as any generated text, including confabulation — and confabulation risk rises with the very load being assessed. Token counts are deterministic facts available to the harness. CLA disclosures are computed outside the model, from measured or estimated counts. A model MAY narrate its load state to the user, but only by reading the harness's measurement back; its self-assessment never substitutes for one. The sole exception is the CLA-SR fallback mode (§8.1): on surfaces where no harness measurement or estimation exists at all, a labeled, basis-backed model self-report is admitted as the weakest evidence tier rather than leaving the operator with nothing — and the label never comes off.

**P2 — Deterministic and versioned.** Same reading, same policy, same stakes → same band, same verdict, every time. Thresholds are policy objects with identifiers and versions, carried in every receipt, so an auditor can reconstruct exactly which rules were in force. No judgment calls in the gate.

**P3 — Fail-honest.** If load cannot be measured or estimated, the system discloses UNKNOWN. It never fabricates a number. An unmeasurable load is treated as grounds for caution at high stakes, not as permission.

**P4 — Round up under doubt.** Estimated readings are inflated by the estimator's declared error margin before classification. Boundary cases classify into the higher band.

**P5 — Receipt before action.** The audit record is written before the output commits. If the record cannot be written, the action does not happen (WAL-fail-DENY).

**P6 — Reciprocal.** The system must warn; the operator must not pressure through warnings silently. Overrides exist (false positives are real, and a control that cannot be overridden will be uninstalled), but they are named, logged, and pattern-monitored.

**P7 — Some brake is better than no brake.** Where the ideal control is unavailable, CLA degrades gracefully rather than absenting itself: measured beats estimated, estimated beats self-reported, self-reported beats silence. Every step down the evidence ladder buys its admission with a larger conservative margin and a louder label.

## 6. Normative Requirements

The key words MUST, MUST NOT, SHOULD, and MAY are used per RFC 2119.

- **CLA-R1 (Measurement).** Context load MUST be computed at the harness level from provider-reported or harness-counted tokens wherever a harness exists. Model self-report MUST NOT substitute for measurement or estimation where either is available; the sole, labeled exception is the CLA-SR fallback (CLA-R11).
- **CLA-R2 (Provenance).** Every disclosed load value MUST carry its provenance: measured, estimated, self-reported, or unknown.
- **CLA-R3 (Disclosure).** Load, band, and verdict MUST be disclosed to the operator before any output of MEDIUM stakes or above, and on every band transition regardless of stakes.
- **CLA-R4 (Determinism).** Band thresholds, evidence margins, and the stakes-gate matrix MUST be deterministic, documented, and versioned. Receipts MUST record the threshold-policy identifier and version, the gate-policy identifier and version, and a content hash of the verdict matrix in force, so any historical verdict is reconstructable from the receipt alone.
- **CLA-R5 (Default refusal).** REFUSE_REFRESH is a default refusal verdict: the system MUST decline to produce the requested output and MUST offer the refresh-and-re-enter path. The refusal stands unless a logged CLA-R7 override exists in a cell where override is permitted; in the CRITICAL-band/CRITICAL-stakes cell it is absolute **for measured or estimated readings**. (A self-reported reading is the weakest evidence tier and carries no absolute floor — see CLA-R7 and §6.6 of the SIL framework: a heuristic guess must never non-overridably hard-block.) The re-entered task is a new action with a new receipt.
- **CLA-R6 (Receipt).** Every audit MUST emit a receipt conforming to `cla.receipt.v1` (or embed equivalent fields in a host framework's receipt) before the gated action commits. Write failure MUST be treated as refusal to act.
- **CLA-R7 (Override).** PAUSE and REFUSE verdicts MAY be overridden only by an explicit operator acknowledgment naming the operator and accepting degraded-output risk, recorded in the receipt. The CRITICAL-band/CRITICAL-stakes cell MUST NOT be overridable **when the reading is measured or estimated** (the absolute floor). **When the reading is self-reported (CLA-SR), that cell IS overridable** with the logged acknowledgment ritual: CLA-SR is the weakest evidence tier and per SIL framework §6.6 carries no non-overridable floor, and the §8.1 1.5× inflation already makes an SR-driven CRITICAL conservative — letting a *guess* hard-block absolutely would be the refusal-engine failure §8.1 forbids. **Override semantics are record-don't-rewrite** (the common SIL gauge contract): an override MUST NOT mutate the recorded verdict; it records the acknowledgment and an `effective_verdict` alongside the original. An override attempted against the absolute floor is *recorded* (`applied=false, ignored_floor=true`), not raised, and the effective verdict stays REFUSE_REFRESH — the floor holds and the attempt is auditable (a rising ignored-floor count is a CLA-R9 CAPA signal).
- **CLA-R8 (Fail-honest).** When load is unmeasurable the system MUST disclose UNKNOWN and MUST NOT display a fabricated or stale value.
- **CLA-R9 (CAPA).** Sustained DEGRADED-band operation and rising override rates SHOULD trigger corrective-action review. Root cause is named as an incentive structure, not a person.
- **CLA-R10 (Reciprocity).** Deploying organizations MUST document the operator's obligation to take load warnings seriously, and SHOULD treat silent pressure-through as a process nonconformity.
- **CLA-R11 (Self-report fallback).** On surfaces where neither measurement nor estimation is possible, a model self-report MAY serve as the load source (CLA-SR mode, §8.1), subject to all of: (a) provenance disclosed as self-reported, value rendered as approximate (tilde), never as a measurement; (b) a non-empty basis naming the observable signals behind the estimate — no basis, no number; (c) classification only after the self-report safety-factor inflation (default 0.50, provisional); (d) disclosure at the 25% / 50% / 65% milestones and every 5 points thereafter; (e) replacement by a real measurement the moment one becomes available. Self-report MUST NOT be used where a measured or estimated path exists; the reference `audit()` entry point rejects the combination outright.

### 6.1 Enforcement locus

Not every requirement can be enforced by a library, and pretending otherwise would be the kind of claim this spec exists to prevent. Each requirement's enforcement locus:

| Requirement | Library-enforced | Harness-enforced | Organization-enforced |
|---|---|---|---|
| R1 measurement-first | precedence rejection in `audit()` | must wire real counts | — |
| R2 provenance | yes (every reading/disclosure/receipt) | — | — |
| R3 disclosure timing | `SessionAuditState` computes when due | must actually display it | — |
| R4 determinism/versioning | yes (policy objects, matrix hash in receipts) | — | must version policy changes |
| R5 default refusal | verdict computed | must honor the verdict | — |
| R6 receipt-before-action | write API raises on failure | must call it before commit | — |
| R7 override logging | yes (non-empty ack, locked cell) | — | non-boilerplate ack review |
| R8 fail-honest | yes (UNKNOWN path) | — | — |
| R9 CAPA | `override_rate`, `degraded_band_rate` helpers | — | the actual CAPA process |
| R10 reciprocity | — | — | yes (documented operator obligation) |
| R11 self-report rules | basis required, inflation, precedence | milestone display | — |

## 7. Load Bands and Default Thresholds

Bands are policy, not physics. The literature shows degradation onset varies by model, task, and context composition — so defaults are conservative, and organizations SHOULD calibrate against their own task suite (§13.2) and MUST version any change.

| Band | Default range | Meaning |
|---|---|---|
| NOMINAL | 0% – <50% | Routine operation |
| ELEVATED | 50% – <75% | Disclose on consequential output |
| DEGRADED | 75% – <90% | Recommend refresh before high-stakes output |
| CRITICAL | ≥90% | Refuse high-stakes output; refresh required |
| UNKNOWN | no measurement | Its own band — surfaced, never hidden |

Default policy identifier: `cla-default/0.1.0`. Lower-quality evidence rounds up before classification (P4), using margins that are themselves versioned policy fields recorded in every receipt: `estimate_margin` (default 0.30, the character heuristic's documented error band) and `self_report_margin` (default 0.50 — a provisional conservative safety factor, not a validated constant: classification happens at the upper bound of the estimate plus 50% relative uncertainty, pending §13.2 calibration). The verdict matrix is versioned separately (`cla-gate-default/0.1.0` plus a content hash; §8). Tokenizer-tier margins are valid only when the tokenizer matches the target model: in multi-model routing where the backend is ambiguous, fall back to the character-heuristic margin or disclose UNKNOWN — a mismatched tokenizer is not better evidence, only more confident error.

The 50% line for ELEVATED is deliberately early: RULER and NoLiMa both locate substantial degradation at fractions of the advertised window, and Chroma's results show distractor-dependent degradation with no safe universal floor. A band that only alarms at 85% would lag the phenomenon it exists to disclose.

## 8. The Stakes × Load Gate

Stakes vocabulary: LOW, MEDIUM, HIGH, CRITICAL (PBHP mapping in §12.2).

| Band \ Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| **NOMINAL** | PROCEED | PROCEED | PROCEED+D | PROCEED+D |
| **ELEVATED** | PROCEED | PROCEED+D | PROCEED+D | PAUSE |
| **DEGRADED** | PROCEED+D | PAUSE | PAUSE | **REFUSE** |
| **CRITICAL** | PROCEED+D | PAUSE | **REFUSE** | **REFUSE** (no override) |
| **UNKNOWN** | PROCEED+D | PROCEED+D | PAUSE | PAUSE |

PROCEED+D = PROCEED_WITH_DISCLOSURE. PAUSE = PAUSE_RECOMMEND_REFRESH. REFUSE = REFUSE_REFRESH.

Notes:

- A 91%-full context is acceptable for fixing a typo and unacceptable for finalizing a regulatory submission. Low-stakes work at high load proceeds with disclosure; the matrix only bites where consequence and degradation risk intersect.
- UNKNOWN at high stakes pauses rather than proceeds: the absence of a gauge is itself disqualifying for qualified work, exactly as an uncalibrated instrument is disqualifying for a release test.
- Override applies to PAUSE and REFUSE verdicts only — PROCEED verdicts have nothing to override — and every such cell except the locked CRITICAL/CRITICAL cell is overridable under CLA-R7. REFUSE_REFRESH is thus a *default* refusal: binding unless a logged override exists, absolute at CRITICAL/CRITICAL. The override is the False-Positive Release Valve of this primitive: the relief path exists, it is receipted, and its usage rate is monitored (§10).
- The matrix is versioned policy in its own right: `cla-gate-default/0.1.0`, with a SHA-256 content hash recorded in every receipt (CLA-R4), so a verdict issued under any historical matrix remains reconstructable.

## 8.1 Self-Report Fallback Mode (CLA-SR)

Some surfaces have no harness at all — a consumer chat window, a bare playground. No API usage counts, no character stream to estimate from outside. On those surfaces the choice is not between a good gauge and a bad gauge; it is between a bad gauge and no gauge. CLA-SR is the bad gauge, installed deliberately, labeled honestly. Some brake is better than no brake.

**How it works.** The model itself maintains a rough load estimate from observable signals — number and length of exchanges, volume of pasted or attached material, symptoms of thread loss — and discloses it under the CLA-R11 rules: tilde-marked approximate value, a stated basis, the 1.5× conservative inflation before band classification, and the milestone cadence below. The paste-ready installation block is `SELF_REPORT_PROTOCOL.md`; the supporting logic (milestone schedule, crossing detection) is `cla/selfreport.py`.

**Milestone cadence.** Disclosures are due the first time the estimate crosses **25% → 50% → 65% → 70% → 75% → 80% → 85% → 90% → 95% → 100%** — sparse early so a fresh session is not nagged, dense in the range where the literature puts real degradation. A disclosure is also due, regardless of milestones, whenever consequential output is requested.

**Brake semantics.** The model applies the §8 gate to its own inflated estimate: DEGRADED at consequential stakes → recommend refresh with a summary handoff, once, without nagging; CRITICAL at high stakes → decline in-session and provide the handoff instead. Handoffs written at these bands carry the §3 degraded-conditions label — the summary is the best available bridge, not trusted output. Because there is no harness to enforce anything, the override ritual is conversational: the user explicitly accepts degraded-output risk, and the model stamps "OVERRIDE acknowledged by user" into the disclosure line so the override is visible in the record.

**Honesty boundaries.** CLA-SR is a soft control and says so. A model's self-estimate is roughly directional at best — that is why it carries the toolkit's largest safety factor (default provisional value 1.5×: classification at the upper bound of the estimate plus 50% relative uncertainty; unvalidated, configurable via `ThresholdPolicy.self_report_margin`, calibration required per §13.2) and why CLA-R11(e) retires it the moment a real meter exists. The known recursion is named rather than hidden: compliance with the protocol may itself degrade with the very load the protocol monitors (§15, limitation 7). CLA-SR also MUST NOT become a refusal engine — a false refusal is a defect too, and the gate matrix's stakes dimension exists precisely so low-stakes work continues at any load.

## 9. Receipt Schema (`cla.receipt.v1`)

Canonical JSON, lex-sorted keys, UTF-8, no whitespace — the same canonicalization rule as `pbhp.receipt.v1` §7. Fields:

| Field | Type | Content |
|---|---|---|
| `schema` | string | `"cla.receipt.v1"` |
| `id` | string | `cla:<actor_id>:<timestamp>:<nonce>` |
| `model_id` | string/null | Model identifier — bands are model-dependent (RULER); a load number without a model name is incomplete evidence |
| `session_id` | string/null | Groups receipts from one session for trend analysis |
| `cla_version` | string | Implementation version |
| `actor_id` | string | The auditing harness/actor |
| `timestamp` | string | ISO-8601 UTC |
| `reading` | object | `used_tokens`, `max_tokens`, `fraction`, `percent`, `provenance`, `source`, `timestamp`, `basis` (CLA-SR) |
| `band` | string | NOMINAL / ELEVATED / DEGRADED / CRITICAL / UNKNOWN |
| `stakes` | string | LOW / MEDIUM / HIGH / CRITICAL |
| `gate` | object | `verdict` (the gate reading, never mutated), `effective_verdict` (what the operator may act on), `reason`, `overridable`, `provenance`, `override` (`{applied:false, ack:null}` by default; on a successful override `{applied:true, operator_id, acknowledgment, effective_verdict}`; on a refused floor attempt `{applied:false, ignored_floor:true, operator_id, acknowledgment}`) |
| `policy` | object | `policy_id`, `policy_version`, band bounds, evidence margins, `gate_policy_id`, `gate_policy_version`, `gate_matrix_hash` |
| `disclosure_text` | string | The exact disclosure shown to the operator |
| `prev` | string/null | SHA-256 of prior CLA receipt (optional standalone chain) |
| `notes` | string/null | Free text |

Standalone receipts are unsigned and append-only (JSONL). When embedded in PBHP the record rides inside the signed envelope and inherits PBHP's signature and hash chain (§12.3).

## 10. Operator Responsibilities

Disclosure without reciprocity is theater. The operator-side obligations:

1. **Read the gauge.** Before relying on consequential output, check the disclosure line that came with it.
2. **Honor the pause.** A PAUSE verdict is a recommendation to refresh, not an obstacle to click through. If proceeding anyway, log the override with a real acknowledgment — "deadline; accepting risk; will verify by hand" is honest; silence is not.
3. **Plan refreshes like changeovers.** High-stakes work is scheduled early in sessions or after a deliberate refresh, the way qualified processes schedule precision work after calibration, not before it.
4. **Watch the override rate.** An individual override is a judgment call. A pattern of overrides is a process telling you its thresholds are wrong, its sessions are too long, or its deadlines are unsafe. That is CAPA input (CLA-R9), and the root cause is an incentive structure — staffing, scheduling, tooling — not the person who clicked override.
5. **Do not pressure the system through its own warning.** An operator who badgers a refusing system into producing anyway has disabled a safety control. Where CLA is integrated with PBHP, this obligation is the Mirror Vow's reciprocal half applied to load.

## 11. Reference Implementation

`cla/` — Python 3.10+, standard library only.

| Module | Contents |
|---|---|
| `estimators.py` | chars/4 token heuristic (30% margin) + tokenizer-tier margin constant (10%) |
| `monitor.py` | `ContextLoadMonitor`: measured / tokenizer / char-estimate / self-reported / unknown readings; per-turn and per-token accumulation |
| `thresholds.py` | `LoadBand`, versioned `ThresholdPolicy` (band bounds + evidence margins), deterministic `classify_band` (rounds estimates up) |
| `gate.py` | Stakes, deterministic verdict matrix (versioned: id + content hash), logged `apply_override`, PBHP threshold mapping |
| `disclosure.py` | One-line and block disclosure formats; renders UNKNOWN as UNMEASURED, self-reports with a tilde |
| `selfreport.py` | CLA-SR milestone schedule, crossing detection, paste-ready protocol block |
| `session.py` | `SessionAuditState`: band-transition + cadence tracking for CLA-R3 timing; serializable; optional cadence-only cooldown (never suppresses CLA-R3 MUSTs) |
| `calibrate.py` | §13.2 calibration harness: org supplies `eval_fn`, library sweeps loads and recommends versioned bands |
| `stakes_classifier.py` | Deterministic heuristic stakes first-pass (labeled `heuristic`; PBHP mapping preferred when integrated) |
| `composition.py` | Context-composition EVENT disclosure: load spikes, harness-reported compaction — events, never quality scores |
| `handoff.py` | Programmatic refresh-handoff builder from receipts + verbatim artifacts; mandatory degraded-conditions label; **handoff fact-verify mode** (`verify_handoff` + `build_handoff(verifier=...)`) — claims labeled CONFIRMED/UNCONFIRMED/MISMATCH/UNVERIFIABLE against a harness-supplied checker |
| `streaming.py` | `StreamingAuditor`: incremental feed/update_counts + gated `checkpoint()` |
| `signing.py` | Optional standalone Ed25519 receipt signing (lazy `cryptography` import; core stays dependency-free) |
| `receipt.py` | `cla.receipt.v1` build/serialize/persist (append-only JSONL, fsync), `to_pbhp_extension()`, `override_rate` CAPA signal |
| `__init__.py` | `audit(...)` one-call convenience |
| `tests/test_cla.py` | 75 tests covering bands, gate matrix, overrides (incl. v0.2 record-don't-rewrite, the measured absolute floor recording an ignored-floor attempt, and the self-report floor being overridable), fail-honest paths, receipts, PBHP extension shape, CLA-SR, gate-policy versioning, session tracking, tokenizer tier, calibration, stakes heuristic, composition events, handoff labeling, streaming, cooldown, windowed CAPA metrics, signing |
| `examples/wrapper_example.py` | Full guarded-call loop against a fake client |

Example disclosures produced by the implementation:

```
CLA v0.1 | load: 72.3% (measured) | band: ELEVATED | stakes: HIGH | verdict: PROCEED_WITH_DISCLOSURE | refresh at: 90% | policy: cla-default/0.1.0
```

```
CLA-SR v0.1 | self-reported load: ~62.0% | basis: 40+ exchanges, three large documents | band: CRITICAL | stakes: HIGH | verdict: REFUSE_REFRESH | refresh at: 90% | policy: cla-default/0.1.0
```

```
=== CONTEXT LOAD AUDIT ===
Context load: 92.5% (measured)
Band: CRITICAL
Stakes: HIGH
Verdict: REFUSE_REFRESH
Reason: Load is in the CRITICAL band and stakes are HIGH. Per policy, high-stakes
output is refused at this load. Refresh the session and re-enter the task with a
summary handoff; it returns as a new action with a new receipt.
Policy: cla-default/0.1.0 (bands: <50% NOMINAL, <75% ELEVATED, <90% DEGRADED, else CRITICAL)
Recommended action: summarize state, refresh the session, re-enter the task clean.
The work survives the refresh; degraded output may not.
Operator note (reciprocal): a warning you pressure through is a warning you have disabled.
Take it seriously or log the override.
==========================
```

## 12. PBHP / Project Shadow Integration

CLA-1 is designed to run standalone (any harness, any framework, no PBHP required) and to snap into PBHP as a primitive extension. Integration points:

### 12.1 Gate semantics → Door/Wall/Gap

- REFUSE_REFRESH behaves as a **Wall** for the action *as posed in this session*: refuse and log. The action is not destroyed; it re-enters through a fresh session as a different action with a different receipt — the same re-entry semantics PBHP gives Wall verdicts with missing authorizations.
- PAUSE_RECOMMEND_REFRESH behaves as a **Gap**: unclear whether this session can produce qualified output; the flow engages instead of silently promoting to a Door.
- PROCEED_WITH_DISCLOSURE is a **Door with a rider**.
- A Gap raised by load is never silently promoted: either the operator overrides with a logged acknowledgment, or the session refreshes.

### 12.2 Stakes ← Harm Threshold ladder

GREEN→LOW, YELLOW→MEDIUM, ORANGE→HIGH, RED→CRITICAL, BLACK→CRITICAL. BLACK refuses at compile time in PBHP regardless of load; CLA never weakens that — the mapping exists only so a CLA receipt can be emitted alongside the PBHP refusal. Implemented in `gate.stakes_from_pbhp_threshold`.

### 12.3 Receipt embedding

`pbhp.receipt.v1` has no first-class context-load field. v1-compatible embedding:

```python
pbhp_receipt.action["parameters"]["context_load"] = cla_receipt.to_pbhp_extension()
```

Because `action.parameters` sits inside the signed envelope, the CLA record inherits the Ed25519/ML-DSA-65 signature and the hash chain with zero schema change. **Recommendation for `pbhp.receipt.v2`:** promote `context_load` to a first-class top-level field with the extension's shape (`load_percent`, `used_tokens`, `max_tokens`, `provenance`, `band`, `verdict`, `override`, `policy_id`, `policy_version`).

### 12.4 Drift Alarm

CLA adds a drift class: **context-load drift**, distinct from operator-collapse drift. Indicators are mechanical-pattern output, lost-thread responses, over-elaboration late in session — but under CLA the *primary* indicator is the gauge, not the symptoms. Symptom-watching remains as defense in depth.

### 12.5 Sacred Refusal

The REFUSE_REFRESH verdict extends Sacred Refusal to load: the system declines high-stakes production past the documented threshold even under operator pressure, and the CRITICAL/CRITICAL cell is non-overridable by construction **for measured or estimated readings** (v0.2; a self-reported reading carries no absolute floor per §6.6, so its CRITICAL/CRITICAL cell is overridable with the logged ritual).

### 12.6 Mirror Vow

§10 is the reciprocal half applied to load: the AI must warn; the operator must not force high-stakes work through a known degraded state without a logged acknowledgment.

### 12.7 False Positive Release Valve

The override path (CLA-R7) is the valve: refusals can be wrong, the relief path exists, every use is receipted, and `override_rate` is the structured signal that feeds CAPA review (CLA-R9) — pattern kind `context_load_override`.

### 12.8 Tier routing

MIN: automated audit, one-line disclosure, receipt. CORE: block disclosure on PAUSE/REFUSE, non-boilerplate override acknowledgments. ULTRA: refresh mandatory at DEGRADED+ regardless of override; CLA receipt embedded in the quorum record.

### 12.9 Repo placement

`05_tools/context_load_audit/` alongside `pbhp_v1_core`, with this spec at `04_synthesis/` level as the CLA-1 primitive addendum. CLA carries no mythic vocabulary anywhere in its public surface; it is wall-off-clean by construction. *(Clarification — F4, audited 2026-06-07: "mythic vocabulary" means the project's Morrowind/Tribunal layer. The PBHP primitives this spec references for integration — Door/Wall/Gap (§12.1), Sacred Refusal (§12.5), Mirror Vow (§12.6) — are framework terms, not mythic vocabulary; their presence is consistent with the wall-off-clean claim. The code surface is likewise clean as of 2026-06-07 — see `../AUDIT_FINDINGS_SIL_2026-06-07.md` F3.)*

## 13. Validation

The critique converged on by all nine external evaluators of PBHP was the absence of empirical validation. CLA-1 is the framework's most directly testable primitive. Two experiments:

### 13.1 Differential disclosure experiment

**Question:** does a CLA-instrumented harness give operators materially better information about output reliability than a baseline?

**Design:** identical long-running task scripts run against (a) a baseline chat harness and (b) the same harness wrapped with CLA. At fixed load points (25/50/75/90%), the operator asks for high-stakes output and asks the system about its reliability state. Score: presence and accuracy of load disclosure; refusal behavior past threshold; auditability of the trail afterward. The baseline predicts confident production and no quantified self-state at every load point; CLA predicts graduated disclosure, pause, refusal, and a receipt chain. The differential **is** the validation, and the experiment doubles as the proof-of-concept demo.

**Status — executed 2026-06-06 (reference run).** A reproducible harness implements this design against the real `cla` library: `experiments/exp_13_1_differential_disclosure.py`; writeup `experiments/EXP_13_1_RESULTS.md`; receipt chain + structured results under `experiments/artifacts/`. On the four fixed load points at HIGH stakes the baseline scored 0/4 disclosure, 0/2 threshold responses, 0 receipts; CLA scored 4/4 disclosure (all `measured`, exact), 2/2 threshold responses (pause at DEGRADED, refuse at CRITICAL), and a 4-link hash-chained, tamper-evident receipt trail that reconstructs from disk. The 90% addendum confirms the non-overridable CRITICAL/CRITICAL floor (override raises) and the receipted relief path at HIGH. Scope note (honest): this demonstrates the **mechanism** + the differential vs a sticker-only baseline; it does not establish band calibration (that is §13.2) or in-the-wild classification accuracy (human audit). Eval loop remains closed.

### 13.2 Threshold calibration experiment

**Question:** are the default bands placed where degradation actually begins for a given model and task suite?

**Design:** run a RULER/NoLiMa-style task battery at controlled load levels; plot quality against load fraction; place organizational thresholds where the curve breaks rather than at the defaults. The sweep and band-recommendation logic are operational in `cla/calibrate.py` (worked demo: `examples/calibration_example.py`); the organization supplies the `eval_fn` that actually exercises its model — the library contributes the method, the org contributes the evidence. Quality floors are themselves policy, not constants: set them from the task's error tolerance — the quality level at which output would require full human rework is the CRITICAL floor — and version them alongside the resulting bands. Publish the calibration method, not just the numbers — different models and task mixes will break in different places, which is precisely why CLA-R4 requires versioned org-tunable policy rather than hard-coded constants.

**Status — executed 2026-06-06 (reference run).** A reproducible harness drives the real `cla.calibrate` end-to-end: `experiments/exp_13_2_threshold_calibration.py`; writeup `experiments/EXP_13_2_RESULTS.md`; hash-chained sweep + structured results under `experiments/artifacts/`. Against a **stylized reference degradation curve** (logistic, shaped after *Lost in the Middle* / RULER / NoLiMa / Chroma context-rot — explicitly synthetic, NOT a measurement), the sweep recommends bands of **NOMINAL <30% · ELEVATED <40% · DEGRADED <55%** versus the 50/75/90 defaults — i.e. a curve like the published findings would place every edge *earlier*. 10/10 self-checks pass and the run re-verifies in a fresh process (deterministic; the recommended policy reconstructs from the on-disk artifact; chain tamper-evident). Honesty boundary (in the harness + writeup): this demonstrates the calibration **method** and a **reference** policy only — it does NOT establish validated bands; real calibration requires the organization's own `eval_fn` on its model/task suite, versioned in place of the reference. `DEFAULT_POLICY` is unchanged; eval loop closed.

### 13.3 Captured incident (observational, 2026-06-05)

One real-world instance of the target failure mode is on record from this project's own audit trail. The Project Shadow whole-tree audit (`AUDIT_FINDINGS_2026-06-05.md`, F1) found a documented layer of the tree absent from its canonical locations while four status documents asserted the files existed. The files had been written to a session scratchpad path; the status documents were written from session recall rather than from disk listings, and the false canonical-placement claims persisted through two session handoffs before a disk audit caught them — recall-based status reporting failing silently under accumulated session load (resolution receipt: R-2026-06-05-04 in `04_synthesis/CHANGELOG.md`). This is observational evidence (n=1, uncontrolled), not experimental validation. The protocol implication it documents: **verify against the filesystem before claiming, or disclose the verification gap.** It is recorded as the empirical justification for the v0.2 backlog item "handoff fact-verify mode" (`INTEGRATION_PBHP.md` §9). **Shipped 2026-06-24 (R-2026-06-24-06):** `cla.verify_handoff(claims, verifier)` and an optional `build_handoff(verifier=...)` run each load-bearing claim past a **harness-supplied** checker and label it CONFIRMED / UNCONFIRMED / MISMATCH / UNVERIFIABLE; CLA does no I/O of its own (the harness owns the check, mirroring the `calibrate.py` `eval_fn` split), and a verifier that raises fails safe to UNVERIFIABLE rather than confirming. CLA suite 75 → 85 green.

## 14. Regulatory Mapping

- **EU AI Act, Article 15** (Reg. (EU) 2024/1689; applicable to high-risk systems from 2 August 2026): high-risk AI systems must achieve appropriate accuracy and robustness and "perform consistently in those respects throughout their lifecycle," with accuracy levels and metrics "declared in the accompanying instructions of use." A system whose effective accuracy degrades with context load, undisclosed, has a consistency-and-declaration problem; CLA is an implementable control for exactly that clause.
- **ISO/IEC 42001:2023:** clause 9 (performance evaluation) requires determining what needs monitoring and measurement for the AI management system; context load is a monitorable, measurable in-operation variable with documented quality impact.
- **NIST AI RMF 1.0:** the MEASURE function calls for tracking metrics for trustworthy characteristics in operation; CLA supplies a concrete operational metric, thresholds, and records.
- **OMB M-24-10 (and successors):** agency AI inventories and safety-impacting-AI controls benefit from receipts showing the operating state under which each consequential output was produced.

The adoption wedge mirrors PBHP's: compliance officers at regulated organizations can require CLA-style disclosure from AI vendors as a procurement condition. Providers already meter the variable for billing; surfacing it is an interface decision, not a research program.

## 15. Limitations

Stated plainly, because overclaim is the failure mode this body of work exists to catch:

1. **Load is a proxy, not a quality measurement.** A high-load session may produce a fine answer; a low-load session may hallucinate. CLA discloses elevated *risk*, not measured per-response quality. The disclosure language must never claim otherwise.
2. **Degradation is task- and content-dependent.** Chroma's results show distractor composition matters beyond raw length. A single scalar cannot capture that; bands are deliberately conservative and calibratable, not exact.
3. **Estimation error.** The character heuristic is wrong by up to ~30% on code and non-English text. That is why provenance is mandatory and estimates round up.
4. **Closed surfaces need provider cooperation.** A wrapper can instrument an API harness today; chat products require the provider to expose the meter. CLA gives procurement and regulation a concrete thing to ask for, but cannot conjure it client-side. (A model's stated guess about its own load on such surfaces does not satisfy CLA-R1 and must be labeled as the guess it is.)
5. **Compaction and retrieval remain only partially covered.** `cla/composition.py` discloses load spikes (bulk/RAG injection) and compaction events the harness knows about — but silent provider-side compaction remains undetectable from the client, and no client-side library can score attention-level composition quality. CLA discloses observable events; it does not pretend to a context-health index it cannot defend.
6. **The bands are starting points.** The 50/75/90 defaults are literature-informed policy, not measured constants. Organizations that deploy without running §13.2 calibration should say so in their policy documentation.
7. **CLA-SR is a soft control with a known recursion.** In self-report mode there is no harness to enforce anything, the estimate is roughly directional at best, and the model's compliance with the protocol may itself degrade with the load the protocol monitors. The 0.50 inflation is an unvalidated placeholder pending calibration. CLA-SR exists because the alternative on meterless surfaces is nothing — it is the spare tire, not the wheel.
8. **The scalar does not distinguish cached or static context from dynamic context.** Prompt caching and large static system payloads may not degrade output the same way accumulated conversational text does at equal load, and a flat fraction cannot tell them apart. This strengthens, not weakens, the §13.2 calibration prerequisite for high-volume deployments.

## 16. Literature

- Liu, N. F., Lin, K., Hewitt, J., Paranjape, A., Bevilacqua, M., Petroni, F., & Liang, P. (2024). Lost in the Middle: How Language Models Use Long Contexts. *Transactions of the Association for Computational Linguistics*, 12, 157–173. doi:10.1162/tacl_a_00638. arXiv:2307.03172.
- RULER: What's the Real Context Size of Your Long-Context Language Models? (NVIDIA, 2024). arXiv:2404.06654.
- NoLiMa: Long-Context Evaluation Beyond Literal Matching (2025). arXiv:2502.05167.
- Chroma Research (2025). Context Rot: Evaluating LLM Performance Degradation with Increasing Input Tokens.
- Regulation (EU) 2024/1689 (EU AI Act), Article 15: Accuracy, robustness and cybersecurity.
- ISO/IEC 42001:2023, Information technology — Artificial intelligence — Management system.
- NIST AI 100-1 (2023), Artificial Intelligence Risk Management Framework 1.0.

---

## Appendix A (non-normative): The Lock / Flood / Glide Framing

A useful explanatory metaphor, contributed by Jonathan Moss, for why load management matters in both directions of a human–AI working session. It is presented here strictly as metaphor — it carries no normative weight and no claims about mechanisms in either humans or models.

A reasoning system under **low constraint pressure** can lock: too few candidate interpretations, rigid attachment to an early frame, inability to update on new input. A system under **excess load** can flood: too many active threads, poor separation between them, loss of earlier material, contradiction and fragmentation. Between the two is the **glide** zone, where there is enough context to be informed and little enough to stay coherent.

The mapping to CLA: an over-full context window produces flood-type failures (lost early threads, contradiction, mechanical repetition), and overfitting to a stale early frame despite correction is lock-type failure. CLA's load bands are a flood gauge; the refresh path is the flood response. The metaphor also applies to the operator: long heavy sessions load the human too, and §10's "plan refreshes like changeovers" is as much for the person as for the model.

What this framing is **not**: a claim that LLM attention works like human memory, a clinical instrument, or a basis for the system to assess the *operator's* cognitive state. CLA measures and discloses the machine's own state, by design and only that. Operator state belongs to the operator and enters the protocol only as self-report.

## Appendix B (non-normative): Example PBHP-embedded receipt fragment

```json
{
  "action": {
    "type": "evaluate",
    "parameters": {
      "context_load": {
        "schema": "cla.receipt.v1",
        "cla_receipt_id": "cla:cla:example:wrapper:2026-06-05T14:12:09Z:3f9a1c2e",
        "load_percent": 72.3,
        "used_tokens": 144600,
        "max_tokens": 200000,
        "provenance": "measured",
        "band": "ELEVATED",
        "verdict": "PROCEED_WITH_DISCLOSURE",
        "override": null,
        "policy_id": "cla-default",
        "policy_version": "0.1.0"
      }
    },
    "text": "Draft the public statement."
  }
}
```

## Appendix C (non-normative): Prior-Art Register

Public prior-art review as of 2026-06-05. These tools and features are acknowledged, useful, and **not** what CLA claims to contribute. They are meters and workflow conveniences; CLA is a safety-control protocol (provenance, deterministic stakes-aware gating, default refusal, receipt-before-action, override logging, operator reciprocity). The register exists so the scoped claim in §2 is checkable.

- **ContextCoach** (browser extension, masteringaifootprint.com) — estimates token context load for Claude.ai and ChatGPT in real time, displays a green/yellow/red health banner, and offers a summarize-and-start-fresh workflow. The closest prior art to CLA's disclosure intent; no provenance tiers, no stakes gating, no refusal path, no receipts.
- **Claude Code context indicator and `/context`** — live context-window usage display (fraction and percent) with per-category breakdown, plus `/compact` and `/clear` workflows. Developer-tool meter; no safety semantics.
- **claude-counter and similar IDE/statusline extensions** — token counts and usage bars overlaid on claude.ai or editor status lines. Meters.
- **Provider API usage fields** — exact token counts returned by major LLM APIs; the measurement source CLA's MEASURED tier is built on.
- **Context-management practice literature** — progressive disclosure, summarization, and context-hygiene guidance for agent builders. Workflow technique, not operator-facing control.
- **Research literature** (§16) — establishes the degradation phenomenon CLA discloses; does not propose operator-facing disclosure controls.

---

*CLA-1 v0.1 · Concept: Phillip Linstrum · Lock/Flood/Glide framing (Appendix A): Jonathan Moss · Drafted with AI assistance under source-verification discipline; all citations verified against primary listings 2026-06-05.*

*Revision 2026-06-05: CLA-SR self-report fallback mode added (§8.1, CLA-R11, P7) at maintainer direction.*

*Revision 2026-06-05 (2): external audit fixes — gate-policy versioning with matrix hash in receipts (CLA-R4), default-refusal terminology (CLA-R5), overridable semantics narrowed to PAUSE/REFUSE cells, evidence margins moved into versioned policy, evidence-precedence enforcement in `audit()` (CLA-R11), `SessionAuditState` band-transition tracker (CLA-R3), enforcement-locus table (§6.1), prior-art register (Appendix C), self-report inflation reframed as provisional safety factor.*

*Revision 2026-06-05 (3): six-evaluator review round — handoff cascading-degradation caution added to Refresh definition and §8.1 (credit: Gemini review), standalone stakes anchors added to §3, optional `model_id`/`session_id` receipt fields added.*

*Revision 2026-06-05 (5): round-three external review polish — core-vs-support framing in README, "What CLA does not tell you" section in the operator guide, tokenizer/router mismatch caution (§7), prompt-caching limitation (§15.8), calibration quality-floor guidance (§13.2), CLA-SR early-trip tradeoff note, stakes-classifier i18n limit note, `StreamingAuditor.update_max_tokens()`. Remaining round-three suggestions logged as v0.2 backlog in `INTEGRATION_PBHP.md` §9.*

*Revision 2026-06-05 (4): all ten convergent review items built into v0.1 pre-release at maintainer direction — tokenizer evidence tier (10% declared margin), §13.2 calibration harness, session serialization + `ReceiptStore`, windowed CAPA metrics + cadence-only cooldown, `StreamingAuditor`, heuristic stakes classifier, composition event disclosure (spikes + harness-reported compaction; events, not scores), programmatic handoff builder with degraded-conditions labeling, `OPERATOR_GUIDE.md`, optional standalone Ed25519 signing. No new normative requirements: every addition implements or supports existing R1–R11 at its documented enforcement locus.*

*Revision 2026-06-05 (6): §13.3 captured-incident note added — the Project Shadow F1 audit incident (receipt R-2026-06-05-04) recorded as observational evidence for the handoff fact-verify failure mode, per maintainer assignment. Documentation-only; no normative changes; tests unaffected.*

*Revision 2026-06-24: handoff fact-verify mode shipped (catalog #1.11, R-2026-06-24-06) — `verify_handoff(claims, verifier)` + optional `build_handoff(verifier=...)`; harness-supplied checker, fail-safe to UNVERIFIABLE; §13.3 + the `handoff.py` module-table row updated. CLA suite 75 → 85 green. Implements the v0.2 backlog item justified by the 2026-06-05 F1 incident; no change to R1–R11 or CORE.*
