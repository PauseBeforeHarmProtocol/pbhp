"""CLA §13.2 — REAL Threshold Calibration runner.

Spec: CLA_SPEC_v0.1.md §13.2. Twin of exp_13_2_threshold_calibration.py,
but the empirical content is REAL: instead of the stylized reference
curve, this reads measured quality-vs-load datapoints produced by the
ORG running ITS model on ITS task suite, and ships a versioned
ThresholdPolicy under that model's id.

Division of labor (the honest one):
  - The ORG measures. Running a model on a task suite at controlled load
    levels (RULER/NoLiMa-style tasks padded to length, scored in [0,1])
    is the empirical piece only the org can do. Its output is a table of
    (load_fraction, quality_score) datapoints.
  - This runner calibrates. It validates the datapoints, drives the
    proven cla.calibrate plumbing (run_calibration validation +
    recommend_bands), writes a tamper-evident hash-chained artifact, and
    emits a versioned policy that reconstructs from disk.

>>> HONESTY GATE (eval loop stays CLOSED until real data lands) <<<
This runner REFUSES to emit a policy from placeholder, template, or
stylized-reference data. A reference curve must never be shippable as
"calibrated bands". Real input must carry real provenance (model id,
task suite, who measured, when) and must not match the template
placeholders or the known exp_13_2 stylized curve.

DEFAULT_POLICY is never mutated. The emitted policy is a NEW object
under id `calibrated-<model_id>/<version>`; record it in receipts and
re-calibrate per model.

Input schema (JSON; see real_inputs/calibration_input.template.json):
  {
    "model_id": "your-model-id@version",
    "policy_version": "1.0.0",
    "task_suite": "what you evaluated (e.g. RULER+NoLiMa, 200k window)",
    "measured_by": "name / team",
    "measured_date": "YYYY-MM-DD",
    "quality_floors": {"elevated": 0.95, "degraded": 0.90, "critical": 0.80},
    "notes": "methodology, padding strategy, scorer, etc.",
    "measurements": [ {"load_fraction": 0.10, "quality_score": 0.98}, ... ]
  }

Run:  python3 experiments/calibrate_real.py <input.json>
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLA_ROOT = HERE.parent  # .../05_tools/context_load_audit
sys.path.insert(0, str(CLA_ROOT))

from cla.calibrate import run_calibration, recommend_bands, CalibrationPoint  # noqa: E402
from cla.thresholds import ThresholdPolicy, DEFAULT_POLICY                    # noqa: E402

ARTIFACTS = HERE / "artifacts"

# exp_13_2 stylized curve params — used ONLY to DETECT and REFUSE a stylized
# reference curve masquerading as real measurements.
_REF = dict(q0=0.99, qmin=0.55, knee=0.55, width=0.12)


def _reference_quality(load: float) -> float:
    x = (load - _REF["knee"]) / _REF["width"]
    q = _REF["qmin"] + (_REF["q0"] - _REF["qmin"]) / (1.0 + math.exp(x))
    return max(0.0, min(1.0, round(q, 4)))


_PLACEHOLDER_TOKENS = ("reference", "stylized", "template", "example",
                       "placeholder", "your-model", "your_model", "unspecified",
                       "smoke", "changeme", "todo", "tbd", "xxx")
REQUIRED_KEYS = ("model_id", "task_suite", "measured_by", "measured_date",
                 "quality_floors", "measurements")


class InputError(ValueError):
    pass


def load_input(path: Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise InputError(f"input file not found: {path}")
    except json.JSONDecodeError as e:
        raise InputError(f"input is not valid JSON: {e}")
    missing = [k for k in REQUIRED_KEYS if k not in data]
    if missing:
        raise InputError(f"input missing required keys: {missing}")
    qf = data["quality_floors"]
    for k in ("elevated", "degraded", "critical"):
        if k not in qf:
            raise InputError(f"quality_floors missing '{k}'")
    if not (qf["critical"] < qf["degraded"] < qf["elevated"]):
        raise InputError("quality_floors must satisfy critical < degraded < elevated")
    ms = data["measurements"]
    if not isinstance(ms, list) or len(ms) < 3:
        raise InputError("need >= 3 measurements (a 2-point curve is a line, not evidence)")
    loads = []
    for m in ms:
        L, q = float(m["load_fraction"]), float(m["quality_score"])
        if not (0.0 < L <= 1.2):
            raise InputError(f"load_fraction {L} outside (0, 1.2]")
        if not (0.0 <= q <= 1.0):
            raise InputError(f"quality_score {q} outside [0, 1]")
        loads.append(L)
    if len(set(loads)) != len(loads):
        raise InputError("duplicate load_fraction values in measurements")
    return data


def placeholder_reasons(data: dict) -> list:
    """Honesty gate: non-empty list of reasons if the input looks like
    placeholder/template/stylized-reference data not to be shipped as real."""
    reasons = []
    mid = str(data.get("model_id", "")).strip().lower()
    if not mid:
        reasons.append("model_id is empty")
    if any(tok in mid for tok in _PLACEHOLDER_TOKENS):
        reasons.append(f"model_id '{data.get('model_id')}' contains a placeholder token")
    who = str(data.get("measured_by", "")).strip().lower()
    if who in ("", "name / team", "name", "you", "team", "tbd", "todo"):
        reasons.append("measured_by is empty/placeholder")
    suite = str(data.get("task_suite", "")).strip().lower()
    if (not suite) or suite.startswith("what you evaluated") or any(
            t in suite for t in ("template", "example", "your ")):
        reasons.append("task_suite is empty/placeholder")
    try:
        datetime.strptime(str(data.get("measured_date", "")), "%Y-%m-%d")
    except ValueError:
        reasons.append("measured_date is not a real YYYY-MM-DD date")
    ms = data.get("measurements", [])
    if ms:
        if all(float(m["quality_score"]) == 0.0 for m in ms):
            reasons.append("all quality_score values are 0.0 (template placeholder)")
        matches = sum(1 for m in ms if abs(
            float(m["quality_score"]) - _reference_quality(float(m["load_fraction"]))) <= 1e-3)
        if matches == len(ms):
            reasons.append("measurements match the exp_13_2 STYLIZED reference curve — not a measurement")
    return reasons


def _stamp_version(rec: ThresholdPolicy, version: str) -> ThresholdPolicy:
    return ThresholdPolicy(
        nominal_max=rec.nominal_max, elevated_max=rec.elevated_max,
        degraded_max=rec.degraded_max, estimate_margin=rec.estimate_margin,
        self_report_margin=rec.self_report_margin,
        policy_id=rec.policy_id, policy_version=version)


def calibrate(data: dict):
    """Measured datapoints -> (points, versioned ThresholdPolicy). Reuses the
    proven run_calibration validation + recommend_bands logic."""
    measured = {float(m["load_fraction"]): float(m["quality_score"]) for m in data["measurements"]}
    points = run_calibration(lambda L: measured[L], tuple(measured.keys()))
    qf = data["quality_floors"]
    rec = recommend_bands(points,
                          elevated_quality_floor=qf["elevated"],
                          degraded_quality_floor=qf["degraded"],
                          critical_quality_floor=qf["critical"],
                          model_id=str(data["model_id"]))
    return points, _stamp_version(rec, str(data.get("policy_version", "1.0.0")))


# --- tamper-evident artifact (mirrors exp_13_2) -----------------------------
def _link_hash(load, quality, prev) -> str:
    payload = json.dumps({"load_fraction": load, "quality_score": quality, "prev": prev}, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_chain(points, chain_path: Path) -> str:
    chain_path.parent.mkdir(parents=True, exist_ok=True)
    if chain_path.exists():
        chain_path.unlink()
    prev = None
    with chain_path.open("w", encoding="utf-8") as fh:
        for i, p in enumerate(points):
            h = _link_hash(p.load_fraction, p.quality_score, prev)
            fh.write(json.dumps({"index": i, "load_fraction": p.load_fraction,
                                 "quality_score": p.quality_score, "prev": prev, "hash": h}) + "\n")
            prev = h
    return prev


def load_chain(chain_path: Path):
    return [json.loads(l) for l in chain_path.read_text(encoding="utf-8").splitlines() if l.strip()]


def verify_chain(chain_path: Path, n_expected: int) -> dict:
    rows = load_chain(chain_path)
    checks = {"links": len(rows), "count_ok": len(rows) == n_expected,
              "first_prev_is_null": rows[0]["prev"] is None if rows else False,
              "links_valid": True, "hashes_recompute": True, "tamper_evident_demo": None}
    for i, r in enumerate(rows):
        if _link_hash(r["load_fraction"], r["quality_score"], r["prev"]) != r["hash"]:
            checks["hashes_recompute"] = False
        if i > 0 and r["prev"] != rows[i - 1]["hash"]:
            checks["links_valid"] = False
    if len(rows) >= 2:
        bad = dict(rows[0]); bad["quality_score"] = round(bad["quality_score"] - 0.1, 4)
        rehash = _link_hash(bad["load_fraction"], bad["quality_score"], bad["prev"])
        checks["tamper_evident_demo"] = bool(rows[1]["prev"] != rehash)
    checks["auditable"] = (checks["count_ok"] and checks["first_prev_is_null"]
                           and checks["links_valid"] and checks["hashes_recompute"]
                           and checks["tamper_evident_demo"] is True)
    return checks


def policy_from_disk(chain_path: Path, data: dict) -> ThresholdPolicy:
    rows = load_chain(chain_path)
    pts = [CalibrationPoint(r["load_fraction"], r["quality_score"]) for r in rows]
    qf = data["quality_floors"]
    rec = recommend_bands(pts, elevated_quality_floor=qf["elevated"],
                          degraded_quality_floor=qf["degraded"],
                          critical_quality_floor=qf["critical"],
                          model_id=str(data["model_id"]))
    return _stamp_version(rec, str(data.get("policy_version", "1.0.0")))


def _slug(s) -> str:
    return "".join(c if (c.isalnum() or c in "-._") else "_" for c in str(s))[:64]


def write_writeup(data, points, policy, deltas, monotonic, chain, path, chain_path, results_path):
    floors = data["quality_floors"]
    rows = "\n".join("| {:.0%} | {:.4f} |".format(p.load_fraction, p.quality_score) for p in points)
    md = f"""# CLA §13.2 — REAL Threshold Calibration: Results

**Date:** {datetime.now(timezone.utc).strftime('%Y-%m-%d')} · **Spec:** `../CLA_SPEC_v0.1.md` §13.2 · **Maintainer:** Phillip Linstrum
**Status:** REAL run — validated bands for the model + task suite below, AS MEASURED. Not transferable to other models/suites.
**Model:** {data['model_id']} · **Task suite:** {data['task_suite']}
**Measured by:** {data['measured_by']} ({data['measured_date']})
**Artifacts:** `{chain_path.name}`, `{results_path.name}`

## Quality floors (policy)
ELEVATED {floors['elevated']} · DEGRADED {floors['degraded']} · CRITICAL {floors['critical']} — set from rework tolerance; versioned with the bands.

## Measured sweep
| Load | Quality |
|------|---------|
{rows}

Curve monotonic non-increasing: {monotonic}.

## Result — recommended vs default
| Band edge | Default | Recommended | delta |
|-----------|---------|-------------|-------|
| nominal_max  | 50% | {policy.nominal_max:.0%} | {deltas['nominal_max']:+.2f} |
| elevated_max | 75% | {policy.elevated_max:.0%} | {deltas['elevated_max']:+.2f} |
| degraded_max | 90% | {policy.degraded_max:.0%} | {deltas['degraded_max']:+.2f} |

Recommended policy: `{policy.policy_id} / {policy.policy_version}` — NOMINAL <{policy.nominal_max:.0%} / ELEVATED <{policy.elevated_max:.0%} / DEGRADED <{policy.degraded_max:.0%} / CRITICAL >={policy.degraded_max:.0%}.

## Auditability
Hash-chained sweep ({chain['links']} links), tamper-evident, reconstructs from disk. Self-checks passed; `DEFAULT_POLICY` unmutated. Record this policy id/version in receipts; re-calibrate per model.
"""
    path.write_text(md, encoding="utf-8")


def run(input_path) -> dict:
    data = load_input(Path(input_path))
    reasons = placeholder_reasons(data)
    if reasons:
        print("REFUSED — the REAL calibration runner will not emit a policy from")
        print("placeholder/template/stylized data:")
        for r in reasons:
            print("  - " + r)
        print("\nProvide measured datapoints from your model on your task suite, with")
        print("real provenance (model_id, task_suite, measured_by, measured_date).")
        raise SystemExit(2)

    points, policy = calibrate(data)
    mid = _slug(data["model_id"])
    chain_path = ARTIFACTS / f"cla_13_2_real_{mid}.jsonl"
    results_path = ARTIFACTS / f"cla_13_2_real_{mid}.results.json"
    writeup_path = ARTIFACTS / f"EXP_13_2_REAL_RESULTS.{mid}.md"
    head = write_chain(points, chain_path)

    deltas = {k: round(getattr(policy, k) - getattr(DEFAULT_POLICY, k), 4)
              for k in ("nominal_max", "elevated_max", "degraded_max")}
    qs = [p.quality_score for p in points]
    monotonic = all(qs[i] >= qs[i + 1] for i in range(len(qs) - 1))

    checks = []
    def ok(label, cond): checks.append((label, bool(cond)))
    ok("all quality in [0,1]", all(0.0 <= q <= 1.0 for q in qs))
    ok("policy is a valid ThresholdPolicy (strict ordering)",
       isinstance(policy, ThresholdPolicy) and 0 < policy.nominal_max < policy.elevated_max < policy.degraded_max)
    ok("DEFAULT_POLICY untouched (0.50/0.75/0.90)",
       (DEFAULT_POLICY.nominal_max, DEFAULT_POLICY.elevated_max, DEFAULT_POLICY.degraded_max) == (0.50, 0.75, 0.90))
    _, policy2 = calibrate(data)
    ok("deterministic (re-run identical)", policy2.to_dict() == policy.to_dict())
    ok("policy reconstructs from on-disk sweep", policy_from_disk(chain_path, data).to_dict() == policy.to_dict())
    chain = verify_chain(chain_path, len(points))
    ok("artifact chain auditable + tamper-evident", chain["auditable"])
    passed = sum(1 for _, c in checks if c)

    print("=" * 72)
    print("CLA §13.2 — REAL THRESHOLD CALIBRATION")
    print(f"model_id    : {data['model_id']}")
    print(f"task_suite  : {data['task_suite']}")
    print(f"measured_by : {data['measured_by']}  ({data['measured_date']})")
    qf = data["quality_floors"]
    print(f"floors E/D/C: {qf['elevated']}/{qf['degraded']}/{qf['critical']}")
    print("=" * 72)
    print("\nMeasured sweep:")
    for p in points:
        print("  load {:>5.1%}   quality {:.4f}".format(p.load_fraction, p.quality_score))
    if not monotonic:
        print("\n  NOTE: measured curve is NOT monotonic non-increasing. recommend_bands")
        print("  places edges at the FIRST downward floor crossing; with a wobbly curve")
        print("  inspect the sweep and consider denser load levels.")
    print("\n{:<14}{:>12}{:>14}{:>10}".format("band edge", "default", "recommended", "delta"))
    for k in ("nominal_max", "elevated_max", "degraded_max"):
        print("{:<14}{:>12.0%}{:>14.0%}{:>+10.2f}".format(k, getattr(DEFAULT_POLICY, k), getattr(policy, k), deltas[k]))
    print(f"\nrecommended policy: {policy.policy_id} / {policy.policy_version}")
    print("reading: NOMINAL <{:.0%} / ELEVATED <{:.0%} / DEGRADED <{:.0%} / CRITICAL >={:.0%}".format(
        policy.nominal_max, policy.elevated_max, policy.degraded_max, policy.degraded_max))
    print("\n--- self-checks ---")
    for label, c in checks:
        print(("  ok  " if c else "  XX  ") + label)
    print(f"[EXP-13.2-REAL] {passed}/{len(checks)} self-checks passed")

    results = {
        "experiment": "CLA §13.2 threshold calibration (REAL run)",
        "spec": "CLA_SPEC_v0.1.md §13.2",
        "generated": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "provenance": {k: data[k] for k in ("model_id", "task_suite", "measured_by", "measured_date")},
        "notes": data.get("notes", ""),
        "quality_floors": qf,
        "measured_curve_monotonic_non_increasing": monotonic,
        "sweep": [p.to_dict() for p in points],
        "default_policy": DEFAULT_POLICY.to_dict(),
        "recommended_policy": policy.to_dict(),
        "band_deltas_recommended_minus_default": deltas,
        "chain": {"file": chain_path.name, "head_hash": head, **{k: chain[k] for k in (
            "links", "count_ok", "links_valid", "hashes_recompute", "tamper_evident_demo", "auditable")}},
        "self_checks": {label: c for label, c in checks},
        "all_self_checks_passed": passed == len(checks),
        "status": ("VALIDATED bands for THIS model + task suite as measured. "
                   "Re-calibrate per model; version any change; not transferable."),
    }
    results_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    write_writeup(data, points, policy, deltas, monotonic, chain, writeup_path, chain_path, results_path)
    print(f"\nChain   : {chain_path}")
    print(f"Results : {results_path}")
    print(f"Writeup : {writeup_path}")
    assert all(c for _, c in checks), f"self-checks failed: {checks}"
    print("\nALL SELF-CHECKS PASSED.")
    return results


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="CLA §13.2 REAL threshold calibration.")
    ap.add_argument("input", help="path to calibration input JSON (see real_inputs/calibration_input.template.json)")
    args = ap.parse_args()
    try:
        sys.exit(0 if run(args.input)["all_self_checks_passed"] else 1)
    except InputError as e:
        print("INPUT ERROR:", e)
        sys.exit(2)
