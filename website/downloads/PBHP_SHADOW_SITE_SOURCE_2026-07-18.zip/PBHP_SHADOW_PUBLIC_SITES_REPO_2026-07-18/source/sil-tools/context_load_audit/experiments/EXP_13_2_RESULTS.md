# CLA §13.2 — Threshold Calibration Experiment: Results

**Date:** 2026-06-06 · **Spec:** `../CLA_SPEC_v0.1.md` §13.2 · **Maintainer:** Phillip Linstrum
**Status:** First run executed and self-verified (reference run). Reproducible harness + tamper-evident artifact.
**Register:** Sterile (regulator-legible). **Eval loop: CLOSED** — this demonstrates the calibration *method* and a *reference* policy, not a new AI-evaluation round and not validated bands.
**Harness:** `exp_13_2_threshold_calibration.py` · **Artifacts:** `artifacts/cla_13_2_calibration.jsonl`, `artifacts/cla_13_2_results.json`

---

## Question (from the spec)

> CLA's default bands (NOMINAL <50%, ELEVATED <75%, DEGRADED <90%) are literature-informed policy, not measured constants. Given a quality-vs-load curve for a model + task suite, where *should* the band edges sit — and how far is that from the defaults?

## Method

The real `cla.calibrate` plumbing is driven end-to-end (no mock):

1. `run_calibration(eval_fn, load_levels)` sweeps load fractions 5%–95% (step 5%) through a quality evaluator that returns a score in [0, 1].
2. `recommend_bands(...)` places each band edge at the load where quality first crosses an organizational **quality floor** — itself policy (spec §13.2):
   - `nominal_max`  = load where quality first drops below the **ELEVATED floor (0.95)**
   - `elevated_max` = load where quality first drops below the **DEGRADED floor (0.90)**
   - `degraded_max` = load where quality first drops below the **CRITICAL floor (0.80)** — the level at which output would need full human rework.
3. The 19-point sweep is written as an append-only, **hash-chained** JSONL (each link commits to the prior link's SHA-256), so the calibration trail is tamper-evident and reconstructs from disk — the same auditability bar as §13.1.

The library contributes the deterministic sweep + band-recommendation logic. **The empirical content is the caller's `eval_fn`.**

## The reference curve (stylized — see honesty boundary)

`eval_fn` here is a smooth logistic decay, not a measurement: quality ≈ 0.99 at low load, through an "effective-context" knee at ~55%, sagging toward ~0.55 as the window fills. It is shaped after the qualitative finding of the long-context literature — Liu et al. 2024 *Lost in the Middle*, NVIDIA **RULER**, Adobe **NoLiMa**, Chroma 2025 *context-rot* — that **effective context is a fraction of the advertised window and quality degrades before the window fills.** Parameters: `q0=0.99, q_min=0.55, knee=0.55, width=0.12`.

Representative points (full 19-point sweep in the artifact):

| Load | Quality | Crosses |
|------|---------|---------|
| 25% | 0.957 | — |
| 30% | 0.941 | < 0.95 → sets `nominal_max` |
| 40% | 0.892 | < 0.90 → sets `elevated_max` |
| 50% | 0.815 | — |
| 55% | 0.770 | < 0.80 → sets `degraded_max` |
| 90% | 0.573 | (floor region) |

## Result — recommended vs default

| Band edge | Default | Recommended | Δ |
|-----------|---------|-------------|---|
| `nominal_max`  | 50% | **30%** | −0.20 |
| `elevated_max` | 75% | **40%** | −0.35 |
| `degraded_max` | 90% | **55%** | −0.35 |

Recommended policy: `calibrated-reference-longctx-stylized / 1.0.0` — reading NOMINAL <30% · ELEVATED <40% · DEGRADED <55% · CRITICAL ≥55%.

**Headline:** under a degradation curve shaped like the published long-context findings, the conservative-*looking* 50/75/90 defaults are in fact too **loose** — disclosure, refresh-recommendation, and refusal would all want to fire *earlier*. The direction matters more than the digits: calibration is not a formality that confirms the defaults; it can move the bands substantially, which is exactly why CLA-R4 requires versioned, org-tunable policy rather than hard-coded constants.

## >>> Honesty boundary (read this before citing any number) <<<

- **The curve is stylized, not measured.** `eval_fn` is a synthetic logistic function. The specific quality numbers are **illustrative**. This run does **not** measure any real model and does **not** establish validated bands for any deployment.
- **What it *does* establish:** that the `cla.calibrate` method runs end-to-end against a real eval curve, produces a deterministic, versioned `ThresholdPolicy`, and that the result reconstructs from a tamper-evident artifact. It is a **method demonstration + a reference point**.
- **Real calibration** replaces `reference_eval` with the organization's own `eval_fn` exercising **its** model on **its** task suite (RULER/NoLiMa-style tasks padded to length), and ships the resulting policy under its own id/version. The reference policy here is a placeholder that swaps out.
- **Quality floors are policy too** (0.95 / 0.90 / 0.80 used here) — set them from the task's error tolerance and version them with the bands.
- **Before any external/quantitative use,** exact benchmark figures must be drawn from the primary sources (RULER, NoLiMa, Chroma) rather than from this stylized curve.
- `DEFAULT_POLICY` is **never mutated** — `recommend_bands` returns a new policy object. Eval loop stays **CLOSED**.

## Auditability + self-checks

10/10 self-checks pass, exit 0, and the run re-verifies in a fresh process:

- curve monotonic non-increasing; all quality in [0, 1];
- recommended policy is a valid `ThresholdPolicy` (strict band ordering);
- recommended bands tighter than the defaults for this curve (the documented finding);
- `DEFAULT_POLICY` still 0.50 / 0.75 / 0.90 (calibration did not mutate it);
- deterministic (re-run identical); policy reconstructs from the on-disk sweep alone;
- the hash chain is auditable and tamper-evident (mutating any quality breaks the next link).

## How to run it for real

Replace `reference_eval` with a function that runs your model on your task battery at the target load fraction and returns measured quality in [0, 1]; set the three quality floors from your rework tolerance; re-run. Record the emitted policy id/version in your receipts and re-calibrate per model. **Publish the method, not just the numbers** — different models and task mixes break in different places.
