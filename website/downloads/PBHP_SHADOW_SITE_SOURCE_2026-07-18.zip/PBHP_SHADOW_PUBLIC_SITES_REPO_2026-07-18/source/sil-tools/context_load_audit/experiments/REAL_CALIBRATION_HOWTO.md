# CLA §13.2 — Real Threshold Calibration: How To

**Spec:** `../CLA_SPEC_v0.1.md` §13.2 · **Maintainer:** Phillip Linstrum · **Register:** Sterile.
**Status:** Method + harness proven (reference run: `exp_13_2_threshold_calibration.py`, receipt R-2026-06-06-13). This is the swap-in for REAL bands. **The eval loop stays CLOSED until real measurements land — a reference curve is not validated bands.**

## What this is
CLA's default load bands (NOMINAL <50%, ELEVATED <75%, DEGRADED <90%) are literature-informed **policy, not measured constants**. §13.2 replaces them, for a specific model + task suite, with bands placed where that model's **output quality actually crosses your acceptance floors**. `calibrate_real.py` turns measured quality-vs-load datapoints into a versioned, audited `ThresholdPolicy`.

## The honest division of labor
- **You measure.** Running your model on your task suite at controlled context-load levels is the empirical piece only you can do. The library cannot measure model quality and does not pretend to.
- **The runner calibrates.** It validates your datapoints, drives the proven `cla.calibrate` plumbing (`run_calibration` + `recommend_bands`), writes a tamper-evident hash-chained artifact, and emits a versioned policy that reconstructs from disk.

## What only you can produce — the measurements
For each load level (e.g. 10%, 25%, … 95% of the window), run a battery that **exercises the model at that load** and score output quality in **[0, 1]**:
- **Load** = fraction of the context window filled. Pad RULER/NoLiMa-style retrieval/reasoning tasks to the target length so the signal sits in a genuinely full window, not a short prompt.
- **Quality** = your task's correctness/acceptability score (exact-match, rubric, graded eval — your call), normalized to [0, 1].
- Deterministic where you can (fixed seeds/tasks) so the curve reproduces.

## Quality floors are policy too (your QA call)
`recommend_bands` places each band edge at the **first load where quality drops below a floor**:
- `elevated` (default 0.95) → sets `nominal_max` (the point you leave NOMINAL)
- `degraded` (default 0.90) → sets `elevated_max` (leave ELEVATED)
- `critical` (default 0.80) → sets `degraded_max` (leave DEGRADED) — the level at which output would need **full human rework**.

Set these from your rework tolerance and version them with the bands. They are not physics.

## Run it
1. Copy `real_inputs/calibration_input.template.json`, fill **every** field with real values and your measured `measurements` (≥3 points; load in (0, 1.2]; quality in [0, 1]).
2. `python3 experiments/calibrate_real.py real_inputs/<your-file>.json`
3. Ships to `artifacts/`: a hash-chained sweep (`.jsonl`), a results JSON carrying the versioned policy, and a results writeup (`.md`).

## Honesty gate
The runner **refuses** to emit a policy from placeholder, template, or the exp_13_2 stylized reference curve, and requires real provenance (model id, task suite, who measured, when). It never mutates `DEFAULT_POLICY`; the emitted policy is a new object `calibrated-<model_id>/<version>`.

## After calibration
Record the policy id/version in your receipts (CLA-R4). **Re-calibrate per model** — different models and task mixes break in different places; a policy is validated only for the model + suite it was measured on, and is not transferable.
