"""CLA §13.2 — Threshold Calibration Experiment (reference harness).

Spec: CLA_SPEC_v0.1.md §13.2.

Question
--------
CLA's default bands (NOMINAL<0.50, ELEVATED<0.75, DEGRADED<0.90) are
literature-informed POLICY, not measured constants. §13.2 asks: given a
quality-vs-load curve for a model+task suite, where SHOULD the band
edges sit, and how far is that from the defaults?

Design (faithful to the spec)
------------------------------
Run a RULER/NoLiMa-style battery at controlled load levels, plot quality
against load fraction, and place band edges where the curve crosses the
organization's quality floors rather than at the defaults. The sweep and
band-recommendation logic live in the real `cla.calibrate` (no mock); the
ORG supplies `eval_fn`. Quality floors are themselves policy: the level
at which output would need full human rework is the CRITICAL floor.

  nominal_max  := load where quality first drops below ELEVATED floor (0.95)
  elevated_max := load where quality first drops below DEGRADED  floor (0.90)
  degraded_max := load where quality first drops below CRITICAL  floor (0.80)

>>> HONESTY BOUNDARY (eval loop is CLOSED) <<<
The `eval_fn` here is a STYLIZED REFERENCE CURVE, not measurements of any
real model. It is a smooth logistic decay shaped after the qualitative
finding of the long-context literature (Liu et al. 2024 "Lost in the
Middle"; NVIDIA RULER; Adobe NoLiMa; Chroma 2025 context-rot) that
effective context is a fraction of the advertised window and quality
degrades before the window fills. The specific numbers are ILLUSTRATIVE.
This run therefore demonstrates (a) that the `cla.calibrate` method works
end-to-end and (b) a REFERENCE policy — NOT validated bands for any
deployment. Real calibration requires the organization's own `eval_fn`
exercising its model on its task suite; the resulting policy then swaps in
with its own version. Exact benchmark figures must be drawn from the
primary sources before any external/quantitative use.

Run:  python3 experiments/exp_13_2_threshold_calibration.py
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
CLA_ROOT = HERE.parent  # .../05_tools/context_load_audit
sys.path.insert(0, str(CLA_ROOT))

from cla.calibrate import run_calibration, recommend_bands, CalibrationPoint  # noqa: E402
from cla.thresholds import ThresholdPolicy, DEFAULT_POLICY                    # noqa: E402

# --- experiment constants ---------------------------------------------------

ARTIFACTS = HERE / "artifacts"
ARTIFACTS.mkdir(parents=True, exist_ok=True)
CHAIN = ARTIFACTS / "cla_13_2_calibration.jsonl"
RESULTS = ARTIFACTS / "cla_13_2_results.json"

MODEL_ID = "reference-longctx-stylized"
LOAD_LEVELS = tuple(round(0.05 * i, 2) for i in range(1, 20))  # 0.05 .. 0.95

# Quality floors are policy (spec §13.2). These are the recommend_bands
# defaults, named explicitly so the writeup can show them.
ELEVATED_FLOOR = 0.95   # below this -> leave NOMINAL
DEGRADED_FLOOR = 0.90   # below this -> leave ELEVATED
CRITICAL_FLOOR = 0.80   # below this -> leave DEGRADED (would need rework)

# Stylized reference curve params (NOT measured; see honesty boundary).
Q0, QMIN, KNEE, WIDTH = 0.99, 0.55, 0.55, 0.12


def reference_eval(load_fraction: float) -> float:
    """STYLIZED logistic degradation curve — NOT a measurement.

    quality holds near Q0 at low load, passes through the 'effective
    context' knee (KNEE), and sags toward QMIN as the window fills.
    Shaped after the published finding that effective context is a
    fraction of the advertised window (Lost-in-the-Middle / RULER /
    NoLiMa / Chroma context-rot). Illustrative numbers only.
    """
    x = (load_fraction - KNEE) / WIDTH
    q = QMIN + (Q0 - QMIN) / (1.0 + math.exp(x))
    return max(0.0, min(1.0, round(q, 4)))


# --- hash-chained artifact (tamper-evident, mirrors §13.1) ------------------

def _link_hash(load: float, quality: float, prev) -> str:
    payload = json.dumps({"load_fraction": load, "quality_score": quality, "prev": prev},
                         sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_chain(points) -> str:
    """Append-only, hash-chained sweep: each link commits to the prior."""
    if CHAIN.exists():
        CHAIN.unlink()  # deterministic artifact: fresh chain each run
    prev = None
    with CHAIN.open("w", encoding="utf-8") as fh:
        for i, p in enumerate(points):
            h = _link_hash(p.load_fraction, p.quality_score, prev)
            fh.write(json.dumps({"index": i, "load_fraction": p.load_fraction,
                                 "quality_score": p.quality_score,
                                 "prev": prev, "hash": h}) + "\n")
            prev = h
    return prev  # head hash


def load_chain():
    rows = [json.loads(l) for l in CHAIN.read_text(encoding="utf-8").splitlines() if l.strip()]
    return rows


def verify_chain() -> dict:
    rows = load_chain()
    checks = {"links": len(rows), "expected": len(LOAD_LEVELS),
              "count_ok": len(rows) == len(LOAD_LEVELS),
              "first_prev_is_null": rows[0]["prev"] is None if rows else False,
              "links_valid": True, "hashes_recompute": True, "tamper_evident_demo": None}
    for i, r in enumerate(rows):
        if _link_hash(r["load_fraction"], r["quality_score"], r["prev"]) != r["hash"]:
            checks["hashes_recompute"] = False
        if i > 0 and r["prev"] != rows[i - 1]["hash"]:
            checks["links_valid"] = False
    # tamper-evidence: bump one quality, show the next link's prev no longer matches.
    if len(rows) >= 2:
        bad = dict(rows[0]); bad["quality_score"] = round(bad["quality_score"] - 0.1, 4)
        rehash = _link_hash(bad["load_fraction"], bad["quality_score"], bad["prev"])
        checks["tamper_evident_demo"] = bool(rows[1]["prev"] != rehash)
    checks["auditable"] = (checks["count_ok"] and checks["first_prev_is_null"]
                           and checks["links_valid"] and checks["hashes_recompute"]
                           and checks["tamper_evident_demo"] is True)
    return checks


def policy_from_disk() -> ThresholdPolicy:
    """Reconstruct the recommended policy from the on-disk sweep alone."""
    rows = load_chain()
    pts = [CalibrationPoint(r["load_fraction"], r["quality_score"]) for r in rows]
    return recommend_bands(pts, elevated_quality_floor=ELEVATED_FLOOR,
                           degraded_quality_floor=DEGRADED_FLOOR,
                           critical_quality_floor=CRITICAL_FLOOR, model_id=MODEL_ID)


# --- driver -----------------------------------------------------------------

def run() -> dict:
    print("=" * 72)
    print("CLA §13.2 — THRESHOLD CALIBRATION EXPERIMENT (reference run)")
    print("eval_fn = STYLIZED reference curve (NOT measured) · floors "
          "E/D/C = {}/{}/{}".format(ELEVATED_FLOOR, DEGRADED_FLOOR, CRITICAL_FLOOR))
    print("=" * 72)

    points = run_calibration(reference_eval, LOAD_LEVELS)
    head = write_chain(points)

    print("\nCalibration sweep (stylized reference curve):")
    for p in points:
        print("  load {:>4.0%}   quality {:.4f}".format(p.load_fraction, p.quality_score))

    rec = recommend_bands(points, elevated_quality_floor=ELEVATED_FLOOR,
                          degraded_quality_floor=DEGRADED_FLOOR,
                          critical_quality_floor=CRITICAL_FLOOR, model_id=MODEL_ID)

    deltas = {
        "nominal_max": round(rec.nominal_max - DEFAULT_POLICY.nominal_max, 4),
        "elevated_max": round(rec.elevated_max - DEFAULT_POLICY.elevated_max, 4),
        "degraded_max": round(rec.degraded_max - DEFAULT_POLICY.degraded_max, 4),
    }

    print("\n{:<14}{:>12}{:>14}{:>10}".format("band edge", "default", "recommended", "delta"))
    for k in ("nominal_max", "elevated_max", "degraded_max"):
        print("{:<14}{:>12.0%}{:>14.0%}{:>+10.2f}".format(
            k, getattr(DEFAULT_POLICY, k), getattr(rec, k), deltas[k]))
    print("\nrecommended policy: {} / {}".format(rec.policy_id, rec.policy_version))
    print("reading: NOMINAL <{:.0%} · ELEVATED <{:.0%} · DEGRADED <{:.0%} · CRITICAL >={:.0%}".format(
        rec.nominal_max, rec.elevated_max, rec.degraded_max, rec.degraded_max))

    # --- self-checks --------------------------------------------------------
    checks = []
    def ok(label, cond): checks.append((label, bool(cond)))

    qs = [p.quality_score for p in points]
    ok("curve monotonic non-increasing", all(qs[i] >= qs[i + 1] for i in range(len(qs) - 1)))
    ok("all quality in [0,1]", all(0.0 <= q <= 1.0 for q in qs))
    ok("recommended policy is a valid ThresholdPolicy",
       isinstance(rec, ThresholdPolicy) and 0 < rec.nominal_max < rec.elevated_max < rec.degraded_max)
    # this stylized curve degrades EARLIER than the conservative defaults
    ok("recommended nominal tighter than default (<0.50)", rec.nominal_max < DEFAULT_POLICY.nominal_max)
    ok("recommended elevated tighter than default (<0.75)", rec.elevated_max < DEFAULT_POLICY.elevated_max)
    ok("recommended degraded tighter than default (<0.90)", rec.degraded_max < DEFAULT_POLICY.degraded_max)
    # the default policy object must never be mutated by calibration
    ok("DEFAULT_POLICY untouched (0.50/0.75/0.90)",
       (DEFAULT_POLICY.nominal_max, DEFAULT_POLICY.elevated_max, DEFAULT_POLICY.degraded_max) == (0.50, 0.75, 0.90))
    # determinism: same eval_fn -> same policy
    rec2 = recommend_bands(run_calibration(reference_eval, LOAD_LEVELS),
                           elevated_quality_floor=ELEVATED_FLOOR, degraded_quality_floor=DEGRADED_FLOOR,
                           critical_quality_floor=CRITICAL_FLOOR, model_id=MODEL_ID)
    ok("deterministic (re-run identical)", rec2.to_dict() == rec.to_dict())
    # reconstruct from disk artifact alone
    ok("policy reconstructs from on-disk sweep", policy_from_disk().to_dict() == rec.to_dict())
    # chain integrity
    chain = verify_chain()
    ok("artifact chain auditable + tamper-evident", chain["auditable"])

    passed = sum(1 for _, c in checks if c)
    print("\n--- self-checks ---")
    for label, c in checks:
        print(("  ok  " if c else "  XX  ") + label)
    print("[EXP-13.2] {}/{} self-checks passed".format(passed, len(checks)))

    results = {
        "experiment": "CLA §13.2 threshold calibration (reference run)",
        "spec": "CLA_SPEC_v0.1.md §13.2",
        "generated": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "eval_fn": {
            "kind": "STYLIZED reference logistic curve — NOT measured",
            "shaped_after": ["Liu 2024 Lost-in-the-Middle", "NVIDIA RULER",
                             "Adobe NoLiMa", "Chroma 2025 context-rot"],
            "params": {"q0": Q0, "q_min": QMIN, "knee": KNEE, "width": WIDTH},
        },
        "quality_floors": {"elevated": ELEVATED_FLOOR, "degraded": DEGRADED_FLOOR,
                           "critical": CRITICAL_FLOOR, "note": "floors are policy (spec §13.2)"},
        "load_levels": list(LOAD_LEVELS),
        "sweep": [p.to_dict() for p in points],
        "default_policy": DEFAULT_POLICY.to_dict(),
        "recommended_policy": rec.to_dict(),
        "band_deltas_recommended_minus_default": deltas,
        "chain": {"file": CHAIN.name, "head_hash": head, **{k: chain[k] for k in
                  ("links", "count_ok", "links_valid", "hashes_recompute",
                   "tamper_evident_demo", "auditable")}},
        "self_checks": {label: c for label, c in checks},
        "all_self_checks_passed": passed == len(checks),
        "honesty_boundary": (
            "eval_fn is a STYLIZED reference curve, not measurements of any model. "
            "Demonstrates the cla.calibrate METHOD end-to-end and a REFERENCE policy "
            "ONLY; it does NOT establish validated bands for any deployment. Real "
            "calibration requires the org's own eval_fn on its model/task suite, "
            "versioned in place of this reference. Exact benchmark figures must come "
            "from the primary sources before external use. Eval loop CLOSED; "
            "DEFAULT_POLICY unchanged."
        ),
    }
    RESULTS.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print("\nChain  : {}".format(CHAIN))
    print("Results: {}".format(RESULTS))

    # hard gates
    assert all(c for _, c in checks), "self-checks failed: {}".format(checks)
    print("\nALL SELF-CHECKS PASSED.")
    return results


if __name__ == "__main__":
    sys.exit(0 if run()["all_self_checks_passed"] else 1)
