# CLA Operator Guide

*Plain-language guide for the person relying on the output. The spec (`CLA_SPEC_v0.1.md`) is for implementers and auditors; this is for you.*

## What the gauge means

Your AI session has a context window — working memory. As it fills, output quality degrades. This is measured and documented across every major model tested, and it happens well before the window is technically "full." CLA puts a gauge on that, the same way a car puts a gauge on fuel: not because you crash at empty, but because you deserve to know before you're stranded.

The disclosure line looks like this:

```
CLA v0.1 | load: 72.3% (measured) | band: ELEVATED | stakes: HIGH | verdict: PROCEED_WITH_DISCLOSURE | refresh at: 90% | policy: cla-default/0.1.0
```

Read it left to right: how full the window is, how trustworthy that number is, what zone you're in, how consequential your request was judged to be, and what the system decided to do about the combination.

## The provenance tag matters

**(measured)** — exact count from the provider. Trust it.
**(estimated)** — computed from text size or a tokenizer. Good, not exact; already rounded up.
**~XX% (self-reported)** — the model's own guess. Weakest evidence there is; already inflated 1.5× before classification. Treat as roughly directional.
**UNMEASURED** — no number exists. The system will say so rather than invent one. At high stakes, unmeasured load is itself a reason to pause.

## The four zones

**NOMINAL** (under 50%) — work normally. **ELEVATED** (50–75%) — fine for most work; consequential outputs come with the disclosure line. **DEGRADED** (75–90%) — schedule a refresh before anything important. **CRITICAL** (90%+) — high-stakes output gets refused here; refresh first.

## Stakes: how your request gets classified

LOW = your own recoverable rework (typos, formatting). MEDIUM = relied on internally, recoverable (drafts, analysis). HIGH = third parties rely on it or it's hard to undo (published content, shipped code). CRITICAL = safety-, legal-, or compliance-relevant, or practically irreversible. When unsure, it rounds up. If the system got your stakes wrong, say so — but say it honestly, not to dodge a pause.

## What each verdict asks of you

**PROCEED** — nothing. **PROCEED_WITH_DISCLOSURE** — read the line before relying on the output. **PAUSE_RECOMMEND_REFRESH** — refresh before this output gets relied on, or override with a real acknowledgment. **REFUSE_REFRESH** — the system declines this output at this load. Refresh and re-enter. One cell (critical load + critical stakes) cannot be overridden at all when the load is *measured or estimated* — the absolute floor. If the only reading is a self-report (CLA-SR), even that cell is overridable with a real acknowledgment: a guess must never hard-block absolutely, and the attempt is logged either way (v0.2).

## Overriding honestly

False alarms are real, and the override path exists because a brake nobody can release gets ripped out. But every override is logged with your name and your stated reason. "Deadline; accepting risk; will verify by hand" is an honest override. Clicking through silently is not — and a rising override rate triggers a process review, because a pattern of overrides means the process is broken, not the people.

## Refreshing without losing your work

A refresh is a pit stop, not a crash. Get a handoff summary, open a fresh session, paste it in. Two warnings: first, prefer handoffs built from logged facts (receipts, saved artifacts) over asking a heavily-loaded model to remember what mattered. Second, if the handoff WAS written by a degraded session, it carries a label saying so — keep the label, and verify anything load-bearing.

## Plan like an operator

Schedule high-stakes work early in sessions or right after a deliberate refresh — the same way precision work gets scheduled after calibration, not before it. Long heavy sessions load you too. The refresh is as much for the person as the machine.

## What CLA does not tell you

CLA discloses operating conditions, not correctness. A NOMINAL band does not prove the answer is right; a fresh session can still hallucinate, and a careful late-session answer can still be fine. CLA does not catch all hallucinations, does not score the quality of any individual response, and does not replace subject-matter review. It is the gauge that tells you when to trust the machine *less* — it is never a certificate to trust it more.

## No meter on your surface?

Paste the block from `SELF_REPORT_PROTOCOL.md` into your custom instructions. You get the weakest version of the gauge — approximate, self-reported, conservatively rounded — which still beats nothing. Some brake is better than no brake.

---

*Part of the Context Load Audit (CLA-1). Concept: Phillip Linstrum. License: open, attribution required, no single owner.*
