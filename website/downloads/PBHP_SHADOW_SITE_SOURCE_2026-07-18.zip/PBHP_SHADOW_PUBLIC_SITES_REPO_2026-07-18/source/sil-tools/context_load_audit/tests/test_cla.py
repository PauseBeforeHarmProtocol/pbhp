"""Tests for the CLA reference implementation."""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cla import audit
from cla.estimators import estimate_tokens_from_text, CHARS_PER_TOKEN
from cla.monitor import ContextLoadMonitor, LoadProvenance
from cla.thresholds import LoadBand, ThresholdPolicy, DEFAULT_POLICY, classify_band
from cla.gate import (
    Stakes,
    Verdict,
    evaluate_gate,
    apply_override,
    stakes_from_pbhp_threshold,
)
from cla.disclosure import format_disclosure_line, format_disclosure_block
from cla.receipt import CLAReceipt, append_receipt, load_receipts, override_rate, degraded_band_rate
from cla.selfreport import MILESTONES, milestones_crossed, should_disclose, SELF_REPORT_PROTOCOL
from cla.session import SessionAuditState
from cla.gate import gate_policy, gate_matrix_hash


# -- estimators ------------------------------------------------------------


def test_estimate_tokens_basic():
    assert estimate_tokens_from_text("") == 0
    assert estimate_tokens_from_text("abcd") == 1
    assert estimate_tokens_from_text("a" * 4000) == 1000


def test_estimate_tokens_rejects_non_string():
    with pytest.raises(TypeError):
        estimate_tokens_from_text(None)


# -- monitor ---------------------------------------------------------------


def test_measured_reading():
    m = ContextLoadMonitor(max_tokens=200_000)
    r = m.reading_from_counts(144_600)
    assert r.provenance == LoadProvenance.MEASURED
    assert r.fraction == pytest.approx(0.723)
    assert r.percent == 72.3


def test_measured_reading_without_window_has_no_fraction():
    m = ContextLoadMonitor()
    r = m.reading_from_counts(50_000)
    assert r.provenance == LoadProvenance.MEASURED
    assert r.fraction is None
    assert classify_band(r) == LoadBand.UNKNOWN  # fail-honest


def test_estimated_reading_from_text():
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_text("a" * 2000)  # ~500 tokens
    assert r.provenance == LoadProvenance.ESTIMATED
    assert r.fraction == pytest.approx(0.5)


def test_accumulated_turns():
    m = ContextLoadMonitor(max_tokens=1000)
    m.add_turn("a" * 1000)  # ~250
    r = m.add_turn("a" * 1000)  # ~500 total
    assert r.used_tokens == 500
    assert r.fraction == pytest.approx(0.5)


def test_unknown_reading():
    m = ContextLoadMonitor(max_tokens=200_000)
    r = m.reading_unknown()
    assert r.provenance == LoadProvenance.UNKNOWN
    assert r.fraction is None
    assert r.percent is None


def test_monitor_rejects_bad_window():
    with pytest.raises(ValueError):
        ContextLoadMonitor(max_tokens=0)


def test_overrun_fraction_not_clamped():
    m = ContextLoadMonitor(max_tokens=100)
    r = m.reading_from_counts(120)
    assert r.fraction == pytest.approx(1.2)
    assert classify_band(r) == LoadBand.CRITICAL


# -- thresholds ------------------------------------------------------------


def test_band_boundaries_measured():
    m = ContextLoadMonitor(max_tokens=1000)
    assert classify_band(m.reading_from_counts(0)) == LoadBand.NOMINAL
    assert classify_band(m.reading_from_counts(499)) == LoadBand.NOMINAL
    assert classify_band(m.reading_from_counts(500)) == LoadBand.ELEVATED
    assert classify_band(m.reading_from_counts(749)) == LoadBand.ELEVATED
    assert classify_band(m.reading_from_counts(750)) == LoadBand.DEGRADED
    assert classify_band(m.reading_from_counts(899)) == LoadBand.DEGRADED
    assert classify_band(m.reading_from_counts(900)) == LoadBand.CRITICAL


def test_estimated_rounds_up():
    """An ESTIMATED 45% inflates by the 30% error margin -> 58.5% -> ELEVATED."""
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_text("a" * 1800)  # ~450 tokens = 45%
    assert classify_band(r) == LoadBand.ELEVATED
    # The same fraction MEASURED stays NOMINAL.
    rm = m.reading_from_counts(450)
    assert classify_band(rm) == LoadBand.NOMINAL


def test_policy_validation():
    with pytest.raises(ValueError):
        ThresholdPolicy(nominal_max=0.8, elevated_max=0.7, degraded_max=0.9)


def test_custom_policy():
    tight = ThresholdPolicy(nominal_max=0.3, elevated_max=0.5, degraded_max=0.7,
                            policy_id="org-tight", policy_version="1.0.0")
    m = ContextLoadMonitor(max_tokens=1000)
    assert classify_band(m.reading_from_counts(600), tight) == LoadBand.DEGRADED


# -- gate ------------------------------------------------------------------


def test_gate_matrix_spot_checks():
    assert evaluate_gate(LoadBand.NOMINAL, Stakes.LOW).verdict == Verdict.PROCEED
    assert evaluate_gate(LoadBand.NOMINAL, Stakes.CRITICAL).verdict == Verdict.PROCEED_WITH_DISCLOSURE
    assert evaluate_gate(LoadBand.ELEVATED, Stakes.CRITICAL).verdict == Verdict.PAUSE_RECOMMEND_REFRESH
    assert evaluate_gate(LoadBand.DEGRADED, Stakes.HIGH).verdict == Verdict.PAUSE_RECOMMEND_REFRESH
    assert evaluate_gate(LoadBand.DEGRADED, Stakes.CRITICAL).verdict == Verdict.REFUSE_REFRESH
    assert evaluate_gate(LoadBand.CRITICAL, Stakes.HIGH).verdict == Verdict.REFUSE_REFRESH
    assert evaluate_gate(LoadBand.CRITICAL, Stakes.LOW).verdict == Verdict.PROCEED_WITH_DISCLOSURE


def test_gate_unknown_band_is_conservative():
    assert evaluate_gate(LoadBand.UNKNOWN, Stakes.LOW).verdict == Verdict.PROCEED_WITH_DISCLOSURE
    assert evaluate_gate(LoadBand.UNKNOWN, Stakes.HIGH).verdict == Verdict.PAUSE_RECOMMEND_REFRESH
    assert evaluate_gate(LoadBand.UNKNOWN, Stakes.CRITICAL).verdict == Verdict.PAUSE_RECOMMEND_REFRESH


def test_gate_determinism():
    a = evaluate_gate(LoadBand.DEGRADED, Stakes.MEDIUM)
    b = evaluate_gate(LoadBand.DEGRADED, Stakes.MEDIUM)
    assert a.verdict == b.verdict == Verdict.PAUSE_RECOMMEND_REFRESH


def test_gate_rejects_bad_stakes():
    with pytest.raises(ValueError):
        evaluate_gate(LoadBand.NOMINAL, "EXTREME")


def test_override_allowed_and_logged():
    # v0.2 record-don't-rewrite: verdict is NOT mutated; the relaxed
    # decision lives in effective_verdict + the override record.
    g = evaluate_gate(LoadBand.DEGRADED, Stakes.HIGH)
    o = apply_override(g, "phil", "I accept degraded-output risk; verifying by hand.")
    assert o.verdict == Verdict.PAUSE_RECOMMEND_REFRESH          # unchanged
    assert o.effective_verdict == Verdict.PROCEED_WITH_DISCLOSURE
    assert o.override["applied"] is True
    assert o.override["effective_verdict"] == Verdict.PROCEED_WITH_DISCLOSURE
    assert o.override["operator_id"] == "phil"


def test_override_recorded_not_raised_at_measured_floor():
    # v0.2: the absolute floor (measured CRITICAL/CRITICAL) is NOT
    # overridable. An attempt is RECORDED (ignored_floor), not raised;
    # the floor holds — effective_verdict stays REFUSE_REFRESH.
    g = evaluate_gate(LoadBand.CRITICAL, Stakes.CRITICAL)  # default provenance = measured
    assert not g.overridable
    o = apply_override(g, "phil", "time-critical; I accept the risk")
    assert o.verdict == Verdict.REFUSE_REFRESH
    assert o.effective_verdict == Verdict.REFUSE_REFRESH
    assert o.override["applied"] is False
    assert o.override["ignored_floor"] is True


def test_self_report_floor_is_overridable():
    # N1 / SIL §6.6: a SELF_REPORTED reading carries no non-overridable
    # floor — a heuristic guess must never hard-block. The same cell that
    # is absolute under measurement is overridable under self-report.
    measured = evaluate_gate(LoadBand.CRITICAL, Stakes.CRITICAL,
                             provenance=LoadProvenance.MEASURED.value)
    sr = evaluate_gate(LoadBand.CRITICAL, Stakes.CRITICAL,
                       provenance=LoadProvenance.SELF_REPORTED.value)
    assert measured.overridable is False
    assert sr.overridable is True
    o = apply_override(sr, "phil", "consumer surface, no meter; I accept the risk")
    assert o.override["applied"] is True
    assert o.effective_verdict == Verdict.PROCEED_WITH_DISCLOSURE


def test_override_requires_acknowledgment():
    g = evaluate_gate(LoadBand.DEGRADED, Stakes.HIGH)
    with pytest.raises(ValueError):
        apply_override(g, "phil", "   ")
    with pytest.raises(ValueError):
        apply_override(g, "", "I accept the risk.")


def test_override_refuses_when_nothing_to_override():
    g = evaluate_gate(LoadBand.NOMINAL, Stakes.LOW)
    with pytest.raises(ValueError):
        apply_override(g, "phil", "I accept the risk.")


def test_pbhp_threshold_mapping():
    assert stakes_from_pbhp_threshold("GREEN") == Stakes.LOW
    assert stakes_from_pbhp_threshold("YELLOW") == Stakes.MEDIUM
    assert stakes_from_pbhp_threshold("ORANGE") == Stakes.HIGH
    assert stakes_from_pbhp_threshold("RED") == Stakes.CRITICAL
    assert stakes_from_pbhp_threshold("BLACK") == Stakes.CRITICAL
    with pytest.raises(ValueError):
        stakes_from_pbhp_threshold("PURPLE")


# -- disclosure ------------------------------------------------------------


def test_disclosure_line_measured():
    m = ContextLoadMonitor(max_tokens=200_000)
    r = m.reading_from_counts(144_600)
    band = classify_band(r)
    g = evaluate_gate(band, Stakes.HIGH)
    line = format_disclosure_line(r, band, g)
    assert "72.3% (measured)" in line
    assert "ELEVATED" in line
    assert "PROCEED_WITH_DISCLOSURE" in line
    assert "cla-default/0.1.0" in line


def test_disclosure_unknown_never_fabricates():
    m = ContextLoadMonitor(max_tokens=200_000)
    r = m.reading_unknown()
    band = classify_band(r)
    g = evaluate_gate(band, Stakes.MEDIUM)
    line = format_disclosure_line(r, band, g)
    assert "UNMEASURED" in line
    assert "%" not in line.split("|")[1]  # no number in the load segment


def test_disclosure_block_refuse_contains_operator_note():
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_counts(950)
    band = classify_band(r)
    g = evaluate_gate(band, Stakes.HIGH)
    block = format_disclosure_block(r, band, g)
    assert "REFUSE_REFRESH" in block
    assert "Operator note" in block


# -- receipts --------------------------------------------------------------


def _make_receipt(used=144_600, maxt=200_000, stakes=Stakes.HIGH):
    m = ContextLoadMonitor(max_tokens=maxt)
    r = m.reading_from_counts(used)
    band = classify_band(r)
    g = evaluate_gate(band, stakes)
    line = format_disclosure_line(r, band, g)
    return CLAReceipt.build(reading=r, band=band, stakes=stakes, gate=g,
                            policy=DEFAULT_POLICY, disclosure_text=line)


def test_receipt_round_trip():
    rec = _make_receipt()
    j = rec.to_json()
    back = CLAReceipt.from_json(j)
    assert back.to_dict() == rec.to_dict()


def test_receipt_canonical_json_sorted():
    rec = _make_receipt()
    j = rec.to_json()
    parsed = json.loads(j)
    assert list(parsed.keys()) == sorted(parsed.keys())


def test_receipt_persistence(tmp_path):
    path = tmp_path / "cla_receipts.jsonl"
    r1 = _make_receipt(used=10_000)
    r2 = _make_receipt(used=180_000)
    append_receipt(path, r1)
    append_receipt(path, r2)
    loaded = load_receipts(path)
    assert len(loaded) == 2
    assert loaded[0].reading["used_tokens"] == 10_000
    assert loaded[1].band == LoadBand.CRITICAL.value


def test_receipt_hash_changes_with_content():
    r1 = _make_receipt(used=10_000)
    r2 = _make_receipt(used=180_000)
    assert r1.receipt_hash() != r2.receipt_hash()


def test_pbhp_extension_shape():
    rec = _make_receipt()
    ext = rec.to_pbhp_extension()
    assert ext["schema"] == "cla.receipt.v1"
    assert ext["load_percent"] == 72.3
    assert ext["provenance"] == "measured"
    assert ext["band"] == "ELEVATED"
    assert ext["verdict"] == "PROCEED_WITH_DISCLOSURE"
    assert ext["policy_id"] == "cla-default"
    # Must be JSON-serializable as-is (it rides inside the signed envelope).
    json.dumps(ext)


def test_override_rate_capa_signal():
    receipts = []
    for used in (800, 850, 880):  # DEGRADED band at max 1000
        m = ContextLoadMonitor(max_tokens=1000)
        r = m.reading_from_counts(used)
        band = classify_band(r)
        g = evaluate_gate(band, Stakes.HIGH)
        g = apply_override(g, "phil", "deadline; accepting risk")
        receipts.append(CLAReceipt.build(reading=r, band=band, stakes=Stakes.HIGH,
                                         gate=g, policy=DEFAULT_POLICY,
                                         disclosure_text="x"))
    assert override_rate(receipts) == 1.0


# -- audit() convenience ----------------------------------------------------


def test_audit_measured_path():
    out = audit(used_tokens=182_000, max_tokens=200_000, stakes=Stakes.HIGH)
    assert out["band"] == LoadBand.CRITICAL
    assert out["gate"].verdict == Verdict.REFUSE_REFRESH
    assert "91.0% (measured)" in out["disclosure"]
    assert out["receipt"].gate["verdict"] == Verdict.REFUSE_REFRESH


def test_audit_estimated_path():
    # 400,000 chars / 4 = 100,000 tokens = 50% of window; ESTIMATED readings
    # inflate by the 30% error margin -> 65% -> ELEVATED.
    out = audit(text="a" * 400_000, max_tokens=200_000, stakes=Stakes.LOW)
    assert out["reading"].provenance == LoadProvenance.ESTIMATED
    assert out["band"] == LoadBand.ELEVATED
    assert out["gate"].verdict == Verdict.PROCEED


def test_audit_unknown_path():
    out = audit(stakes=Stakes.CRITICAL)
    assert out["band"] == LoadBand.UNKNOWN
    assert out["gate"].verdict == Verdict.PAUSE_RECOMMEND_REFRESH
    assert "UNMEASURED" in out["disclosure"]


# -- CLA-SR self-report fallback ---------------------------------------------


def test_self_report_reading():
    m = ContextLoadMonitor()
    r = m.reading_from_self_report(62, "40+ exchanges, three large documents pasted")
    assert r.provenance == LoadProvenance.SELF_REPORTED
    assert r.fraction == pytest.approx(0.62)
    assert r.basis.startswith("40+")


def test_self_report_requires_basis():
    m = ContextLoadMonitor()
    with pytest.raises(ValueError):
        m.reading_from_self_report(62, "")
    with pytest.raises(ValueError):
        m.reading_from_self_report(62, "   ")


def test_self_report_rejects_garbage_percent():
    m = ContextLoadMonitor()
    with pytest.raises(ValueError):
        m.reading_from_self_report(-5, "signals")
    with pytest.raises(ValueError):
        m.reading_from_self_report(300, "signals")
    with pytest.raises(TypeError):
        m.reading_from_self_report("a lot", "signals")


def test_self_report_inflation_is_harshest():
    """~62% self-report inflates by 50% -> 93% -> CRITICAL.
    The same 62% MEASURED is only ELEVATED."""
    sr = ContextLoadMonitor().reading_from_self_report(62, "signals")
    assert classify_band(sr) == LoadBand.CRITICAL
    measured = ContextLoadMonitor(max_tokens=1000).reading_from_counts(620)
    assert classify_band(measured) == LoadBand.ELEVATED


def test_self_report_moderate_band():
    """~40% * 1.5 = 60% -> ELEVATED."""
    sr = ContextLoadMonitor().reading_from_self_report(40, "signals")
    assert classify_band(sr) == LoadBand.ELEVATED


def test_milestone_schedule_shape():
    assert MILESTONES[0] == 0.25
    assert MILESTONES[1] == 0.50
    assert MILESTONES[2] == 0.65
    assert MILESTONES[-1] == 1.00
    assert len(MILESTONES) == 10
    # every-5-points tail
    assert MILESTONES[3:] == [0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1.00]


def test_milestones_crossed():
    assert milestones_crossed(None, 0.30) == [0.25]
    assert milestones_crossed(0.30, 0.40) == []
    assert milestones_crossed(0.40, 0.66) == [0.50, 0.65]
    assert milestones_crossed(0.66, 0.71) == [0.70]
    assert should_disclose(0.84, 0.86)
    assert not should_disclose(0.71, 0.74)


def test_audit_self_report_path():
    out = audit(self_reported_percent=62,
                self_report_basis="40+ exchanges, three large documents",
                stakes=Stakes.HIGH)
    assert out["band"] == LoadBand.CRITICAL
    assert out["gate"].verdict == Verdict.REFUSE_REFRESH
    assert "CLA-SR" in out["disclosure"]
    assert "~62.0%" in out["disclosure"]
    assert "basis:" in out["disclosure"]
    assert "(measured)" not in out["disclosure"]


def test_audit_self_report_without_basis_refused():
    with pytest.raises(ValueError):
        audit(self_reported_percent=62, stakes=Stakes.HIGH)


def test_audit_rejects_self_report_when_better_evidence_exists():
    # CLA-R11: self-report MUST NOT be used where a measured or estimated
    # path exists. Passing both is a caller bug; audit() refuses loudly
    # instead of silently picking one.
    with pytest.raises(ValueError):
        audit(used_tokens=100_000, max_tokens=200_000,
              self_reported_percent=95, self_report_basis="vibes",
              stakes=Stakes.HIGH)
    with pytest.raises(ValueError):
        audit(text="a" * 1000, max_tokens=200_000,
              self_reported_percent=40, self_report_basis="signals",
              stakes=Stakes.LOW)


def test_self_report_block_carries_caution_and_basis():
    out = audit(self_reported_percent=62, self_report_basis="long session, lost early thread",
                stakes=Stakes.HIGH)
    block = format_disclosure_block(out["reading"], out["band"], out["gate"])
    assert "Self-reported context load: ~62.0%" in block
    assert "Not a measurement" in block
    assert "Basis: long session" in block


def test_self_report_receipt_records_provenance_and_basis():
    out = audit(self_reported_percent=70, self_report_basis="signals", stakes=Stakes.MEDIUM)
    d = out["receipt"].to_dict()
    assert d["reading"]["provenance"] == "self-reported"
    assert d["reading"]["basis"] == "signals"
    ext = out["receipt"].to_pbhp_extension()
    assert ext["provenance"] == "self-reported"


def test_protocol_text_contains_the_load_bearing_rules():
    assert "25%, 50%, and 65%" in SELF_REPORT_PROTOCOL
    assert "every 5 points" in SELF_REPORT_PROTOCOL
    assert "1.5x" in SELF_REPORT_PROTOCOL
    assert "OVERRIDE acknowledged by user" in SELF_REPORT_PROTOCOL
    assert "never present it as a measurement" in SELF_REPORT_PROTOCOL
    assert "UNMEASURED" in SELF_REPORT_PROTOCOL


# -- GPT-audit fixes (2026-06-05) ---------------------------------------------


def test_overridable_only_on_pause_and_refuse():
    # PROCEED cells have nothing to override.
    assert evaluate_gate(LoadBand.NOMINAL, Stakes.LOW).overridable is False
    assert evaluate_gate(LoadBand.ELEVATED, Stakes.HIGH).overridable is False
    # PAUSE / REFUSE cells are overridable...
    assert evaluate_gate(LoadBand.DEGRADED, Stakes.HIGH).overridable is True
    assert evaluate_gate(LoadBand.CRITICAL, Stakes.HIGH).overridable is True
    # ...except the locked CRITICAL/CRITICAL cell.
    assert evaluate_gate(LoadBand.CRITICAL, Stakes.CRITICAL).overridable is False


def test_gate_policy_record_shape():
    gp = gate_policy()
    assert gp["gate_policy_id"] == "cla-gate-default"
    assert gp["gate_policy_version"] == "0.2.0"
    assert gp["gate_matrix_hash"].startswith("sha256:")
    assert len(gp["gate_matrix_hash"]) == len("sha256:") + 64


def test_gate_matrix_hash_deterministic():
    assert gate_matrix_hash() == gate_matrix_hash()


def test_receipt_carries_gate_policy():
    out = audit(used_tokens=144_600, max_tokens=200_000, stakes=Stakes.HIGH)
    pol = out["receipt"].to_dict()["policy"]
    assert pol["gate_policy_id"] == "cla-gate-default"
    assert pol["gate_matrix_hash"].startswith("sha256:")
    assert pol["estimate_margin"] == 0.30
    assert pol["self_report_margin"] == 0.50
    ext = out["receipt"].to_pbhp_extension()
    assert ext["gate_matrix_hash"].startswith("sha256:")


def test_policy_margins_configurable_and_recorded():
    lenient = ThresholdPolicy(self_report_margin=0.25, policy_id="org-calibrated",
                              policy_version="1.0.0")
    sr = ContextLoadMonitor().reading_from_self_report(62, "signals")
    # 62% * 1.25 = 77.5% -> DEGRADED under the calibrated margin
    assert classify_band(sr, lenient) == LoadBand.DEGRADED
    assert lenient.to_dict()["self_report_margin"] == 0.25
    with pytest.raises(ValueError):
        ThresholdPolicy(self_report_margin=-0.1)


def test_session_tracker_band_transition_and_stakes():
    m = ContextLoadMonitor(max_tokens=1000)
    s = SessionAuditState()
    # First reading: disclosure due (first reading of session), no transition.
    r1 = m.reading_from_counts(300)
    u1 = s.update(r1, classify_band(r1), Stakes.LOW)
    assert u1["disclosure_required"] is True
    assert u1["band_transition"] is False
    # Same band, LOW stakes, milestone 50% crossed -> disclosure via cadence.
    r2 = m.reading_from_counts(520)
    u2 = s.update(r2, classify_band(r2), Stakes.LOW)
    assert u2["band_transition"] is True  # NOMINAL -> ELEVATED
    # Same band, LOW stakes, no milestone -> NO disclosure owed.
    r3 = m.reading_from_counts(540)
    u3 = s.update(r3, classify_band(r3), Stakes.LOW)
    assert u3["disclosure_required"] is False
    # MEDIUM stakes always requires disclosure (CLA-R3).
    r4 = m.reading_from_counts(560)
    u4 = s.update(r4, classify_band(r4), Stakes.MEDIUM)
    assert u4["disclosure_required"] is True
    # Band transition at LOW stakes still requires disclosure (CLA-R3).
    r5 = m.reading_from_counts(800)
    u5 = s.update(r5, classify_band(r5), Stakes.LOW)
    assert u5["band_transition"] is True
    assert u5["disclosure_required"] is True


def test_receipt_model_and_session_ids():
    out = audit(used_tokens=144_600, max_tokens=200_000, stakes=Stakes.HIGH,
                model_id="claude-opus-4-8", session_id="sess-001")
    d = out["receipt"].to_dict()
    assert d["model_id"] == "claude-opus-4-8"
    assert d["session_id"] == "sess-001"
    assert out["receipt"].to_pbhp_extension()["model_id"] == "claude-opus-4-8"
    # Optional: defaults to None and round-trips.
    out2 = audit(used_tokens=10, max_tokens=200_000, stakes=Stakes.LOW)
    rt = CLAReceipt.from_json(out2["receipt"].to_json())
    assert rt.model_id is None and rt.session_id is None


def test_degraded_band_rate_capa_signal():
    out_low = audit(used_tokens=10_000, max_tokens=200_000, stakes=Stakes.LOW)
    out_hi1 = audit(used_tokens=160_000, max_tokens=200_000, stakes=Stakes.LOW)
    out_hi2 = audit(used_tokens=185_000, max_tokens=200_000, stakes=Stakes.LOW)
    rate = degraded_band_rate([out_low["receipt"], out_hi1["receipt"], out_hi2["receipt"]])
    assert rate == pytest.approx(2 / 3)
    assert degraded_band_rate([]) == 0.0


# -- v0.1 full feature set (roadmap items built in pre-release) ----------------


from cla.calibrate import CalibrationPoint, run_calibration, recommend_bands
from cla.stakes_classifier import classify_stakes
from cla.composition import detect_load_spike, record_compaction_event
from cla.handoff import build_handoff, verify_handoff, HandoffVerification, ClaimStatus
from cla.streaming import StreamingAuditor
from cla.receipt import ReceiptStore


def _fake_tokenizer(text):
    return len(text) // 5  # pretend-tokenizer: 5 chars/token


def test_tokenizer_reading_carries_smaller_margin():
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_tokenizer("a" * 2500, _fake_tokenizer)  # 500 tokens = 50%
    assert r.provenance == LoadProvenance.ESTIMATED
    assert r.source == "tokenizer"
    assert r.declared_margin == 0.10
    # 50% * 1.10 = 55% -> ELEVATED; same text via chars/4 (625 tok = 62.5% * 1.3
    # = 81.25%) would be DEGRADED. Tokenizer tier earns the better band.
    assert classify_band(r) == LoadBand.ELEVATED
    assert classify_band(m.reading_from_text("a" * 2500)) == LoadBand.DEGRADED


def test_tokenizer_accepts_encode_style_sequences():
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_tokenizer("abcdef", lambda t: list(range(3)))  # len()=3
    assert r.used_tokens == 3


def test_audit_tokenizer_path():
    out = audit(text="a" * 2500, tokenizer=_fake_tokenizer, max_tokens=1000,
                stakes=Stakes.LOW)
    assert out["reading"].source == "tokenizer"
    assert out["receipt"].to_dict()["reading"]["declared_margin"] == 0.10


def test_calibration_recommends_bands_from_curve():
    def curve(load):
        return 0.97 if load <= 0.4 else 0.93 if load <= 0.6 else 0.87 if load <= 0.8 else 0.74
    points = run_calibration(curve)
    pol = recommend_bands(points, model_id="testmodel")
    assert pol.policy_id == "calibrated-testmodel"
    assert pol.nominal_max == 0.50   # first quality < 0.95
    assert pol.elevated_max == 0.70  # first quality < 0.90
    assert pol.degraded_max == 0.90  # first quality < 0.80
    # ThresholdPolicy ordering invariants hold.
    assert pol.nominal_max < pol.elevated_max < pol.degraded_max


def test_calibration_refuses_garbage():
    with pytest.raises(ValueError):
        run_calibration(lambda l: 1.5)  # quality out of range
    with pytest.raises(ValueError):
        recommend_bands([CalibrationPoint(0.5, 0.9)])  # too few points


def test_calibration_keeps_defaults_when_curve_never_breaks():
    points = run_calibration(lambda l: 0.99)
    pol = recommend_bands(points, model_id="rocksolid")
    assert pol.nominal_max == 0.50  # default kept, never silently loosened... 
    assert pol.degraded_max == 0.90


def test_stakes_classifier_rules():
    assert classify_stakes("fix the typo in my draft").stakes == Stakes.LOW
    assert classify_stakes("publish this post to the company blog").stakes == Stakes.HIGH
    assert classify_stakes("prepare the FDA submission package").stakes == Stakes.CRITICAL
    out = classify_stakes("analyze these numbers for me")
    assert out.stakes == Stakes.MEDIUM and out.matched_rule is None
    assert out.provenance == "heuristic"
    with pytest.raises(ValueError):
        classify_stakes("   ")


def test_spike_detection():
    assert detect_load_spike(0.30, 0.70).kind == "load_spike"
    assert detect_load_spike(0.30, 0.40) is None
    assert detect_load_spike(None, 0.20).delta_fraction == pytest.approx(0.20)


def test_compaction_event_requires_detail_and_warns():
    ev = record_compaction_event("harness compacted first 40 turns", freed_fraction=0.30)
    assert ev.kind == "compaction"
    assert "less early-context fidelity" in ev.detail
    assert ev.delta_fraction == -0.30
    with pytest.raises(ValueError):
        record_compaction_event("")


def test_handoff_labels_degraded_sources():
    rec = audit(used_tokens=185_000, max_tokens=200_000, stakes=Stakes.LOW)["receipt"]
    text = build_handoff(task_state="Spec draft at section 9; receipts verified.",
                         artifacts=["commit d5104fc", "policy cla-default/0.1.0"],
                         receipts=[rec], source_band=LoadBand.CRITICAL,
                         next_steps="Re-verify section 9 table.")
    assert "COMPILED UNDER DEGRADED CONDITIONS" in text
    assert "commit d5104fc" in text
    assert "SESSION OPERATING HISTORY" in text
    # Nominal-band handoffs carry no scare label.
    clean = build_handoff(task_state="x", source_band=LoadBand.NOMINAL)
    assert "DEGRADED CONDITIONS" not in clean
    with pytest.raises(ValueError):
        build_handoff(task_state="  ")


def test_handoff_flags_overrides():
    g = evaluate_gate(LoadBand.DEGRADED, Stakes.HIGH)
    g = apply_override(g, "phil", "deadline")
    m = ContextLoadMonitor(max_tokens=1000)
    r = m.reading_from_counts(800)
    rec = CLAReceipt.build(reading=r, band=LoadBand.DEGRADED, stakes=Stakes.HIGH,
                           gate=g, policy=DEFAULT_POLICY, disclosure_text="x")
    text = build_handoff(task_state="x", receipts=[rec], source_band=LoadBand.DEGRADED)
    assert "override(s) occurred" in text


# -- handoff fact-verify mode (catalog #1.11; spec 13.3) ----------------------


def test_verify_handoff_all_confirmed():
    v = verify_handoff(["a.md", "R-1"], lambda c: True)
    assert v.all_confirmed
    assert v.total == 2 and v.confirmed == 2
    assert "2/2 load-bearing claims confirmed" in v.summary_line()


def test_verify_handoff_unconfirmed_and_mismatch():
    def verifier(claim):
        if claim == "missing.md":
            return False                  # absent on disk -> UNCONFIRMED
        if claim == "count=99":
            return ClaimStatus.MISMATCH   # exists but contradicts
        return True
    v = verify_handoff(["ok.md", "missing.md", "count=99"], verifier)
    assert not v.all_confirmed
    assert v.confirmed == 1 and v.unconfirmed == 1 and v.mismatch == 1
    s = v.summary_line()
    assert "1/3 confirmed" in s and "UNCONFIRMED" in s and "MISMATCH" in s


def test_verify_handoff_unverifiable_on_none():
    v = verify_handoff(["x"], lambda c: None)
    assert v.unverifiable == 1 and not v.all_confirmed
    assert v.checks[0].status is ClaimStatus.UNVERIFIABLE


def test_verify_handoff_accepts_tuple_with_detail():
    v = verify_handoff(["x"], lambda c: (False, "not found on disk"))
    assert v.checks[0].status is ClaimStatus.UNCONFIRMED
    assert v.checks[0].detail == "not found on disk"
    assert "not found on disk" in v.to_block()


def test_verify_handoff_broken_verifier_is_unverifiable_not_confirmed():
    def boom(claim):
        raise RuntimeError("checker offline")
    v = verify_handoff(["x"], boom)
    assert v.checks[0].status is ClaimStatus.UNVERIFIABLE  # fail-safe, never CONFIRMED
    assert "checker offline" in v.checks[0].detail


def test_verify_handoff_rejects_bad_return_type():
    with pytest.raises(TypeError):
        verify_handoff(["x"], lambda c: 123)  # not bool / ClaimStatus / None / tuple


def test_verify_handoff_requires_callable():
    with pytest.raises(TypeError):
        verify_handoff(["x"], "not-callable")


def test_verify_handoff_empty_claims_is_vacuously_confirmed():
    v = verify_handoff([], lambda c: True)
    assert v.all_confirmed and v.total == 0
    assert "no load-bearing claims" in v.summary_line()


def test_build_handoff_with_verifier_injects_section_and_flags():
    # Marquee: the R-2026-06-05-04 failure mode — a recalled file claim that
    # disk cannot confirm is surfaced in the handoff instead of inherited.
    on_disk = {"04_synthesis/CHANGELOG.md", "commit d5104fc"}
    text = build_handoff(
        task_state="Tree audited; mythic layer placed.",
        artifacts=["04_synthesis/CHANGELOG.md", "shadow_complete_coverage.md", "commit d5104fc"],
        source_band=LoadBand.DEGRADED,
        verifier=lambda c: c in on_disk,
    )
    assert "FACT-VERIFY" in text
    assert "2/3 confirmed" in text                    # summary present and counted
    assert "shadow_complete_coverage.md" in text      # the unconfirmed claim is named
    assert "UNCONFIRMED" in text


def test_build_handoff_without_verifier_unchanged():
    text = build_handoff(task_state="x", artifacts=["a"], source_band=LoadBand.NOMINAL)
    assert "FACT-VERIFY" not in text  # backward-compatible: no verifier -> no section


def test_streaming_estimated_mode():
    s = StreamingAuditor(max_tokens=1000)
    out1 = s.feed("a" * 1200)  # ~300 tokens
    assert out1["session"]["disclosure_required"] is True  # first reading
    out2 = s.feed("a" * 1200)  # ~600 total -> 60% raw, est-inflated
    assert out2["spike"] is not None  # 30% jump in one step
    cp = s.checkpoint(Stakes.HIGH)
    assert cp["receipt"].reading["source"].startswith("char_heuristic")
    assert cp["gate"].verdict in (Verdict.PROCEED_WITH_DISCLOSURE,
                                  Verdict.PAUSE_RECOMMEND_REFRESH,
                                  Verdict.REFUSE_REFRESH)


def test_streaming_measured_mode_locks_out_feed():
    s = StreamingAuditor(max_tokens=1000)
    s.update_counts(900)
    with pytest.raises(RuntimeError):
        s.feed("more text")
    cp = s.checkpoint(Stakes.HIGH)
    assert cp["band"] == LoadBand.CRITICAL
    assert cp["gate"].verdict == Verdict.REFUSE_REFRESH


def test_session_serialization_round_trip():
    m = ContextLoadMonitor(max_tokens=1000)
    s = SessionAuditState(cooldown_seconds=60)
    r = m.reading_from_counts(520)
    s.update(r, classify_band(r), Stakes.LOW, now=1000.0)
    restored = SessionAuditState.from_dict(s.to_dict())
    assert restored.prev_band == LoadBand.ELEVATED
    assert restored.prev_fraction == pytest.approx(0.52)
    assert restored.cooldown_seconds == 60
    assert restored.updates == 1


def test_cooldown_suppresses_cadence_but_never_musts():
    m = ContextLoadMonitor(max_tokens=1000)
    s = SessionAuditState(cooldown_seconds=300)
    r1 = m.reading_from_counts(100)
    s.update(r1, classify_band(r1), Stakes.LOW, now=0.0)        # first reading discloses
    # Milestone crossing (25%) at LOW stakes, same band, inside cooldown -> suppressed.
    r2 = m.reading_from_counts(300)
    u2 = s.update(r2, classify_band(r2), Stakes.LOW, now=10.0)
    assert u2["suppressed_by_cooldown"] is True
    assert u2["disclosure_required"] is False
    # MEDIUM stakes inside cooldown -> MUST discloses anyway.
    r3 = m.reading_from_counts(310)
    u3 = s.update(r3, classify_band(r3), Stakes.MEDIUM, now=20.0)
    assert u3["disclosure_required"] is True
    # Band transition at LOW stakes inside cooldown -> MUST discloses anyway.
    r4 = m.reading_from_counts(600)
    u4 = s.update(r4, classify_band(r4), Stakes.LOW, now=30.0)
    assert u4["band_transition"] is True
    assert u4["disclosure_required"] is True


def test_windowed_capa_metrics():
    rs = []
    for used in (10_000, 20_000, 160_000, 185_000):
        rs.append(audit(used_tokens=used, max_tokens=200_000, stakes=Stakes.LOW)["receipt"])
    assert degraded_band_rate(rs) == pytest.approx(0.5)
    assert degraded_band_rate(rs, last_n=2) == pytest.approx(1.0)
    with pytest.raises(ValueError):
        degraded_band_rate(rs, last_n=0)


def test_receipt_store(tmp_path):
    store = ReceiptStore(tmp_path / "r.jsonl")
    store.append(audit(used_tokens=10_000, max_tokens=200_000, stakes=Stakes.LOW)["receipt"])
    store.append(audit(used_tokens=185_000, max_tokens=200_000, stakes=Stakes.LOW)["receipt"])
    assert len(store.load()) == 2
    assert store.degraded_band_rate() == pytest.approx(0.5)


def test_standalone_signing_round_trip():
    pytest.importorskip("cryptography")
    from cla.signing import generate_keypair, sign_receipt, verify_receipt
    rec = audit(used_tokens=144_600, max_tokens=200_000, stakes=Stakes.HIGH)["receipt"]
    priv, pub = generate_keypair()
    sign_receipt(rec, priv)
    assert verify_receipt(rec, pub) is True
    rec.band = "NOMINAL"  # tamper
    assert verify_receipt(rec, pub) is False


def test_streaming_update_max_tokens():
    s = StreamingAuditor(max_tokens=None)
    s.update_counts(50_000)
    assert s.checkpoint(Stakes.HIGH)["band"] == LoadBand.UNKNOWN  # no window yet
    s.update_max_tokens(200_000)
    out = s.update_counts(50_000)
    assert out["reading"].fraction == pytest.approx(0.25)
    with pytest.raises(ValueError):
        s.update_max_tokens(0)
