# Context Load Audit (CLA)

**Your AI has a gas gauge. You're just not allowed to see it.**

Context load is not the whole health panel — it is the first gauge users should have been shown.

LLM output quality degrades as the context window fills — documented across every frontier model tested (Lost in the Middle, RULER, NoLiMa, Chroma's context-rot report). The provider meters context utilization exactly; the person relying on the output gets nothing. CLA closes that gap.

CLA is a deployment-side safety primitive: **measure context load at the harness level, disclose it with provenance, gate high-stakes output behind load thresholds, and write an audit receipt before the output commits.** Plus the reciprocal half: the operator commits to taking the warnings seriously.

```
CLA v0.1 | load: 72.3% (measured) | band: ELEVATED | stakes: HIGH | verdict: PROCEED_WITH_DISCLOSURE | refresh at: 90% | policy: cla-default/0.1.0
```

## Quick start

Zero required dependencies (`cryptography` optional, for standalone receipt signing only). Python 3.10+.

```python
from cla import audit, append_receipt
from cla.gate import Stakes, Verdict

out = audit(used_tokens=182_000, max_tokens=200_000, stakes=Stakes.HIGH)

append_receipt("cla_receipts.jsonl", out["receipt"])   # receipt BEFORE action

if out["gate"].verdict in (Verdict.PAUSE_RECOMMEND_REFRESH, Verdict.REFUSE_REFRESH):
    print(out["disclosure"])   # stop: refresh session (or log an explicit
                               # operator override via apply_override) before producing
else:
    response = call_your_model(prompt)
    print(response, "\n---\n", out["disclosure"])
```

Demos: `python examples/wrapper_example.py` · `python examples/calibration_example.py` · Tests: `python -m pytest tests/` (75 passing; v0.2)

*The calibration demo illustrates the method with a simulated curve; it does not validate the default bands.*

## No meter at all? CLA-SR

On surfaces with no harness and no meter (consumer chat windows), the fallback is **CLA-SR**: the model self-reports an approximate load with a stated basis, discloses at milestones (25%, 50%, 65%, then every 5 points), classifies after a 1.5× conservative inflation, and brakes on high-stakes output at critical bands. Weakest evidence tier, loudest labels, retired the moment a real meter exists. Paste-ready install block: `SELF_REPORT_PROTOCOL.md`. Some brake is better than no brake.

## The rules in one breath

Load is measured by the harness whenever a harness exists; model self-report is a last-resort fallback with the loudest labels and the harshest rounding (CLA-SR). Provenance (measured / estimated / self-reported / unknown) is always disclosed. Unknown is disclosed as unknown — never a made-up number. Estimates round up. Thresholds are versioned policy. High stakes + critical load = refusal with a refresh path. Every audit leaves a receipt. Overrides are logged, and a rising override rate is a CAPA signal, not a victory.

## Design

| | |
|---|---|
| `cla/monitor.py` | Measured / estimated / self-reported / unknown load readings |
| `cla/thresholds.py` | NOMINAL → ELEVATED → DEGRADED → CRITICAL bands, versioned policy |
| `cla/gate.py` | Deterministic stakes × load verdict matrix, logged overrides |
| `cla/disclosure.py` | Per-response disclosure line + pause/refuse block |
| `cla/receipt.py` | `cla.receipt.v1`, append-only JSONL, PBHP embedding |
| `cla/selfreport.py` | CLA-SR milestones, crossing detection, paste-ready protocol |
| `cla/session.py` | Session state: band-transition + disclosure timing, serializable, anti-fatigue cooldown |
| `cla/streaming.py` | Incremental audit for streaming harnesses, with gated checkpoints |
| `cla/calibrate.py` | Band calibration harness — plug in your model eval, get versioned bands |
| `cla/stakes_classifier.py` | Heuristic stakes first-pass (labeled as such; your harness knows better) |
| `cla/composition.py` | Load-spike + compaction event disclosure (events, not pseudo-scores) |
| `cla/handoff.py` | Refresh handoffs built from receipts and logged artifacts, not model recall |
| `cla/signing.py` | Optional Ed25519 signing for standalone receipts |

**Core path:** monitor → thresholds → gate → disclosure → receipt. That is CLA. Everything else in the table — session, streaming, calibrate, stakes classifier, composition, handoff, signing, self-report — is support tooling that implements or assists the same eleven requirements at their documented enforcement locus. None of it adds normative surface.

## Standalone, and also a PBHP primitive

CLA runs in any harness with no other framework. It is also designed as a primitive extension to the [Pause Before Harm Protocol](../project-shadow/): REFUSE maps to Wall semantics, stakes map from the GREEN→BLACK harm ladder, receipts embed inside the signed `pbhp.receipt.v1` envelope, the override path is the False Positive Release Valve, and the operator obligation is the Mirror Vow's reciprocal half. See `CLA_SPEC_v0.1.md` §12 and `INTEGRATION_PBHP.md`.

## Spec

`CLA_SPEC_v0.1.md` — normative requirements (CLA-R1…R11), default thresholds and rationale, gate matrix, CLA-SR fallback mode, receipt schema, regulatory mapping (EU AI Act Art. 15, ISO/IEC 42001, NIST AI RMF), validation experiment designs, and an honest limitations section. New to the gauge? Start with `OPERATOR_GUIDE.md`.

---

*Concept: Phillip Linstrum, 2026. License: open, attribution required, no single owner.*
