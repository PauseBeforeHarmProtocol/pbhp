# CLA → Project Shadow Integration Work Order

**Purpose:** the concrete checklist for folding CLA-1 into Project Shadow / PBHP once the standalone tool is accepted. Written so a future session can execute it without re-deriving context.
**Prerequisite reading:** `CLA_SPEC_v0.1.md` §12 (the normative integration mapping).

---

## 1. File moves

| # | Action | Target |
|---|---|---|
| 1.1 | Copy `context-load-audit/` (this folder) into the Shadow tree | `project-shadow/05_tools/context_load_audit/` |
| 1.2 | Add CLA-1 primitive addendum reference to the canonical spec index | `project-shadow/04_synthesis/` (addendum pointer to the spec; do NOT rewrite `00_PBHP_v1.0_CORE.md` — version-bump discipline applies) |
| 1.3 | Add CLA one-paragraph entry to the adoption package | `07_adoption_package/PBHP_ONE_PAGE_SUMMARY.md` (under supporting structures) + `README.md` entry tree |

## 2. Spec-level changes (proposed for PBHP v1.1, NOT retroactive edits to v1.0)

| # | Change | Where |
|---|---|---|
| 2.1 | `pbhp.receipt.v2`: promote `context_load` to a first-class top-level field (shape = `CLAReceipt.to_pbhp_extension()`) | receipt schema §7 |
| 2.2 | Drift Alarm: add **context-load drift** as a drift class distinct from operator-collapse drift | drift/CAPA sections |
| 2.3 | CAPA: add `pattern_kind: "context_load_override"` as a fourth structural trigger alongside repeated_wall / repeated_gap / maybe_drift | CAPA section + `CapaPattern.pattern_kind` |
| 2.4 | Sacred Refusal: note the load-threshold extension (REFUSE_REFRESH; CRITICAL/CRITICAL non-overridable for measured/estimated — self-report overridable per §6.6, v0.2) | Sacred Refusal section |
| 2.5 | Mirror Vow: add the reciprocal load clause (operator does not pressure through load warnings without logged acknowledgment) | Mirror Vow doc |
| 2.6 | Tier table: MIN = inline disclosure; CORE = block disclosure + non-boilerplate override ack; ULTRA = refresh mandatory at DEGRADED+, no override | §4 tiers |

## 3. Code-level changes in `pbhp_v1_core`

| # | Change | File |
|---|---|---|
| 3.1 | Optional `cla_extension` parameter on `evaluate()` that merges `to_pbhp_extension()` into `action.parameters.context_load` before canonicalization/hash | `pbhp/core.py` |
| 3.2 | Helper: `stakes_from_pbhp_threshold(receipt.harm_threshold.value)` wiring example | `pbhp/examples.py` |
| 3.3 | Tests: embedded CLA record survives sign → verify → chain round trip (the extension changes the canonical bytes, so it must be merged BEFORE signing) | `tests/` |

## 4. Sequencing against the existing Shadow work plan

The nine-evaluator converged plan (version-skew reconciliation, public-surface sterilization, repo pushes, first reviewer outreach) stays priority one. CLA slots in as follows:

1. CLA standalone tool review by Phil (this deliverable) — accept/revise.
2. Items 1.1–1.3 (file moves) ride along with the next repo-cleanup commit. Cheap.
3. Items 2.x are **v1.1 roadmap entries**, not edits to shipped v1.0 — preserves version discipline and avoids reopening the skew problem just closed.
4. Item 3.x lands with the pip-package finalization task already on the engineering list.
5. The §13.1 differential-disclosure experiment is the empirical-validation deliverable all nine evaluators asked for — strong candidate for the first public demo artifact and the reviewer cold-email hook ("here is a falsifiable experiment you can run yourself").

## 5. Public-surface discipline

CLA's public surface (README, spec, code, this doc) is mythic-vocabulary-free by construction — wall-off-clean. The Lock/Flood/Glide appendix is explicitly labeled non-normative metaphor and credits Jon Moss without importing neuro-architecture vocabulary into any normative section. Keep it that way: CLA is the most regulator-legible artifact in the ecosystem and the likeliest first point of external contact.

*(F4, audited 2026-06-07: "mythic-vocabulary-free" refers to the project's Morrowind/Tribunal layer; the PBHP primitives the spec uses for integration — Door/Wall/Gap, Sacred Refusal, Mirror Vow — are framework terms, not mythic vocabulary. The code surface was confirmed clean 2026-06-07 after a stray "(ALMSIVI)" was removed from `cla/__init__.py` — see `../AUDIT_FINDINGS_SIL_2026-06-07.md` F3.)*

## 6. Claim discipline (for any public writing about CLA)

The defensible claim, verified against prior art 2026-06-05 (full register: spec Appendix C — ContextCoach, Claude Code indicator + `/context`, claude-counter/statusline extensions, API usage fields, context-management practice literature): meters and refresh workflows already exist, and the degradation literature is established. **The contribution is treating context load as an operator-facing safety disclosure with provenance, deterministic stakes-aware gating, refusal thresholds, audit receipts, and reciprocal operator obligations — integrated into an operational harm-prevention framework.** No known safety framework does that. Claim exactly this; nothing bigger.

CLA-SR discipline: any public mention of the self-report fallback must lead with its evidence tier (weakest), its inflation (1.5×), and its retirement rule (replaced by a real meter the moment one exists). Never demo CLA-SR as if it were the primary mode — it is the spare tire, and saying so is what keeps the rest of the claim credible.

## 7. Convergent review items (six-evaluator review 2026-06-05) — BUILT INTO v0.1

Maintainer decision 2026-06-05: identified-before-release means fixed-before-release. All ten items below shipped in v0.1 (73/73 tests). Statuses are honest about what a library can deliver vs what stays org-side:

| # | Item | Source | Status in v0.1 |
|---|---|---|---|
| 7.1 | Real-tokenizer evidence tier | Grok, DeepSeek, Mistral | SHIPPED — `monitor.reading_from_tokenizer` / `audit(tokenizer=...)`, 10% declared margin vs 30% char heuristic |
| 7.2 | §13.2 calibration + per-model profiles | DeepSeek, Gemini, Kimi, Mistral | SHIPPED as harness — `cla/calibrate.py` + `examples/calibration_example.py`; the org supplies the model `eval_fn` (empirical runs cannot ship in a library) |
| 7.3 | Session serialization + receipt persistence | DeepSeek, Gemini, Mistral | SHIPPED — `SessionAuditState.to_dict/from_dict`, thread-safe `ReceiptStore`; multi-process limits documented, not hidden |
| 7.4 | Windowed CAPA metrics + disclosure cooldown | Kimi, Mistral, DeepSeek | SHIPPED — `last_n` windows on both rates; cooldown suppresses cadence-only disclosures, never CLA-R3 MUSTs |
| 7.5 | Streaming/incremental audit | Grok, Mistral | SHIPPED — `StreamingAuditor` (feed / update_counts / gated checkpoint; evidence tiers don't blend) |
| 7.6 | Stakes-classifier helper | Kimi, Mistral | SHIPPED — `cla/stakes_classifier.py`, deterministic patterns, provenance `heuristic`, unmatched defaults to MEDIUM (round up); PBHP mapping preferred when integrated |
| 7.7 | Context-composition beyond the scalar | Kimi, Gemini, GPT | PARTIAL by design — `cla/composition.py` ships spike + harness-reported compaction EVENT disclosure; attention-level quality scoring deliberately excluded (a number that can't be defended is worse than none). Silent provider compaction stays a §15 limitation |
| 7.8 | Programmatic handoff builder | Gemini, Grok, Kimi | SHIPPED — `cla/handoff.py`; degraded-conditions label mandatory at DEGRADED+, override history surfaced |
| 7.9 | Operator guide | Mistral | SHIPPED — `OPERATOR_GUIDE.md` |
| 7.10 | Optional standalone signing | Mistral | SHIPPED — `cla/signing.py`, lazy optional `cryptography` import; core stays dependency-free |

The single most repeated structural critique (Kimi said it sharpest): the scalar load fraction is an odometer, not a health panel. v0.1's answer is twofold: honest scoping (§15.1–2) plus event-level composition disclosure (7.7) — what is observable gets disclosed, what is not measurable gets named as a limitation instead of faked as a score. Do not let any public claim drift past what a scalar plus events supports.

## 8. Pre-release checklist (round-three review, 2026-06-05)

1. Clean repo export: no `__pycache__`, no pytest caches, no stale file copies (stale uploads caused two false defect reports across review rounds — GPT round 2 and DeepSeek round 3 both audited outdated files).
2. Commit pytest output (or CI badge) to the repo so the 75/75 claim is independently checkable — reviewers cannot verify a number they cannot see.
3. Public demos lead with MEASURED mode. CLA-SR appears only as the labeled spare tire.
4. Public pitch always pairs the gas-gauge hook with the scope caveat: context load is a runtime risk indicator, not a full quality score.
5. The §13.1 differential-disclosure experiment is the launch artifact: baseline interface confidently producing at 92% load vs CLA-instrumented hard refusal, side by side.

## 9. v0.2 backlog (round-three items, logged with attribution)

| Item | Source |
|---|---|
| `model_id` field on `ThresholdPolicy` with cross-field validation (naming convention is fragile) | Kimi |
| Sliding-window receipt iterator / pluggable backend for unbounded logs | Kimi, DeepSeek |
| Cross-session and per-operator CAPA trend helpers | Kimi |
| `StreamingAuditor.reset_to_measured()` for mixed-evidence harnesses | Kimi |
| Localized stakes-classifier rule packs (current patterns are English-centric) | Kimi |
| CLI tool (`cla simulate`, `cla verify`) | Mistral |
| Drop-in tokenizer helpers (tiktoken / HF) + provider wrapper examples | Grok, Mistral |
| Pre-computed example calibration profiles per major model | Grok |
| Observability exporters (Prometheus/OTel) | Grok |
| Bootstrap confidence intervals on calibration breakpoints | DeepSeek |
| Composition `reason` field enrichment | DeepSeek, Grok |
| Handoff fact-verify mode — **SHIPPED 2026-06-24 (R-2026-06-24-06)**: `cla.verify_handoff` + `build_handoff(verifier=...)`; claims labeled CONFIRMED/UNCONFIRMED/MISMATCH/UNVERIFIABLE against a harness-supplied checker; 85 CLA tests green. (Justification on record: the 2026-06-05 F1 incident — recall-based status reporting carried false file-existence claims through two handoffs; R-2026-06-05-04; spec §13.3.) | DeepSeek, Grok |
