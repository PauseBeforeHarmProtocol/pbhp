"""Example: wrapping an LLM call with a Context Load Audit.

Demonstrates the full loop against a fake LLM client:

  1. Harness measures load (from API usage counts — never model self-report)
  2. Band classified under the versioned policy
  3. Stakes-aware gate evaluated
  4. Receipt written BEFORE the output is committed (no log = no action)
  5. Disclosure attached to the output, or refusal returned

Run:  python examples/wrapper_example.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cla import audit, append_receipt
from cla.gate import Stakes, Verdict
from cla.disclosure import format_disclosure_block
from cla.thresholds import classify_band

RECEIPT_LOG = Path(__file__).parent / "cla_receipts.jsonl"


class FakeLLMClient:
    """Stands in for a real provider SDK. The only thing that matters:
    real SDKs return usage counts (e.g. usage.input_tokens) — measured,
    harness-side evidence. That is what CLA runs on."""

    MAX_TOKENS = 200_000

    def __init__(self, simulated_used_tokens: int):
        self.used = simulated_used_tokens

    def count_session_tokens(self) -> int:
        return self.used

    def complete(self, prompt: str) -> str:
        return "[model output for: {!r}]".format(prompt[:40])


def guarded_call(client: FakeLLMClient, prompt: str, stakes: str) -> str:
    """The CLA-instrumented call path."""
    out = audit(
        used_tokens=client.count_session_tokens(),
        max_tokens=client.MAX_TOKENS,
        stakes=stakes,
        actor_id="cla:example:wrapper",
    )

    # Receipt BEFORE action. If this write fails, we do not call the model.
    append_receipt(RECEIPT_LOG, out["receipt"])

    verdict = out["gate"].verdict
    if verdict == Verdict.REFUSE_REFRESH:
        return format_disclosure_block(out["reading"], out["band"], out["gate"])
    if verdict == Verdict.PAUSE_RECOMMEND_REFRESH:
        # A real harness would surface this to the operator and wait.
        # Here we just show the block and stop.
        return format_disclosure_block(out["reading"], out["band"], out["gate"])

    response = client.complete(prompt)
    return "{}\n\n---\n{}".format(response, out["disclosure"])


if __name__ == "__main__":
    print("=== Scenario 1: fresh session, low stakes ===")
    print(guarded_call(FakeLLMClient(simulated_used_tokens=18_000),
                       "Fix the typo in this sentence.", Stakes.LOW))

    print("\n=== Scenario 2: mid-session, high stakes ===")
    print(guarded_call(FakeLLMClient(simulated_used_tokens=144_600),
                       "Draft the public statement.", Stakes.HIGH))

    print("\n=== Scenario 3: late session, high stakes -> refusal ===")
    print(guarded_call(FakeLLMClient(simulated_used_tokens=185_000),
                       "Finalize the regulatory submission.", Stakes.HIGH))

    print("\nReceipts written to: {}".format(RECEIPT_LOG))
