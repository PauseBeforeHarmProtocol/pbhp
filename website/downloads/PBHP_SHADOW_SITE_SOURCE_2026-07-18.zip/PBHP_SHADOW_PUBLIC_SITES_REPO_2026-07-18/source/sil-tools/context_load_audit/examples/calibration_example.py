"""Example: calibrating CLA bands against a (simulated) model.

In production, replace `simulated_eval` with a function that actually
runs YOUR model on YOUR task suite at the target load fraction (e.g.,
RULER/NoLiMa-style retrieval tasks padded to length) and returns the
measured quality in [0, 1]. The library contributes the sweep and the
band-recommendation logic; the empirical content is yours.

Run:  python examples/calibration_example.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from cla.calibrate import run_calibration, recommend_bands


def simulated_eval(load_fraction: float) -> float:
    """Stand-in degradation curve: quality holds, then sags, then drops.
    Shaped after the RULER finding that effective context is a fraction
    of advertised context. Deterministic for the demo."""
    if load_fraction <= 0.40:
        return 0.97
    if load_fraction <= 0.60:
        return 0.93
    if load_fraction <= 0.80:
        return 0.87
    return 0.74


if __name__ == "__main__":
    points = run_calibration(simulated_eval)
    print("Calibration sweep:")
    for p in points:
        print("  load {:>4.0%}  quality {:.2f}".format(p.load_fraction, p.quality_score))

    policy = recommend_bands(points, model_id="simulated-model-v1")
    print("\nRecommended policy:", policy.policy_id, policy.policy_version)
    print("  NOMINAL  < {:.0%}".format(policy.nominal_max))
    print("  ELEVATED < {:.0%}".format(policy.elevated_max))
    print("  DEGRADED < {:.0%}".format(policy.degraded_max))
    print("  CRITICAL >= {:.0%}".format(policy.degraded_max))
    print("\nRecord this policy id/version in your receipts; re-calibrate per model.")
