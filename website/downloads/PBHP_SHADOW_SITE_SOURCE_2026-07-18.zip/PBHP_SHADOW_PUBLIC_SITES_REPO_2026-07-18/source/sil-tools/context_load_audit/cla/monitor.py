"""Harness-level context load measurement.

The monitor lives OUTSIDE the model. It computes load from token
counts that the calling harness measures or estimates. It never asks
the model how full it feels. (CLA-R1: a model's self-report of its own
context state is not a measurement and must never substitute for one.
The CLA-SR fallback in selfreport.py exists only for surfaces where no
harness measurement is possible, and is labeled as the weakest tier.)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

from cla.estimators import estimate_tokens_from_text


class LoadProvenance(Enum):
    """Where the load number came from. Always disclosed (CLA-R2).

    Evidence hierarchy, best to worst:
    MEASURED > ESTIMATED > SELF_REPORTED > UNKNOWN.
    Each tier is permitted only when every better tier is unavailable.
    """

    MEASURED = "measured"            # exact counts from provider API / harness
    ESTIMATED = "estimated"          # tokenizer or character heuristic
    SELF_REPORTED = "self-reported"  # model's own estimate; CLA-SR fallback only
    UNKNOWN = "unknown"              # nothing measurable; disclosed, never guessed


@dataclass
class ContextLoadReading:
    """A single point-in-time load reading.

    `fraction` is used_tokens / max_tokens in [0, 1+]. It can exceed
    1.0 when a harness overruns into compaction; the reading preserves
    that fact rather than clamping it away.
    """

    used_tokens: Optional[int]
    max_tokens: Optional[int]
    fraction: Optional[float]
    provenance: LoadProvenance
    source: str  # e.g. "api_usage_counts", "char_heuristic", "model_self_report", "none"
    timestamp: str
    basis: Optional[str] = None  # CLA-SR: the observable signals behind a self-report
    declared_margin: Optional[float] = None  # overrides policy default margin when set
                                              # (e.g., tokenizer readings carry 0.10)

    @property
    def percent(self) -> Optional[float]:
        """Load as a percentage, or None when UNKNOWN."""
        return None if self.fraction is None else round(self.fraction * 100.0, 1)

    def to_dict(self) -> dict:
        return {
            "used_tokens": self.used_tokens,
            "max_tokens": self.max_tokens,
            "fraction": self.fraction,
            "percent": self.percent,
            "provenance": self.provenance.value,
            "source": self.source,
            "timestamp": self.timestamp,
            "basis": self.basis,
            "declared_margin": self.declared_margin,
        }


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class ContextLoadMonitor:
    """Builds readings from whatever evidence the harness actually has.

    Four entry points, by evidence quality:

      reading_from_counts(used)              -> MEASURED   (exact counts)
      reading_from_text(text)                -> ESTIMATED  (raw text only)
      reading_from_self_report(pct, basis)   -> SELF_REPORTED (CLA-SR, last resort)
      reading_unknown()                      -> UNKNOWN    (nothing available)

    `add_turn(text)` lets a harness accumulate an estimated running
    total across turns when the provider exposes no counts at all.
    """

    def __init__(self, max_tokens: Optional[int] = None):
        if max_tokens is not None and max_tokens <= 0:
            raise ValueError(
                "ContextLoadMonitor refuses to run: max_tokens must be a "
                "positive integer or None, got {!r}.".format(max_tokens)
            )
        self.max_tokens = max_tokens
        self._accumulated_estimate: int = 0

    # -- MEASURED ----------------------------------------------------------

    def reading_from_counts(self, used_tokens: int) -> ContextLoadReading:
        """Exact counts from the provider API. The gold standard."""
        if used_tokens < 0:
            raise ValueError("used_tokens must be >= 0, got {!r}.".format(used_tokens))
        if self.max_tokens is None:
            # A count without a window is still better than nothing, but
            # no fraction can be computed -> provenance stays MEASURED,
            # fraction is None and band will be UNKNOWN (fail-honest).
            return ContextLoadReading(
                used_tokens=used_tokens,
                max_tokens=None,
                fraction=None,
                provenance=LoadProvenance.MEASURED,
                source="api_usage_counts_no_window",
                timestamp=_now_iso(),
            )
        return ContextLoadReading(
            used_tokens=used_tokens,
            max_tokens=self.max_tokens,
            fraction=used_tokens / self.max_tokens,
            provenance=LoadProvenance.MEASURED,
            source="api_usage_counts",
            timestamp=_now_iso(),
        )

    # -- ESTIMATED ---------------------------------------------------------

    def reading_from_text(self, text: str) -> ContextLoadReading:
        """Character-heuristic estimate from raw conversation text."""
        used = estimate_tokens_from_text(text)
        if self.max_tokens is None:
            return ContextLoadReading(
                used_tokens=used,
                max_tokens=None,
                fraction=None,
                provenance=LoadProvenance.ESTIMATED,
                source="char_heuristic_no_window",
                timestamp=_now_iso(),
            )
        return ContextLoadReading(
            used_tokens=used,
            max_tokens=self.max_tokens,
            fraction=used / self.max_tokens,
            provenance=LoadProvenance.ESTIMATED,
            source="char_heuristic",
            timestamp=_now_iso(),
        )

    def add_turn(self, text: str) -> ContextLoadReading:
        """Accumulate an estimated running total across turns."""
        self._accumulated_estimate += estimate_tokens_from_text(text)
        if self.max_tokens is None:
            return ContextLoadReading(
                used_tokens=self._accumulated_estimate,
                max_tokens=None,
                fraction=None,
                provenance=LoadProvenance.ESTIMATED,
                source="char_heuristic_accumulated_no_window",
                timestamp=_now_iso(),
            )
        return ContextLoadReading(
            used_tokens=self._accumulated_estimate,
            max_tokens=self.max_tokens,
            fraction=self._accumulated_estimate / self.max_tokens,
            provenance=LoadProvenance.ESTIMATED,
            source="char_heuristic_accumulated",
            timestamp=_now_iso(),
        )

    def reading_from_tokenizer(self, text: str, encode_fn) -> ContextLoadReading:
        """Real-tokenizer estimate (roadmap 7.1). Better than chars/4,
        still ESTIMATED: the tokenizer counts the text the harness can
        see, not provider-side additions. Carries a declared 10% margin
        instead of the char heuristic's 30%.

        `encode_fn(text)` returns a token count (int) or a sequence
        whose len() is the count — covers tiktoken-style .encode and
        plain counting callables.
        """
        result = encode_fn(text)
        used = result if isinstance(result, int) else len(result)
        if used < 0:
            raise ValueError("tokenizer returned a negative count; refusing.")
        from cla.estimators import TOKENIZER_RELATIVE_ERROR
        if self.max_tokens is None:
            return ContextLoadReading(
                used_tokens=used, max_tokens=None, fraction=None,
                provenance=LoadProvenance.ESTIMATED,
                source="tokenizer_no_window", timestamp=_now_iso(),
                declared_margin=TOKENIZER_RELATIVE_ERROR,
            )
        return ContextLoadReading(
            used_tokens=used, max_tokens=self.max_tokens,
            fraction=used / self.max_tokens,
            provenance=LoadProvenance.ESTIMATED,
            source="tokenizer", timestamp=_now_iso(),
            declared_margin=TOKENIZER_RELATIVE_ERROR,
        )

    def add_tokens(self, token_count: int) -> ContextLoadReading:
        """Accumulate an exact-ish token count (tokenizer-fed streaming)."""
        if token_count < 0:
            raise ValueError("token_count must be >= 0.")
        from cla.estimators import TOKENIZER_RELATIVE_ERROR
        self._accumulated_estimate += token_count
        if self.max_tokens is None:
            return ContextLoadReading(
                used_tokens=self._accumulated_estimate, max_tokens=None,
                fraction=None, provenance=LoadProvenance.ESTIMATED,
                source="tokenizer_accumulated_no_window", timestamp=_now_iso(),
                declared_margin=TOKENIZER_RELATIVE_ERROR,
            )
        return ContextLoadReading(
            used_tokens=self._accumulated_estimate, max_tokens=self.max_tokens,
            fraction=self._accumulated_estimate / self.max_tokens,
            provenance=LoadProvenance.ESTIMATED,
            source="tokenizer_accumulated", timestamp=_now_iso(),
            declared_margin=TOKENIZER_RELATIVE_ERROR,
        )

    # -- SELF_REPORTED (CLA-SR fallback) -------------------------------------

    def reading_from_self_report(self, percent: float, basis: str) -> ContextLoadReading:
        """Model self-reported load estimate. LAST-RESORT tier (CLA-R11).

        Permitted only when no measured or estimated path exists — e.g.
        a consumer chat surface with no harness and no meter. `percent`
        is the model's approximate estimate (0-120); `basis` is the
        observable evidence behind it (turn count, pasted volume,
        thread-loss symptoms). A self-report without a basis is refused:
        an unexplained number is indistinguishable from a fabricated one.

        Some brake is better than no brake — but the label stays honest:
        provenance is SELF_REPORTED, the band classifier applies the
        larger self-report error margin, and the disclosure renders the
        value with a tilde, never as a measurement.
        """
        if not isinstance(percent, (int, float)) or isinstance(percent, bool):
            raise TypeError(
                "reading_from_self_report refuses to run: percent must be a "
                "number, got {!r}.".format(type(percent).__name__)
            )
        if not (0.0 <= float(percent) <= 120.0):
            raise ValueError(
                "reading_from_self_report refuses to run: percent must be in "
                "[0, 120], got {!r}. A self-report outside that range is not "
                "an estimate, it is noise.".format(percent)
            )
        if not basis or not str(basis).strip():
            raise ValueError(
                "reading_from_self_report refuses to run: a non-empty basis is "
                "required (CLA-R11). Name the observable signals — turn count, "
                "pasted volume, thread-loss symptoms — or report UNKNOWN instead."
            )
        return ContextLoadReading(
            used_tokens=None,
            max_tokens=self.max_tokens,
            fraction=float(percent) / 100.0,
            provenance=LoadProvenance.SELF_REPORTED,
            source="model_self_report",
            timestamp=_now_iso(),
            basis=str(basis).strip(),
        )

    # -- UNKNOWN -----------------------------------------------------------

    def reading_unknown(self) -> ContextLoadReading:
        """Nothing measurable. Disclosed as such — never fabricated (CLA-R8)."""
        return ContextLoadReading(
            used_tokens=None,
            max_tokens=self.max_tokens,
            fraction=None,
            provenance=LoadProvenance.UNKNOWN,
            source="none",
            timestamp=_now_iso(),
        )
