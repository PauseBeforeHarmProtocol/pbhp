"""Context-composition event disclosure (roadmap 7.7).

Honesty boundary, stated up front: the literature (Chroma 2025; Liu et
al. 2024) shows degradation depends on context COMPOSITION — where the
relevant tokens sit, how distracting the rest is — not just on raw
load. A client-side library cannot measure attention or score response
quality. What it CAN do honestly is disclose composition EVENTS that
are deterministically observable at the harness:

  - load spikes (e.g., a RAG payload landing mid-session),
  - compaction events (when the harness performs or is told about
    summarization/truncation of earlier context),
  - estimated dilution (how much of the window one injection consumed).

These are event disclosures, not quality scores. Anything resembling a
"context health index" is deliberately absent: a number that cannot be
defended is worse than no number (CLA-R8 spirit).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# A single-turn load increase at or above this fraction of the window
# is disclosed as a spike. Policy-tunable via the function argument.
DEFAULT_SPIKE_THRESHOLD = 0.15


@dataclass(frozen=True)
class CompositionEvent:
    kind: str          # "load_spike" | "compaction" | "bulk_injection"
    detail: str
    delta_fraction: Optional[float]
    timestamp: str

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "detail": self.detail,
            "delta_fraction": self.delta_fraction,
            "timestamp": self.timestamp,
        }


def detect_load_spike(
    prev_fraction: Optional[float],
    new_fraction: float,
    threshold: float = DEFAULT_SPIKE_THRESHOLD,
) -> Optional[CompositionEvent]:
    """Disclose a single-step load jump >= threshold (e.g., RAG payload).

    A spike is not inherently bad — but a session that went 30% -> 70%
    in one turn has a very different composition than one that grew
    there gradually, and the operator should know which one they have.
    Returns None when no spike occurred.
    """
    if new_fraction is None:
        return None
    prev = prev_fraction or 0.0
    delta = new_fraction - prev
    if delta >= threshold:
        return CompositionEvent(
            kind="load_spike",
            detail=(f"context load jumped {prev:.0%} -> {new_fraction:.0%} in one step "
                    f"(+{delta:.0%}); bulk injection (e.g., RAG/document paste) likely"),
            delta_fraction=round(delta, 4),
            timestamp=_now_iso(),
        )
    return None


def record_compaction_event(detail: str, freed_fraction: Optional[float] = None) -> CompositionEvent:
    """Disclose a compaction the HARNESS knows about (it performed it, or
    the provider reported it). Client code cannot detect silent provider
    compaction; this function exists for the cases where the information
    exists, so it reaches the operator instead of dying in a log.

    Compaction means earlier content was summarized or dropped: the load
    number may go DOWN while fidelity to early context also goes down.
    A post-compaction session is not a fresh session and must not be
    presented as one.
    """
    if not detail or not detail.strip():
        raise ValueError("record_compaction_event refuses to run: detail is required. "
                         "An unexplained compaction event is no disclosure at all.")
    return CompositionEvent(
        kind="compaction",
        detail=detail.strip() + " [NOTE: post-compaction sessions retain less early-context "
               "fidelity than the load number suggests]",
        delta_fraction=(-freed_fraction if freed_fraction else None),
        timestamp=_now_iso(),
    )
