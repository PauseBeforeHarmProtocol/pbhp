"""Calibration harness for band thresholds (spec section 13.2; roadmap 7.2).

CLA's default bands are literature-informed policy, not measured
constants. This module makes calibration operational WITHOUT
pretending the library can measure model quality itself: the
organization supplies `eval_fn` — a callable that runs THEIR model on
THEIR task suite at a given load fraction and returns a quality score
in [0, 1]. This module sweeps load levels, finds where the quality
curve crosses the org's acceptance thresholds, and emits a versioned
ThresholdPolicy.

The library's contribution is the deterministic sweep + band
recommendation logic; the empirical content comes from the caller.
See examples/calibration_example.py for a simulated end-to-end run.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional, Sequence

from cla.thresholds import ThresholdPolicy


@dataclass(frozen=True)
class CalibrationPoint:
    load_fraction: float
    quality_score: float  # [0, 1], as measured by the caller's eval_fn

    def to_dict(self) -> dict:
        return {"load_fraction": self.load_fraction, "quality_score": self.quality_score}


DEFAULT_LOAD_LEVELS = (0.10, 0.25, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95)


def run_calibration(
    eval_fn: Callable[[float], float],
    load_levels: Sequence[float] = DEFAULT_LOAD_LEVELS,
) -> List[CalibrationPoint]:
    """Sweep load levels through the caller's quality evaluator.

    `eval_fn(load_fraction) -> quality in [0, 1]`. The caller is
    responsible for making eval_fn actually exercise a model at that
    load (e.g., RULER/NoLiMa-style tasks padded to the target length).
    Deterministic given a deterministic eval_fn.
    """
    if not callable(eval_fn):
        raise TypeError("run_calibration refuses to run: eval_fn must be callable.")
    points = []
    for level in sorted(set(load_levels)):
        if not (0.0 < level <= 1.2):
            raise ValueError(f"load level {level} outside (0, 1.2].")
        q = float(eval_fn(level))
        if not (0.0 <= q <= 1.0):
            raise ValueError(
                f"eval_fn returned {q} at load {level}; quality must be in [0, 1]. "
                "Fail-honest: do not normalize silently."
            )
        points.append(CalibrationPoint(level, q))
    return points


def _first_crossing(points: List[CalibrationPoint], floor: float) -> Optional[float]:
    """Lowest load fraction at which quality drops below `floor`."""
    for p in points:  # points are sorted by load
        if p.quality_score < floor:
            return p.load_fraction
    return None


def recommend_bands(
    points: List[CalibrationPoint],
    *,
    elevated_quality_floor: float = 0.95,
    degraded_quality_floor: float = 0.90,
    critical_quality_floor: float = 0.80,
    model_id: str = "unspecified-model",
    base_policy: ThresholdPolicy = ThresholdPolicy(),
) -> ThresholdPolicy:
    """Place band boundaries where the measured quality curve breaks.

    nominal_max  = load where quality first drops below elevated_quality_floor
    elevated_max = load where quality first drops below degraded_quality_floor
    degraded_max = load where quality first drops below critical_quality_floor

    Where the curve never crosses a floor, the default (conservative)
    boundary is kept — calibration may only ever LOOSEN a bound when
    the evidence says quality holds, never silently tighten acceptance
    floors. Returns a NEW versioned policy; the default policy is never
    mutated.
    """
    if len(points) < 3:
        raise ValueError(
            "recommend_bands refuses to run: need at least 3 calibration "
            "points. A two-point curve is a line, not evidence."
        )
    if not (critical_quality_floor < degraded_quality_floor < elevated_quality_floor):
        raise ValueError("quality floors must satisfy critical < degraded < elevated.")
    pts = sorted(points, key=lambda p: p.load_fraction)

    nominal = _first_crossing(pts, elevated_quality_floor) or base_policy.nominal_max
    elevated = _first_crossing(pts, degraded_quality_floor) or base_policy.elevated_max
    degraded = _first_crossing(pts, critical_quality_floor) or base_policy.degraded_max

    # Enforce strict ordering; under doubt, round down (tighter bands).
    elevated = max(elevated, nominal + 0.01)
    degraded = max(degraded, elevated + 0.01)

    return ThresholdPolicy(
        nominal_max=round(nominal, 4),
        elevated_max=round(elevated, 4),
        degraded_max=round(degraded, 4),
        estimate_margin=base_policy.estimate_margin,
        self_report_margin=base_policy.self_report_margin,
        policy_id=f"calibrated-{model_id}",
        policy_version="1.0.0",
    )
