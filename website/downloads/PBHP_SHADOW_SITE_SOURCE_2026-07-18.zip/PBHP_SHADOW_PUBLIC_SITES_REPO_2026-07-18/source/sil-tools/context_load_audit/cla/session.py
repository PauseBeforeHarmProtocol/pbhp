"""Session-level audit state: band-transition tracking (CLA-R3).

CLA-R3 requires disclosure (a) before any output of MEDIUM stakes or
above, and (b) on every band transition regardless of stakes. The
per-call functions can't see yesterday's band; this tracker can. A
harness keeps one SessionAuditState per session and consults it on
every reading.

Also folds in the CLA-SR milestone cadence (selfreport.MILESTONES) so
a single update() call answers the one question the harness actually
has: "do I owe the operator a disclosure right now, and why?"

Cooldown (roadmap 7.4): an optional anti-fatigue window that may
suppress CADENCE-ONLY disclosures (milestones). It never suppresses
the normative MUSTs — MEDIUM+ stakes or a band transition always
require disclosure regardless of cooldown. A safety control that nags
gets uninstalled; one that hides mandatory warnings is defective.

Serialization (roadmap 7.3): to_dict()/from_dict() let a harness
persist session state across process restarts.
"""

from __future__ import annotations

import time
from typing import List, Optional

from cla.gate import Stakes
from cla.monitor import ContextLoadReading
from cla.selfreport import milestones_crossed
from cla.thresholds import LoadBand


_DISCLOSURE_STAKES = (Stakes.MEDIUM, Stakes.HIGH, Stakes.CRITICAL)


class SessionAuditState:
    """Remembers the previous band/fraction; reports what changed.

    update() is deterministic given (stored state, inputs, now), and
    stores the new state. Reasons are returned as strings so the
    harness can put them straight into the disclosure or the receipt
    notes field.
    """

    def __init__(self, cooldown_seconds: float = 0.0):
        if cooldown_seconds < 0:
            raise ValueError("cooldown_seconds must be >= 0.")
        self.prev_band: Optional[LoadBand] = None
        self.prev_fraction: Optional[float] = None
        self.updates: int = 0
        self.cooldown_seconds = cooldown_seconds
        self.last_disclosure_at: Optional[float] = None  # epoch seconds

    # -- persistence (roadmap 7.3) -------------------------------------------

    def to_dict(self) -> dict:
        return {
            "prev_band": self.prev_band.value if self.prev_band else None,
            "prev_fraction": self.prev_fraction,
            "updates": self.updates,
            "cooldown_seconds": self.cooldown_seconds,
            "last_disclosure_at": self.last_disclosure_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SessionAuditState":
        s = cls(cooldown_seconds=d.get("cooldown_seconds", 0.0))
        pb = d.get("prev_band")
        s.prev_band = LoadBand(pb) if pb else None
        s.prev_fraction = d.get("prev_fraction")
        s.updates = d.get("updates", 0)
        s.last_disclosure_at = d.get("last_disclosure_at")
        return s

    # -- the one call that matters ---------------------------------------------

    def update(
        self,
        reading: ContextLoadReading,
        band: LoadBand,
        stakes: str,
        *,
        now: Optional[float] = None,
    ) -> dict:
        if stakes not in Stakes.ALL:
            raise ValueError(
                "SessionAuditState.update refuses to run: stakes must be one "
                f"of {Stakes.ALL}, got {stakes!r}."
            )
        t = time.time() if now is None else now

        band_transition = self.prev_band is not None and band != self.prev_band
        crossed: List[float] = []
        if reading.fraction is not None:
            crossed = milestones_crossed(self.prev_fraction, reading.fraction)

        mandatory: List[str] = []
        cadence: List[str] = []
        if stakes in _DISCLOSURE_STAKES:
            mandatory.append("stakes {} require pre-output disclosure (CLA-R3)".format(stakes))
        if band_transition:
            mandatory.append("band transition {} -> {} (CLA-R3)".format(
                self.prev_band.value, band.value))
        if self.updates == 0:
            mandatory.append("first reading of session")
        if crossed:
            cadence.append("milestone(s) crossed: {} (CLA-R11 cadence)".format(
                ", ".join("{:.0f}%".format(m * 100) for m in crossed)))

        suppressed = False
        if (not mandatory and cadence and self.cooldown_seconds > 0
                and self.last_disclosure_at is not None
                and (t - self.last_disclosure_at) < self.cooldown_seconds):
            # Cooldown applies to cadence-only disclosures. MUSTs above
            # are never suppressed.
            suppressed = True

        reasons = mandatory + cadence
        disclosure_required = bool(reasons) and not suppressed

        result = {
            "disclosure_required": disclosure_required,
            "band_transition": band_transition,
            "previous_band": self.prev_band.value if self.prev_band else None,
            "current_band": band.value,
            "milestones_crossed": crossed,
            "reasons": reasons,
            "suppressed_by_cooldown": suppressed,
        }

        # Store new state AFTER computing the diff.
        self.prev_band = band
        if reading.fraction is not None:
            self.prev_fraction = reading.fraction
        self.updates += 1
        if disclosure_required:
            self.last_disclosure_at = t
        return result
