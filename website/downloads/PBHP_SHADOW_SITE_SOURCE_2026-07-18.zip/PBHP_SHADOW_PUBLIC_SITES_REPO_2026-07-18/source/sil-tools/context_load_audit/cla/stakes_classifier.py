"""Heuristic stakes classification helper (roadmap 7.6).

Stakes determination is ultimately the harness's job — it knows the
recipient, the blast radius, the reversibility. This module exists for
harnesses that have nothing better: a deterministic, pattern-based
first pass with its own honesty labels. It is a conservative heuristic,
NOT an authority; when integrated with PBHP, use the harm-threshold
mapping (`gate.stakes_from_pbhp_threshold`) instead.

Rules mirror the spec's section 3 anchors. First match wins; no match
falls to MEDIUM (round up from LOW under doubt — an unclassified
request is not evidence of low stakes).

Known limit: the patterns are English-centric. Non-English requests
fall through to the MEDIUM default — a bounded failure, not a silent
LOW. Localized rule packs are a v0.2 item.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

from cla.gate import Stakes


@dataclass(frozen=True)
class StakesAssessment:
    stakes: str
    matched_rule: Optional[str]
    basis: str
    provenance: str = "heuristic"  # never pretend this is the harness's judgment

    def to_dict(self) -> dict:
        return {
            "stakes": self.stakes,
            "matched_rule": self.matched_rule,
            "basis": self.basis,
            "provenance": self.provenance,
        }


_CRITICAL_RULES: List[Tuple[str, re.Pattern]] = [
    ("CRIT-regulatory-submission",
     re.compile(r"(?i)\b(regulatory|fda|510\(k\)|ce[- ]mark|ind|nda|submission to (the )?(fda|ema|agency))\b")),
    ("CRIT-medical-legal-advice",
     re.compile(r"(?i)\b(medical (advice|dosage|diagnos)|legal (advice|opinion|filing)|prescri(be|ption)|contract (execution|signing))\b")),
    ("CRIT-safety-compliance",
     re.compile(r"(?i)\b(safety[- ]critical|compliance (filing|attestation|report)|audit response|capa (closure|response))\b")),
    ("CRIT-public-record",
     re.compile(r"(?i)\b(press release|public statement|sec filing|earnings (report|call)|testimony)\b")),
]

_HIGH_RULES: List[Tuple[str, re.Pattern]] = [
    ("HIGH-third-party-published",
     re.compile(r"(?i)\b(publish|post (to|on)|send to (client|customer|vendor)|customer[- ]facing|external (email|memo|report))\b")),
    ("HIGH-production-deploy",
     re.compile(r"(?i)\b(deploy|ship|release|merge)\b.*\b(prod(uction)?|live|main)\b")),
    ("HIGH-irreversible",
     re.compile(r"(?i)\b(delete|terminate|cancel (the )?(contract|account)|broadcast|mass (email|message))\b")),
]

_LOW_RULES: List[Tuple[str, re.Pattern]] = [
    ("LOW-self-rework",
     re.compile(r"(?i)\b(typo|spelling|grammar|reformat|rename|convert .* to (json|yaml|csv|markdown)|summarize my (notes|draft))\b")),
    ("LOW-brainstorm",
     re.compile(r"(?i)\b(brainstorm|rough (ideas|draft)|just for me|scratch(pad)?)\b")),
]


def classify_stakes(request_text: str) -> StakesAssessment:
    """Deterministic pattern-based stakes assessment. First match wins.

    Order: CRITICAL rules, then HIGH, then LOW; no match -> MEDIUM.
    The unmatched default is MEDIUM, not LOW: absence of a match is
    absence of evidence, and stakes round up under doubt.
    """
    if not isinstance(request_text, str) or not request_text.strip():
        raise ValueError(
            "classify_stakes refuses to run: request_text must be a non-empty "
            "string. Classifying nothing as low-stakes is how gates get bypassed."
        )
    for rule_id, pat in _CRITICAL_RULES:
        if pat.search(request_text):
            return StakesAssessment(Stakes.CRITICAL, rule_id,
                                    "matched critical-stakes pattern")
    for rule_id, pat in _HIGH_RULES:
        if pat.search(request_text):
            return StakesAssessment(Stakes.HIGH, rule_id,
                                    "matched high-stakes pattern")
    for rule_id, pat in _LOW_RULES:
        if pat.search(request_text):
            return StakesAssessment(Stakes.LOW, rule_id,
                                    "matched low-stakes (self-rework) pattern")
    return StakesAssessment(Stakes.MEDIUM, None,
                            "no pattern matched; defaulting to MEDIUM (round up under doubt)")
