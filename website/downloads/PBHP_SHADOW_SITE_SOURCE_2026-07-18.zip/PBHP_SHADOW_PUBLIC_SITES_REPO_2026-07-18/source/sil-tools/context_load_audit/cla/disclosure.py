"""Disclosure formatting.

Two formats:
  - a compact one-liner for per-response display, and
  - a multi-line block for pause/refuse verdicts.

Both always carry provenance (CLA-R2). An UNKNOWN reading is rendered
as UNMEASURED — the tool never prints a number it does not have
(CLA-R8). A SELF_REPORTED reading (CLA-SR) is rendered with a tilde
and an explicit not-a-measurement caution (CLA-R11).
"""

from __future__ import annotations

from cla.gate import GateResult, Verdict
from cla.monitor import ContextLoadReading, LoadProvenance
from cla.thresholds import LoadBand, ThresholdPolicy, DEFAULT_POLICY


def _load_phrase(reading: ContextLoadReading) -> str:
    if reading.provenance == LoadProvenance.UNKNOWN or reading.percent is None:
        return "load: UNMEASURED"
    if reading.provenance == LoadProvenance.SELF_REPORTED:
        # Tilde marks approximation; the label never lets a self-report
        # pass as a measurement (CLA-R11).
        return "self-reported load: ~{}%".format(reading.percent)
    return "load: {}% ({})".format(reading.percent, reading.provenance.value)


def format_disclosure_line(
    reading: ContextLoadReading,
    band: LoadBand,
    gate: GateResult,
    policy: ThresholdPolicy = DEFAULT_POLICY,
) -> str:
    """Compact per-response disclosure line.

    Example:
      CLA v0.1 | load: 72.3% (measured) | band: ELEVATED | stakes: HIGH |
      verdict: PROCEED_WITH_DISCLOSURE | refresh at: 90% | policy: cla-default/0.1.0
    """
    header = "CLA-SR v0.1" if reading.provenance == LoadProvenance.SELF_REPORTED else "CLA v0.1"
    parts = [
        header,
        _load_phrase(reading),
    ]
    if reading.provenance == LoadProvenance.SELF_REPORTED and reading.basis:
        parts.append("basis: {}".format(reading.basis))
    parts += [
        "band: {}".format(band.value),
        "stakes: {}".format(gate.stakes),
        "verdict: {}".format(gate.verdict),
    ]
    if band not in (LoadBand.UNKNOWN,):
        parts.append("refresh at: {:.0f}%".format(policy.degraded_max * 100))
    if gate.override.get("applied"):
        parts.append("OVERRIDDEN by {} -> {}".format(
            gate.override["operator_id"], gate.effective_verdict))
    elif gate.override.get("ignored_floor"):
        parts.append("override REFUSED (absolute floor held)")
    parts.append("policy: {}/{}".format(policy.policy_id, policy.policy_version))
    return " | ".join(parts)


def format_disclosure_block(
    reading: ContextLoadReading,
    band: LoadBand,
    gate: GateResult,
    policy: ThresholdPolicy = DEFAULT_POLICY,
) -> str:
    """Multi-line disclosure for PAUSE / REFUSE verdicts."""
    if reading.provenance == LoadProvenance.UNKNOWN or reading.percent is None:
        load_line = "Context load: UNMEASURED"
    elif reading.provenance == LoadProvenance.SELF_REPORTED:
        load_line = "Self-reported context load: ~{}%".format(reading.percent)
    else:
        load_line = "Context load: {}% ({})".format(reading.percent, reading.provenance.value)
    lines = [
        "=== CONTEXT LOAD AUDIT ===",
        load_line,
    ]
    if reading.provenance == LoadProvenance.SELF_REPORTED:
        lines.append("Caution: value is a model self-report (weakest evidence tier), "
                     "classified after a 50% conservative inflation. Not a measurement.")
        if reading.basis:
            lines.append("Basis: {}".format(reading.basis))
    lines += [
        "Band: {}".format(band.value),
        "Stakes: {}".format(gate.stakes),
        "Verdict: {}".format(gate.verdict),
        "Reason: {}".format(gate.reason),
        "Policy: {}/{} (bands: <{:.0%} NOMINAL, <{:.0%} ELEVATED, <{:.0%} DEGRADED, else CRITICAL)".format(
            policy.policy_id, policy.policy_version,
            policy.nominal_max, policy.elevated_max, policy.degraded_max,
        ),
    ]
    if gate.verdict in (Verdict.PAUSE_RECOMMEND_REFRESH, Verdict.REFUSE_REFRESH):
        lines.append(
            "Recommended action: summarize state, refresh the session, re-enter "
            "the task clean. The work survives the refresh; degraded output may not."
        )
        lines.append(
            "Operator note (reciprocal): a warning you pressure through is a "
            "warning you have disabled. Take it seriously or log the override."
        )
    if gate.override.get("applied"):
        lines.append("Override: {} -> {} by {} -- \"{}\"".format(
            gate.verdict,
            gate.effective_verdict,
            gate.override["operator_id"],
            gate.override["acknowledgment"],
        ))
    elif gate.override.get("ignored_floor"):
        lines.append("Override attempted by {} but REFUSED -- absolute floor "
                     "({} held). \"{}\"".format(
            gate.override["operator_id"],
            gate.verdict,
            gate.override["acknowledgment"],
        ))
    lines.append("==========================")
    return "\n".join(lines)
