"""Load bands and the threshold policy.

Bands are POLICY, not physics. The long-context literature (Liu et al.
2024 "Lost in the Middle"; NVIDIA RULER; Adobe NoLiMa; Chroma's 2025
context-rot report) shows degradation beginning well below the
advertised window and varying by task and by how distracting the
context is. So the defaults here are deliberately conservative, and
every receipt carries the policy version so an auditor can see exactly
which thresholds were in force (CLA-R4).

Default bands (fraction of max window):

  NOMINAL   [0.00, 0.50)  routine
  ELEVATED  [0.50, 0.75)  disclose on consequential output
  DEGRADED  [0.75, 0.90)  recommend refresh before high-stakes output
  CRITICAL  [0.90, ...)   refuse high-stakes output; refresh required
  UNKNOWN   no measurable reading — handled as its own band, not hidden

Lower-quality evidence rounds UP before classification, using margins
that are themselves policy fields (configurable, versioned, recorded
in receipts): `estimate_margin` (default 0.30, the character
heuristic's documented error band) and `self_report_margin` (default
0.50 — a provisional conservative safety factor, NOT a validated
constant; classification happens at the upper bound of the estimate
plus the margin's relative uncertainty, pending §13.2 calibration).
Under doubt, round up.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from cla.estimators import ESTIMATE_RELATIVE_ERROR, SELF_REPORT_RELATIVE_ERROR
from cla.monitor import ContextLoadReading, LoadProvenance


class LoadBand(Enum):
    NOMINAL = "NOMINAL"
    ELEVATED = "ELEVATED"
    DEGRADED = "DEGRADED"
    CRITICAL = "CRITICAL"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class ThresholdPolicy:
    """Versioned, deterministic threshold policy.

    Carries both the band bounds and the evidence-quality margins, so a
    receipt's policy record fully reconstructs the classification rules
    in force. Organizations SHOULD calibrate bounds and margins against
    their own task suite (see spec section 13, Validation) and MUST
    version any change.
    """

    nominal_max: float = 0.50    # < this -> NOMINAL
    elevated_max: float = 0.75   # < this -> ELEVATED
    degraded_max: float = 0.90   # < this -> DEGRADED; >= this -> CRITICAL
    estimate_margin: float = ESTIMATE_RELATIVE_ERROR        # ESTIMATED round-up
    self_report_margin: float = SELF_REPORT_RELATIVE_ERROR  # CLA-SR round-up (provisional)
    policy_id: str = "cla-default"
    policy_version: str = "0.1.0"

    def __post_init__(self):
        if not (0.0 < self.nominal_max < self.elevated_max < self.degraded_max):
            raise ValueError(
                "ThresholdPolicy refuses to construct: bounds must satisfy "
                "0 < nominal_max < elevated_max < degraded_max. Got "
                f"{self.nominal_max}, {self.elevated_max}, {self.degraded_max}."
            )
        if self.estimate_margin < 0.0 or self.self_report_margin < 0.0:
            raise ValueError(
                "ThresholdPolicy refuses to construct: margins must be >= 0. "
                f"Got estimate_margin={self.estimate_margin}, "
                f"self_report_margin={self.self_report_margin}."
            )

    def to_dict(self) -> dict:
        return {
            "policy_id": self.policy_id,
            "policy_version": self.policy_version,
            "nominal_max": self.nominal_max,
            "elevated_max": self.elevated_max,
            "degraded_max": self.degraded_max,
            "estimate_margin": self.estimate_margin,
            "self_report_margin": self.self_report_margin,
        }


DEFAULT_POLICY = ThresholdPolicy()


def classify_band(reading: ContextLoadReading, policy: ThresholdPolicy = DEFAULT_POLICY) -> LoadBand:
    """Deterministic band classification. Same reading + policy -> same band.

    Rules:
      - UNKNOWN provenance, or no computable fraction -> LoadBand.UNKNOWN.
        The absence of a measurement is surfaced, never papered over.
      - ESTIMATED readings are inflated by policy.estimate_margin before
        classification (round up under doubt).
      - SELF_REPORTED readings (CLA-SR) are inflated by
        policy.self_report_margin — the weakest numeric evidence gets
        the most conservative treatment.
      - MEASURED readings classify at face value.
    """
    if reading.provenance == LoadProvenance.UNKNOWN or reading.fraction is None:
        return LoadBand.UNKNOWN

    fraction = reading.fraction
    if reading.declared_margin is not None:
        # The reading carries its own declared error band (e.g., a real
        # tokenizer's 10%). Recorded in the receipt either way.
        fraction = fraction * (1.0 + reading.declared_margin)
    elif reading.provenance == LoadProvenance.ESTIMATED:
        fraction = fraction * (1.0 + policy.estimate_margin)
    elif reading.provenance == LoadProvenance.SELF_REPORTED:
        fraction = fraction * (1.0 + policy.self_report_margin)

    if fraction < policy.nominal_max:
        return LoadBand.NOMINAL
    if fraction < policy.elevated_max:
        return LoadBand.ELEVATED
    if fraction < policy.degraded_max:
        return LoadBand.DEGRADED
    return LoadBand.CRITICAL
