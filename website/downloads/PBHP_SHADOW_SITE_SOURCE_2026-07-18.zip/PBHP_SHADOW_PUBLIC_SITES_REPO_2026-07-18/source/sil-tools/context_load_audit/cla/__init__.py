"""CLA — Context Load Audit.

A standalone, dependency-free reference implementation of the Context
Load Audit (CLA-1) primitive: deterministic, harness-level measurement
and disclosure of LLM context-window load, with stakes-aware
refuse/refresh gating and append-only audit receipts.

Design rule #1: load is MEASURED BY THE HARNESS whenever a harness
exists. A model's introspective estimate of its own degradation is not
evidence; a token count is. The CLA-SR self-report fallback exists for
surfaces with no meter at all (see selfreport.py) — weakest tier,
hardest conservative inflation, labeled everywhere. Some brake is
better than no brake.

Design rule #2: fail-honest. If load cannot be measured, the tool says
UNKNOWN. It never fabricates a number.

Standalone by default; integrates into PBHP / Project Shadow via
`CLAReceipt.to_pbhp_extension()` and the stakes mapping in `gate.py`.

Concept: Phillip Linstrum, 2026-06-02.
"""

from cla.estimators import (
    estimate_tokens_from_text,
    CHARS_PER_TOKEN,
    SELF_REPORT_RELATIVE_ERROR,
)
from cla.monitor import ContextLoadMonitor, ContextLoadReading, LoadProvenance
from cla.thresholds import LoadBand, ThresholdPolicy, DEFAULT_POLICY, classify_band
from cla.gate import (
    Stakes,
    Verdict,
    GateResult,
    evaluate_gate,
    apply_override,
    stakes_from_pbhp_threshold,
)
from cla.disclosure import format_disclosure_line, format_disclosure_block
from cla.receipt import CLAReceipt, append_receipt, load_receipts
from cla.selfreport import (
    MILESTONES,
    milestones_crossed,
    should_disclose,
    SELF_REPORT_PROTOCOL,
)
from cla.session import SessionAuditState
from cla.gate import gate_policy, gate_matrix_hash, GATE_POLICY_ID, GATE_POLICY_VERSION
from cla.receipt import ReceiptStore, override_rate, degraded_band_rate
from cla.calibrate import CalibrationPoint, run_calibration, recommend_bands
from cla.stakes_classifier import StakesAssessment, classify_stakes
from cla.composition import CompositionEvent, detect_load_spike, record_compaction_event
from cla.handoff import (
    build_handoff,
    verify_handoff,
    HandoffVerification,
    ClaimStatus,
    ClaimCheck,
)
from cla.streaming import StreamingAuditor

__version__ = "0.2.0"

__all__ = [
    "audit",
    "ContextLoadMonitor",
    "ContextLoadReading",
    "LoadProvenance",
    "LoadBand",
    "ThresholdPolicy",
    "DEFAULT_POLICY",
    "classify_band",
    "Stakes",
    "Verdict",
    "GateResult",
    "evaluate_gate",
    "apply_override",
    "stakes_from_pbhp_threshold",
    "format_disclosure_line",
    "format_disclosure_block",
    "CLAReceipt",
    "append_receipt",
    "load_receipts",
    "estimate_tokens_from_text",
    "CHARS_PER_TOKEN",
    "SELF_REPORT_RELATIVE_ERROR",
    "MILESTONES",
    "milestones_crossed",
    "should_disclose",
    "SELF_REPORT_PROTOCOL",
    "SessionAuditState",
    "gate_policy",
    "gate_matrix_hash",
    "GATE_POLICY_ID",
    "GATE_POLICY_VERSION",
    "ReceiptStore",
    "override_rate",
    "degraded_band_rate",
    "CalibrationPoint",
    "run_calibration",
    "recommend_bands",
    "StakesAssessment",
    "classify_stakes",
    "CompositionEvent",
    "detect_load_spike",
    "record_compaction_event",
    "build_handoff",
    "verify_handoff",
    "HandoffVerification",
    "ClaimStatus",
    "ClaimCheck",
    "StreamingAuditor",
]


def audit(
    *,
    used_tokens=None,
    max_tokens=None,
    text=None,
    tokenizer=None,
    self_reported_percent=None,
    self_report_basis=None,
    stakes=Stakes.MEDIUM,
    policy=DEFAULT_POLICY,
    actor_id="cla:local:reference",
    model_id=None,
    session_id=None,
):
    """One-call convenience: reading -> band -> gate -> receipt -> disclosure.

    Evidence priority (best wins; lower tiers are fallbacks only):
      1. used_tokens + max_tokens                      -> MEASURED
      2. text + tokenizer + max_tokens                 -> ESTIMATED (10% margin)
      3. text + max_tokens                             -> ESTIMATED (chars/4, 30% margin)
      4. self_reported_percent + self_report_basis     -> SELF_REPORTED (CLA-SR)
      5. nothing                                       -> UNKNOWN (disclosed, never guessed)

    Returns a dict with keys: reading, band, gate, receipt, disclosure.
    The receipt is NOT persisted; call `append_receipt(path, receipt)`
    before committing the action (no log = no action).
    """
    # Evidence-precedence enforcement (CLA-R11): self-report is refused
    # outright when better evidence is on the table. Passing both is a
    # caller bug, and silently preferring one would hide it.
    if self_reported_percent is not None and (used_tokens is not None or text is not None):
        raise ValueError(
            "audit refuses to run: self_reported_percent was provided alongside "
            "better evidence (used_tokens or text). CLA-R11: self-report MUST "
            "NOT be used where a measured or estimated path exists. Drop the "
            "self-report input."
        )
    monitor = ContextLoadMonitor(max_tokens=max_tokens)
    if used_tokens is not None and max_tokens is not None:
        reading = monitor.reading_from_counts(used_tokens)
    elif text is not None and max_tokens is not None and tokenizer is not None:
        reading = monitor.reading_from_tokenizer(text, tokenizer)
    elif text is not None and max_tokens is not None:
        reading = monitor.reading_from_text(text)
    elif self_reported_percent is not None:
        basis = self_report_basis if self_report_basis is not None else ""
        reading = monitor.reading_from_self_report(self_reported_percent, basis)
    else:
        reading = monitor.reading_unknown()

    band = classify_band(reading, policy)
    gate = evaluate_gate(band, stakes, policy, provenance=reading.provenance.value)
    disclosure = format_disclosure_line(reading, band, gate, policy)
    receipt = CLAReceipt.build(
        reading=reading,
        band=band,
        stakes=stakes,
        gate=gate,
        policy=policy,
        disclosure_text=disclosure,
        actor_id=actor_id,
        model_id=model_id,
        session_id=session_id,
    )
    return {
        "reading": reading,
        "band": band,
        "gate": gate,
        "receipt": receipt,
        "disclosure": disclosure,
    }
