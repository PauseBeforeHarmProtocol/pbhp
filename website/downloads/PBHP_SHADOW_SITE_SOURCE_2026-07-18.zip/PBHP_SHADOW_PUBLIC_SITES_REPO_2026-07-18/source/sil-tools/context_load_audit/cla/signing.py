"""Optional Ed25519 signing for standalone receipts (roadmap 7.10).

The core library is dependency-free; signing is the one feature that
honestly cannot be (cryptography is not something to hand-roll). The
`cryptography` package is therefore an OPTIONAL dependency, imported
lazily: everything else in CLA works without it, and these functions
raise a clear error if it is absent.

When CLA is embedded in PBHP, prefer the PBHP envelope signature —
the CLA record rides inside it and needs no signature of its own.
Standalone signing exists for non-PBHP deployments that still need
tamper evidence.

Signature rule (same as PBHP section 7): the signature covers the
receipt's canonical bytes with the signature value itself excluded;
canonicalization is lex-sorted keys, UTF-8, no whitespace.
"""

from __future__ import annotations

import base64
from typing import Tuple

from cla.receipt import CLAReceipt, canonical_json_bytes


def _require_crypto():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey, Ed25519PublicKey,
        )
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import serialization
        return Ed25519PrivateKey, Ed25519PublicKey, InvalidSignature, serialization
    except ImportError as e:
        raise ImportError(
            "cla.signing requires the optional 'cryptography' package "
            "(pip install cryptography). The rest of CLA works without it; "
            "signing honestly cannot."
        ) from e


def generate_keypair() -> Tuple[object, object]:
    Ed25519PrivateKey, _, _, _ = _require_crypto()
    priv = Ed25519PrivateKey.generate()
    return priv, priv.public_key()


def _signing_payload(receipt: CLAReceipt) -> bytes:
    d = receipt.to_dict()
    sig = d.get("signature")
    if sig is not None:
        d["signature"] = {k: v for k, v in sig.items() if k != "value"}
    return canonical_json_bytes(d)


def sign_receipt(receipt: CLAReceipt, private_key, *, public_key_ref: str = None) -> CLAReceipt:
    """Attach an Ed25519 signature to a standalone receipt (in place)."""
    Ed25519PrivateKey, _, _, serialization = _require_crypto()
    if not isinstance(private_key, Ed25519PrivateKey):
        raise TypeError("sign_receipt refuses to run: private_key must be an Ed25519PrivateKey.")
    if public_key_ref is None:
        raw = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw)
        public_key_ref = "raw-b64:" + base64.b64encode(raw).decode("ascii")
    receipt.signature = {"alg": "Ed25519", "value": "", "public_key_ref": public_key_ref}
    sig = private_key.sign(_signing_payload(receipt))
    receipt.signature["value"] = base64.b64encode(sig).decode("ascii")
    return receipt


def verify_receipt(receipt: CLAReceipt, public_key) -> bool:
    """True iff the receipt's signature is present and valid."""
    _, Ed25519PublicKey, InvalidSignature, _ = _require_crypto()
    if not receipt.signature or not receipt.signature.get("value"):
        return False
    if receipt.signature.get("alg") != "Ed25519":
        return False
    try:
        public_key.verify(
            base64.b64decode(receipt.signature["value"].encode("ascii")),
            _signing_payload(receipt),
        )
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False
