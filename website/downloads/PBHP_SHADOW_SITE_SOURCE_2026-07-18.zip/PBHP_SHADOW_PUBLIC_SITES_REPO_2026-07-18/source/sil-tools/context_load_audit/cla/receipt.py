"""CLA receipts: cla.receipt.v1.

Standalone, append-only, JSONL-persisted audit records. Receipt before
action: when CLA is wired into a harness, the receipt is written
before the model output is committed to the world (no log = no action
— Faramesh WAL-fail-DENY discipline, same rule PBHP uses).

Standalone receipts are unsigned. When embedded in PBHP, the CLA
record rides INSIDE the signed pbhp.receipt.v1 envelope (see
`to_pbhp_extension`), so it inherits PBHP's Ed25519/ML-DSA-65
signature and hash chain without needing its own crypto stack.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional, Union

from cla.gate import GateResult, gate_policy
from cla.monitor import ContextLoadReading
from cla.thresholds import LoadBand, ThresholdPolicy


SCHEMA = "cla.receipt.v1"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def canonical_json_bytes(obj: dict) -> bytes:
    """Lex-sorted keys, no whitespace, UTF-8 — same rule as PBHP §7."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


@dataclass
class CLAReceipt:
    receipt_id: str
    schema: str
    cla_version: str
    actor_id: str
    timestamp: str
    reading: dict          # ContextLoadReading.to_dict()
    band: str              # LoadBand value
    stakes: str
    gate: dict             # GateResult.to_dict() (includes any override)
    policy: dict           # ThresholdPolicy.to_dict()
    disclosure_text: str
    prev: Optional[str] = None      # SHA-256 of prior CLA receipt (optional chain)
    notes: Optional[str] = None
    model_id: Optional[str] = None    # bands are model-dependent; a load number
                                      # without a model name is incomplete evidence
    session_id: Optional[str] = None  # groups receipts from one session
    signature: Optional[dict] = None  # optional standalone Ed25519 signature
                                      # (cla/signing.py); None when riding inside
                                      # a signed PBHP envelope

    # -- construction --------------------------------------------------

    @classmethod
    def build(
        cls,
        *,
        reading: ContextLoadReading,
        band: LoadBand,
        stakes: str,
        gate: GateResult,
        policy: ThresholdPolicy,
        disclosure_text: str,
        actor_id: str = "cla:local:reference",
        prev: Optional[str] = None,
        notes: Optional[str] = None,
        model_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> "CLAReceipt":
        ts = _now_iso()
        rid = "cla:{}:{}:{}".format(actor_id, ts, uuid.uuid4().hex[:8])
        # Threshold policy + gate policy together fully reconstruct the
        # classification and verdict rules in force (CLA-R4).
        policy_record = dict(policy.to_dict())
        policy_record.update(gate_policy())
        return cls(
            receipt_id=rid,
            schema=SCHEMA,
            cla_version="0.2.0",
            actor_id=actor_id,
            timestamp=ts,
            reading=reading.to_dict(),
            band=band.value,
            stakes=stakes,
            gate=gate.to_dict(),
            policy=policy_record,
            disclosure_text=disclosure_text,
            prev=prev,
            notes=notes,
            model_id=model_id,
            session_id=session_id,
        )

    # -- serialization --------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "id": self.receipt_id,
            "cla_version": self.cla_version,
            "actor_id": self.actor_id,
            "timestamp": self.timestamp,
            "reading": self.reading,
            "band": self.band,
            "stakes": self.stakes,
            "gate": self.gate,
            "policy": self.policy,
            "disclosure_text": self.disclosure_text,
            "prev": self.prev,
            "notes": self.notes,
            "model_id": self.model_id,
            "session_id": self.session_id,
            "signature": self.signature,
        }

    def to_json(self, *, pretty: bool = False) -> str:
        if pretty:
            return json.dumps(self.to_dict(), sort_keys=True, indent=2, ensure_ascii=False)
        return canonical_json_bytes(self.to_dict()).decode("utf-8")

    @classmethod
    def from_dict(cls, d: dict) -> "CLAReceipt":
        return cls(
            receipt_id=d["id"],
            schema=d.get("schema", SCHEMA),
            cla_version=d.get("cla_version", "0.1.0"),
            actor_id=d["actor_id"],
            timestamp=d["timestamp"],
            reading=d["reading"],
            band=d["band"],
            stakes=d["stakes"],
            gate=d["gate"],
            policy=d["policy"],
            disclosure_text=d["disclosure_text"],
            prev=d.get("prev"),
            notes=d.get("notes"),
            model_id=d.get("model_id"),
            session_id=d.get("session_id"),
            signature=d.get("signature"),
        )

    @classmethod
    def from_json(cls, s: str) -> "CLAReceipt":
        return cls.from_dict(json.loads(s))

    def receipt_hash(self) -> str:
        """SHA-256 hex over canonical bytes (for the optional CLA chain)."""
        return hashlib.sha256(canonical_json_bytes(self.to_dict())).hexdigest()

    # -- PBHP integration -----------------------------------------------

    def to_pbhp_extension(self) -> dict:
        """The dict a PBHP harness merges into pbhp.receipt.v1.

        pbhp.receipt.v1 (§7) has no first-class context_load field, so
        v1-compatible embedding goes through `action.parameters`:

            receipt.action["parameters"]["context_load"] = cla.to_pbhp_extension()

        Because action.parameters sits inside the signed envelope, the
        CLA record inherits the PBHP signature and hash chain. A future
        pbhp.receipt.v2 SHOULD promote `context_load` to a first-class
        top-level field (see CLA_SPEC §12.3).
        """
        return {
            "schema": self.schema,
            "cla_receipt_id": self.receipt_id,
            "load_percent": self.reading.get("percent"),
            "used_tokens": self.reading.get("used_tokens"),
            "max_tokens": self.reading.get("max_tokens"),
            "provenance": self.reading.get("provenance"),
            "band": self.band,
            "verdict": self.gate.get("verdict"),
            "override": self.gate.get("override"),
            "policy_id": self.policy.get("policy_id"),
            "policy_version": self.policy.get("policy_version"),
            "gate_policy_version": self.policy.get("gate_policy_version"),
            "gate_matrix_hash": self.policy.get("gate_matrix_hash"),
            "model_id": self.model_id,
        }


# -- persistence (append-only JSONL) -------------------------------------


def append_receipt(path: Union[str, os.PathLike], receipt: CLAReceipt) -> None:
    """Append one canonical-JSON line. Raises on write failure; callers
    must treat a failed write as a refusal to act (WAL-fail-DENY)."""
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    line = receipt.to_json() + "\n"
    with open(p, "a", encoding="utf-8", newline="\n") as f:
        f.write(line)
        f.flush()
        os.fsync(f.fileno())


def iter_receipts(path: Union[str, os.PathLike]) -> Iterator[CLAReceipt]:
    p = Path(path).expanduser()
    if not p.exists():
        return
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield CLAReceipt.from_json(line)


def load_receipts(path: Union[str, os.PathLike]) -> list:
    return list(iter_receipts(path))


def _window(receipts: list, last_n: int = None) -> list:
    """Time-windowed view for CAPA metrics (roadmap 7.4): last N receipts.
    Receipts are append-ordered, so slicing is chronological."""
    if last_n is None:
        return list(receipts)
    if last_n <= 0:
        raise ValueError("last_n must be a positive integer.")
    return list(receipts)[-last_n:]


def degraded_band_rate(receipts: list, last_n: int = None) -> float:
    """Fraction of receipts issued in DEGRADED or CRITICAL bands.

    Sustained operation in degraded bands is its own CAPA trigger
    (CLA-R9), separate from override_rate: it means sessions routinely
    run past the point the policy calls safe, which is a scheduling /
    workflow root cause, not an operator one.
    """
    rs = _window(receipts, last_n)
    if not rs:
        return 0.0
    degraded = [r for r in rs if r.band in ("DEGRADED", "CRITICAL")]
    return len(degraded) / len(rs)


def override_rate(receipts: list, last_n: int = None) -> float:
    """Fraction of pause/refuse-eligible receipts that were overridden.

    A rising override rate is a CAPA trigger (CLA-R9): the relief valve
    is being used as a bypass. Root cause is an incentive structure,
    not a person.
    """
    rs = _window(receipts, last_n)
    eligible = [r for r in rs if r.gate.get("verdict") != "PROCEED"]
    if not eligible:
        return 0.0
    # v0.2 record-don't-rewrite: an override is "used" only when actually
    # applied. A recorded-but-ignored floor attempt (applied=False) is NOT
    # a bypass — it is a held floor — so it must not inflate the rate.
    overridden = [r for r in eligible if (r.gate.get("override") or {}).get("applied")]
    return len(overridden) / len(eligible)


class ReceiptStore:
    """Thread-safe receipt persistence + CAPA metrics (roadmap 7.3).

    In-process safety via a lock around appends. For multi-PROCESS
    deployments, append-only JSONL with fsync is robust on POSIX for
    line-sized writes, but true multi-writer deployments should point
    each writer at its own file (receipts chain per-actor anyway) or
    use a real log backend. That limit is documented, not hidden.
    """

    def __init__(self, path):
        import threading
        self.path = path
        self._lock = threading.Lock()

    def append(self, receipt: CLAReceipt) -> None:
        with self._lock:
            append_receipt(self.path, receipt)

    def load(self) -> list:
        return load_receipts(self.path)

    def override_rate(self, last_n: int = None) -> float:
        return override_rate(self.load(), last_n)

    def degraded_band_rate(self, last_n: int = None) -> float:
        return degraded_band_rate(self.load(), last_n)
