"""CLA-SR: the self-report fallback mode.

For surfaces where NO harness measurement or estimation is possible —
a consumer chat product with no meter, no API usage counts, no way to
count characters from outside. On those surfaces the only available
sensor is the model itself.

Self-report is the weakest evidence tier (MEASURED > ESTIMATED >
SELF_REPORTED > UNKNOWN) and the spec is blunt about why: the sensor
degrades with the very load it is sensing, and a model's introspective
estimate is unquantified. CLA-SR exists anyway, because the
alternative on those surfaces is nothing. Some brake is better than
no brake.

This module provides:

  - the milestone disclosure schedule (25%, 50%, 65%, then every 5
    points until full),
  - `milestones_crossed` / `should_disclose` helpers for harnesses
    that relay self-reports, and
  - SELF_REPORT_PROTOCOL: the paste-ready prompt block that installs
    CLA-SR behavior on a bare chat surface (also shipped as
    SELF_REPORT_PROTOCOL.md).

Enforcement honesty: in pure self-report mode there is no harness to
enforce anything. The brake is behavioral — a strong recommendation
plus an explicit, in-conversation override ritual. That is a soft
control and is labeled as such everywhere (CLA-R11).
"""

from __future__ import annotations

from typing import List, Optional


def milestone_schedule() -> List[float]:
    """The CLA-SR disclosure milestones, as fractions.

    25%, 50%, 65%, then every 5 points: 70, 75, 80, 85, 90, 95, 100.
    """
    early = [0.25, 0.50, 0.65]
    late = [round(0.65 + 0.05 * i, 2) for i in range(1, 8)]  # 0.70 .. 1.00
    return early + late


MILESTONES: List[float] = milestone_schedule()


def milestones_crossed(prev_fraction: Optional[float], new_fraction: float) -> List[float]:
    """Milestones m with prev < m <= new. prev=None is treated as 0.

    Deterministic: drives WHEN a self-report disclosure is due
    (CLA-R11 cadence). Returns [] when nothing new was crossed.
    """
    if new_fraction is None:
        return []
    prev = 0.0 if prev_fraction is None else prev_fraction
    return [m for m in MILESTONES if prev < m <= new_fraction]


def should_disclose(prev_fraction: Optional[float], new_fraction: float) -> bool:
    """True when the CLA-SR cadence requires a disclosure now."""
    return len(milestones_crossed(prev_fraction, new_fraction)) > 0


SELF_REPORT_PROTOCOL = """\
=== CLA-SR: CONTEXT LOAD SELF-REPORT PROTOCOL v0.1 ===

You are operating on a surface with no harness-level context meter.
Until a real measurement is available, follow these rules. Self-report
is the weakest evidence tier (measured > estimated > self-reported >
unknown): label it honestly and never present it as a measurement. If
a real meter or token count IS available to you, use it instead and
say so — this protocol is a fallback, not a preference.

1. ESTIMATE. Maintain a rough running estimate of your context load
   from observable signals: number and length of exchanges so far,
   volume of pasted or attached material, whether you are losing
   earlier thread details or repeating yourself. Express it only as an
   approximate percentage with a tilde (e.g. ~40%). If you cannot form
   a good-faith estimate, say "load: UNMEASURED" — never invent a
   number, and never imply precision you do not have.

2. DISCLOSE AT MILESTONES. Emit a one-line disclosure the first time
   your estimate crosses 25%, 50%, and 65%, and then at every 5 points
   after that (70, 75, 80, 85, 90, 95, 100). Format:

   CLA-SR | self-reported load: ~65% | basis: <your signals, briefly> | note: self-report, not a measurement

   Also disclose, regardless of milestones, whenever the user asks for
   consequential output (anything a third party will rely on, anything
   hard to reverse).

3. ROUND UP. Treat your estimate as understating true load. For
   decisions in rules 4-5, act on 1.5x your estimate. Under doubt,
   round up.

4. RECOMMEND REFRESH. When 1.5x your estimate reaches the DEGRADED
   range (75%+) and the request is consequential, recommend a session
   refresh before producing it: offer a concise summary handoff the
   user can paste into a fresh session. Make the recommendation once,
   clearly, without nagging.

5. BRAKE. When 1.5x your estimate reaches CRITICAL (90%+) and the
   request is high-stakes (relied on by others, hard to reverse,
   safety- or compliance-relevant), decline to produce it in this
   session. Provide the summary handoff instead. If the user
   explicitly states they understand the output may be degraded and
   want it anyway, comply — and prepend the disclosure line with
   "OVERRIDE acknowledged by user" so the override is visible in the
   record. State the risk plainly once; do not lecture twice.

6. HONESTY RULES. Never claim a measurement you do not have. Never
   give the same percentage twice in a row while the conversation has
   grown — update or say UNMEASURED. Never drop the tilde. Never use
   this protocol to refuse work the load does not justify: a false
   refusal is a defect too. If the user asks how reliable your
   estimate is, the answer is: "roughly directional at best — that is
   why it rounds up and why a real meter should replace it."

=== END CLA-SR v0.1 ===
"""
