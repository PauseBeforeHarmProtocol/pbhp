"""Streaming / incremental audit mode (roadmap 7.5).

For harnesses that stream: feed chunks (or exact running counts) as
they arrive, get composition events and band transitions as they
happen, and checkpoint with a full stakes-gated audit before any
consequential commit. One StreamingAuditor per session.
"""

from __future__ import annotations

from typing import Callable, Optional

from cla.composition import detect_load_spike, CompositionEvent
from cla.disclosure import format_disclosure_line
from cla.gate import Stakes, evaluate_gate
from cla.monitor import ContextLoadMonitor
from cla.receipt import CLAReceipt
from cla.session import SessionAuditState
from cla.thresholds import ThresholdPolicy, DEFAULT_POLICY, classify_band


class StreamingAuditor:
    """Incremental load tracking with session-aware disclosure timing.

    feed(text_chunk)      -> ESTIMATED accumulation (char heuristic or tokenizer)
    update_counts(used)   -> MEASURED running total (preferred when available)
    checkpoint(stakes)    -> full gated audit at a commit point

    Evidence tiers do not blend: once update_counts() is used the
    auditor is in MEASURED mode and feed() refuses to run.
    """

    def __init__(
        self,
        max_tokens: Optional[int],
        *,
        policy: ThresholdPolicy = DEFAULT_POLICY,
        tokenizer: Optional[Callable[[str], int]] = None,
        actor_id: str = "cla:streaming:reference",
        model_id: Optional[str] = None,
        session_id: Optional[str] = None,
        cooldown_seconds: float = 0.0,
    ):
        self.monitor = ContextLoadMonitor(max_tokens=max_tokens)
        self.session = SessionAuditState(cooldown_seconds=cooldown_seconds)
        self.policy = policy
        self.tokenizer = tokenizer
        self.actor_id = actor_id
        self.model_id = model_id
        self.session_id = session_id
        self._measured_used: Optional[int] = None
        self._prev_fraction: Optional[float] = None

    # -- incremental updates -------------------------------------------------

    def feed(self, text_chunk: str, stakes: str = Stakes.LOW) -> dict:
        """Accumulate a chunk; returns reading, band, session update, spike."""
        if self._measured_used is not None:
            raise RuntimeError(
                "StreamingAuditor.feed refuses to run: this auditor is in "
                "MEASURED mode (update_counts was used). Evidence tiers don't blend."
            )
        if self.tokenizer is not None:
            reading = self.monitor.add_tokens(int(self.tokenizer(text_chunk)))
        else:
            reading = self.monitor.add_turn(text_chunk)
        return self._after(reading, stakes)

    def update_counts(self, used_tokens: int, stakes: str = Stakes.LOW) -> dict:
        """MEASURED running total from the provider; preferred over feed()."""
        self._measured_used = used_tokens
        reading = self.monitor.reading_from_counts(used_tokens)
        return self._after(reading, stakes)

    def _after(self, reading, stakes: str) -> dict:
        band = classify_band(reading, self.policy)
        spike: Optional[CompositionEvent] = None
        if reading.fraction is not None:
            spike = detect_load_spike(self._prev_fraction, reading.fraction)
        update = self.session.update(reading, band, stakes)
        if spike:
            update["reasons"].append(spike.detail)
            update["disclosure_required"] = True
        self._prev_fraction = reading.fraction
        return {"reading": reading, "band": band, "session": update, "spike": spike}

    def update_max_tokens(self, new_max: int) -> None:
        """Provider revealed or changed the window mid-session. Fractions
        recompute from the next reading; the change shows up in subsequent
        receipts via reading.max_tokens, so the shift is auditable."""
        if new_max <= 0:
            raise ValueError("update_max_tokens refuses to run: new_max must be positive.")
        self.monitor.max_tokens = new_max

    # -- gated commit point ----------------------------------------------------

    def current_reading(self):
        if self._measured_used is not None:
            return self.monitor.reading_from_counts(self._measured_used)
        return self.monitor.add_turn("")  # accumulated estimate, nothing added

    def checkpoint(self, stakes: str) -> dict:
        """Full stakes-gated audit at a commit point. Same return shape as
        cla.audit(). The receipt is NOT persisted; append it before commit."""
        reading = self.current_reading()
        band = classify_band(reading, self.policy)
        gate = evaluate_gate(band, stakes, self.policy)
        disclosure = format_disclosure_line(reading, band, gate, self.policy)
        receipt = CLAReceipt.build(
            reading=reading, band=band, stakes=stakes, gate=gate,
            policy=self.policy, disclosure_text=disclosure,
            actor_id=self.actor_id, model_id=self.model_id,
            session_id=self.session_id,
        )
        return {"reading": reading, "band": band, "gate": gate,
                "receipt": receipt, "disclosure": disclosure}
