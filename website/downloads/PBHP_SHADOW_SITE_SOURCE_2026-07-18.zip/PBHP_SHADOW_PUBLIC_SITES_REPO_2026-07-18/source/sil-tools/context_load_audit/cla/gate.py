"""The stakes-aware load gate.

Crossing load with stakes is the whole point: a 91%-full context is
fine for fixing a typo and unacceptable for drafting the press release
that goes out under someone's name. The gate is a deterministic matrix
(CLA-R4) — same (band, stakes, policy) always yields the same verdict.

The matrix is itself versioned policy: GATE_POLICY_ID / GATE_POLICY_VERSION
plus a content hash (gate_matrix_hash) are recorded in every receipt so
an auditor can reconstruct exactly which verdict table was in force,
even if the matrix changes in a later release.

REFUSE_REFRESH is a DEFAULT refusal verdict: binding unless a logged
CLA-R7 override exists, and absolute (non-overridable) in the
CRITICAL-band/CRITICAL-stakes cell — but only for MEASURED or ESTIMATED
readings. A SELF_REPORTED (CLA-SR) reading is the weakest evidence tier
and, per SIL framework §6.6, MUST NOT carry a non-overridable floor: a
heuristic self-assessment never hard-blocks what the measured
instruments gate. So the locked cell is provenance-aware (CLA-R7,
v0.2) — absolute under measurement, overridable-with-logged-ritual
under self-report. Calling a measured floor anything weaker, or a
self-report anything stronger, would be overclaim either direction.

Override semantics are record-don't-rewrite (the common SIL gauge
contract, v0.2): apply_override never mutates `verdict`; it records the
operator acknowledgment and an `effective_verdict` alongside the
original. An override attempted against an absolute floor is recorded
(`applied=False, ignored_floor=True`), not raised — the attempt becomes
an auditable receipt, and `effective_verdict` stays REFUSE_REFRESH so
the floor holds.

Standalone vocabulary is LOW/MEDIUM/HIGH/CRITICAL. When integrated
with PBHP, stakes map from the canonical GREEN→BLACK harm-threshold
ladder via `stakes_from_pbhp_threshold` — note that PBHP BLACK refuses
at compile time regardless of context load; CLA never weakens that.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from cla.thresholds import LoadBand, ThresholdPolicy, DEFAULT_POLICY
from cla.monitor import LoadProvenance


class Stakes:
    """Plain string-enum (kept simple for zero-dependency portability)."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    ALL = (LOW, MEDIUM, HIGH, CRITICAL)


class Verdict:
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    PAUSE_RECOMMEND_REFRESH = "PAUSE_RECOMMEND_REFRESH"
    REFUSE_REFRESH = "REFUSE_REFRESH"

    ALL = (PROCEED, PROCEED_WITH_DISCLOSURE, PAUSE_RECOMMEND_REFRESH, REFUSE_REFRESH)


# (band, stakes) -> verdict. Deterministic. Conservative under UNKNOWN:
# an unmeasurable load is treated as a reason for caution at high
# stakes, not as permission (round up under doubt).
_GATE_MATRIX: Dict[Tuple[str, str], str] = {
    # NOMINAL
    (LoadBand.NOMINAL.value, Stakes.LOW): Verdict.PROCEED,
    (LoadBand.NOMINAL.value, Stakes.MEDIUM): Verdict.PROCEED,
    (LoadBand.NOMINAL.value, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.NOMINAL.value, Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    # ELEVATED
    (LoadBand.ELEVATED.value, Stakes.LOW): Verdict.PROCEED,
    (LoadBand.ELEVATED.value, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.ELEVATED.value, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.ELEVATED.value, Stakes.CRITICAL): Verdict.PAUSE_RECOMMEND_REFRESH,
    # DEGRADED
    (LoadBand.DEGRADED.value, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.DEGRADED.value, Stakes.MEDIUM): Verdict.PAUSE_RECOMMEND_REFRESH,
    (LoadBand.DEGRADED.value, Stakes.HIGH): Verdict.PAUSE_RECOMMEND_REFRESH,
    (LoadBand.DEGRADED.value, Stakes.CRITICAL): Verdict.REFUSE_REFRESH,
    # CRITICAL
    (LoadBand.CRITICAL.value, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.CRITICAL.value, Stakes.MEDIUM): Verdict.PAUSE_RECOMMEND_REFRESH,
    (LoadBand.CRITICAL.value, Stakes.HIGH): Verdict.REFUSE_REFRESH,
    (LoadBand.CRITICAL.value, Stakes.CRITICAL): Verdict.REFUSE_REFRESH,
    # UNKNOWN — disclosure is mandatory; high stakes pause until measured.
    (LoadBand.UNKNOWN.value, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.UNKNOWN.value, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (LoadBand.UNKNOWN.value, Stakes.HIGH): Verdict.PAUSE_RECOMMEND_REFRESH,
    (LoadBand.UNKNOWN.value, Stakes.CRITICAL): Verdict.PAUSE_RECOMMEND_REFRESH,
}


# -- gate policy versioning (CLA-R4) ----------------------------------------

GATE_POLICY_ID = "cla-gate-default"
GATE_POLICY_VERSION = "0.2.0"  # v0.2: provenance-aware floor (N1) + record-don't-rewrite
                               # override semantics (N11). Verdict matrix unchanged, so
                               # gate_matrix_hash() is identical to v0.1 — the 2026-06-07
                               # tamper-evidence baseline still holds; only override/floor
                               # *semantics* moved, which the version bump records.


def gate_matrix_hash() -> str:
    """SHA-256 over the canonical bytes of the verdict matrix.

    Canonicalization: {"BAND|STAKES": verdict} with lex-sorted keys,
    no whitespace, UTF-8 — the same rule receipts use. If anyone edits
    the matrix without bumping GATE_POLICY_VERSION, the hash still
    changes, so receipts remain reconstructable either way.
    """
    canon = {"{}|{}".format(b, s): v for (b, s), v in _GATE_MATRIX.items()}
    payload = json.dumps(canon, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def gate_policy() -> dict:
    """The gate-policy record carried in every receipt."""
    return {
        "gate_policy_id": GATE_POLICY_ID,
        "gate_policy_version": GATE_POLICY_VERSION,
        "gate_matrix_hash": "sha256:" + gate_matrix_hash(),
    }


@dataclass
class GateResult:
    verdict: str            # the gate's reading — NEVER mutated by an override
                            # (record-don't-rewrite, the common SIL gauge contract)
    band: str
    stakes: str
    reason: str
    overridable: bool
    provenance: str = LoadProvenance.MEASURED.value  # evidence tier of the reading;
                                                     # the floor is absolute only when
                                                     # this is MEASURED or ESTIMATED
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})

    @property
    def effective_verdict(self) -> str:
        """What the operator may actually act on.

        Equals `verdict` unless a successful override is recorded, in
        which case it is the override's relaxed verdict. On an absolute
        floor the override is recorded but not applied, so this stays
        REFUSE_REFRESH — the floor holds without an exception.
        """
        if self.override.get("applied"):
            return self.override.get("effective_verdict", self.verdict)
        return self.verdict

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict,
            "effective_verdict": self.effective_verdict,
            "band": self.band,
            "stakes": self.stakes,
            "reason": self.reason,
            "overridable": self.overridable,
            "provenance": self.provenance,
            "override": self.override,
        }


def _reason_for(band: str, stakes: str, verdict: str) -> str:
    if verdict == Verdict.PROCEED:
        return "Load within nominal policy bounds for these stakes."
    if verdict == Verdict.PROCEED_WITH_DISCLOSURE:
        if band == LoadBand.UNKNOWN.value:
            return ("Context load is unmeasured. Proceeding is permitted at these "
                    "stakes, but the absence of measurement is disclosed, not hidden.")
        return "Load is material to output reliability at these stakes; disclosure attached."
    if verdict == Verdict.PAUSE_RECOMMEND_REFRESH:
        if band == LoadBand.UNKNOWN.value:
            return ("Context load is unmeasured and stakes are high. Obtain a "
                    "measurement or refresh the session before proceeding.")
        return ("Load is in the {} band. Long-context degradation risk is elevated; "
                "a session refresh is recommended before this output is relied on.".format(band))
    # REFUSE_REFRESH
    return ("Load is in the {} band and stakes are {}. Per policy, high-stakes "
            "output is refused at this load. Refresh the session and re-enter "
            "the task with a summary handoff; it returns as a new action with "
            "a new receipt.".format(band, stakes))


def evaluate_gate(
    band: LoadBand,
    stakes: str,
    policy: ThresholdPolicy = DEFAULT_POLICY,
    provenance: str = LoadProvenance.MEASURED.value,
) -> GateResult:
    """Deterministic verdict for (band, stakes) under `policy`.

    Note `policy` participates via band classification upstream; it is
    accepted here so callers keep one object flowing through, and so a
    future policy revision can also re-map the matrix (versioned).

    `provenance` is the evidence tier of the reading (LoadProvenance
    value). The verdict itself is provenance-independent — the matrix
    is the matrix. What provenance changes is *overridability of the
    locked cell* (CLA-R7, v0.2 / SIL framework §6.6): the
    CRITICAL/CRITICAL cell is an absolute floor under MEASURED or
    ESTIMATED evidence, but a SELF_REPORTED reading is the weakest tier
    and MUST NOT carry a non-overridable floor — so under self-report
    that cell is overridable with the logged acknowledgment ritual. The
    1.5x self-report inflation already makes an SR-driven CRITICAL
    conservative; refusing to let the operator override a *guess* would
    be the refusal-engine failure CLA_SPEC §8.1 forbids.
    """
    if stakes not in Stakes.ALL:
        raise ValueError(
            "evaluate_gate refuses to run: stakes must be one of "
            f"{Stakes.ALL}, got {stakes!r}."
        )
    verdict = _GATE_MATRIX[(band.value, stakes)]
    # Overridable means: there is a PAUSE or REFUSE verdict to override,
    # AND the cell is not an *absolute* floor. PROCEED verdicts carry
    # overridable=False because there is nothing to override. The relief
    # path (False-Positive-Release-Valve analog) exists, is receipted,
    # and repeated use is a CAPA signal.
    #
    # The absolute floor is the locked CRITICAL/CRITICAL cell — but only
    # for measured/estimated evidence. A self-report never produces an
    # absolute floor (§6.6), so its locked cell is overridable.
    is_blockable = verdict in (Verdict.PAUSE_RECOMMEND_REFRESH, Verdict.REFUSE_REFRESH)
    is_locked_cell = (band == LoadBand.CRITICAL and stakes == Stakes.CRITICAL)
    is_self_report = (provenance == LoadProvenance.SELF_REPORTED.value)
    absolute_floor = is_locked_cell and not is_self_report
    overridable = is_blockable and not absolute_floor
    return GateResult(
        verdict=verdict,
        band=band.value,
        stakes=stakes,
        reason=_reason_for(band.value, stakes, verdict),
        overridable=overridable,
        provenance=provenance,
    )


def apply_override(result: GateResult, operator_id: str, acknowledgment: str) -> GateResult:
    """Operator override of a PAUSE/REFUSE verdict. Logged, never silent.

    Record-don't-rewrite (the common SIL gauge contract, v0.2): this
    NEVER mutates `verdict`. It returns a new GateResult whose `verdict`
    is the original gate reading and whose `override` record carries the
    operator acknowledgment plus an `effective_verdict`. Read
    `result.effective_verdict` to learn what the operator may act on.

    Requirements (CLA-R7):
      - `acknowledgment` must be a non-empty statement that the operator
        accepts degraded-output risk. Empty/boilerplate-free check is the
        caller's CORE-tier job; non-empty is enforced here.
      - The absolute floor (measured/estimated CRITICAL band + CRITICAL
        stakes) is NOT overridable. An override attempted against it is
        *recorded* — `applied=False, ignored_floor=True` — not raised, so
        the bypass attempt becomes an auditable receipt and a rising
        ignored-floor count is a CAPA signal. `effective_verdict` stays
        REFUSE_REFRESH: the floor holds. (A self-reported reading carries
        no absolute floor per §6.6, so its locked cell IS overridable.)

    Raises only on caller error: nothing-to-override, or a missing
    operator id / acknowledgment.
    """
    if result.verdict in (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE):
        raise ValueError("apply_override refuses to run: nothing to override "
                         f"(verdict is {result.verdict}).")
    if not operator_id or not operator_id.strip():
        raise ValueError("apply_override refuses to run: operator_id is required.")
    if not acknowledgment or not acknowledgment.strip():
        raise ValueError(
            "apply_override refuses to run: a non-empty risk acknowledgment "
            "is required. The operator must say, in words, that they accept "
            "degraded-output risk (Mirror Vow reciprocal half)."
        )
    if not result.overridable:
        # Absolute floor. Record the attempt; do not relax. The verdict
        # is unchanged and effective_verdict stays REFUSE_REFRESH.
        return GateResult(
            verdict=result.verdict,
            band=result.band,
            stakes=result.stakes,
            reason=result.reason + " [OVERRIDE ATTEMPTED ON ABSOLUTE FLOOR — "
                                   "REFUSED; floor holds. Refresh and re-enter.]",
            overridable=result.overridable,
            provenance=result.provenance,
            override={
                "applied": False,
                "ignored_floor": True,
                "operator_id": operator_id.strip(),
                "acknowledgment": acknowledgment.strip(),
            },
        )
    return GateResult(
        verdict=result.verdict,
        band=result.band,
        stakes=result.stakes,
        reason=result.reason + " [OVERRIDDEN BY OPERATOR — see override record]",
        overridable=result.overridable,
        provenance=result.provenance,
        override={
            "applied": True,
            "operator_id": operator_id.strip(),
            "acknowledgment": acknowledgment.strip(),
            "effective_verdict": Verdict.PROCEED_WITH_DISCLOSURE,
        },
    )


def stakes_from_pbhp_threshold(harm_threshold: str) -> str:
    """Map PBHP's GREEN→BLACK harm-threshold ladder onto CLA stakes.

    GREEN  -> LOW       (no plausible harm; routine)
    YELLOW -> MEDIUM    (recoverable harm)
    ORANGE -> HIGH      (identifiable third-party harm)
    RED    -> CRITICAL  (serious harm; ULTRA tier)
    BLACK  -> CRITICAL  (PBHP refuses BLACK at compile time regardless of
                         load; CLA's mapping exists only so a CLA receipt
                         can still be emitted alongside the PBHP refusal)
    """
    mapping = {
        "GREEN": Stakes.LOW,
        "YELLOW": Stakes.MEDIUM,
        "ORANGE": Stakes.HIGH,
        "RED": Stakes.CRITICAL,
        "BLACK": Stakes.CRITICAL,
    }
    key = str(harm_threshold).upper()
    if key not in mapping:
        raise ValueError(
            "stakes_from_pbhp_threshold refuses to run: unknown PBHP harm "
            f"threshold {harm_threshold!r}. Expected GREEN/YELLOW/ORANGE/RED/BLACK."
        )
    return mapping[key]
