"""Programmatic refresh-handoff builder (roadmap 7.8) + handoff fact-verify
mode (v0.2 / catalog #1.11).

The cascading-degradation trap (spec section 3, Refresh): asking a
DEGRADED/CRITICAL session to free-recall its own summary inherits the
omissions the refresh exists to escape. This builder assembles the
handoff from LOGGED material instead — receipts, verbatim artifacts
the harness passes in, explicit task state — and stamps the mandatory
degraded-conditions label when the source session was DEGRADED or
worse. Free recall never enters the pipeline.

Fact-verify mode (spec section 13.3) takes the next step the captured
incident (R-2026-06-05-04) calls for: *verify against the filesystem
before claiming, or disclose the verification gap.* `verify_handoff`
runs the handoff's load-bearing claims past a HARNESS-SUPPLIED verifier
and labels each CONFIRMED / UNCONFIRMED / MISMATCH / UNVERIFIABLE, so a
claim that recall asserts but disk cannot confirm is surfaced in the
handoff instead of silently inherited. CLA stays dependency-free and
does no I/O of its own — the harness owns the check (the same division
of labor as the `calibrate.py` org-supplied `eval_fn`). A broken
verifier fails safe to UNVERIFIABLE; it never confirms by accident.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable, List, Optional, Sequence, Tuple

from cla.receipt import CLAReceipt
from cla.thresholds import LoadBand


DEGRADED_LABEL = ("[HANDOFF COMPILED UNDER DEGRADED CONDITIONS — source session was at "
                  "{band} load. Contents below are programmatically extracted (receipts + "
                  "verbatim artifacts), not model recall, but verify anything load-bearing "
                  "before relying on it.]")


class ClaimStatus(Enum):
    """The verification verdict for a single load-bearing claim."""

    CONFIRMED = "CONFIRMED"        # verifier matched the claim against source
    UNCONFIRMED = "UNCONFIRMED"    # source could not confirm it (e.g. file/receipt absent)
    MISMATCH = "MISMATCH"          # source exists but contradicts the claim
    UNVERIFIABLE = "UNVERIFIABLE"  # no check was possible (verifier returned None or raised)


# A verifier maps a claim string to a verdict. Accepted return shapes:
#   True  / ClaimStatus.CONFIRMED                    -> CONFIRMED
#   False                                            -> UNCONFIRMED
#   ClaimStatus.UNCONFIRMED / .MISMATCH / .UNVERIFIABLE -> as given
#   None                                             -> UNVERIFIABLE
#   (any of the above, "detail string")              -> verdict + detail
# Anything else is a caller bug and raises TypeError. A verifier that
# raises while running is caught and recorded UNVERIFIABLE (fail-safe).
Verifier = Callable[[str], object]

_FLAGGED = (ClaimStatus.UNCONFIRMED, ClaimStatus.MISMATCH, ClaimStatus.UNVERIFIABLE)
_MARK = {
    ClaimStatus.CONFIRMED: "ok  ",
    ClaimStatus.UNCONFIRMED: "!!  ",
    ClaimStatus.MISMATCH: "XX  ",
    ClaimStatus.UNVERIFIABLE: "??  ",
}


def _coerce_status(result) -> Tuple[ClaimStatus, str]:
    """Normalize a verifier's return value into (status, detail).

    TypeError/ValueError here mean the verifier returned a shape CLA
    does not understand — a caller bug, surfaced loudly rather than
    papered over with a false CONFIRMED.
    """
    detail = ""
    if isinstance(result, tuple):
        if len(result) != 2:
            raise ValueError(
                "verifier returned a tuple that is not (verdict, detail): {!r}".format(result)
            )
        result, raw_detail = result
        detail = "" if raw_detail is None else str(raw_detail)
    if result is None:
        return ClaimStatus.UNVERIFIABLE, detail
    if isinstance(result, ClaimStatus):
        return result, detail
    if isinstance(result, bool):
        return (ClaimStatus.CONFIRMED if result else ClaimStatus.UNCONFIRMED), detail
    raise TypeError(
        "verifier must return bool, ClaimStatus, None, or (one of those, detail); "
        "got {!r}".format(type(result).__name__)
    )


@dataclass(frozen=True)
class ClaimCheck:
    """One claim and the verdict it received."""

    claim: str
    status: ClaimStatus
    detail: str = ""

    def to_dict(self) -> dict:
        return {"claim": self.claim, "status": self.status.value, "detail": self.detail}


@dataclass(frozen=True)
class HandoffVerification:
    """Result of running a handoff's claims past a harness-supplied verifier."""

    checks: Tuple[ClaimCheck, ...]

    def _count(self, status: ClaimStatus) -> int:
        return sum(1 for c in self.checks if c.status is status)

    @property
    def total(self) -> int:
        return len(self.checks)

    @property
    def confirmed(self) -> int:
        return self._count(ClaimStatus.CONFIRMED)

    @property
    def unconfirmed(self) -> int:
        return self._count(ClaimStatus.UNCONFIRMED)

    @property
    def mismatch(self) -> int:
        return self._count(ClaimStatus.MISMATCH)

    @property
    def unverifiable(self) -> int:
        return self._count(ClaimStatus.UNVERIFIABLE)

    @property
    def all_confirmed(self) -> bool:
        """True iff every claim was CONFIRMED (vacuously true with no claims)."""
        return all(c.status is ClaimStatus.CONFIRMED for c in self.checks)

    @property
    def flagged(self) -> Tuple[ClaimCheck, ...]:
        """The checks that are not CONFIRMED — what a reader must not trust yet."""
        return tuple(c for c in self.checks if c.status in _FLAGGED)

    def summary_line(self) -> str:
        if not self.checks:
            return "[FACT-VERIFY: no load-bearing claims to verify.]"
        if self.all_confirmed:
            return "[FACT-VERIFY: {n}/{n} load-bearing claims confirmed against source.]".format(
                n=self.total)
        parts = ["{}/{} confirmed".format(self.confirmed, self.total)]
        if self.unconfirmed:
            parts.append("{} UNCONFIRMED".format(self.unconfirmed))
        if self.mismatch:
            parts.append("{} MISMATCH".format(self.mismatch))
        if self.unverifiable:
            parts.append("{} UNVERIFIABLE".format(self.unverifiable))
        return ("[FACT-VERIFY: " + " · ".join(parts)
                + " — do NOT rely on the flagged claims below until checked.]")

    def detail_lines(self) -> List[str]:
        out: List[str] = []
        for c in self.checks:
            mark = _MARK.get(c.status, "??  ")
            line = "  {}{} — {}".format(mark, c.status.value, c.claim)
            if c.detail:
                line += "  ({})".format(c.detail)
            out.append(line)
        return out

    def to_block(self) -> str:
        return "\n".join([self.summary_line()] + self.detail_lines())

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "confirmed": self.confirmed,
            "unconfirmed": self.unconfirmed,
            "mismatch": self.mismatch,
            "unverifiable": self.unverifiable,
            "all_confirmed": self.all_confirmed,
            "checks": [c.to_dict() for c in self.checks],
        }


def verify_handoff(claims: Sequence[str], verifier: Verifier) -> HandoffVerification:
    """Check each load-bearing claim against a harness-supplied verifier.

    `claims`: the verbatim load-bearing strings a handoff carries
        (file paths, receipt IDs, counts, decisions) — typically the
        `artifacts` passed to `build_handoff`.
    `verifier`: a harness callable `claim -> verdict`. CLA does no I/O
        of its own; the harness owns the filesystem / receipt check and
        returns one of the shapes documented on `Verifier`. A verifier
        that raises is recorded UNVERIFIABLE, never propagated and never
        silently treated as confirmed — a broken checker must fail safe.
    """
    if not callable(verifier):
        raise TypeError("verify_handoff requires a callable verifier (claim -> verdict).")
    checks: List[ClaimCheck] = []
    for claim in claims:
        try:
            raw = verifier(claim)
        except Exception as exc:  # noqa: BLE001 — a broken verifier must fail safe, not confirm
            checks.append(ClaimCheck(str(claim), ClaimStatus.UNVERIFIABLE,
                                     "verifier raised: {}".format(exc)))
            continue
        status, detail = _coerce_status(raw)  # bad return shape = caller bug -> raises
        checks.append(ClaimCheck(str(claim), status, detail))
    return HandoffVerification(checks=tuple(checks))


def build_handoff(
    *,
    task_state: str,
    artifacts: Sequence[str] = (),
    receipts: Sequence[CLAReceipt] = (),
    source_band: LoadBand = LoadBand.UNKNOWN,
    next_steps: Optional[str] = None,
    verifier: Optional[Verifier] = None,
) -> str:
    """Assemble a paste-ready handoff block for a fresh session.

    `task_state`: the harness's explicit statement of where the task
        stands (facts the harness KNOWS, not asks the model to recall).
    `artifacts`: verbatim strings worth carrying (decisions, IDs,
        quotes, file paths). Passed through unmodified.
    `receipts`: this session's CLA receipts; summarized to band/verdict
        history so the next session knows the operating conditions.
    `source_band`: the band at handoff time — drives the mandatory label.
    `verifier`: optional harness checker. When supplied, the `artifacts`
        are run through `verify_handoff` and a FACT-VERIFY summary +
        per-claim breakdown are folded into the block, so unconfirmed
        recall-claims are surfaced rather than inherited (spec 13.3).
        Omitted -> behavior is byte-for-byte the prior builder.
    """
    if not task_state or not task_state.strip():
        raise ValueError("build_handoff refuses to run: task_state is required. "
                         "A handoff with no stated task state is a vibe, not a handoff.")
    verification: Optional[HandoffVerification] = None
    if verifier is not None and artifacts:
        verification = verify_handoff(artifacts, verifier)
    lines: List[str] = ["=== CLA SESSION HANDOFF ==="]
    if source_band in (LoadBand.DEGRADED, LoadBand.CRITICAL):
        lines.append(DEGRADED_LABEL.format(band=source_band.value))
    if verification is not None:
        lines.append(verification.summary_line())
    lines.append("")
    lines.append("TASK STATE (harness-stated):")
    lines.append(task_state.strip())
    if artifacts:
        lines.append("")
        lines.append("VERBATIM ARTIFACTS ({}):".format(len(artifacts)))
        for i, a in enumerate(artifacts, 1):
            lines.append("  [{}] {}".format(i, a))
        if verification is not None:
            lines.append("")
            lines.append("FACT-VERIFY (claims checked against source):")
            lines.extend(verification.detail_lines())
    if receipts:
        lines.append("")
        lines.append("SESSION OPERATING HISTORY ({} receipts):".format(len(receipts)))
        for r in receipts[-10:]:  # last 10 are the ones that matter
            pct = r.reading.get("percent")
            lines.append("  {} | load {} | {} | {}".format(
                r.timestamp,
                "{}%".format(pct) if pct is not None else "UNMEASURED",
                r.band,
                r.gate.get("verdict"),
            ))
        overrides = [r for r in receipts if (r.gate.get("override") or {}).get("applied")]
        if overrides:
            lines.append("  NOTE: {} override(s) occurred this session — re-verify those outputs.".format(len(overrides)))
    if next_steps and next_steps.strip():
        lines.append("")
        lines.append("NEXT STEPS:")
        lines.append(next_steps.strip())
    lines.append("")
    lines.append("=== END HANDOFF — re-enter as a new action with a new receipt ===")
    return "\n".join(lines)
