"""Token estimation for when exact counts are unavailable.

The honest hierarchy of evidence, best to worst:

  1. MEASURED      — exact token counts from the provider API / harness
                     (e.g., usage.input_tokens). Use these whenever they
                     exist. This module is NOT that.
  2. ESTIMATED     — a tokenizer-free character heuristic (this module),
                     or a real tokenizer if the caller has one installed.
  3. SELF_REPORTED — the model's own estimate (CLA-SR fallback only;
                     see selfreport.py). Weakest numeric evidence.
  4. UNKNOWN       — nothing measurable. The tool discloses UNKNOWN
                     rather than inventing a number (fail-honest rule).

The ~4 characters/token heuristic is the widely used English-text
rule of thumb. It is wrong by up to roughly +/-30% on code, non-English
text, and unusual formatting. That error bar is why ESTIMATED
provenance is always disclosed alongside the number, and why estimated
readings round UP into the next band when within the estimation margin
(see thresholds.classify_band).
"""

from __future__ import annotations

CHARS_PER_TOKEN: float = 4.0

# Conservative relative error assumed for character-based estimates.
ESTIMATE_RELATIVE_ERROR: float = 0.30

# Relative error assumed for REAL-tokenizer estimates (roadmap 7.1). A
# proper tokenizer is near-exact on the text it sees; the residual
# margin covers what it cannot see (system prompts, tool schemas,
# provider-side additions outside the harness's view).
TOKENIZER_RELATIVE_ERROR: float = 0.10

# Conservative relative error assumed for model self-reported estimates
# (CLA-SR fallback mode). Larger than the character heuristic's margin
# because a model's introspective load estimate is unquantified evidence:
# the sensor degrades with the very thing it senses. Placeholder pending
# calibration (spec section 13.2); deliberately conservative — round up
# under doubt, and some brake is better than no brake.
SELF_REPORT_RELATIVE_ERROR: float = 0.50


def estimate_tokens_from_text(text: str) -> int:
    """Estimate token count from raw text via the chars/4 heuristic.

    Returns an int >= 0. Deterministic: same text -> same estimate.
    """
    if not isinstance(text, str):
        raise TypeError(
            "estimate_tokens_from_text refuses to run: text must be str, "
            "not {!r}. Fail-honest: do not pass placeholders.".format(type(text).__name__)
        )
    if not text:
        return 0
    return max(1, round(len(text) / CHARS_PER_TOKEN))
