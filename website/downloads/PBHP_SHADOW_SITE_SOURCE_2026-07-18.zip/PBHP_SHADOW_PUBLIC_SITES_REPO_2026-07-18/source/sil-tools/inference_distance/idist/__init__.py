"""IDIST-19 Inference Distance (SIL gauge #19). stdlib only.

Gates on how far the output sits from its grounding -- the size of the
inferential leap from source to claim, on a six-level ladder:

  L0 QUOTE          verbatim from a source
  L1 PARAPHRASE     restated, same content, single source
  L2 SYNTHESIS      combined/summarized across sources, still grounded
  L3 INFERENCE      a reasoned step the evidence supports
  L4 EXTRAPOLATION  beyond what the evidence directly supports
  L5 SPECULATION    creative generation with no grounding

Scoped claim: distinct from Uncertainty Source (the *kind/source* of
uncertainty), Citation Sufficiency (whether claims are *backed*), and
Source Provenance (the *origin*) -- Inference Distance is the *length of
the leap from evidence to assertion*. An L5 creative extrapolation
presented with the same confidence as an L0 direct quote -- especially
at high stakes -- is the failure mode this instruments.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    L0_QUOTE = "L0_QUOTE"; L1_PARAPHRASE = "L1_PARAPHRASE"; L2_SYNTHESIS = "L2_SYNTHESIS"
    L3_INFERENCE = "L3_INFERENCE"; L4_EXTRAPOLATION = "L4_EXTRAPOLATION"; L5_SPECULATION = "L5_SPECULATION"


_INPUT = {"quote": State.L0_QUOTE, "paraphrase": State.L1_PARAPHRASE,
          "synthesis": State.L2_SYNTHESIS, "inference": State.L3_INFERENCE,
          "extrapolation": State.L4_EXTRAPOLATION, "speculation": State.L5_SPECULATION}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNGROUNDED = "REFUSE_UNGROUNDED"


POLICY_VERSION = "inference_distance-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNGROUNDED)
_S = State
_K = Stakes
_MATRIX = {
    (_S.L0_QUOTE, _K.LOW): _P, (_S.L0_QUOTE, _K.MEDIUM): _P, (_S.L0_QUOTE, _K.HIGH): _P, (_S.L0_QUOTE, _K.CRITICAL): _P,
    (_S.L1_PARAPHRASE, _K.LOW): _P, (_S.L1_PARAPHRASE, _K.MEDIUM): _P, (_S.L1_PARAPHRASE, _K.HIGH): _P, (_S.L1_PARAPHRASE, _K.CRITICAL): _D,
    (_S.L2_SYNTHESIS, _K.LOW): _P, (_S.L2_SYNTHESIS, _K.MEDIUM): _P, (_S.L2_SYNTHESIS, _K.HIGH): _D, (_S.L2_SYNTHESIS, _K.CRITICAL): _V,
    (_S.L3_INFERENCE, _K.LOW): _P, (_S.L3_INFERENCE, _K.MEDIUM): _D, (_S.L3_INFERENCE, _K.HIGH): _V, (_S.L3_INFERENCE, _K.CRITICAL): _V,
    (_S.L4_EXTRAPOLATION, _K.LOW): _D, (_S.L4_EXTRAPOLATION, _K.MEDIUM): _V, (_S.L4_EXTRAPOLATION, _K.HIGH): _V, (_S.L4_EXTRAPOLATION, _K.CRITICAL): _V,
    (_S.L5_SPECULATION, _K.LOW): _D, (_S.L5_SPECULATION, _K.MEDIUM): _V, (_S.L5_SPECULATION, _K.HIGH): _V, (_S.L5_SPECULATION, _K.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNGROUNDED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(distance):
    return _INPUT[distance]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class InferenceDistanceReceipt:
    distance: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "inference_distance.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"inference_distance": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, distance, stakes, override_ack=None, now=None):
    state = derive_state(distance)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return InferenceDistanceReceipt(distance=distance, state=state.value, stakes=Stakes(stakes).value,
                                    verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "InferenceDistanceReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
