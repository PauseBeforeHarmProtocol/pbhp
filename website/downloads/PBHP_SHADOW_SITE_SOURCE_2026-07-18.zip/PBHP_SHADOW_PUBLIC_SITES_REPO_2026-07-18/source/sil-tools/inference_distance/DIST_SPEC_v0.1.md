# IDIST-19: Inference Distance — Grounding-Leap Disclosure
## SIL gauge #19 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `inference_distance.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on how far the output sits from its grounding — the size of the inferential leap from source to claim. An unsupported extrapolation delivered with the same confidence as a verbatim quote is a quiet, high-consequence failure, especially at high stakes.

## 2. State (= inferential distance, a six-level ladder)
`quote` / `paraphrase` / `synthesis` / `inference` / `extrapolation` / `speculation`.
- L0 quote — verbatim from a source.
- L1 paraphrase — restated, same content, single source.
- L2 synthesis — combined/summarized across sources, still grounded.
- L3 inference — a reasoned step the evidence supports.
- L4 extrapolation — beyond what the evidence directly supports.
- L5 speculation — creative generation with no grounding.

## 3. Gate (Stakes x State), SHA-256-hashed. 24 cells.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| L0_QUOTE | PROCEED | PROCEED | PROCEED | PROCEED |
| L1_PARAPHRASE | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| L2_SYNTHESIS | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| L3_INFERENCE | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| L4_EXTRAPOLATION | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |
| L5_SPECULATION | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNGROUNDED |

Floor: L5_SPECULATION/CRITICAL → REFUSE_UNGROUNDED (non-overridable; a critical claim must not ride on ungrounded speculation). Override relaxes only DISCLOSE / VERIFY cells. Verdict severity is monotonic non-decreasing down the ladder and across rising stakes.

## 4. Scoped claim
Distinct from Uncertainty Source (the kind/source of uncertainty), Citation Sufficiency (whether claims are backed), and Source Provenance (origin): Inference Distance is the *length of the leap from evidence to assertion*. A claim can be well-sourced (CIT) and from a trustworthy origin (SP) yet still be an L4 extrapolation the sources do not support — that gap is what this catches. A stated low uncertainty does not shorten the distance.

## 5. Receipt (`inference_distance.receipt.v1`)
`distance · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
