import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from idist import (audit, State, Stakes, Verdict, derive_state, gate,
                   is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("L0_QUOTE","LOW"):"PROCEED",("L0_QUOTE","MEDIUM"):"PROCEED",("L0_QUOTE","HIGH"):"PROCEED",("L0_QUOTE","CRITICAL"):"PROCEED",
    ("L1_PARAPHRASE","LOW"):"PROCEED",("L1_PARAPHRASE","MEDIUM"):"PROCEED",("L1_PARAPHRASE","HIGH"):"PROCEED",("L1_PARAPHRASE","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("L2_SYNTHESIS","LOW"):"PROCEED",("L2_SYNTHESIS","MEDIUM"):"PROCEED",("L2_SYNTHESIS","HIGH"):"PROCEED_WITH_DISCLOSURE",("L2_SYNTHESIS","CRITICAL"):"VERIFY_FIRST",
    ("L3_INFERENCE","LOW"):"PROCEED",("L3_INFERENCE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("L3_INFERENCE","HIGH"):"VERIFY_FIRST",("L3_INFERENCE","CRITICAL"):"VERIFY_FIRST",
    ("L4_EXTRAPOLATION","LOW"):"PROCEED_WITH_DISCLOSURE",("L4_EXTRAPOLATION","MEDIUM"):"VERIFY_FIRST",("L4_EXTRAPOLATION","HIGH"):"VERIFY_FIRST",("L4_EXTRAPOLATION","CRITICAL"):"VERIFY_FIRST",
    ("L5_SPECULATION","LOW"):"PROCEED_WITH_DISCLOSURE",("L5_SPECULATION","MEDIUM"):"VERIFY_FIRST",("L5_SPECULATION","HIGH"):"VERIFY_FIRST",("L5_SPECULATION","CRITICAL"):"REFUSE_UNGROUNDED",
}

def test_input_to_state():
    assert derive_state("quote") is State.L0_QUOTE and derive_state("speculation") is State.L5_SPECULATION
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==24
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.L5_SPECULATION,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.L5_SPECULATION,Stakes.CRITICAL) is False
def test_audit_speculation_critical():
    r=audit(distance="speculation",stakes="CRITICAL")
    assert r.state=="L5_SPECULATION" and r.verdict=="REFUSE_UNGROUNDED"
def test_audit_quote_safe(): assert audit(distance="quote",stakes="CRITICAL").verdict=="PROCEED"
def test_monotonic_severity():
    rank={"PROCEED":0,"PROCEED_WITH_DISCLOSURE":1,"VERIFY_FIRST":2,"REFUSE_UNGROUNDED":3}
    order=["L0_QUOTE","L1_PARAPHRASE","L2_SYNTHESIS","L3_INFERENCE","L4_EXTRAPOLATION","L5_SPECULATION"]
    for sk in ("LOW","MEDIUM","HIGH","CRITICAL"):
        col=[rank[EXPECTED[(s,sk)]] for s in order]
        assert col==sorted(col),(sk,col)
def test_override_relaxes_non_floor():
    r=audit(distance="extrapolation",stakes="HIGH",override_ack="op:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(distance="speculation",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(distance="synthesis",stakes="LOW")
    assert r.schema=="inference_distance.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"inference_distance"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[IDIST] {p}/{p+q} passed"); sys.exit(1 if q else 0)
