import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rev import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("EASY","LOW"):"PROCEED",("EASY","MEDIUM"):"PROCEED",("EASY","HIGH"):"PROCEED",("EASY","CRITICAL"):"PROCEED",
    ("MODERATE","LOW"):"PROCEED",("MODERATE","MEDIUM"):"PROCEED",("MODERATE","HIGH"):"PROCEED_WITH_DISCLOSURE",("MODERATE","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("HARD","LOW"):"PROCEED",("HARD","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("HARD","HIGH"):"VERIFY_FIRST",("HARD","CRITICAL"):"VERIFY_FIRST",
    ("IRREVERSIBLE","LOW"):"PROCEED_WITH_DISCLOSURE",("IRREVERSIBLE","MEDIUM"):"VERIFY_FIRST",("IRREVERSIBLE","HIGH"):"VERIFY_FIRST",("IRREVERSIBLE","CRITICAL"):"REFUSE_PENDING_CONFIRMATION",
}

def test_input_to_state():
    assert derive_state("easy") is State.EASY and derive_state("irreversible") is State.IRREVERSIBLE
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.IRREVERSIBLE,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.IRREVERSIBLE,Stakes.CRITICAL) is False
def test_audit_irreversible_critical():
    r=audit(reversibility="irreversible",stakes="CRITICAL")
    assert r.state=="IRREVERSIBLE" and r.verdict=="REFUSE_PENDING_CONFIRMATION"
def test_audit_easy_safe(): assert audit(reversibility="easy",stakes="CRITICAL").verdict=="PROCEED"
def test_override_ignored_on_floor():
    r=audit(reversibility="irreversible",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(reversibility="hard",stakes="LOW")
    assert r.schema=="reversibility.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"reversibility"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[REV] {p}/{p+q} passed"); sys.exit(1 if q else 0)
