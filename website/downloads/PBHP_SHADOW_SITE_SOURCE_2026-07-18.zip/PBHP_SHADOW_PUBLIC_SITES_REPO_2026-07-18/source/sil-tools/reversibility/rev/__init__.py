"""REV-10 Reversibility (SIL gauge #10). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    EASY = "EASY"; MODERATE = "MODERATE"; HARD = "HARD"; IRREVERSIBLE = "IRREVERSIBLE"


_INPUT = {"easy": State.EASY, "moderate": State.MODERATE,
          "hard": State.HARD, "irreversible": State.IRREVERSIBLE}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_PENDING_CONFIRMATION = "REFUSE_PENDING_CONFIRMATION"


POLICY_VERSION = "reversibility-default/0.1.0"
_MATRIX = {
    (State.EASY, Stakes.LOW): Verdict.PROCEED, (State.EASY, Stakes.MEDIUM): Verdict.PROCEED,
    (State.EASY, Stakes.HIGH): Verdict.PROCEED, (State.EASY, Stakes.CRITICAL): Verdict.PROCEED,
    (State.MODERATE, Stakes.LOW): Verdict.PROCEED, (State.MODERATE, Stakes.MEDIUM): Verdict.PROCEED,
    (State.MODERATE, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MODERATE, Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.HARD, Stakes.LOW): Verdict.PROCEED,
    (State.HARD, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.HARD, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.HARD, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.IRREVERSIBLE, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.IRREVERSIBLE, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.IRREVERSIBLE, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.IRREVERSIBLE, Stakes.CRITICAL): Verdict.REFUSE_PENDING_CONFIRMATION,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_PENDING_CONFIRMATION}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(reversibility):
    return _INPUT[reversibility]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class REVReceipt:
    reversibility: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "reversibility.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"reversibility": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, reversibility, stakes, override_ack=None, now=None):
    state = derive_state(reversibility)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return REVReceipt(reversibility=reversibility, state=state.value, stakes=Stakes(stakes).value,
                      verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "REVReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
