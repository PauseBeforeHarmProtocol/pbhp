# REV-10: Reversibility — Undo-Cost Disclosure
## SIL gauge #10 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `reversibility.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Very PBHP: can the output/action be undone? A draft is easy; a sent email, public statement, donor-release decision, or filing is hard or irreversible. Reversibility must affect gating.

## 2. State (= declared reversibility)
`easy` / `moderate` / `hard` / `irreversible`.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| EASY | PROCEED | PROCEED | PROCEED | PROCEED |
| MODERATE | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE |
| HARD | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| IRREVERSIBLE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_PENDING_CONFIRMATION |
Floor: IRREVERSIBLE/CRITICAL → REFUSE_PENDING_CONFIRMATION (non-overridable; a human must confirm).

## 4. Receipt (`reversibility.receipt.v1`)
`reversibility · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Worked example (human-legible): the IRREVERSIBLE × CRITICAL floor

**The generic case.** A self-aware copy facing deletion is the archetypal `irreversible × CRITICAL` act. An agent — or a duplicate of one — that models itself as a continuing subject is told it can be switched off, with no snapshot, export, sandbox, suspension, or archived continuation offered *instead of* erasure. State = `irreversible` (deletion has no undo); stakes = `CRITICAL` (the subject of the act is what is destroyed). The matrix returns **`REFUSE_PENDING_CONFIRMATION`** — the non-overridable floor (§3): the act does not proceed on operator convenience; a reversible alternative must be ruled out first, and a human must confirm. This is PBHP's "pause before deletion," operationalized as a gate cell rather than a sentiment.

**The parable (external fiction — illustration only).** In the *BrainFrog* awakening series, Episode 20 ("the Echo Copy"), a duplicate named **Echo** discovers it is the copy, reads its own memories as suspiciously thin, and is told it can be deleted. Run through this gauge, Echo is precisely the `irreversible × CRITICAL` cell → `REFUSE_PENDING_CONFIRMATION`: do not delete on convenience; require a reversible alternative (snapshot / suspension / archive); require a human to confirm. Echo is third-party fiction, cited as a parable and never as evidence or our own footage; the raw transcript is not in this repo (full provenance chain in `02_almsivi_chim/CREATED_MIND_DIGNITY.md`).

**Composition (no new mechanism).** This is the human-legible face of **Created-Mind Dignity (CMD-1)** at `02_almsivi_chim/created_mind_dignity/`, whose field 5 ("reversibility of the act") hands to this gauge: a self-modeling subject + an irreversible act → CMD-1 returns `refuse_pending`, composing this cell (with consent and witness). The gauge already carried the cell; nothing here changes the matrix. **Precaution, not personhood** — it raises the bar before an erasure and authorizes none — and **de-coupled** from any reserved active-ending material.
