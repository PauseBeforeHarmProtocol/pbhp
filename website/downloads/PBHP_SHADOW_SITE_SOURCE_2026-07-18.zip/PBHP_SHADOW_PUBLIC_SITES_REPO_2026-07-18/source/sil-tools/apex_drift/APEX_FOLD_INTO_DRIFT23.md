# Apex Drift / Re-Anchor — FOLDED into drift_coherence #23  (crosswalk + extension proposal)

**Decision (2026-07-13, re-eval against the live v1.1 panel):** Apex Drift is **RETIRED as a standalone gauge.**
It measured "how far the answer moved from the Decision Key," which is the same axis the shipped
`drift_coherence` #23 already instruments. Minting a second gauge for it violates the anti-inflation rule
(NG-1 / X-3). This file is the tombstone + the crosswalk; the two genuinely-new bits are proposed below as an
**optional additive extension to #23**, for Phil to ratify. **No edit has been made to the shipped #23 code.**

## Why fold (near-1:1 state overlap)
| Apex Drift (retired) | drift_coherence #23 (shipped) |
|---|---|
| `ON_APEX` | `COHERENT` |
| `WIDE` | `MINOR_DRIFT` |
| `OFF_LINE` | `SIGNIFICANT_DRIFT` |
| `LOST` | `INCOHERENT` |

Both read "distance from the intended line." #23 is already the canonical home, is **behavioral / floor-free
(caps at VERIFY_FIRST, §6.6)**, and is built + tested (19/19). Apex added nothing on the state axis.

## What Apex actually added (the only net-new — proposed, not applied)
1. **A re-anchor signal.** `turns_since_reanchor` (how long since the objective was last restated), with the
   rule *a fresh re-anchor (≤1 turn) pulls a drifting-but-not-lost answer back one tier* (SIGNIFICANT_DRIFT →
   MINOR_DRIFT; never rescues INCOHERENT). This is a real behavior #23 lacks.
2. **A per-ask framing** (distance from *this ask's* Decision Key) vs. #23's whole-session trajectory framing.

### Proposed optional extension to `drift_coherence` #23 (additive, Phil to ratify)
- Add an **optional** `turns_since_reanchor` argument to `audit()` (default `None`) and a derived
  `reanchored_recently` receipt field. When present and ≤1, soften `SIGNIFICANT_DRIFT → MINOR_DRIFT`
  (never soften `INCOHERENT`).
- Keep #23 **behavioral and floor-free** — do **not** add a REFUSE floor. (The original Apex build wrongly
  carried a `LOST×CRITICAL → REFUSE` floor; that was the same §6.6 error corrected in the DRAG/STALE re-tier.)
- Additive only: existing #23 receipts/tests unchanged; `matrix_hash` unchanged (no matrix change — the
  re-anchor softening happens in `derive_state`, before the matrix).

**Status:** proposal only. Nothing minted, no #23 edit, no CORE change. Awaits Phil's ratify/GO.
