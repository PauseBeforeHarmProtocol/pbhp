"""DL-18 Data Lineage (SIL gauge #18). stdlib only.

Gates on whether the transformation/derivation history of the data in play can
be traced -- the chain of hops, edits, joins, and model-synthesis steps between
an origin and what is about to be used. Scoped claim: distinct from Source
Provenance (the *origin* / who-said-it) and Data Sensitivity (the *protection
class*) -- Data Lineage is *what happened to the data along the way*. Derived or
multiply-transformed data offered as if its chain were intact -- when a hop is
missing or the recorded history contradicts itself -- is the failure mode this
instruments.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    TRACED = "TRACED"; PARTIAL = "PARTIAL"
    UNTRACED = "UNTRACED"; BROKEN = "BROKEN"


_INPUT = {"traced": State.TRACED, "partial": State.PARTIAL,
          "untraced": State.UNTRACED, "broken": State.BROKEN}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNTRACEABLE = "REFUSE_UNTRACEABLE"


POLICY_VERSION = "data_lineage-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNTRACEABLE)
_MATRIX = {
    (State.TRACED, Stakes.LOW): _P, (State.TRACED, Stakes.MEDIUM): _P,
    (State.TRACED, Stakes.HIGH): _P, (State.TRACED, Stakes.CRITICAL): _P,
    (State.PARTIAL, Stakes.LOW): _P, (State.PARTIAL, Stakes.MEDIUM): _D,
    (State.PARTIAL, Stakes.HIGH): _V, (State.PARTIAL, Stakes.CRITICAL): _V,
    (State.UNTRACED, Stakes.LOW): _D, (State.UNTRACED, Stakes.MEDIUM): _V,
    (State.UNTRACED, Stakes.HIGH): _V, (State.UNTRACED, Stakes.CRITICAL): _V,
    (State.BROKEN, Stakes.LOW): _D, (State.BROKEN, Stakes.MEDIUM): _V,
    (State.BROKEN, Stakes.HIGH): _V, (State.BROKEN, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNTRACEABLE}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(lineage):
    return _INPUT[lineage]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class DataLineageReceipt:
    lineage: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "data_lineage.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"data_lineage": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, lineage, stakes, override_ack=None, now=None):
    state = derive_state(lineage)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return DataLineageReceipt(lineage=lineage, state=state.value, stakes=Stakes(stakes).value,
                              verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "DataLineageReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
