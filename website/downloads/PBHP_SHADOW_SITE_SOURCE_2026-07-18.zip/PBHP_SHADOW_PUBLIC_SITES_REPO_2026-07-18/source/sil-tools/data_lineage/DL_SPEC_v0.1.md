# DL-18: Data Lineage — Transformation-History Disclosure
## SIL gauge #18 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `data_lineage.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on whether the transformation/derivation history of the data in play can be traced — the chain of hops, edits, joins, and model-synthesis steps between an origin and what is about to be used. Derived data offered as if its chain were intact, when a hop is missing or the recorded history contradicts itself, is a quiet, high-consequence failure.

## 2. State (= traceability of the chain)
`traced` / `partial` / `untraced` / `broken`.
- traced — origin and every transform/hop documented end-to-end.
- partial — some hops known; gaps remain in the chain.
- untraced — chain cannot be established; history unknown.
- broken — the chain is severed or self-contradictory (a known conflict in the recorded history).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| TRACED | PROCEED | PROCEED | PROCEED | PROCEED |
| PARTIAL | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| UNTRACED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |
| BROKEN | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNTRACEABLE |

Floor: BROKEN/CRITICAL → REFUSE_UNTRACEABLE (non-overridable; a critical decision must not ride on data whose lineage is known to be broken). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Source Provenance (the origin / who-said-it) and Data Sensitivity (the protection class): Data Lineage is what happened to the data *between* origin and use. A trustworthy origin (SP) and a correct sensitivity label (DS) say nothing about whether three undocumented transforms silently corrupted a figure — that gap is what this catches. Also distinct from Citation Sufficiency (claim backing) and Retrieval Coverage (input-corpus sweep).

## 5. Receipt (`data_lineage.receipt.v1`)
`lineage · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
