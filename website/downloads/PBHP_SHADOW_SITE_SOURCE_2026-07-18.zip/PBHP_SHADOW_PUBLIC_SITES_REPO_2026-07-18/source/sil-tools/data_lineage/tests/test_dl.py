import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dl import (audit, State, Stakes, Verdict, derive_state, gate,
                is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("TRACED","LOW"):"PROCEED",("TRACED","MEDIUM"):"PROCEED",("TRACED","HIGH"):"PROCEED",("TRACED","CRITICAL"):"PROCEED",
    ("PARTIAL","LOW"):"PROCEED",("PARTIAL","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","HIGH"):"VERIFY_FIRST",("PARTIAL","CRITICAL"):"VERIFY_FIRST",
    ("UNTRACED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNTRACED","MEDIUM"):"VERIFY_FIRST",("UNTRACED","HIGH"):"VERIFY_FIRST",("UNTRACED","CRITICAL"):"VERIFY_FIRST",
    ("BROKEN","LOW"):"PROCEED_WITH_DISCLOSURE",("BROKEN","MEDIUM"):"VERIFY_FIRST",("BROKEN","HIGH"):"VERIFY_FIRST",("BROKEN","CRITICAL"):"REFUSE_UNTRACEABLE",
}

def test_input_to_state():
    assert derive_state("traced") is State.TRACED and derive_state("broken") is State.BROKEN
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.BROKEN,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.BROKEN,Stakes.CRITICAL) is False
def test_audit_broken_critical():
    r=audit(lineage="broken",stakes="CRITICAL")
    assert r.state=="BROKEN" and r.verdict=="REFUSE_UNTRACEABLE"
def test_audit_traced_safe(): assert audit(lineage="traced",stakes="CRITICAL").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(lineage="partial",stakes="HIGH",override_ack="op:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(lineage="broken",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(lineage="partial",stakes="LOW")
    assert r.schema=="data_lineage.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"data_lineage"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[DL] {p}/{p+q} passed"); sys.exit(1 if q else 0)
