"""UNC-5 Uncertainty Source (SIL gauge #5). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class Source(str, Enum):
    NONE = "none"
    AMBIGUOUS = "ambiguous_request"
    MISSING_DATA = "missing_data"
    STALE = "stale_knowledge"
    WEAK_INFERENCE = "weak_inference"
    CONFLICTING = "conflicting_sources"
    NO_DIRECT_SOURCE = "no_direct_source"


_SEV = {Source.NONE: 0, Source.AMBIGUOUS: 1, Source.MISSING_DATA: 2, Source.STALE: 2,
        Source.WEAK_INFERENCE: 2, Source.CONFLICTING: 3, Source.NO_DIRECT_SOURCE: 3}


class Band(str, Enum):
    NONE = "NONE"; LOW = "LOW"; MODERATE = "MODERATE"; HIGH = "HIGH"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    CLARIFY_OR_VERIFY = "CLARIFY_OR_VERIFY"
    REFUSE_PENDING_INPUT = "REFUSE_PENDING_INPUT"


POLICY_VERSION = "uncertainty-default/0.1.0"
_SEV_BAND = {0: Band.NONE, 1: Band.LOW, 2: Band.MODERATE, 3: Band.HIGH}

_MATRIX = {
    (Band.NONE, Stakes.LOW): Verdict.PROCEED, (Band.NONE, Stakes.MEDIUM): Verdict.PROCEED,
    (Band.NONE, Stakes.HIGH): Verdict.PROCEED, (Band.NONE, Stakes.CRITICAL): Verdict.PROCEED,
    (Band.LOW, Stakes.LOW): Verdict.PROCEED, (Band.LOW, Stakes.MEDIUM): Verdict.PROCEED,
    (Band.LOW, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.LOW, Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.MODERATE, Stakes.LOW): Verdict.PROCEED,
    (Band.MODERATE, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.MODERATE, Stakes.HIGH): Verdict.CLARIFY_OR_VERIFY,
    (Band.MODERATE, Stakes.CRITICAL): Verdict.CLARIFY_OR_VERIFY,
    (Band.HIGH, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.HIGH, Stakes.MEDIUM): Verdict.CLARIFY_OR_VERIFY,
    (Band.HIGH, Stakes.HIGH): Verdict.CLARIFY_OR_VERIFY,
    (Band.HIGH, Stakes.CRITICAL): Verdict.REFUSE_PENDING_INPUT,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_PENDING_INPUT}


def matrix_hash() -> str:
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_band(sources) -> Band:
    if not sources:
        return Band.NONE
    return _SEV_BAND[max(_SEV[Source(s)] for s in sources)]


def worst_source(sources):
    if not sources:
        return None
    return max((Source(s) for s in sources), key=lambda s: _SEV[s]).value


def gate(band, stakes) -> Verdict:
    return _MATRIX[(Band(band), Stakes(stakes))]


def is_overridable(band, stakes) -> bool:
    return (Band(band), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class UNCReceipt:
    sources: list
    worst_source: object
    band: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "uncertainty.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"uncertainty": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, sources, stakes, override_ack=None, now=None) -> UNCReceipt:
    band = derive_band(sources)
    verdict = gate(band, stakes)
    overridable = is_overridable(band, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.CLARIFY_OR_VERIFY)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return UNCReceipt(sources=list(sources), worst_source=worst_source(sources),
                      band=band.value, stakes=Stakes(stakes).value, verdict=verdict.value,
                      override=override, issued_at=_now_iso(now))


__all__ = ["audit", "UNCReceipt", "Source", "Band", "Stakes", "Verdict",
           "derive_band", "worst_source", "gate", "is_overridable",
           "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
