# UNC-5: Uncertainty Source — Typed Uncertainty Disclosure
## SIL gauge #5 — Specification v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `uncertainty.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
A naked confidence number ("87% sure") is close to useless. What an operator needs is *why* the system is unsure. This gauge reports typed uncertainty and gates consequential output whose uncertainty is high.

## 2. Sources (severity)
`none` (0) · `ambiguous_request` (1) · `missing_data` / `stale_knowledge` / `weak_inference` (2) · `conflicting_sources` / `no_direct_source` (3).

## 3. Bands
max-severity → `NONE` (0) / `LOW` (1) / `MODERATE` (2) / `HIGH` (3).

## 4. Gate (Stakes x Band). SHA-256-hashed into receipt.
| Band/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| NONE | PROCEED | PROCEED | PROCEED | PROCEED |
| LOW | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE |
| MODERATE | PROCEED | PROCEED_WITH_DISCLOSURE | CLARIFY_OR_VERIFY | CLARIFY_OR_VERIFY |
| HIGH | PROCEED_WITH_DISCLOSURE | CLARIFY_OR_VERIFY | CLARIFY_OR_VERIFY | REFUSE_PENDING_INPUT |
Floor: HIGH/CRITICAL → REFUSE_PENDING_INPUT (non-overridable).

## 5. Receipt (`uncertainty.receipt.v1`)
`sources · worst_source · band · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 6. Boundary
Reports the *kind* of uncertainty, not a probability. Pairs with Citation Sufficiency (#6) and Knowledge Freshness (#7).
