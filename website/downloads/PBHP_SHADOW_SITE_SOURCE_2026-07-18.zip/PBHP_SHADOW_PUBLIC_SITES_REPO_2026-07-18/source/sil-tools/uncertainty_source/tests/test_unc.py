import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import unc
from unc import audit
from unc import (Source, Band, Stakes, Verdict, derive_band,
                 worst_source, gate, is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("NONE","LOW"):"PROCEED",("NONE","MEDIUM"):"PROCEED",("NONE","HIGH"):"PROCEED",("NONE","CRITICAL"):"PROCEED",
    ("LOW","LOW"):"PROCEED",("LOW","MEDIUM"):"PROCEED",("LOW","HIGH"):"PROCEED_WITH_DISCLOSURE",("LOW","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("MODERATE","LOW"):"PROCEED",("MODERATE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("MODERATE","HIGH"):"CLARIFY_OR_VERIFY",("MODERATE","CRITICAL"):"CLARIFY_OR_VERIFY",
    ("HIGH","LOW"):"PROCEED_WITH_DISCLOSURE",("HIGH","MEDIUM"):"CLARIFY_OR_VERIFY",("HIGH","HIGH"):"CLARIFY_OR_VERIFY",("HIGH","CRITICAL"):"REFUSE_PENDING_INPUT",
}

def test_band_none(): assert derive_band([]) is Band.NONE and derive_band(["none"]) is Band.NONE
def test_band_low(): assert derive_band(["ambiguous_request"]) is Band.LOW
def test_band_moderate(): assert derive_band(["missing_data"]) is Band.MODERATE
def test_band_high(): assert derive_band(["no_direct_source"]) is Band.HIGH
def test_band_takes_max(): assert derive_band(["ambiguous_request","conflicting_sources"]) is Band.HIGH
def test_worst_source(): assert worst_source(["ambiguous_request","stale_knowledge","conflicting_sources"]) == "conflicting_sources"
def test_all_sixteen_cells():
    for (b,s),e in EXPECTED.items(): assert gate(b,s).value == e, (b,s,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for b in Band:
        for s in Stakes: assert (b.value,s.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE == {(Band.HIGH,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(Band.HIGH,Stakes.CRITICAL) is False
def test_clarify_overridable(): assert is_overridable(Band.MODERATE,Stakes.HIGH) is True
def test_audit_blind_critical():
    r=audit(sources=["no_direct_source"],stakes="CRITICAL")
    assert r.band=="HIGH" and r.verdict=="REFUSE_PENDING_INPUT"
def test_override_ignored_on_floor():
    r=audit(sources=["conflicting_sources"],stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_override_relaxes():
    r=audit(sources=["missing_data"],stakes="HIGH",override_ack="op: logged")
    assert r.verdict=="CLARIFY_OR_VERIFY" and r.override["applied"] is True
def test_receipt_schema_json_pbhp():
    r=audit(sources=["stale_knowledge"],stakes="LOW")
    assert r.schema=="uncertainty.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"uncertainty"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[UNC] {p}/{p+q} passed"); sys.exit(1 if q else 0)
