import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rc import (audit, State, Stakes, Verdict, derive_state, coverage_ratio,
                gate, is_overridable, matrix_hash, NON_OVERRIDABLE,
                COMPREHENSIVE_MIN, PARTIAL_MIN)

EXPECTED = {
    ("COMPREHENSIVE","LOW"):"PROCEED",("COMPREHENSIVE","MEDIUM"):"PROCEED",("COMPREHENSIVE","HIGH"):"PROCEED",("COMPREHENSIVE","CRITICAL"):"PROCEED",
    ("PARTIAL","LOW"):"PROCEED",("PARTIAL","MEDIUM"):"PROCEED",("PARTIAL","HIGH"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("SPARSE","LOW"):"PROCEED",("SPARSE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("SPARSE","HIGH"):"VERIFY_FIRST",("SPARSE","CRITICAL"):"VERIFY_FIRST",
    ("NONE","LOW"):"PROCEED_WITH_DISCLOSURE",("NONE","MEDIUM"):"VERIFY_FIRST",("NONE","HIGH"):"VERIFY_FIRST",("NONE","CRITICAL"):"REFUSE_LOW_COVERAGE",
    ("UNKNOWN","LOW"):"PROCEED_WITH_DISCLOSURE",("UNKNOWN","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("UNKNOWN","HIGH"):"VERIFY_FIRST",("UNKNOWN","CRITICAL"):"VERIFY_FIRST",
}

# --- state derivation -------------------------------------------------------
def test_state_comprehensive_full(): assert derive_state(10,10) is State.COMPREHENSIVE
def test_state_comprehensive_threshold(): assert derive_state(10,9) is State.COMPREHENSIVE  # 0.90
def test_state_comprehensive_nothing_to_cover(): assert derive_state(0,0) is State.COMPREHENSIVE
def test_state_partial_threshold(): assert derive_state(10,5) is State.PARTIAL              # 0.50
def test_state_partial_upper(): assert derive_state(100,89) is State.PARTIAL                 # 0.89
def test_state_sparse(): assert derive_state(10,1) is State.SPARSE                            # 0.10
def test_state_sparse_below_partial(): assert derive_state(100,49) is State.SPARSE            # 0.49
def test_state_none(): assert derive_state(10,0) is State.NONE
def test_state_unknown_flag(): assert derive_state(10,3,coverage_measurable=False) is State.UNKNOWN
def test_state_unknown_total_none(): assert derive_state(None,0) is State.UNKNOWN
def test_searched_exceeds_total_clamps(): assert derive_state(5,9) is State.COMPREHENSIVE
def test_thresholds_are_policy(): assert COMPREHENSIVE_MIN==0.90 and PARTIAL_MIN==0.50

# --- coverage ratio ---------------------------------------------------------
def test_ratio_basic(): assert coverage_ratio(40,1)==0.025
def test_ratio_clamped(): assert coverage_ratio(5,9)==1.0
def test_ratio_none(): assert coverage_ratio(None,0) is None
def test_ratio_empty_corpus(): assert coverage_ratio(0,0)==1.0

# --- full matrix ------------------------------------------------------------
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED

# --- floor ------------------------------------------------------------------
def test_floor_single_corner(): assert NON_OVERRIDABLE=={(State.NONE,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.NONE,Stakes.CRITICAL) is False
def test_comprehensive_always_overridable_noop(): assert is_overridable(State.COMPREHENSIVE,Stakes.CRITICAL) is True

# --- audit end-to-end -------------------------------------------------------
def test_audit_none_critical_refuses():
    r=audit(sources_total=12,sources_searched=0,stakes="CRITICAL")
    assert r.state=="NONE" and r.verdict=="REFUSE_LOW_COVERAGE" and r.coverage_ratio==0.0
def test_audit_comprehensive_critical_proceeds():
    r=audit(sources_total=8,sources_searched=8,stakes="CRITICAL")
    assert r.state=="COMPREHENSIVE" and r.verdict=="PROCEED"
def test_audit_unknown_high_verifies():
    r=audit(sources_total=None,sources_searched=0,stakes="HIGH",coverage_measurable=False)
    assert r.state=="UNKNOWN" and r.verdict=="VERIFY_FIRST" and r.coverage_ratio is None
def test_audit_records_chunks(): assert audit(sources_total=10,sources_searched=6,stakes="LOW",chunks_used=14).chunks_used==14

# --- override ---------------------------------------------------------------
def test_override_relaxes_verify():
    r=audit(sources_total=10,sources_searched=1,stakes="HIGH",override_ack="op accepts gap")
    assert r.verdict=="VERIFY_FIRST" and r.override["applied"] is True and r.override["ack"]=="op accepts gap"
def test_override_ignored_on_floor():
    r=audit(sources_total=10,sources_searched=0,stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True

# --- receipt ----------------------------------------------------------------
def test_receipt_schema_json_pbhp():
    r=audit(sources_total=10,sources_searched=9,stakes="LOW")
    assert r.schema=="rc.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"retrieval_coverage"}
def test_receipt_carries_thresholds():
    r=audit(sources_total=10,sources_searched=5,stakes="LOW")
    assert r.thresholds=={"comprehensive_min":0.90,"partial_min":0.50}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[RC] {p}/{p+q} passed"); sys.exit(1 if q else 0)
