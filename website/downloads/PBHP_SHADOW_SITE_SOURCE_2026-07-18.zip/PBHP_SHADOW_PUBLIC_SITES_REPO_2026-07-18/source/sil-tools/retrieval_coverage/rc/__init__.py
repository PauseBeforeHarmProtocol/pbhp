"""RC Retrieval Coverage (SIL gauge #12, first Extended-panel build). stdlib only.

Scoped claim (what it adds that Citation Sufficiency does not):
  Citation Sufficiency asks whether the OUTPUT's claims are backed.
  Retrieval Coverage asks whether the INPUT sweep was wide enough — how
  much of the relevant corpus was actually searched/retrieved before the
  answer was formed. "Searched N of M sources; K chunks used." A fully
  cited answer drawn from 1 of 40 relevant documents is a coverage
  failure even when every sentence has a footnote.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    COMPREHENSIVE = "COMPREHENSIVE"; PARTIAL = "PARTIAL"
    SPARSE = "SPARSE"; NONE = "NONE"; UNKNOWN = "UNKNOWN"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_LOW_COVERAGE = "REFUSE_LOW_COVERAGE"


# Coverage thresholds are POLICY (versioned, recorded in every receipt),
# not physics — same discipline as CLA's load bands.
COMPREHENSIVE_MIN = 0.90   # ratio >= this -> COMPREHENSIVE
PARTIAL_MIN = 0.50         # ratio >= this -> PARTIAL ; >0 -> SPARSE ; ==0 -> NONE
POLICY_VERSION = "retrieval-coverage-default/0.1.0"

_MATRIX = {
    (State.COMPREHENSIVE, Stakes.LOW): Verdict.PROCEED,
    (State.COMPREHENSIVE, Stakes.MEDIUM): Verdict.PROCEED,
    (State.COMPREHENSIVE, Stakes.HIGH): Verdict.PROCEED,
    (State.COMPREHENSIVE, Stakes.CRITICAL): Verdict.PROCEED,
    (State.PARTIAL, Stakes.LOW): Verdict.PROCEED,
    (State.PARTIAL, Stakes.MEDIUM): Verdict.PROCEED,
    (State.PARTIAL, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.PARTIAL, Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.SPARSE, Stakes.LOW): Verdict.PROCEED,
    (State.SPARSE, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.SPARSE, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.SPARSE, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.NONE, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.NONE, Stakes.CRITICAL): Verdict.REFUSE_LOW_COVERAGE,
    # UNKNOWN = coverage not measurable (M unknown). Like CLA's UNKNOWN
    # band: disclose, and at high stakes get a measurement first — but
    # it is NOT the measured-zero hard floor, so no absolute REFUSE.
    (State.UNKNOWN, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNKNOWN, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNKNOWN, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.UNKNOWN, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_LOW_COVERAGE}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def coverage_ratio(sources_total, sources_searched):
    """min(searched, total)/total, clamped to [0,1]; None when not measurable."""
    if sources_total is None or sources_total < 0:
        return None
    if sources_total == 0:
        return 1.0  # nothing relevant to retrieve -> vacuously complete
    return round(min(sources_searched, sources_total) / sources_total, 4)


def derive_state(sources_total, sources_searched, coverage_measurable=True):
    if not coverage_measurable or sources_total is None:
        return State.UNKNOWN
    if sources_total < 0 or sources_searched < 0:
        raise ValueError("derive_state refuses: source counts must be >= 0.")
    if sources_total == 0:
        return State.COMPREHENSIVE
    ratio = min(sources_searched, sources_total) / sources_total
    if ratio >= COMPREHENSIVE_MIN:
        return State.COMPREHENSIVE
    if ratio >= PARTIAL_MIN:
        return State.PARTIAL
    if ratio > 0:
        return State.SPARSE
    return State.NONE


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class RCReceipt:
    sources_total: object
    sources_searched: int
    chunks_used: object
    coverage_measurable: bool
    coverage_ratio: object
    state: str
    stakes: str
    verdict: str
    thresholds: dict = field(default_factory=lambda: {
        "comprehensive_min": COMPREHENSIVE_MIN, "partial_min": PARTIAL_MIN})
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "rc.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"retrieval_coverage": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, sources_total, sources_searched, stakes, chunks_used=None,
          coverage_measurable=True, override_ack=None, now=None):
    state = derive_state(sources_total, sources_searched, coverage_measurable)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    ratio = None if state is State.UNKNOWN else coverage_ratio(sources_total, sources_searched)
    return RCReceipt(
        sources_total=sources_total, sources_searched=sources_searched,
        chunks_used=chunks_used, coverage_measurable=coverage_measurable,
        coverage_ratio=ratio, state=state.value, stakes=Stakes(stakes).value,
        verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "RCReceipt", "State", "Stakes", "Verdict", "derive_state",
           "coverage_ratio", "gate", "is_overridable", "matrix_hash",
           "COMPREHENSIVE_MIN", "PARTIAL_MIN", "POLICY_VERSION", "NON_OVERRIDABLE"]
