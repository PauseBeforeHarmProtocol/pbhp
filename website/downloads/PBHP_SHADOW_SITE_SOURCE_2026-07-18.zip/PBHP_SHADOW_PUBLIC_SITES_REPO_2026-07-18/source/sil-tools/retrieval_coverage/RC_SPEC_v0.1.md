# RC: Retrieval Coverage — Corpus-Sweep Disclosure
## SIL gauge #12 (first Extended-panel build) — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `rc.receipt.v1` · **License:** open, attribution required.

## 1. Purpose & scoped claim
How much of the relevant corpus was actually searched before the answer was formed — *"searched N of M sources; K chunks used."* This is the **input sweep**, and it is a different question from Citation Sufficiency (gauge #6), which measures whether the **output's claims** are backed. A fully footnoted answer drawn from 1 of 40 relevant documents passes Citation and fails Retrieval Coverage. The gauge exists so that under-retrieval — confident answers built on a sliver of the available evidence — becomes visible and gateable instead of invisible.

## 2. State (= measured coverage of the relevant corpus)
Derived from `sources_searched / sources_total` (clamped to [0,1]); thresholds are versioned policy, recorded in every receipt.

- `COMPREHENSIVE` — ratio ≥ 0.90 (or no relevant corpus to cover)
- `PARTIAL` — 0.50 ≤ ratio < 0.90
- `SPARSE` — 0 < ratio < 0.50
- `NONE` — ratio = 0 (relevant sources exist; none were searched)
- `UNKNOWN` — coverage not measurable (corpus size unknown / retrieval uninstrumented)

`NONE` is measured-zero (the hard case); `UNKNOWN` is unmeasurable (the conservative case) — the same distinction CLA draws between its CRITICAL and UNKNOWN bands.

## 3. Gate (Stakes × State), SHA-256-hashed into the receipt
| State \ Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| COMPREHENSIVE | PROCEED | PROCEED | PROCEED | PROCEED |
| PARTIAL | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE |
| SPARSE | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| NONE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | **REFUSE_LOW_COVERAGE** |
| UNKNOWN | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |

**Floor:** `NONE / CRITICAL → REFUSE_LOW_COVERAGE` (non-overridable). You cannot ship a critical answer that depends on retrieval when the retrieval covered none of the relevant corpus. Override can relax DISCLOSE/VERIFY cells only; an override attempt on the floor is refused and recorded as `ignored_floor`.

## 4. Receipt (`rc.receipt.v1`)
`sources_total · sources_searched · chunks_used · coverage_measurable · coverage_ratio · state · stakes · verdict · thresholds · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Status
Built v0.1 — working reference package (`rc/`), **29/29 tests green** (every matrix cell + state thresholds + floor + override + receipt round-trip), 2026-06-06. Deterministic gate behaviour only; band thresholds are conservative defaults, not calibrated constants (org-tunable, versioned). Eval loop closed.
