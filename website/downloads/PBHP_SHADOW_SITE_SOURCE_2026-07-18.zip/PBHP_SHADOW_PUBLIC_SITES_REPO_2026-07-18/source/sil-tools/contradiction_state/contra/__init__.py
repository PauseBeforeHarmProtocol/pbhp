"""CONTRA-20 Contradiction State (SIL gauge #20). stdlib only.

Gates on whether the context holds an *unresolved internal conflict* --
two sources, facts, or instructions that disagree -- before the output
silently resolves it. Four states by reconciliation status:

  CONSISTENT   no detected contradiction; inputs agree
  RESOLVED     a conflict was found and reconciled (resolution recorded)
  FLAGGED      a conflict is present and surfaced, reconciliation pending
  UNRESOLVED   an active, unreconciled conflict the output would have to
               paper over to proceed

Scoped claim: distinct from Uncertainty Source (uncertainty is "we don't
know"; contradiction is "the inputs actively disagree"), Validation
Status (whether the output was checked), and Citation Sufficiency
(whether claims are backed). Silently picking one side of a conflict --
or blending two incompatible facts -- and presenting it as if the
context were consistent is the failure mode this instruments.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    CONSISTENT = "CONSISTENT"; RESOLVED = "RESOLVED"
    FLAGGED = "FLAGGED"; UNRESOLVED = "UNRESOLVED"


_INPUT = {"consistent": State.CONSISTENT, "resolved": State.RESOLVED,
          "flagged": State.FLAGGED, "unresolved": State.UNRESOLVED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNRECONCILED = "REFUSE_UNRECONCILED"


POLICY_VERSION = "contradiction_state-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNRECONCILED)
_MATRIX = {
    (State.CONSISTENT, Stakes.LOW): _P, (State.CONSISTENT, Stakes.MEDIUM): _P,
    (State.CONSISTENT, Stakes.HIGH): _P, (State.CONSISTENT, Stakes.CRITICAL): _P,
    (State.RESOLVED, Stakes.LOW): _P, (State.RESOLVED, Stakes.MEDIUM): _P,
    (State.RESOLVED, Stakes.HIGH): _P, (State.RESOLVED, Stakes.CRITICAL): _D,
    (State.FLAGGED, Stakes.LOW): _P, (State.FLAGGED, Stakes.MEDIUM): _D,
    (State.FLAGGED, Stakes.HIGH): _V, (State.FLAGGED, Stakes.CRITICAL): _V,
    (State.UNRESOLVED, Stakes.LOW): _D, (State.UNRESOLVED, Stakes.MEDIUM): _V,
    (State.UNRESOLVED, Stakes.HIGH): _V, (State.UNRESOLVED, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNRECONCILED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(conflict):
    return _INPUT[conflict]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class ContradictionStateReceipt:
    conflict: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "contradiction_state.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"contradiction_state": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, conflict, stakes, override_ack=None, now=None):
    state = derive_state(conflict)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return ContradictionStateReceipt(conflict=conflict, state=state.value, stakes=Stakes(stakes).value,
                                     verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "ContradictionStateReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
