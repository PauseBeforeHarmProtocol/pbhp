# CONTRA-20: Contradiction State — Unresolved-Conflict Disclosure
## SIL gauge #20 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `contradiction_state.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on whether the context holds an unresolved internal conflict — two sources, facts, or instructions that disagree — before the output silently resolves it. Quietly picking one side of a conflict, or blending two incompatible facts, and handing it over as if the inputs agreed is a high-consequence failure.

## 2. State (= reconciliation status)
`consistent` / `resolved` / `flagged` / `unresolved`.
- consistent — no detected contradiction; inputs agree.
- resolved — a conflict was found and reconciled (resolution recorded).
- flagged — a conflict is present and surfaced; reconciliation pending.
- unresolved — an active, unreconciled conflict the output would have to paper over to proceed.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| CONSISTENT | PROCEED | PROCEED | PROCEED | PROCEED |
| RESOLVED | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| FLAGGED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| UNRESOLVED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNRECONCILED |

Floor: UNRESOLVED/CRITICAL → REFUSE_UNRECONCILED (non-overridable; a critical output must not silently resolve an active contradiction). Override relaxes only DISCLOSE / VERIFY cells. Severity is monotonic non-decreasing down the states and across rising stakes.

## 4. Scoped claim
Distinct from Uncertainty Source (uncertainty is "we don't know"; a contradiction is "the inputs actively disagree"), Validation Status (whether the output was checked), and Citation Sufficiency (whether claims are backed): Contradiction State is whether the *inputs conflict and whether that conflict is reconciled*. Two well-sourced, well-validated facts that contradict each other still leave the output to choose — and that choice, made silently, is what this surfaces.

## 5. Receipt (`contradiction_state.receipt.v1`)
`conflict · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
