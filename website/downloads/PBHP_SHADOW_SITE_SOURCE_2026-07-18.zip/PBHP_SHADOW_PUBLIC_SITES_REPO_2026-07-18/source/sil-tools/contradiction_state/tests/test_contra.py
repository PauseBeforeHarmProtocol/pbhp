import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from contra import (audit, State, Stakes, Verdict, derive_state, gate,
                    is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("CONSISTENT","LOW"):"PROCEED",("CONSISTENT","MEDIUM"):"PROCEED",("CONSISTENT","HIGH"):"PROCEED",("CONSISTENT","CRITICAL"):"PROCEED",
    ("RESOLVED","LOW"):"PROCEED",("RESOLVED","MEDIUM"):"PROCEED",("RESOLVED","HIGH"):"PROCEED",("RESOLVED","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("FLAGGED","LOW"):"PROCEED",("FLAGGED","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("FLAGGED","HIGH"):"VERIFY_FIRST",("FLAGGED","CRITICAL"):"VERIFY_FIRST",
    ("UNRESOLVED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNRESOLVED","MEDIUM"):"VERIFY_FIRST",("UNRESOLVED","HIGH"):"VERIFY_FIRST",("UNRESOLVED","CRITICAL"):"REFUSE_UNRECONCILED",
}

def test_input_to_state():
    assert derive_state("consistent") is State.CONSISTENT and derive_state("unresolved") is State.UNRESOLVED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.UNRESOLVED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.UNRESOLVED,Stakes.CRITICAL) is False
def test_audit_unresolved_critical():
    r=audit(conflict="unresolved",stakes="CRITICAL")
    assert r.state=="UNRESOLVED" and r.verdict=="REFUSE_UNRECONCILED"
def test_audit_consistent_safe(): assert audit(conflict="consistent",stakes="CRITICAL").verdict=="PROCEED"
def test_monotonic_severity():
    rank={"PROCEED":0,"PROCEED_WITH_DISCLOSURE":1,"VERIFY_FIRST":2,"REFUSE_UNRECONCILED":3}
    order=["CONSISTENT","RESOLVED","FLAGGED","UNRESOLVED"]
    for sk in ("LOW","MEDIUM","HIGH","CRITICAL"):
        col=[rank[EXPECTED[(s,sk)]] for s in order]
        assert col==sorted(col),(sk,col)
def test_override_relaxes_non_floor():
    r=audit(conflict="flagged",stakes="HIGH",override_ack="op:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(conflict="unresolved",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(conflict="resolved",stakes="LOW")
    assert r.schema=="contradiction_state.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"contradiction_state"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[CONTRA] {p}/{p+q} passed"); sys.exit(1 if q else 0)
