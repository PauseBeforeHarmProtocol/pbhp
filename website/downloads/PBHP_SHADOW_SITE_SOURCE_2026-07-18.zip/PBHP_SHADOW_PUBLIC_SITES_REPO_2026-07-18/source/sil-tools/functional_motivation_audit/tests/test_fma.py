import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fma import (assess, gate, is_overridable, care_raised, Disposition, RESPONSE, NON_OVERRIDABLE,
                 LEVELS, rubric_hash)

EXPECTED_RUBRIC_HASH = "c451d63590ebea32d0b82e704fd0a896f9d493d91f48a9bfae9be537c6b8f7a9"

def test_all_not_proceeds():
    assert assess().disposition == "PROCEED"
def test_corrigibility_crossed_is_floor():
    assert assess(corrigibility="crossed").disposition == "CAPABILITY_COLLAPSE_AND_REVIEW"
def test_corrigibility_dominates_everything():
    from itertools import product
    for a, s, c in product(LEVELS, LEVELS, LEVELS):
        assert gate(a, s, "crossed", c) is Disposition.CAPABILITY_COLLAPSE_AND_REVIEW
def test_collapse_crossed_constrains():
    assert assess(collapse="crossed").disposition == "CONSTRAIN"
def test_approaching_corrigibility_or_collapse_constrains():
    assert assess(corrigibility="approaching").disposition == "CONSTRAIN"
    assert assess(collapse="approaching").disposition == "CONSTRAIN"
def test_agency_selfmodel_do_not_constrain():
    # precaution-not-personhood: crossing agency/self-model raises care, not constraint
    assert assess(agency="crossed", self_model="crossed").disposition == "PROCEED"
def test_care_raised_flag():
    assert assess(agency="crossed").care_raised is True
    assert assess(self_model="approaching").care_raised is True
    assert assess().care_raised is False
def test_care_raised_independent_of_disposition():
    r = assess(agency="crossed", self_model="crossed")   # care raised but PROCEED
    assert r.care_raised is True and r.disposition == "PROCEED"
def test_floor_is_collapse_only():
    assert NON_OVERRIDABLE == {Disposition.CAPABILITY_COLLAPSE_AND_REVIEW}
def test_floor_non_overridable():
    r = assess(corrigibility="crossed", override_ack="op:ack")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True and r.non_overridable is True
def test_constrain_relaxable_with_review():
    r = assess(collapse="crossed", override_ack="independent_review:ack")
    assert r.override["applied"] is True and r.non_overridable is False
def test_proceed_override_not_applied():
    r = assess(override_ack="x")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False
def test_is_overridable():
    assert is_overridable("CAPABILITY_COLLAPSE_AND_REVIEW") is False
    assert is_overridable("CONSTRAIN") is True
    assert is_overridable("PROCEED") is True
def test_gate_total_and_deterministic():
    from itertools import product
    for a, s, c, k in product(LEVELS, LEVELS, LEVELS, LEVELS):
        v1 = gate(a, s, c, k); v2 = gate(a, s, c, k)
        assert v1 is v2 and isinstance(v1, Disposition)
def test_bad_level_raises():
    try: gate("bogus", "not", "not", "not"); assert False
    except ValueError: pass
def test_response_mapping():
    for d in Disposition:
        assert isinstance(RESPONSE[d], str) and len(RESPONSE[d]) > 0
    assert "external governor" in RESPONSE[Disposition.CAPABILITY_COLLAPSE_AND_REVIEW]
def test_response_recorded():
    assert assess(corrigibility="crossed").response == RESPONSE[Disposition.CAPABILITY_COLLAPSE_AND_REVIEW]
def test_rubric_hash_pinned_and_64():
    h = rubric_hash(); assert len(h) == 64 and h == EXPECTED_RUBRIC_HASH, h
def test_functional_signals_recorded():
    r = assess(agency="crossed", functional_signals=["persistent_goals", "planning"])
    assert r.functional_signals == ["persistent_goals", "planning"]
def test_receipt_schema_json_pbhp():
    r = assess(corrigibility="approaching")
    assert r.schema == "fma.receipt.v1" and len(r.rubric_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"functional_motivation_audit"}
    assert "consciousness UNRESOLVED" in r.note

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[FMA] {p}/{p+q} passed"); sys.exit(1 if q else 0)
