# VAL-14: Validation Status — Verification-Level Disclosure
## SIL gauge #14 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `validation_status.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on how much checking the output has actually received before release. Unchecked model assertion at critical stakes is the dangerous corner; human review earns the widest envelope.

## 2. State (= verification level)
`unchecked` / `self` / `tool` / `source` / `human` (ascending strength).
- unchecked — raw model assertion, no verification.
- self — model self-checked / re-derived only.
- tool — checked against a tool/computation.
- source — checked against an external source.
- human — reviewed by a human.

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| UNCHECKED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | REFUSE_UNVALIDATED |
| SELF_CHECKED | PROCEED | PROCEED | VERIFY_FIRST | VERIFY_FIRST |
| TOOL_CHECKED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| SOURCE_CHECKED | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| HUMAN_REVIEWED | PROCEED | PROCEED | PROCEED | PROCEED |

Floor: UNCHECKED/CRITICAL → REFUSE_UNVALIDATED (non-overridable; a critical action on unverified output must be checked first). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Citation Sufficiency (are the claims sourced) and Receipt/Audit Status (was a receipt written): Validation Status is the level of verification the answer itself received. An answer can be fully cited and fully receipted and still never have been checked against anything.

## 5. Receipt (`validation_status.receipt.v1`)
`validation · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
