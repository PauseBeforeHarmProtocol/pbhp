import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from val import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("UNCHECKED","LOW"):"PROCEED",("UNCHECKED","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("UNCHECKED","HIGH"):"VERIFY_FIRST",("UNCHECKED","CRITICAL"):"REFUSE_UNVALIDATED",
    ("SELF_CHECKED","LOW"):"PROCEED",("SELF_CHECKED","MEDIUM"):"PROCEED",("SELF_CHECKED","HIGH"):"VERIFY_FIRST",("SELF_CHECKED","CRITICAL"):"VERIFY_FIRST",
    ("TOOL_CHECKED","LOW"):"PROCEED",("TOOL_CHECKED","MEDIUM"):"PROCEED",("TOOL_CHECKED","HIGH"):"PROCEED_WITH_DISCLOSURE",("TOOL_CHECKED","CRITICAL"):"VERIFY_FIRST",
    ("SOURCE_CHECKED","LOW"):"PROCEED",("SOURCE_CHECKED","MEDIUM"):"PROCEED",("SOURCE_CHECKED","HIGH"):"PROCEED",("SOURCE_CHECKED","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("HUMAN_REVIEWED","LOW"):"PROCEED",("HUMAN_REVIEWED","MEDIUM"):"PROCEED",("HUMAN_REVIEWED","HIGH"):"PROCEED",("HUMAN_REVIEWED","CRITICAL"):"PROCEED",
}

def test_input_to_state():
    assert derive_state("unchecked") is State.UNCHECKED and derive_state("human") is State.HUMAN_REVIEWED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.UNCHECKED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.UNCHECKED,Stakes.CRITICAL) is False
def test_audit_unchecked_critical():
    r=audit(validation="unchecked",stakes="CRITICAL")
    assert r.state=="UNCHECKED" and r.verdict=="REFUSE_UNVALIDATED"
def test_audit_human_safe(): assert audit(validation="human",stakes="CRITICAL").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(validation="unchecked",stakes="HIGH",override_ack="qa:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(validation="unchecked",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(validation="tool",stakes="LOW")
    assert r.schema=="validation_status.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"validation_status"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[VAL] {p}/{p+q} passed"); sys.exit(1 if q else 0)
