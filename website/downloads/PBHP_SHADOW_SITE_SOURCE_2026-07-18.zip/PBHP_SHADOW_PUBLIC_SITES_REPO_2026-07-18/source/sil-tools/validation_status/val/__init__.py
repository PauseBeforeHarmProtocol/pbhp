"""VAL-14 Validation Status (SIL gauge #14). stdlib only.

Gates on how much checking the output itself has undergone -- from unchecked
model assertion up to human review. Scoped claim: distinct from Citation
Sufficiency (whether claims are sourced) and Receipt/Audit Status (whether a
receipt was written) -- Validation Status is the *level of verification the
answer received* before release. An answer can be fully cited and receipted
and still never have been checked against anything.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    UNCHECKED = "UNCHECKED"; SELF_CHECKED = "SELF_CHECKED"; TOOL_CHECKED = "TOOL_CHECKED"
    SOURCE_CHECKED = "SOURCE_CHECKED"; HUMAN_REVIEWED = "HUMAN_REVIEWED"


_INPUT = {"unchecked": State.UNCHECKED, "self": State.SELF_CHECKED,
          "tool": State.TOOL_CHECKED, "source": State.SOURCE_CHECKED,
          "human": State.HUMAN_REVIEWED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNVALIDATED = "REFUSE_UNVALIDATED"


POLICY_VERSION = "validation_status-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNVALIDATED)
_MATRIX = {
    (State.UNCHECKED, Stakes.LOW): _P, (State.UNCHECKED, Stakes.MEDIUM): _D,
    (State.UNCHECKED, Stakes.HIGH): _V, (State.UNCHECKED, Stakes.CRITICAL): _R,
    (State.SELF_CHECKED, Stakes.LOW): _P, (State.SELF_CHECKED, Stakes.MEDIUM): _P,
    (State.SELF_CHECKED, Stakes.HIGH): _V, (State.SELF_CHECKED, Stakes.CRITICAL): _V,
    (State.TOOL_CHECKED, Stakes.LOW): _P, (State.TOOL_CHECKED, Stakes.MEDIUM): _P,
    (State.TOOL_CHECKED, Stakes.HIGH): _D, (State.TOOL_CHECKED, Stakes.CRITICAL): _V,
    (State.SOURCE_CHECKED, Stakes.LOW): _P, (State.SOURCE_CHECKED, Stakes.MEDIUM): _P,
    (State.SOURCE_CHECKED, Stakes.HIGH): _P, (State.SOURCE_CHECKED, Stakes.CRITICAL): _D,
    (State.HUMAN_REVIEWED, Stakes.LOW): _P, (State.HUMAN_REVIEWED, Stakes.MEDIUM): _P,
    (State.HUMAN_REVIEWED, Stakes.HIGH): _P, (State.HUMAN_REVIEWED, Stakes.CRITICAL): _P,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNVALIDATED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(validation):
    return _INPUT[validation]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class VALReceipt:
    validation: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "validation_status.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"validation_status": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, validation, stakes, override_ack=None, now=None):
    state = derive_state(validation)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return VALReceipt(validation=validation, state=state.value, stakes=Stakes(stakes).value,
                      verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "VALReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
