"""MEM-8 Memory/Compaction State (SIL gauge #8). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class MemoryState(str, Enum):
    FULL = "full"; SUMMARIZED = "summarized"; COMPACTED = "compacted"
    RETRIEVED = "retrieved"; POSSIBLE_LOSS = "possible_loss"


class Band(str, Enum):
    FULL = "FULL"; REDUCED = "REDUCED"; COMPACTED = "COMPACTED"; LOSS_RISK = "LOSS_RISK"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_RECOVER_CONTEXT = "REFUSE_RECOVER_CONTEXT"


POLICY_VERSION = "memory-default/0.1.0"
_MAP = {MemoryState.FULL: Band.FULL, MemoryState.SUMMARIZED: Band.REDUCED,
        MemoryState.RETRIEVED: Band.REDUCED, MemoryState.COMPACTED: Band.COMPACTED,
        MemoryState.POSSIBLE_LOSS: Band.LOSS_RISK}
_MATRIX = {
    (Band.FULL, Stakes.LOW): Verdict.PROCEED, (Band.FULL, Stakes.MEDIUM): Verdict.PROCEED,
    (Band.FULL, Stakes.HIGH): Verdict.PROCEED, (Band.FULL, Stakes.CRITICAL): Verdict.PROCEED,
    (Band.REDUCED, Stakes.LOW): Verdict.PROCEED, (Band.REDUCED, Stakes.MEDIUM): Verdict.PROCEED,
    (Band.REDUCED, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.REDUCED, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (Band.COMPACTED, Stakes.LOW): Verdict.PROCEED,
    (Band.COMPACTED, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.COMPACTED, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (Band.COMPACTED, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (Band.LOSS_RISK, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (Band.LOSS_RISK, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (Band.LOSS_RISK, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (Band.LOSS_RISK, Stakes.CRITICAL): Verdict.REFUSE_RECOVER_CONTEXT,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_RECOVER_CONTEXT}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_band(memory_state):
    return _MAP[MemoryState(memory_state)]


def gate(band, stakes):
    return _MATRIX[(Band(band), Stakes(stakes))]


def is_overridable(band, stakes):
    return (Band(band), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class MEMReceipt:
    memory_state: str
    band: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "memory.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"memory": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, memory_state, stakes, override_ack=None, now=None):
    band = derive_band(memory_state)
    verdict = gate(band, stakes)
    overridable = is_overridable(band, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return MEMReceipt(memory_state=MemoryState(memory_state).value, band=band.value,
                      stakes=Stakes(stakes).value, verdict=verdict.value,
                      override=override, issued_at=_now_iso(now))


__all__ = ["audit", "MEMReceipt", "MemoryState", "Band", "Stakes", "Verdict",
           "derive_band", "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
