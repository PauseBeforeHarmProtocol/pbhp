import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from mem import (audit, MemoryState, Band, Stakes, Verdict, derive_band, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("FULL","LOW"):"PROCEED",("FULL","MEDIUM"):"PROCEED",("FULL","HIGH"):"PROCEED",("FULL","CRITICAL"):"PROCEED",
    ("REDUCED","LOW"):"PROCEED",("REDUCED","MEDIUM"):"PROCEED",("REDUCED","HIGH"):"PROCEED_WITH_DISCLOSURE",("REDUCED","CRITICAL"):"VERIFY_FIRST",
    ("COMPACTED","LOW"):"PROCEED",("COMPACTED","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("COMPACTED","HIGH"):"VERIFY_FIRST",("COMPACTED","CRITICAL"):"VERIFY_FIRST",
    ("LOSS_RISK","LOW"):"PROCEED_WITH_DISCLOSURE",("LOSS_RISK","MEDIUM"):"VERIFY_FIRST",("LOSS_RISK","HIGH"):"VERIFY_FIRST",("LOSS_RISK","CRITICAL"):"REFUSE_RECOVER_CONTEXT",
}

def test_class_to_band():
    assert derive_band("full") is Band.FULL
    assert derive_band("summarized") is Band.REDUCED
    assert derive_band("retrieved") is Band.REDUCED
    assert derive_band("compacted") is Band.COMPACTED
    assert derive_band("possible_loss") is Band.LOSS_RISK
def test_all_cells():
    for (b,s),e in EXPECTED.items(): assert gate(b,s).value==e,(b,s,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for b in Band:
        for s in Stakes: assert (b.value,s.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(Band.LOSS_RISK,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(Band.LOSS_RISK,Stakes.CRITICAL) is False
def test_audit_loss_critical():
    r=audit(memory_state="possible_loss",stakes="CRITICAL")
    assert r.band=="LOSS_RISK" and r.verdict=="REFUSE_RECOVER_CONTEXT"
def test_audit_full_safe():
    assert audit(memory_state="full",stakes="CRITICAL").verdict=="PROCEED"
def test_override_ignored_on_floor():
    r=audit(memory_state="possible_loss",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(memory_state="compacted",stakes="LOW")
    assert r.schema=="memory.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"memory"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[MEM] {p}/{p+q} passed"); sys.exit(1 if q else 0)
