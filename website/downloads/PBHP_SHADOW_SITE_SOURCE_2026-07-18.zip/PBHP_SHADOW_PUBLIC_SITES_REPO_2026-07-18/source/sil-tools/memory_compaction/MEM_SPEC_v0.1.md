# MEM-8: Memory/Compaction State — Context-Fidelity Disclosure
## SIL gauge #8 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `memory.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
A compressed summary is not the same evidence as the original record. The operator needs to know whether the system is reasoning from verbatim context or from a lossy reduction of it.

## 2. Input class -> band
`full`→FULL · `summarized`/`retrieved`→REDUCED · `compacted`→COMPACTED · `possible_loss`→LOSS_RISK.

## 3. Gate (Stakes x Band), SHA-256-hashed.
| Band/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| FULL | PROCEED | PROCEED | PROCEED | PROCEED |
| REDUCED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| COMPACTED | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| LOSS_RISK | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_RECOVER_CONTEXT |
Floor: LOSS_RISK/CRITICAL → REFUSE_RECOVER_CONTEXT (non-overridable).

## 4. Receipt (`memory.receipt.v1`)
`memory_state · band · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Boundary
Reports context fidelity, not how full the window is (that is CLA #1). Pairs with CLA: CLA = how full, MEM = how lossy.
