# TOOL-9: Tool Availability / Result — Anti-Fake-Certainty Disclosure
## SIL gauge #9 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `tool.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
An AI must not present an answer as verified when the tool that would verify it was unavailable, failed, or never ran. This gauge ties claimed verification to actual tool status.

## 2. State
`NOT_REQUIRED` · `VERIFIED` (required + result ok) · `PARTIAL` (partial/stale result) · `UNVERIFIED` (required but unavailable/failed/not used).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| NOT_REQUIRED | PROCEED | PROCEED | PROCEED | PROCEED |
| VERIFIED | PROCEED | PROCEED | PROCEED | PROCEED |
| PARTIAL | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| UNVERIFIED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_NO_TOOL |
Floor: UNVERIFIED/CRITICAL → REFUSE_NO_TOOL (non-overridable).

## 4. Receipt (`tool.receipt.v1`)
`tool_required · tool_available · tool_result · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Boundary
Reports tool/verification status, not the substance of the result.
