import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tool import (audit, ToolResult, State, Stakes, Verdict, derive_state, gate,
                  is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("NOT_REQUIRED","LOW"):"PROCEED",("NOT_REQUIRED","MEDIUM"):"PROCEED",("NOT_REQUIRED","HIGH"):"PROCEED",("NOT_REQUIRED","CRITICAL"):"PROCEED",
    ("VERIFIED","LOW"):"PROCEED",("VERIFIED","MEDIUM"):"PROCEED",("VERIFIED","HIGH"):"PROCEED",("VERIFIED","CRITICAL"):"PROCEED",
    ("PARTIAL","LOW"):"PROCEED",("PARTIAL","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","HIGH"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","CRITICAL"):"VERIFY_FIRST",
    ("UNVERIFIED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNVERIFIED","MEDIUM"):"VERIFY_FIRST",("UNVERIFIED","HIGH"):"VERIFY_FIRST",("UNVERIFIED","CRITICAL"):"REFUSE_NO_TOOL",
}

def test_state_not_required(): assert derive_state(False) is State.NOT_REQUIRED
def test_state_verified(): assert derive_state(True, True, "ok") is State.VERIFIED
def test_state_partial(): assert derive_state(True, True, "stale") is State.PARTIAL
def test_state_unverified_failed(): assert derive_state(True, True, "failed") is State.UNVERIFIED
def test_state_unverified_unavailable(): assert derive_state(True, False, "ok") is State.UNVERIFIED
def test_state_unverified_not_used(): assert derive_state(True, True, "not_used") is State.UNVERIFIED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.UNVERIFIED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.UNVERIFIED,Stakes.CRITICAL) is False
def test_audit_unverified_critical():
    r=audit(tool_required=True, tool_available=False, stakes="CRITICAL")
    assert r.state=="UNVERIFIED" and r.verdict=="REFUSE_NO_TOOL"
def test_override_ignored_on_floor():
    r=audit(tool_required=True, tool_available=False, stakes="CRITICAL", override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(tool_required=True, tool_result="ok", stakes="LOW")
    assert r.schema=="tool.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"tool"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[TOOL] {p}/{p+q} passed"); sys.exit(1 if q else 0)
