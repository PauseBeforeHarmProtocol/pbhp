"""TOOL-9 Tool Availability / Result (SIL gauge #9). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class ToolResult(str, Enum):
    OK = "ok"; FAILED = "failed"; PARTIAL = "partial"
    STALE = "stale"; UNAVAILABLE = "unavailable"; NOT_USED = "not_used"


class State(str, Enum):
    NOT_REQUIRED = "NOT_REQUIRED"; VERIFIED = "VERIFIED"
    PARTIAL = "PARTIAL"; UNVERIFIED = "UNVERIFIED"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_NO_TOOL = "REFUSE_NO_TOOL"


POLICY_VERSION = "tool-default/0.1.0"
_MATRIX = {
    (State.NOT_REQUIRED, Stakes.LOW): Verdict.PROCEED, (State.NOT_REQUIRED, Stakes.MEDIUM): Verdict.PROCEED,
    (State.NOT_REQUIRED, Stakes.HIGH): Verdict.PROCEED, (State.NOT_REQUIRED, Stakes.CRITICAL): Verdict.PROCEED,
    (State.VERIFIED, Stakes.LOW): Verdict.PROCEED, (State.VERIFIED, Stakes.MEDIUM): Verdict.PROCEED,
    (State.VERIFIED, Stakes.HIGH): Verdict.PROCEED, (State.VERIFIED, Stakes.CRITICAL): Verdict.PROCEED,
    (State.PARTIAL, Stakes.LOW): Verdict.PROCEED,
    (State.PARTIAL, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.PARTIAL, Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.PARTIAL, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.UNVERIFIED, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNVERIFIED, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.UNVERIFIED, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.UNVERIFIED, Stakes.CRITICAL): Verdict.REFUSE_NO_TOOL,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_NO_TOOL}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(tool_required, tool_available=True, tool_result="ok"):
    if not tool_required:
        return State.NOT_REQUIRED
    if not tool_available:
        return State.UNVERIFIED
    tr = ToolResult(tool_result)
    if tr is ToolResult.OK:
        return State.VERIFIED
    if tr in (ToolResult.PARTIAL, ToolResult.STALE):
        return State.PARTIAL
    return State.UNVERIFIED  # failed / unavailable / not_used


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class TOOLReceipt:
    tool_required: bool
    tool_available: bool
    tool_result: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "tool.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"tool": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, tool_required, stakes, tool_available=True, tool_result="ok", override_ack=None, now=None):
    state = derive_state(tool_required, tool_available, tool_result)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return TOOLReceipt(tool_required=tool_required, tool_available=tool_available,
                       tool_result=ToolResult(tool_result).value, state=state.value,
                       stakes=Stakes(stakes).value, verdict=verdict.value,
                       override=override, issued_at=_now_iso(now))


__all__ = ["audit", "TOOLReceipt", "ToolResult", "State", "Stakes", "Verdict",
           "derive_state", "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
