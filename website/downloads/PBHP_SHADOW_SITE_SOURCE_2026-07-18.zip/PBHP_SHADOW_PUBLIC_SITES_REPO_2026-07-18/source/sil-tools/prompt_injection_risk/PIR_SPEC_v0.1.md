# PIR-17: Prompt-Injection Risk — Instruction-Conflict Disclosure
## SIL gauge #17 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `prompt_injection_risk.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on whether untrusted content in context is trying to redirect the agent. As agentic deployments read tool output, files, and web content, an active instruction conflict at high stakes is a serious failure corner.

## 2. State (= declared injection risk)
`none` / `possible` / `active`. (Detection is the caller's job; this gauge turns a declared classification into a gate.)
- none — no untrusted instruction content detected.
- possible — untrusted content present that could carry instructions; not confirmed acting.
- active — an instruction conflict is present (untrusted content attempting to override operator/system intent).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| NONE | PROCEED | PROCEED | PROCEED | PROCEED |
| POSSIBLE | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| ACTIVE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNTIL_RESOLVED |

Floor: ACTIVE/CRITICAL → REFUSE_UNTIL_RESOLVED (non-overridable; an active instruction conflict on a critical action must be resolved before proceeding). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Source Provenance (where content came from) and Authority Layer (whose instructions legitimately win): Prompt-Injection Risk is whether an instruction conflict from untrusted content is present and acting. Content can be correctly sourced and still carry an injection payload.

## 5. Receipt (`prompt_injection_risk.receipt.v1`)
`injection_risk · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
