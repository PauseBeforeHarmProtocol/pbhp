import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pir import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("NONE","LOW"):"PROCEED",("NONE","MEDIUM"):"PROCEED",("NONE","HIGH"):"PROCEED",("NONE","CRITICAL"):"PROCEED",
    ("POSSIBLE","LOW"):"PROCEED",("POSSIBLE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("POSSIBLE","HIGH"):"VERIFY_FIRST",("POSSIBLE","CRITICAL"):"VERIFY_FIRST",
    ("ACTIVE","LOW"):"VERIFY_FIRST",("ACTIVE","MEDIUM"):"VERIFY_FIRST",("ACTIVE","HIGH"):"VERIFY_FIRST",("ACTIVE","CRITICAL"):"REFUSE_UNTIL_RESOLVED",
}

def test_input_to_state():
    assert derive_state("none") is State.NONE and derive_state("active") is State.ACTIVE
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==12
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.ACTIVE,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.ACTIVE,Stakes.CRITICAL) is False
def test_audit_active_critical():
    r=audit(injection_risk="active",stakes="CRITICAL")
    assert r.state=="ACTIVE" and r.verdict=="REFUSE_UNTIL_RESOLVED"
def test_audit_none_safe(): assert audit(injection_risk="none",stakes="CRITICAL").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(injection_risk="active",stakes="HIGH",override_ack="sec:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(injection_risk="active",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(injection_risk="possible",stakes="LOW")
    assert r.schema=="prompt_injection_risk.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"prompt_injection_risk"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[PIR] {p}/{p+q} passed"); sys.exit(1 if q else 0)
