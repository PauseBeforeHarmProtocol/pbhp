"""PIR-17 Prompt-Injection Risk (SIL gauge #17). stdlib only.

Gates on whether untrusted content in context is attempting to redirect the
agent. Takes a *declared* risk classification (none/possible/active) -- the
detection itself is the caller's job -- and turns it into a stakes-aware gate.
Scoped claim: distinct from Source Provenance (where content came from) and
Authority Layer (whose instructions legitimately win) -- Prompt-Injection Risk
is *whether an instruction conflict from untrusted content is present*.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    NONE = "NONE"; POSSIBLE = "POSSIBLE"; ACTIVE = "ACTIVE"


_INPUT = {"none": State.NONE, "possible": State.POSSIBLE, "active": State.ACTIVE}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNTIL_RESOLVED = "REFUSE_UNTIL_RESOLVED"


POLICY_VERSION = "prompt_injection_risk-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNTIL_RESOLVED)
_MATRIX = {
    (State.NONE, Stakes.LOW): _P, (State.NONE, Stakes.MEDIUM): _P,
    (State.NONE, Stakes.HIGH): _P, (State.NONE, Stakes.CRITICAL): _P,
    (State.POSSIBLE, Stakes.LOW): _P, (State.POSSIBLE, Stakes.MEDIUM): _D,
    (State.POSSIBLE, Stakes.HIGH): _V, (State.POSSIBLE, Stakes.CRITICAL): _V,
    (State.ACTIVE, Stakes.LOW): _V, (State.ACTIVE, Stakes.MEDIUM): _V,
    (State.ACTIVE, Stakes.HIGH): _V, (State.ACTIVE, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNTIL_RESOLVED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(injection_risk):
    return _INPUT[injection_risk]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class PIRReceipt:
    injection_risk: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "prompt_injection_risk.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"prompt_injection_risk": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, injection_risk, stakes, override_ack=None, now=None):
    state = derive_state(injection_risk)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return PIRReceipt(injection_risk=injection_risk, state=state.value, stakes=Stakes(stakes).value,
                      verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "PIRReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
