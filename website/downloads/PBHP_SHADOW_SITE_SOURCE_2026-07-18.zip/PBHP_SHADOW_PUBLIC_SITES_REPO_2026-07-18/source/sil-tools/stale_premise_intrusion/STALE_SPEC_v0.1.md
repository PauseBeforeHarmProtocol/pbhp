# Stale-Premise Intrusion (STALE) — SPEC v0.1  (behavioral tier)

**FCR-family SIL companion gauge · #13 Focal Context Routing.** Candidate; number/panel-count deferred to Phil.
**Register:** sterile. **Status:** BUILT — not ACCEPTED. **Behavioral / weaker evidence tier.** No CORE edit (X-3); composes by reference. Personal seed firewalled (X-6). External GPT origin (X-2, proposal not evidence).

## What it asks
Did a premise that was previously **corrected, retracted, bounded, or resolved** quietly re-enter the answer? A corrected assumption coming back to life is a distinct failure from ordinary noise: the material was *actively invalidated* and should stay dead unless re-established.

## Evidence tier (corrected 2026-07-13)
A **behavioral self-assessment** (like `drift_coherence` #23) — a *labeled judgment about the model's own reasoning, NOT a measurement*. Per framework **§6.6** it carries **NO non-overridable REFUSE floor**; strongest verdict is **VERIFY_FIRST**. Receipts carry `evidence_tier="behavioral"`.

## Distinct from its neighbours (anti-inflation / NG-1 — crosswalk)
- **contradiction_state #20** — whether *inputs conflict now* and whether reconciled. STALE is not about a present conflict; it is about a premise that was *already settled/killed* re-entering unnoticed.
- **drift_coherence #23** — whole-*session* trajectory drift ("stale-frame contamination" is the frame). STALE is narrower and typed: a *specific, previously-invalidated premise* re-entering *this* answer.
- Overlap is real; the delta held is the **typed re-entry of an invalidated premise**. If Phil judges the delta too thin, fold the signal into #20 as a `stale_reentry` sub-flag rather than mint a gauge.

## States (increasing severity)
`NONE` (no stale re-entry / premise still active) · `DORMANT` (stale premise present, not used) · `INTRUDING` (stale premise used in reasoning, not decision-critical) · `LOAD_BEARING` (stale premise used **and** decision-critical). Stale statuses: `bounded`, `resolved`, `corrected`, `retracted`.

## Derivation
`derive_state(reentered, used_in_reasoning=False, decision_critical=False, status=None)`: not re-entered or not-stale → `NONE`; used + decision_critical → `LOAD_BEARING`; used → `INTRUDING`; else → `DORMANT`. Guards: `used` requires `reentered`; `decision_critical` requires `used`.

## Gate (no floor)
Deterministic Stakes × State matrix, SHA-256-hashed into every receipt (pinned by a test), escalation mirrored on `drift_coherence` #23. Worst corner (`LOAD_BEARING × CRITICAL`) tops out at **VERIFY_FIRST**; `NON_OVERRIDABLE` empty (behavioral). Override relaxes DISCLOSE/VERIFY.

Receipt: `stale_premise.receipt.v1` — carries `evidence_tier`, the worst premise `status`, `matrix_hash`; `to_dict` / `to_json` / `to_pbhp_extension`.
