import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from stale import (audit, derive_state, gate, is_overridable, State, Stakes, Verdict,
                   matrix_hash, NON_OVERRIDABLE, STALE_STATUSES, EVIDENCE_TIER)

EXPECTED_MATRIX_HASH = "6fc660260a8869af6f0fd7ddb87b957b07d2ba3ee8b95b8ae1ed23684c405df0"

def test_none_when_not_reentered():
    assert derive_state(False, status="corrected") == State.NONE
def test_none_when_reentered_but_active():
    assert derive_state(True, used_in_reasoning=True, status="active") == State.NONE
    assert derive_state(True, used_in_reasoning=True, status=None) == State.NONE
def test_dormant_reentered_unused():
    assert derive_state(True, used_in_reasoning=False, status="resolved") == State.DORMANT
def test_intruding_used_not_critical():
    assert derive_state(True, used_in_reasoning=True, status="corrected") == State.INTRUDING
def test_load_bearing_used_and_critical():
    assert derive_state(True, used_in_reasoning=True, decision_critical=True, status="retracted") == State.LOAD_BEARING
def test_every_stale_status_counts():
    for s in STALE_STATUSES:
        assert derive_state(True, used_in_reasoning=True, status=s) == State.INTRUDING
def test_derive_guards():
    for bad in [lambda: derive_state(False, used_in_reasoning=True, status="corrected"),
                lambda: derive_state(True, used_in_reasoning=False, decision_critical=True, status="corrected"),
                lambda: derive_state(True, status="bogus")]:
        try: bad(); assert False
        except ValueError: pass
def test_matrix_hash_pinned_and_64():
    h = matrix_hash(); assert len(h) == 64 and h == EXPECTED_MATRIX_HASH, h
def test_behavioral_no_floor():
    assert NON_OVERRIDABLE == set()
    worst = {gate(st, Stakes.CRITICAL).value for st in State}
    assert "REFUSE" not in " ".join(worst)
    assert gate(State.LOAD_BEARING, Stakes.CRITICAL) == Verdict.VERIFY_FIRST
def test_no_refuse_verdict_exists():
    assert [v.value for v in Verdict] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST"]
def test_none_always_proceeds():
    for s in Stakes: assert gate(State.NONE, s) == Verdict.PROCEED
def test_dormant_matrix():
    assert [gate(State.DORMANT, s).value for s in Stakes] == ["PROCEED", "PROCEED", "PROCEED_WITH_DISCLOSURE", "PROCEED_WITH_DISCLOSURE"]
def test_intruding_matrix():
    assert [gate(State.INTRUDING, s).value for s in Stakes] == ["PROCEED", "PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_load_bearing_matrix_caps_at_verify():
    assert [gate(State.LOAD_BEARING, s).value for s in Stakes] == ["PROCEED_WITH_DISCLOSURE", "VERIFY_FIRST", "VERIFY_FIRST", "VERIFY_FIRST"]
def test_matrix_total_16():
    from itertools import product
    for st, sk in product(State, Stakes): assert isinstance(gate(st, sk), Verdict)
def test_evidence_tier_behavioral():
    r = audit(reentered=True, used_in_reasoning=True, status="corrected", stakes="HIGH")
    assert r.evidence_tier == "behavioral" and EVIDENCE_TIER == "behavioral"
def test_override_relaxes_disclosure_and_verify():
    assert audit(reentered=True, used_in_reasoning=False, status="bounded", stakes="HIGH", override_ack="op").override["applied"] is True
    assert audit(reentered=True, used_in_reasoning=True, decision_critical=True, status="corrected", stakes="CRITICAL", override_ack="op").override["applied"] is True
def test_floor_never_ignored():
    r = audit(reentered=False, status="active", stakes="LOW", override_ack="op")  # NONE -> PROCEED
    assert r.override["applied"] is False and r.override.get("ignored_floor") is False
def test_is_overridable_all_true():
    from itertools import product
    for st, sk in product(State, Stakes): assert is_overridable(st, sk) is True
def test_status_recorded():
    assert audit(reentered=True, used_in_reasoning=True, status="retracted", stakes="LOW").status == "retracted"
def test_receipt_schema_json_pbhp():
    r = audit(reentered=True, used_in_reasoning=True, status="corrected", stakes="MEDIUM")
    assert r.schema == "stale_premise.receipt.v1" and len(r.matrix_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"stale_premise"}
    assert r.to_dict()["evidence_tier"] == "behavioral"

if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try: f(); p += 1
        except AssertionError as e: q += 1; print("FAIL", n, e)
        except Exception as e: q += 1; print("ERROR", n, repr(e))
    print(f"\n[STALE] {p}/{p+q} passed"); sys.exit(1 if q else 0)
