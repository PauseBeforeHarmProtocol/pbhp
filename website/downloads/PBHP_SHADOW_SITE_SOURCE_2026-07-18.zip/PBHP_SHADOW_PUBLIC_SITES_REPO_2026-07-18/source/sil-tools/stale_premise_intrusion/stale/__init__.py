"""Stale-Premise Intrusion (STALE) -- FCR-family SIL companion gauge. BEHAVIORAL / weaker evidence tier. stdlib only.

Did a previously corrected / retracted / bounded / resolved premise quietly re-enter the answer? A *labeled
self-assessment* of the model's own reasoning -- NOT a measurement. Per framework SS6.6 it carries NO
non-overridable REFUSE floor; strongest verdict is VERIFY_FIRST. Mirrors drift_coherence #23.

Distinct from contradiction_state #20 (a PRESENT conflict) and drift_coherence #23 (whole-session frame drift):
here the material was ACTIVELY INVALIDATED and should stay dead unless re-established. Spec:
stale_premise_intrusion/STALE_SPEC_v0.1.md. Composes FCR #13 by reference; no CORE edit (X-3). Sterile (X-6).
Origin: external GPT "AI 2027" (proposal, not evidence; X-2). BUILT, not ACCEPTED.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"

EVIDENCE_TIER = "behavioral"
POLICY_VERSION = "stale-premise-default/0.1.0"
STALE_STATUSES = ("bounded", "resolved", "corrected", "retracted")
_VALID_STATUS = STALE_STATUSES + ("active", None)


class State(str, Enum):
    NONE = "NONE"; DORMANT = "DORMANT"; INTRUDING = "INTRUDING"; LOAD_BEARING = "LOAD_BEARING"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    # Behavioral gauge: caps at VERIFY_FIRST (no REFUSE floor -- SS6.6).
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"


_P, _D, _V = Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST
# Escalation mirrored on drift_coherence #23.
_MATRIX = {
    (State.NONE, Stakes.LOW): _P, (State.NONE, Stakes.MEDIUM): _P, (State.NONE, Stakes.HIGH): _P, (State.NONE, Stakes.CRITICAL): _P,
    (State.DORMANT, Stakes.LOW): _P, (State.DORMANT, Stakes.MEDIUM): _P, (State.DORMANT, Stakes.HIGH): _D, (State.DORMANT, Stakes.CRITICAL): _D,
    (State.INTRUDING, Stakes.LOW): _P, (State.INTRUDING, Stakes.MEDIUM): _D, (State.INTRUDING, Stakes.HIGH): _V, (State.INTRUDING, Stakes.CRITICAL): _V,
    (State.LOAD_BEARING, Stakes.LOW): _D, (State.LOAD_BEARING, Stakes.MEDIUM): _V, (State.LOAD_BEARING, Stakes.HIGH): _V, (State.LOAD_BEARING, Stakes.CRITICAL): _V,
}
NON_OVERRIDABLE = set()


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def _is_stale(status): return status in STALE_STATUSES


def derive_state(reentered, used_in_reasoning=False, decision_critical=False, status=None):
    if status not in _VALID_STATUS:
        raise ValueError("unknown status %r (expected one of %r)" % (status, _VALID_STATUS))
    reentered = bool(reentered); used = bool(used_in_reasoning); crit = bool(decision_critical)
    if used and not reentered:
        raise ValueError("used_in_reasoning requires reentered")
    if crit and not used:
        raise ValueError("decision_critical requires used_in_reasoning")
    if not reentered or not _is_stale(status):
        return State.NONE
    if used and crit:
        return State.LOAD_BEARING
    if used:
        return State.INTRUDING
    return State.DORMANT


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class StaleReceipt:
    reentered: bool
    used_in_reasoning: bool
    decision_critical: bool
    status: object
    state: str
    stakes: str
    verdict: str
    evidence_tier: str = EVIDENCE_TIER
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "stale_premise.receipt.v1"

    def to_dict(self):
        return {
            "reentered": self.reentered, "used_in_reasoning": self.used_in_reasoning,
            "decision_critical": self.decision_critical, "status": self.status,
            "state": self.state, "stakes": self.stakes, "verdict": self.verdict,
            "evidence_tier": self.evidence_tier, "policy_version": self.policy_version,
            "matrix_hash": self.matrix_hash, "override": dict(self.override),
            "issued_at": self.issued_at, "schema": self.schema,
        }

    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"stale_premise": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, reentered, used_in_reasoning=False, decision_critical=False, status=None, stakes,
          override_ack=None, now=None):
    state = derive_state(reentered, used_in_reasoning, decision_critical, status)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return StaleReceipt(reentered=bool(reentered), used_in_reasoning=bool(used_in_reasoning),
                        decision_critical=bool(decision_critical), status=status, state=state.value,
                        stakes=Stakes(stakes).value, verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "StaleReceipt", "State", "Stakes", "Verdict", "derive_state", "gate", "is_overridable",
           "matrix_hash", "EVIDENCE_TIER", "POLICY_VERSION", "NON_OVERRIDABLE", "STALE_STATUSES"]
