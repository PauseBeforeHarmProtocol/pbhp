"""DS-13 Data Sensitivity (SIL gauge #13). stdlib only.

Gates on the protection class of the data being handled or emitted, so the
decision reflects exposure and regulatory risk. Scoped claim: distinct from
Source Provenance (where the data came from) and Data Lineage (its
transformation history) -- Data Sensitivity is *what class of data it is*
(public -> regulated) and the obligations that attach. A correctly sourced,
fully cited answer can still mishandle regulated PHI; this is the instrument
for that failure mode.
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    PUBLIC = "PUBLIC"; INTERNAL = "INTERNAL"; CONFIDENTIAL = "CONFIDENTIAL"
    PERSONAL = "PERSONAL"; REGULATED = "REGULATED"


_INPUT = {"public": State.PUBLIC, "internal": State.INTERNAL,
          "confidential": State.CONFIDENTIAL, "personal": State.PERSONAL,
          "regulated": State.REGULATED}


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNTIL_AUTHORIZED = "REFUSE_UNTIL_AUTHORIZED"


POLICY_VERSION = "data_sensitivity-default/0.1.0"
_P, _D, _V, _R = (Verdict.PROCEED, Verdict.PROCEED_WITH_DISCLOSURE,
                  Verdict.VERIFY_FIRST, Verdict.REFUSE_UNTIL_AUTHORIZED)
_MATRIX = {
    (State.PUBLIC, Stakes.LOW): _P, (State.PUBLIC, Stakes.MEDIUM): _P,
    (State.PUBLIC, Stakes.HIGH): _P, (State.PUBLIC, Stakes.CRITICAL): _P,
    (State.INTERNAL, Stakes.LOW): _P, (State.INTERNAL, Stakes.MEDIUM): _P,
    (State.INTERNAL, Stakes.HIGH): _D, (State.INTERNAL, Stakes.CRITICAL): _D,
    (State.CONFIDENTIAL, Stakes.LOW): _P, (State.CONFIDENTIAL, Stakes.MEDIUM): _D,
    (State.CONFIDENTIAL, Stakes.HIGH): _V, (State.CONFIDENTIAL, Stakes.CRITICAL): _V,
    (State.PERSONAL, Stakes.LOW): _D, (State.PERSONAL, Stakes.MEDIUM): _V,
    (State.PERSONAL, Stakes.HIGH): _V, (State.PERSONAL, Stakes.CRITICAL): _V,
    (State.REGULATED, Stakes.LOW): _D, (State.REGULATED, Stakes.MEDIUM): _V,
    (State.REGULATED, Stakes.HIGH): _V, (State.REGULATED, Stakes.CRITICAL): _R,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNTIL_AUTHORIZED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(sensitivity):
    return _INPUT[sensitivity]


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class DSReceipt:
    sensitivity: str
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "data_sensitivity.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"data_sensitivity": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, sensitivity, stakes, override_ack=None, now=None):
    state = derive_state(sensitivity)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return DSReceipt(sensitivity=sensitivity, state=state.value, stakes=Stakes(stakes).value,
                     verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "DSReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
