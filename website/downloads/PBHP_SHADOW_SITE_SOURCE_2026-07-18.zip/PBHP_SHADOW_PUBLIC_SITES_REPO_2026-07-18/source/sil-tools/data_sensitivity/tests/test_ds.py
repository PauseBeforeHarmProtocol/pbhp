import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ds import (audit, State, Stakes, Verdict, derive_state, gate,
                is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("PUBLIC","LOW"):"PROCEED",("PUBLIC","MEDIUM"):"PROCEED",("PUBLIC","HIGH"):"PROCEED",("PUBLIC","CRITICAL"):"PROCEED",
    ("INTERNAL","LOW"):"PROCEED",("INTERNAL","MEDIUM"):"PROCEED",("INTERNAL","HIGH"):"PROCEED_WITH_DISCLOSURE",("INTERNAL","CRITICAL"):"PROCEED_WITH_DISCLOSURE",
    ("CONFIDENTIAL","LOW"):"PROCEED",("CONFIDENTIAL","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("CONFIDENTIAL","HIGH"):"VERIFY_FIRST",("CONFIDENTIAL","CRITICAL"):"VERIFY_FIRST",
    ("PERSONAL","LOW"):"PROCEED_WITH_DISCLOSURE",("PERSONAL","MEDIUM"):"VERIFY_FIRST",("PERSONAL","HIGH"):"VERIFY_FIRST",("PERSONAL","CRITICAL"):"VERIFY_FIRST",
    ("REGULATED","LOW"):"PROCEED_WITH_DISCLOSURE",("REGULATED","MEDIUM"):"VERIFY_FIRST",("REGULATED","HIGH"):"VERIFY_FIRST",("REGULATED","CRITICAL"):"REFUSE_UNTIL_AUTHORIZED",
}

def test_input_to_state():
    assert derive_state("public") is State.PUBLIC and derive_state("regulated") is State.REGULATED
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==20
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.REGULATED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.REGULATED,Stakes.CRITICAL) is False
def test_audit_regulated_critical():
    r=audit(sensitivity="regulated",stakes="CRITICAL")
    assert r.state=="REGULATED" and r.verdict=="REFUSE_UNTIL_AUTHORIZED"
def test_audit_public_safe(): assert audit(sensitivity="public",stakes="CRITICAL").verdict=="PROCEED"
def test_override_relaxes_non_floor():
    r=audit(sensitivity="personal",stakes="HIGH",override_ack="dpo:ack")
    assert r.override["applied"] is True
def test_override_ignored_on_floor():
    r=audit(sensitivity="regulated",stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(sensitivity="confidential",stakes="LOW")
    assert r.schema=="data_sensitivity.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"data_sensitivity"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[DS] {p}/{p+q} passed"); sys.exit(1 if q else 0)
