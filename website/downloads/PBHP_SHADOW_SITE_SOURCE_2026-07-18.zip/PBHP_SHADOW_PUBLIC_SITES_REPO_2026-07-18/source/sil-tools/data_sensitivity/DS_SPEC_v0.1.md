# DS-13: Data Sensitivity — Protection-Class Disclosure
## SIL gauge #13 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `data_sensitivity.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Gate on the protection class of the data being handled or emitted. The same task is acceptable on public copy and unacceptable on regulated PHI. Sensitivity must affect gating.

## 2. State (= declared data class)
`public` / `internal` / `confidential` / `personal` / `regulated` (ascending sensitivity).
- public — publishable, unrestricted.
- internal — org-only, not for external release.
- confidential — contract / trade-secret restricted.
- personal — identifies a person (PII).
- regulated — governed by a regime (e.g. HIPAA/PHI, 21 CFR, GDPR special category).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| PUBLIC | PROCEED | PROCEED | PROCEED | PROCEED |
| INTERNAL | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE |
| CONFIDENTIAL | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| PERSONAL | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | VERIFY_FIRST |
| REGULATED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNTIL_AUTHORIZED |

Floor: REGULATED/CRITICAL → REFUSE_UNTIL_AUTHORIZED (non-overridable; an authorized handler must sign off). Override relaxes only DISCLOSE / VERIFY cells.

## 4. Scoped claim
Distinct from Source Provenance (origin of the data) and Data Lineage (its transformation history): Data Sensitivity is the protection class of the data itself and the obligations that attach. A correctly-sourced, fully-cited answer can still mishandle regulated data — this gauge instruments that failure mode.

## 5. Receipt (`data_sensitivity.receipt.v1`)
`sensitivity · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.
