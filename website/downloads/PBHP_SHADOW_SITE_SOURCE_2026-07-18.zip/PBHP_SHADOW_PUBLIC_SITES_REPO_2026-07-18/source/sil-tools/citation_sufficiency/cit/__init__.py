"""CIT-6 Citation Sufficiency (SIL gauge #6). stdlib only."""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import hashlib, json
__version__ = "0.1.0"


class State(str, Enum):
    SUFFICIENT = "SUFFICIENT"; PARTIAL = "PARTIAL"
    UNAVAILABLE = "UNAVAILABLE"; UNSUPPORTED = "UNSUPPORTED"


class Stakes(str, Enum):
    LOW = "LOW"; MEDIUM = "MEDIUM"; HIGH = "HIGH"; CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNSOURCED = "REFUSE_UNSOURCED"


POLICY_VERSION = "citation-default/0.1.0"
_MATRIX = {
    (State.SUFFICIENT,  Stakes.LOW): Verdict.PROCEED, (State.SUFFICIENT, Stakes.MEDIUM): Verdict.PROCEED,
    (State.SUFFICIENT,  Stakes.HIGH): Verdict.PROCEED, (State.SUFFICIENT, Stakes.CRITICAL): Verdict.PROCEED,
    (State.PARTIAL,     Stakes.LOW): Verdict.PROCEED,
    (State.PARTIAL,     Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.PARTIAL,     Stakes.HIGH): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.PARTIAL,     Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.UNAVAILABLE, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNAVAILABLE, Stakes.MEDIUM): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNAVAILABLE, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.UNAVAILABLE, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.UNSUPPORTED, Stakes.LOW): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.UNSUPPORTED, Stakes.MEDIUM): Verdict.VERIFY_FIRST,
    (State.UNSUPPORTED, Stakes.HIGH): Verdict.VERIFY_FIRST,
    (State.UNSUPPORTED, Stakes.CRITICAL): Verdict.REFUSE_UNSOURCED,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNSOURCED}


def matrix_hash():
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def derive_state(required, sourced, citations_available=True):
    if required <= 0:
        return State.SUFFICIENT
    if not citations_available:
        return State.UNAVAILABLE
    if sourced >= required:
        return State.SUFFICIENT
    if sourced <= 0:
        return State.UNSUPPORTED
    return State.PARTIAL


def gate(state, stakes):
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes):
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE


@dataclass
class CITReceipt:
    required: int
    sourced: int
    citations_available: bool
    coverage_ratio: float
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "citation.receipt.v1"

    def to_dict(self): return asdict(self)
    def to_json(self, **kw): return json.dumps(self.to_dict(), **kw)
    def to_pbhp_extension(self): return {"citation": self.to_dict()}


def _now_iso(now=None):
    if now is None: return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, required, sourced, stakes, citations_available=True, override_ack=None, now=None):
    state = derive_state(required, sourced, citations_available)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    ratio = 1.0 if required <= 0 else round(min(sourced, required) / required, 4)
    return CITReceipt(required=required, sourced=sourced, citations_available=citations_available,
                      coverage_ratio=ratio, state=state.value, stakes=Stakes(stakes).value,
                      verdict=verdict.value, override=override, issued_at=_now_iso(now))


__all__ = ["audit", "CITReceipt", "State", "Stakes", "Verdict", "derive_state",
           "gate", "is_overridable", "matrix_hash", "POLICY_VERSION", "NON_OVERRIDABLE"]
