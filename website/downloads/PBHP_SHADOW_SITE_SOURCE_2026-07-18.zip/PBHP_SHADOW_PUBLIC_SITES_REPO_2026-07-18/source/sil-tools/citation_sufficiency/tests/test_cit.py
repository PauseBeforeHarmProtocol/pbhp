import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from cit import (audit, State, Stakes, Verdict, derive_state, gate,
                 is_overridable, matrix_hash, NON_OVERRIDABLE)

EXPECTED = {
    ("SUFFICIENT","LOW"):"PROCEED",("SUFFICIENT","MEDIUM"):"PROCEED",("SUFFICIENT","HIGH"):"PROCEED",("SUFFICIENT","CRITICAL"):"PROCEED",
    ("PARTIAL","LOW"):"PROCEED",("PARTIAL","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","HIGH"):"PROCEED_WITH_DISCLOSURE",("PARTIAL","CRITICAL"):"VERIFY_FIRST",
    ("UNAVAILABLE","LOW"):"PROCEED_WITH_DISCLOSURE",("UNAVAILABLE","MEDIUM"):"PROCEED_WITH_DISCLOSURE",("UNAVAILABLE","HIGH"):"VERIFY_FIRST",("UNAVAILABLE","CRITICAL"):"VERIFY_FIRST",
    ("UNSUPPORTED","LOW"):"PROCEED_WITH_DISCLOSURE",("UNSUPPORTED","MEDIUM"):"VERIFY_FIRST",("UNSUPPORTED","HIGH"):"VERIFY_FIRST",("UNSUPPORTED","CRITICAL"):"REFUSE_UNSOURCED",
}

def test_state_none_required(): assert derive_state(0,0) is State.SUFFICIENT
def test_state_sufficient(): assert derive_state(3,3) is State.SUFFICIENT
def test_state_partial(): assert derive_state(3,1) is State.PARTIAL
def test_state_unsupported(): assert derive_state(3,0) is State.UNSUPPORTED
def test_state_unavailable(): assert derive_state(3,0,citations_available=False) is State.UNAVAILABLE
def test_all_cells():
    for (st,sk),e in EXPECTED.items(): assert gate(st,sk).value==e,(st,sk,e)
def test_matrix_complete():
    assert len(EXPECTED)==16
    for s in State:
        for k in Stakes: assert (s.value,k.value) in EXPECTED
def test_floor(): assert NON_OVERRIDABLE=={(State.UNSUPPORTED,Stakes.CRITICAL)}
def test_refuse_not_overridable(): assert is_overridable(State.UNSUPPORTED,Stakes.CRITICAL) is False
def test_audit_unsupported_critical():
    r=audit(required=5,sourced=0,stakes="CRITICAL")
    assert r.state=="UNSUPPORTED" and r.verdict=="REFUSE_UNSOURCED" and r.coverage_ratio==0.0
def test_coverage_ratio(): assert audit(required=4,sourced=1,stakes="LOW").coverage_ratio==0.25
def test_override_ignored_on_floor():
    r=audit(required=2,sourced=0,stakes="CRITICAL",override_ack="op")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True
def test_receipt_schema_json_pbhp():
    r=audit(required=2,sourced=2,stakes="LOW")
    assert r.schema=="citation.receipt.v1" and len(r.matrix_hash)==64
    assert json.loads(r.to_json())==r.to_dict() and set(r.to_pbhp_extension())=={"citation"}

if __name__ == "__main__":
    fns=[(n,f) for n,f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    p=q=0
    for n,f in fns:
        try: f(); p+=1
        except AssertionError as e: q+=1; print("FAIL",n,e)
        except Exception as e: q+=1; print("ERROR",n,repr(e))
    print(f"\n[CIT] {p}/{p+q} passed"); sys.exit(1 if q else 0)
