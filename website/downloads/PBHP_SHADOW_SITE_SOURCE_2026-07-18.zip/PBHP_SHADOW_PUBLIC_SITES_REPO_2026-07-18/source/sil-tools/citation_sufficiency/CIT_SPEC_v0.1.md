# CIT-6: Citation Sufficiency — Source-Coverage Disclosure
## SIL gauge #6 — v0.1
**Date:** 2026-06-06 · **Concept:** Phillip Linstrum · **Schema:** `citation.receipt.v1` · **License:** open, attribution required.

## 1. Purpose
Not "does it have citations" but "are the claims that REQUIRE sources actually sourced." Lets the system say: "this answer contains claims needing support that are currently unsupported."

## 2. States
`SUFFICIENT` (all source-requiring claims sourced, or none require) · `PARTIAL` (some) · `UNAVAILABLE` (citation mechanism unavailable here) · `UNSUPPORTED` (claims require sources, none provided).

## 3. Gate (Stakes x State), SHA-256-hashed.
| State/Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| SUFFICIENT | PROCEED | PROCEED | PROCEED | PROCEED |
| PARTIAL | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| UNAVAILABLE | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| UNSUPPORTED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNSOURCED |
Floor: UNSUPPORTED/CRITICAL → REFUSE_UNSOURCED (non-overridable).

## 4. Receipt (`citation.receipt.v1`)
`required · sourced · citations_available · coverage_ratio · state · stakes · verdict · policy_version · matrix_hash · override · issued_at · schema`.

## 5. Boundary
Counts coverage; does not judge source quality (that pairs with Source Provenance #3) or currency (Knowledge Freshness #7).
