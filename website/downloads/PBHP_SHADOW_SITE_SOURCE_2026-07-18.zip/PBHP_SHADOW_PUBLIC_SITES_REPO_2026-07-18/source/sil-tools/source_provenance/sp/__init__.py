"""SP-3 Source Provenance — Source-Class Disclosure (SIL gauge #3)."""
from __future__ import annotations
from datetime import datetime, timezone

from .core import (SourceClass, State, Stakes, Verdict, POLICY_VERSION,
                   derive_state, gate, is_overridable, matrix_hash,
                   profile, worst_tier, NON_OVERRIDABLE)
from .receipt import SPReceipt

__version__ = "0.1.0"


def _now_iso(now=None) -> str:
    if now is None:
        return datetime.now(timezone.utc).isoformat()
    return now if isinstance(now, str) else now.isoformat()


def audit(*, claims, stakes, attributed=True, override_ack=None, now=None) -> SPReceipt:
    state = derive_state(claims, attributed)
    verdict = gate(state, stakes)
    overridable = is_overridable(state, stakes)
    relaxable = verdict in (Verdict.PROCEED_WITH_DISCLOSURE, Verdict.VERIFY_FIRST)
    applied = bool(override_ack) and overridable and relaxable
    override = {"applied": applied, "ack": override_ack if applied else None}
    if override_ack and not applied:
        override["ignored_floor"] = not overridable
    return SPReceipt(
        n_claims=len(claims),
        claims_profile=profile(claims),
        attributed=attributed,
        worst_tier=worst_tier(claims),
        state=state.value,
        stakes=Stakes(stakes).value,
        verdict=verdict.value,
        override=override,
        issued_at=_now_iso(now),
    )


__all__ = ["audit", "SPReceipt", "SourceClass", "State", "Stakes", "Verdict",
           "derive_state", "gate", "is_overridable", "matrix_hash", "profile",
           "worst_tier", "POLICY_VERSION", "NON_OVERRIDABLE"]
