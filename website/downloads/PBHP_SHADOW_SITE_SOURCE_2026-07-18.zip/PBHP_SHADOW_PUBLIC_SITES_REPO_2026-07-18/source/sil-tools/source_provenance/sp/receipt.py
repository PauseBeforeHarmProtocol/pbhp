"""SP-3 Source Provenance — receipt (sp.receipt.v1)."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import json
from .core import POLICY_VERSION, matrix_hash


@dataclass
class SPReceipt:
    n_claims: int
    claims_profile: dict
    attributed: bool
    worst_tier: object
    state: str
    stakes: str
    verdict: str
    policy_version: str = POLICY_VERSION
    matrix_hash: str = field(default_factory=matrix_hash)
    override: dict = field(default_factory=lambda: {"applied": False, "ack": None})
    issued_at: str = ""
    schema: str = "sp.receipt.v1"

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self, **kw) -> str:
        return json.dumps(self.to_dict(), **kw)

    def to_pbhp_extension(self) -> dict:
        return {"sp": self.to_dict()}
