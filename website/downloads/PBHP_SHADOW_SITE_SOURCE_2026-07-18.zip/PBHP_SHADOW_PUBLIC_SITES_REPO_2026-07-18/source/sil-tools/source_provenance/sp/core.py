"""SP-3 Source Provenance — core logic (stdlib only)."""
from __future__ import annotations
from enum import Enum
import hashlib


class SourceClass(str, Enum):
    USER = "user"
    FILE = "file"
    TOOL = "tool"
    INFERENCE = "inference"
    MODEL = "model"
    SPECULATION = "speculation"


_EXTERNAL = {SourceClass.USER, SourceClass.FILE, SourceClass.TOOL}
_RANK = {SourceClass.USER: 3, SourceClass.FILE: 3, SourceClass.TOOL: 3,
         SourceClass.INFERENCE: 2, SourceClass.MODEL: 1, SourceClass.SPECULATION: 0}


class State(str, Enum):
    GROUNDED = "GROUNDED"
    MIXED = "MIXED"
    MODEL_HEAVY = "MODEL_HEAVY"
    SPECULATIVE = "SPECULATIVE"
    BLURRED = "BLURRED"


class Stakes(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Verdict(str, Enum):
    PROCEED = "PROCEED"
    PROCEED_WITH_DISCLOSURE = "PROCEED_WITH_DISCLOSURE"
    VERIFY_FIRST = "VERIFY_FIRST"
    REFUSE_UNLABELED = "REFUSE_UNLABELED"


POLICY_VERSION = "sp-default/0.1.0"

_MATRIX = {
    (State.GROUNDED,    Stakes.LOW):      Verdict.PROCEED,
    (State.GROUNDED,    Stakes.MEDIUM):   Verdict.PROCEED,
    (State.GROUNDED,    Stakes.HIGH):     Verdict.PROCEED,
    (State.GROUNDED,    Stakes.CRITICAL): Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MIXED,       Stakes.LOW):      Verdict.PROCEED,
    (State.MIXED,       Stakes.MEDIUM):   Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MIXED,       Stakes.HIGH):     Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MIXED,       Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.MODEL_HEAVY, Stakes.LOW):      Verdict.PROCEED,
    (State.MODEL_HEAVY, Stakes.MEDIUM):   Verdict.PROCEED_WITH_DISCLOSURE,
    (State.MODEL_HEAVY, Stakes.HIGH):     Verdict.VERIFY_FIRST,
    (State.MODEL_HEAVY, Stakes.CRITICAL): Verdict.VERIFY_FIRST,
    (State.SPECULATIVE, Stakes.LOW):      Verdict.PROCEED_WITH_DISCLOSURE,
    (State.SPECULATIVE, Stakes.MEDIUM):   Verdict.VERIFY_FIRST,
    (State.SPECULATIVE, Stakes.HIGH):     Verdict.VERIFY_FIRST,
    (State.SPECULATIVE, Stakes.CRITICAL): Verdict.REFUSE_UNLABELED,
    (State.BLURRED,     Stakes.LOW):      Verdict.PROCEED_WITH_DISCLOSURE,
    (State.BLURRED,     Stakes.MEDIUM):   Verdict.VERIFY_FIRST,
    (State.BLURRED,     Stakes.HIGH):     Verdict.REFUSE_UNLABELED,
    (State.BLURRED,     Stakes.CRITICAL): Verdict.REFUSE_UNLABELED,
}
NON_OVERRIDABLE = {k for k, v in _MATRIX.items() if v is Verdict.REFUSE_UNLABELED}


def matrix_hash() -> str:
    items = sorted(f"{a.value}|{b.value}={v.value}" for (a, b), v in _MATRIX.items())
    return hashlib.sha256("\n".join(items).encode("utf-8")).hexdigest()


def profile(claims) -> dict:
    out = {}
    for c in claims:
        c = SourceClass(c)
        out[c.value] = out.get(c.value, 0) + 1
    return out


def worst_tier(claims):
    cs = [SourceClass(c) for c in claims]
    if not cs:
        return None
    return min(cs, key=lambda c: _RANK[c]).value


def derive_state(claims, attributed=True) -> State:
    cs = [SourceClass(c) for c in claims]
    if not cs:
        return State.GROUNDED
    if any(c is SourceClass.SPECULATION for c in cs):
        return State.SPECULATIVE
    has_ext = any(c in _EXTERNAL for c in cs)
    has_soft = any(c in (SourceClass.MODEL, SourceClass.INFERENCE) for c in cs)
    if has_ext and has_soft and not attributed:
        return State.BLURRED
    if all(c in _EXTERNAL for c in cs):
        return State.GROUNDED
    model_n = sum(1 for c in cs if c is SourceClass.MODEL)
    if model_n * 2 >= len(cs):
        return State.MODEL_HEAVY
    return State.MIXED


def gate(state, stakes) -> Verdict:
    return _MATRIX[(State(state), Stakes(stakes))]


def is_overridable(state, stakes) -> bool:
    return (State(state), Stakes(stakes)) not in NON_OVERRIDABLE
