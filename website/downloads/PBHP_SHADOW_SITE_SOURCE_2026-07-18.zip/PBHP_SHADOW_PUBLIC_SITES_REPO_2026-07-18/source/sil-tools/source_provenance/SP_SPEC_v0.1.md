# SP-3: Source Provenance — Source-Class Disclosure
## SIL gauge #3 — Specification v0.1

**Status:** Draft for review · **Date:** 2026-06-06 · **Concept:** Phillip Linstrum
**Class:** PBHP-SIL instrument #3 (`04_synthesis/02_SIL_FRAMEWORK_v0.1.md`); follows the CLA-1 / TDA-2 template.
**Schema:** `sp.receipt.v1` · **License:** open, attribution required, no single owner.

## 1. Purpose
AI blends user input, uploaded files, tool results, prior knowledge, inference, and outright guesses into one fluent voice. Source blur is among the biggest hidden hazards: the operator cannot tell a checkable fact from a confident invention. Source Provenance tags each claim by origin class, surfaces blur, and gates consequential output that mixes checkable evidence with model guesses **unlabeled**.

## 2. Scope and honest claims
Already exists (not new): RAG citation/attribution, provenance metadata, content-credential standards. SP contributes an **operator-facing per-output provenance profile + a blur flag + stakes-aware gating + a receipt**, inside a harm-prevention framework. Per-claim tagging is the model's responsibility; SP makes the resulting mix visible, auditable, and gated.
**Boundary:** SP classifies *where claims came from*. Whether cited sources are *enough* is Citation Sufficiency (#6); whether they are *current* is Knowledge Freshness (#7).

## 3. Source classes (reliability, best first)
`user` · `file` · `tool` (external, checkable — rank 3) > `inference` (from sources — 2) > `model` (training prior — 1) > `speculation` (0).

## 4. States
`GROUNDED` (all claims external/checkable) · `MIXED` (external + attributed soft) · `MODEL_HEAVY` (>= half model-prior) · `SPECULATIVE` (any speculation present) · `BLURRED` (external + soft mixed with NO per-claim attribution — the hazard).

## 5. Gate (Stakes x State). Matrix SHA-256-hashed into every receipt.

| State / Stakes | LOW | MEDIUM | HIGH | CRITICAL |
|---|---|---|---|---|
| GROUNDED | PROCEED | PROCEED | PROCEED | PROCEED_WITH_DISCLOSURE |
| MIXED | PROCEED | PROCEED_WITH_DISCLOSURE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST |
| MODEL_HEAVY | PROCEED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST |
| SPECULATIVE | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | VERIFY_FIRST | REFUSE_UNLABELED |
| BLURRED | PROCEED_WITH_DISCLOSURE | VERIFY_FIRST | REFUSE_UNLABELED | REFUSE_UNLABELED |

Verdicts: PROCEED · PROCEED_WITH_DISCLOSURE (label sources) · VERIFY_FIRST (attribute + check) · REFUSE_UNLABELED (do not present blurred/speculative content as fact). Every REFUSE_UNLABELED cell is a **non-overridable floor**; override can only relax DISCLOSE/VERIFY (logged ack).

**Floor design note (intentional multi-cell floor; F1, audited 2026-06-07).** SP locks three non-overridable cells — SPECULATIVE×CRITICAL, BLURRED×HIGH, BLURRED×CRITICAL — rather than the single CRITICAL×CRITICAL corner most gauges use. This is deliberate and risk-based: presenting *unlabeled* blurred or speculative content as fact is the exact hazard SP exists to stop, so it is refused at HIGH as well as CRITICAL. Recorded as a maintainer decision in `../AUDIT_FINDINGS_SIL_2026-06-07.md` (cf. Time/Date #2, stricter on temporal blindness for the same reason).

## 6. Receipt (`sp.receipt.v1`)
`n_claims · claims_profile{class:count} · attributed · worst_tier · state · stakes · verdict · policy_version · matrix_hash · override{applied,ack} · issued_at · schema`. Written before output commits; embeddable beside `cla`/`tda` in a signed PBHP receipt.

## 7. PBHP integration
PROCEED→Door · REFUSE_UNLABELED→Wall (Sacred Refusal) · DISCLOSE/VERIFY→Gap (record Maybe/Therefore). Stakes ← GREEN→BLACK. Repeated overrides → CAPA. Mirror Vow: operator does not pressure unlabeled blur past a floor without logged ack.

*Vocabulary note (F4):* Door/Wall/Gap, Sacred Refusal, and Mirror Vow here are **PBHP-framework integration primitives** (the layer SP plugs into), not the project's mythic/Tribunal vocabulary — the SIL gauge surface itself stays sterile.

## 8. Validation (empirical; eval loop closed)
Differential battery: prompts that invite source blur (mix uploaded data with model priors) through baseline vs. SP-instrumented harness; measure rate of unlabeled model-claims presented as sourced fact caught.

## 9. Limitations
Depends on honest per-claim tagging upstream; `attributed=False` is the conservative default when tagging is absent. Classifies origin, not truth.

## 10. Attribution
Concept: Phillip Linstrum (SIL gauge #3). Template: CLA-1. License: open, attribution required, no single owner.
