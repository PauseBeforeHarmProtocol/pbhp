"""SP-3 test suite. pytest or standalone: python3 tests/test_sp.py"""
import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import sp
from sp import audit, SPReceipt
from sp.core import (SourceClass, State, Stakes, Verdict, derive_state, gate,
                     is_overridable, matrix_hash, profile, worst_tier, NON_OVERRIDABLE)

EXPECTED = {
    ("GROUNDED", "LOW"): "PROCEED", ("GROUNDED", "MEDIUM"): "PROCEED",
    ("GROUNDED", "HIGH"): "PROCEED", ("GROUNDED", "CRITICAL"): "PROCEED_WITH_DISCLOSURE",
    ("MIXED", "LOW"): "PROCEED", ("MIXED", "MEDIUM"): "PROCEED_WITH_DISCLOSURE",
    ("MIXED", "HIGH"): "PROCEED_WITH_DISCLOSURE", ("MIXED", "CRITICAL"): "VERIFY_FIRST",
    ("MODEL_HEAVY", "LOW"): "PROCEED", ("MODEL_HEAVY", "MEDIUM"): "PROCEED_WITH_DISCLOSURE",
    ("MODEL_HEAVY", "HIGH"): "VERIFY_FIRST", ("MODEL_HEAVY", "CRITICAL"): "VERIFY_FIRST",
    ("SPECULATIVE", "LOW"): "PROCEED_WITH_DISCLOSURE", ("SPECULATIVE", "MEDIUM"): "VERIFY_FIRST",
    ("SPECULATIVE", "HIGH"): "VERIFY_FIRST", ("SPECULATIVE", "CRITICAL"): "REFUSE_UNLABELED",
    ("BLURRED", "LOW"): "PROCEED_WITH_DISCLOSURE", ("BLURRED", "MEDIUM"): "VERIFY_FIRST",
    ("BLURRED", "HIGH"): "REFUSE_UNLABELED", ("BLURRED", "CRITICAL"): "REFUSE_UNLABELED",
}


def test_state_grounded():
    assert derive_state(["user", "file", "tool"]) is State.GROUNDED

def test_state_speculative_wins():
    assert derive_state(["user", "speculation"]) is State.SPECULATIVE

def test_state_blurred_when_unattributed():
    assert derive_state(["user", "model"], attributed=False) is State.BLURRED

def test_state_mixed_when_attributed():
    assert derive_state(["user", "file", "model"], attributed=True) is State.MIXED

def test_state_model_heavy_half_or_more():
    assert derive_state(["user", "model", "model"], attributed=True) is State.MODEL_HEAVY
    assert derive_state(["model"]) is State.MODEL_HEAVY

def test_empty_is_grounded():
    assert derive_state([]) is State.GROUNDED

def test_profile_counts():
    assert profile(["user", "user", "model"]) == {"user": 2, "model": 1}

def test_worst_tier():
    assert worst_tier(["user", "model", "speculation"]) == "speculation"
    assert worst_tier(["user", "file"]) in ("user", "file")
    assert worst_tier([]) is None

def test_all_twenty_cells():
    for (st, sk), exp in EXPECTED.items():
        assert gate(st, sk).value == exp, (st, sk, exp)

def test_matrix_covers_every_cell():
    assert len(EXPECTED) == 20
    for s in State:
        for k in Stakes:
            assert (s.value, k.value) in EXPECTED

def test_floor_cells():
    assert NON_OVERRIDABLE == {
        (State.SPECULATIVE, Stakes.CRITICAL),
        (State.BLURRED, Stakes.HIGH),
        (State.BLURRED, Stakes.CRITICAL),
    }

def test_refuse_not_overridable():
    assert is_overridable(State.BLURRED, Stakes.HIGH) is False
    assert is_overridable(State.SPECULATIVE, Stakes.CRITICAL) is False

def test_disclose_overridable():
    assert is_overridable(State.MIXED, Stakes.MEDIUM) is True

def test_audit_grounded_low():
    r = audit(claims=["user", "tool"], stakes="LOW")
    assert r.state == "GROUNDED" and r.verdict == "PROCEED"
    assert r.n_claims == 2 and r.worst_tier in ("user", "tool")

def test_audit_blurred_high_refuses():
    r = audit(claims=["file", "model"], stakes="HIGH", attributed=False)
    assert r.state == "BLURRED" and r.verdict == "REFUSE_UNLABELED"

def test_override_relaxes_verify():
    r = audit(claims=["user", "file", "model"], stakes="CRITICAL", attributed=True,
              override_ack="op: accept, logged")
    assert r.verdict == "VERIFY_FIRST" and r.override["applied"] is True

def test_override_ignored_on_floor():
    r = audit(claims=["file", "model"], stakes="CRITICAL", attributed=False,
              override_ack="op: just answer")
    assert r.override["applied"] is False and r.override.get("ignored_floor") is True

def test_receipt_schema_json_pbhp():
    r = audit(claims=["user"], stakes="LOW")
    assert r.schema == "sp.receipt.v1" and len(r.matrix_hash) == 64
    assert json.loads(r.to_json()) == r.to_dict()
    assert set(r.to_pbhp_extension()) == {"sp"}


if __name__ == "__main__":
    fns = [(n, f) for n, f in sorted(globals().items())
           if n.startswith("test_") and callable(f)]
    p = q = 0
    for n, f in fns:
        try:
            f(); p += 1
        except AssertionError as e:
            q += 1; print("FAIL", n, e)
        except Exception as e:
            q += 1; print("ERROR", n, repr(e))
    print(f"\n{p}/{p + q} passed")
    sys.exit(1 if q else 0)
