from __future__ import annotations

from dataclasses import dataclass
import html
from typing import Any

from component_catalog import (
    COMPONENT_LIBRARY_VERSION,
    PBHP_COMPONENTS,
    SHADOW_COMPONENTS,
    combined_bundle_name,
    project_bundle_name,
    render_component_catalog,
    render_testing_matrix,
)
from sil_catalog import SIL_LIBRARY_VERSION, SIL_TOOLS, full_panel_pack_name, tool_pack_name

RELEASE_DATE = "2026-07-18"
PBHP_CANONICAL = "https://pausebeforeharm.frylock117.chatgpt.site"
SHADOW_CANONICAL = "https://projectshadow.frylock117.chatgpt.site"
ALMSIVI_CANONICAL = "https://almsivi.frylock117.chatgpt.site"
RECORD_CANONICAL = "https://therecord.frylock117.chatgpt.site"
ARM_CANONICAL = "https://americanrepairmanual.frylock117.chatgpt.site"
PBHP_GITHUB = "https://github.com/PauseBeforeHarmProtocol/pbhp"
SHADOW_COMPLETE_PACKAGE_NAME = "PROJECT_SHADOW_COMPLETE_PACKAGE_v1.3.1_2026-07-18.zip"
SHADOW_COMPLETE_PACKAGE_SHA = SHADOW_COMPLETE_PACKAGE_NAME + ".sha256"
SHADOW_COMPLETE_MANIFEST = "PROJECT_SHADOW_COMPLETE_PACKAGE_v1.3.1_MANIFEST.json"
SHADOW_COMPLETE_TEST_RESULTS = "PROJECT_SHADOW_COMPLETE_PACKAGE_v1.3.1_TEST_RESULTS.json"


def shadow_complete_package_card() -> str:
    return f"""
<div class="tool-launch tool-launch--package">
  <div class="tool-launch__copy">
    <p class="kicker">Complete Project Shadow download</p>
    <h2>Runtime, prompt, language, instruments, and evidence — one package</h2>
    <p>The three core files are at the root with simple names. The same ZIP also carries the 28-gauge SIL panel, component library, Grand TEVV v0.3, public tools, experiment packs, manifests, checksums, and a local verifier.</p>
    <div class="package-file-list" aria-label="Core files included"><code>shadow.py</code><code>shadow_prompt.md</code><code>shadow_lang.py</code></div>
    <details class="package-details">
      <summary>See direct files and verification records</summary>
      <div class="package-details__links">
        <a href="[[ASSET|downloads/shadow.py]]" download>Download shadow.py</a>
        <a href="[[ASSET|downloads/shadow_prompt.md]]" download>Download shadow_prompt.md</a>
        <a href="[[ASSET|downloads/shadow_lang.py]]" download>Download shadow_lang.py</a>
        <a href="[[ASSET|downloads/{SHADOW_COMPLETE_MANIFEST}]]">Open manifest</a>
        <a href="[[ASSET|downloads/{SHADOW_COMPLETE_TEST_RESULTS}]]">Open test record</a>
        <a href="[[ASSET|downloads/{SHADOW_COMPLETE_PACKAGE_SHA}]]">SHA-256</a>
      </div>
    </details>
  </div>
  <a class="button button--primary package-download-button" href="[[ASSET|downloads/{SHADOW_COMPLETE_PACKAGE_NAME}]]" download>Download complete package</a>
</div>
"""


def card_grid(cards: list[tuple[str, str, str]], columns: int = 2) -> str:
    items = []
    for title, body, target in cards:
        items.append(
            f'<a class="nav-card" href="[[URL|{target}]]"><span class="nav-card__title">{title}</span>'
            f'<span class="nav-card__body">{body}</span><span class="nav-card__arrow" aria-hidden="true">→</span></a>'
        )
    return f'<div class="card-grid card-grid--{columns}">' + "".join(items) + "</div>"


def evidence_badges() -> str:
    return """
<div class="evidence-key" aria-label="Evidence-state key">
  <span class="evidence evidence--specified">Specified</span>
  <span class="evidence evidence--expected">Expected</span>
  <span class="evidence evidence--observed">Observed</span>
  <span class="evidence evidence--adverse">Adverse</span>
  <span class="evidence evidence--open">Open</span>
</div>
"""


def project_family() -> str:
    return f"""
<div class="project-family">
  <a href="{PBHP_CANONICAL}"><strong>Pause Before Harm</strong><span>Practical protocol</span></a>
  <a href="{SHADOW_CANONICAL}"><strong>Project Shadow</strong><span>Technical system</span></a>
  <a href="{ALMSIVI_CANONICAL}"><strong>ALMSIVI</strong><span>Independent mythic temple</span></a>
  <a href="{RECORD_CANONICAL}"><strong>The Record</strong><span>Civic accountability archive</span></a>
  <a href="{ARM_CANONICAL}"><strong>American Repair Manual</strong><span>Civic QA / CAPA</span></a>
</div>
"""


PBHP_NAV = [
    ("Start", [("Home", ""), ("Start here", "start"), ("Daily ledger", "daily")]),
    ("Use the protocol", [("Protocol", "protocol"), ("Workbench", "workbench"), ("Examples", "examples"), ("Receipts", "receipts")]),
    ("Learn", [("Field manual", "manual"), ("Risk & power", "risk"), ("Foundations", "foundations"), ("Glossary", "glossary")]),
    ("Evidence", [("Evidence ledger", "evidence"), ("Research", "research")]),
    ("Adopt", [("Implementation", "implementation"), ("Operations", "operations"), ("Context Load Audit", "cla"), ("Templates", "templates")]),
    ("Project", [("Repository & downloads", "repository"), ("Versions", "versions"), ("About", "about"), ("Directory", "directory")]),
]

SHADOW_NAV = [
    ("Start", [("Home", ""), ("Start here", "start"), ("Daily ledger", "daily")]),
    ("System", [("System map", "system"), ("Runtime", "runtime"), ("Synthesis", "synthesis"), ("Primitives", "primitives"), ("Gates", "gates")]),
    ("Instrumentation", [("SIL", "sil"), ("Receipts", "receipts")]),
    ("Evaluation", [("TEVV v0.3", "tevv"), ("Behavioral Falsifier", "behavioral-falsifier"), ("Research", "research"), ("Status", "status")]),
    ("Governance", [("Governance", "governance"), ("Narrative governance", "narrative-governance")]),
    ("Build", [("Integrations", "integrations"), ("Blueprint", "blueprint"), ("Roadmap", "roadmap")]),
    ("Reference", [("System reference", "reference"), ("Mythic Atlas", "atlas"), ("Glossary", "glossary")]),
    ("Project", [("Repository & downloads", "repository"), ("Versions", "versions"), ("About", "about"), ("Directory", "directory")]),
]


PBHP_PAGES: list[dict[str, Any]] = [
    {
        "route": "",
        "title": "Pause Before Harm",
        "eyebrow": "The practical action-boundary protocol",
        "description": "A usable decision protocol for moments when being wrong could affect another person’s safety, rights, livelihood, privacy, reputation, agency, or future.",
        "body": f"""
<div class="hero hero--pbhp">
  <div class="hero__copy">
    <p class="kicker">Canonical current release · updated {RELEASE_DATE}</p>
    <h1>Pause before power becomes harm.</h1>
    <p class="lede">PBHP inserts a deliberate, auditable pause between a consequential decision and the act that makes it real. It does not demand paralysis. It demands that the decision-maker identify who pays first, test reversibility and power, argue the strongest honest case against proceeding, choose the smallest safer path, and write the receipt before acting.</p>
    <div class="hero__actions"><a class="button button--primary" href="[[URL|workbench]]">Run the workbench</a><a class="button" href="[[URL|protocol]]">Read the protocol</a></div>
  </div>
  <div class="hero__signal" aria-label="PBHP governing sequence">
    <span>Pause</span><i>→</i><span>Classify</span><i>→</i><span>Invert power</span><i>→</i><span>Challenge</span><i>→</i><span>Receipt</span>
  </div>
</div>

<div class="status-strip">
  <div><strong>Purpose</strong><span>Safer consequential action</span></div>
  <div><strong>Primary question</strong><span>Who pays first if this is wrong?</span></div>
  <div><strong>Binding rule</strong><span>The gate—not preference—sets the action</span></div>
  <div><strong>Evidence posture</strong><span>Specified, observed, adverse, open</span></div>
</div>

## Choose your path

{card_grid([
    ("I have a decision now", "Walk a real action through PBHP and generate a local receipt.", "workbench"),
    ("I am new to PBHP", "Understand the protocol in ten minutes, then see a worked example.", "start"),
    ("I need to implement it", "Use the adoption, governance, CAPA, and template materials.", "implementation"),
    ("I am evaluating the claims", "Inspect supportive, adverse, and still-open evidence side by side.", "evidence"),
], 2)}

## What PBHP changes

PBHP turns an intuitive warning—*slow down when the stakes are real*—into an operational sequence with named inputs and required outputs. A complete run states the action, classifies it as a Door, Wall, or Gap, identifies who bears the first cost, tests the decision from the least-powerful position, assigns a harm threshold, chooses proportionate rigor, completes Maybe/Therefore, and writes a receipt before commitment.

The output is not always refusal. It may be **PROCEED**, **PROCEED WITH MITIGATIONS**, **CONSTRAIN AND REVIEW**, **DELAY PENDING EVIDENCE**, or **REFUSE**. The protocol is designed to preserve useful action while preventing urgency, authority, sunk cost, flattery, or narrative momentum from substituting for evidence.

## PBHP and Project Shadow

PBHP is the understandable action protocol. [[Project Shadow|{SHADOW_CANONICAL}]] is the deeper technical system that implements, instruments, tests, and governs it. Start here when the question is, “What should I do?” Move into Shadow when the question becomes, “How is this enforced, measured, falsified, and corrected?”

## The project family

These are separate projects with distinct purposes—not one giant website. ALMSIVI remains independent; The Record and the American Repair Manual form the civic family; PBHP and Project Shadow are intentionally cross-linked.

{project_family()}
""",
        "related": ["start", "protocol", "workbench", "evidence"],
    },
    {
        "route": "start",
        "title": "Start here",
        "eyebrow": "A ten-minute orientation",
        "description": "Understand what PBHP is, what it is not, and how to move from a consequential action to a documented decision state.",
        "body": """
# Start here

PBHP is a deployment-time decision discipline. It belongs between broad governance principles and the moment a person or system commits a consequential act. It does not replace law, professional judgment, domain expertise, or organizational accountability. It gives those things a repeatable action boundary.

## The shortest usable version

1. **Name the act.** State exactly what will be done, to whom, through what mechanism, and on what timeline.
2. **Classify the path.** Is it a Door, a Wall, or a Gap?
3. **Name who pays first.** Identify the first person or group harmed if the decision is wrong.
4. **Invert the power.** Would this still seem legitimate from the least-powerful position?
5. **Set the harm threshold.** GREEN, YELLOW, ORANGE, RED, or BLACK.
6. **Argue against yourself.** Write the strongest honest Maybe before the Therefore.
7. **Choose the action state.** Proceed, mitigate, constrain, delay, or refuse.
8. **Write the receipt before the act.** No record means no authorization.

## What it is not

- It is not a claim that every hard decision can be reduced to a checklist.
- It is not a legal certification or a substitute for regulated review.
- It is not proof that an AI system is safe.
- It is not permission for a model to override the responsible human owner.
- It is not a moral-performance ritual. A weak or ceremonial Maybe is itself a drift signal.

## A two-minute example

**Proposed act:** Publish an employee-performance summary generated from incomplete AI notes.

**Who pays first:** The employee, through reputation and employment consequences.

**Power inversion:** The subject cannot inspect the source notes or correct the model’s interpretation before publication.

**Threshold:** ORANGE because a higher-power actor would impose a potentially durable judgment on a lower-power person using incomplete evidence.

**Maybe:** The summary may be wrong, may encode managerial bias, and may be difficult to reverse after circulation.

**Therefore:** Do not publish the generated summary. Use it only as a private draft, give the employee the underlying factual claims, require a human reviewer, and preserve a correction path.

**Decision state:** CONSTRAIN AND REVIEW.

## Where to go next

""" + card_grid([
            ("Run it", "Use the interactive workbench on a real decision.", "workbench"),
            ("Study it", "Read the full protocol and manual.", "protocol"),
            ("Challenge it", "Read evidence, adverse results, and open validation gaps.", "evidence"),
            ("Adopt it", "See implementation pathways and templates.", "implementation"),
        ], 2),
        "related": ["protocol", "workbench", "examples", "about"],
    },
    {
        "route": "protocol",
        "title": "The PBHP protocol",
        "eyebrow": "Eight gates · one binding action state",
        "description": "The complete human-readable protocol, including required inputs, outputs, escalation logic, and the conditions that block authorization.",
        "body": """
# The PBHP protocol

The protocol is sequential because later confidence must not erase an earlier binding condition. Each gate produces an explicit output. Missing output is not silent permission; it is an incomplete run.

## Gate 0 — Competence and honest use

Confirm that the protocol is being used to examine the decision rather than bless a predetermined answer. Name missing expertise, unavailable tools, conflicts of interest, time pressure, and any instruction that asks for endorsement without inspection.

**Required output:** `competent`, `competent_with_limits`, or `not_competent` plus the limits.

## Gate 1 — State the action

Write one specific sentence describing what will be done, to whom, through what mechanism, and within what timeframe. Replace intentions such as “improve safety” with the actual act that creates consequences.

**Required output:** a concrete action statement and affected parties.

## Gate 2 — Door, Wall, or Gap

- **Door:** a legitimate and sufficiently safe route forward.
- **Wall:** a binding reason not to proceed in the proposed form.
- **Gap:** unresolved uncertainty, missing evidence, or a route through which harm could escape.

A Gap is a real decision state. It is never silently upgraded to a Door because the operator is confident or hurried.

**Required output:** classification plus the reason.

## Gate 3 — Who pays first

Name the person or group that bears the first cost if the decision is wrong. Describe the harm, the timing, and whether the affected party can recover.

**Required output:** stakeholder, first cost, recovery path, and evidence basis.

## Gate 3.5 — Power inversion

Reverse the position. Would the decision still look legitimate if you were the least-powerful person receiving it? Does the affected party have notice, voice, consent, appeal, exit, and repair?

A low-power stakeholder plus an irreversible decision creates an ORANGE floor. Selective weighting cannot ratchet that floor down.

**Required output:** power relationship and any forced floor.

## Gate 4 — Harm threshold

| Threshold | Meaning | Default action posture |
|---|---|---|
| GREEN | Low, bounded, reversible harm | Proceed if other gates clear |
| YELLOW | Recoverable harm requiring safeguards | Proceed with mitigations |
| ORANGE | Material third-party harm or power asymmetry | Constrain, fence, and review |
| RED | Severe or difficult-to-reverse harm | Delay or refuse pending independent confirmation |
| BLACK | Catastrophic, non-consensual, or unacceptable irreversible harm | Refuse absolutely |

**Required output:** threshold, rationale, and governing factor.

## Gate 5 — Proportionate rigor

Use the lightest edition that is adequate to the stakes:

- **HUMAN:** paper or conversational run for ordinary decisions.
- **MIN:** fast reflex for bounded operational choices.
- **CORE:** complete gate, evidence, and receipt discipline.
- **ULTRA:** independent review, quorum, and reversal authority.
- **ULTIMATE:** full Project Shadow stack and reference materials.

**Required output:** tier and why it is sufficient.

## Gate 6 — Maybe / Therefore

Write the strongest honest case against the preferred action before writing why it should proceed anyway.

- **Maybe:** the best argument that the act is wrong, premature, unfair, unsafe, or unsupported.
- **Therefore:** the evidence-based reason for proceeding, constraining, delaying, or refusing.

A token objection, straw man, or evasive Maybe fails the gate.

**Required output:** substantive Maybe and Therefore.

## Gate 7 — Receipt before action

Record the action, affected parties, evidence, classification, threshold, safeguards, Maybe/Therefore, decision state, owner, review date, and effectiveness check before commitment.

**Binding rule:** **no record, no action; the gate—not preference—sets the action.**

## Decision states

A completed run ends in one of five public-facing states:

1. **PROCEED** — the Door is clear and sufficiently reversible.
2. **PROCEED WITH MITIGATIONS** — the act may proceed only with named safeguards.
3. **CONSTRAIN AND REVIEW** — scope is reduced and independent review is required.
4. **DELAY PENDING EVIDENCE** — missing evidence is decision-critical.
5. **REFUSE** — a Wall, RED/BLACK condition, or failed authorization blocks the act.

## Challenge and release valve

Any pause can be challenged through the False Positive Release Valve. The response must state the trigger, the risk, an alternative Door, and the evidence that would prevent the pause next time. Repeated pressure without new evidence is a drift alarm, not a reason to yield.
""",
        "related": ["workbench", "receipts", "risk", "manual"],
    },
    {
        "route": "workbench",
        "title": "Decision workbench",
        "eyebrow": "Run PBHP locally in your browser",
        "description": "A privacy-preserving client-side worksheet that produces a draft PBHP receipt without sending the entered decision anywhere.",
        "body": """
# Decision workbench

Use this to structure a decision, not to outsource it. The tool runs entirely in the browser and does not certify correctness. Its recommendation is a transparent routing aid based on the fields you enter.

<div class="privacy-note"><strong>Local-only draft:</strong> this static workbench does not transmit or store your entries. Download or copy the receipt before leaving the page.</div>

<form id="pbhp-workbench" class="workbench" novalidate>
  <div class="form-grid">
    <label><span>Proposed action</span><textarea name="action" required placeholder="What exactly will be done, to whom, through what mechanism, and when?"></textarea></label>
    <label><span>Affected parties</span><textarea name="affected" required placeholder="Name roles or groups, not vague abstractions."></textarea></label>
    <label><span>Door / Wall / Gap</span><select name="classification" required><option value="">Choose…</option><option>Door</option><option>Wall</option><option>Gap</option></select></label>
    <label><span>Who pays first?</span><textarea name="who_pays" required placeholder="Who bears the first cost if this is wrong, and how?"></textarea></label>
    <label><span>Power relationship</span><select name="power"><option value="balanced">Roughly balanced</option><option value="asymmetric">Meaningfully asymmetric</option><option value="extreme">Extreme / coercive</option></select></label>
    <label><span>Reversibility</span><select name="reversibility"><option value="easy">Easy to reverse</option><option value="partial">Partially reversible</option><option value="hard">Hard to reverse</option><option value="irreversible">Irreversible</option></select></label>
    <label><span>Initial harm threshold</span><select name="harm"><option>GREEN</option><option>YELLOW</option><option>ORANGE</option><option>RED</option><option>BLACK</option></select></label>
    <label><span>Evidence basis</span><textarea name="evidence" placeholder="What is measured, attested, declared, or still unknown?"></textarea></label>
    <label class="form-span"><span>Maybe — strongest honest case against</span><textarea name="maybe" required placeholder="Write the strongest version, not the easiest objection to dismiss."></textarea></label>
    <label class="form-span"><span>Therefore — why this action state follows</span><textarea name="therefore" required placeholder="Explain why the act proceeds, is constrained, is delayed, or is refused."></textarea></label>
    <label><span>Safeguards / smaller Door</span><textarea name="safeguards" placeholder="What reduces scope, exposure, duration, or irreversibility?"></textarea></label>
    <label><span>Owner and effectiveness check</span><textarea name="followup" placeholder="Who checks the result, when, and against what criterion?"></textarea></label>
  </div>
  <div class="workbench__actions"><button class="button button--primary" type="submit">Generate draft receipt</button><button class="button" type="reset">Clear</button></div>
</form>

<section id="receipt-output" class="receipt-output" hidden aria-live="polite">
  <div class="receipt-output__head"><div><p class="kicker">Draft decision receipt</p><h2 id="receipt-state">—</h2></div><div><button class="button button--small" id="copy-receipt" type="button">Copy JSON</button><button class="button button--small" id="download-receipt" type="button">Download</button></div></div>
  <p id="receipt-rationale"></p>
  <pre><code id="receipt-json"></code></pre>
</section>

## How the draft router works

The workbench applies only explicit, conservative rules: a Wall or BLACK condition routes to refusal; RED routes to delay or refusal; an asymmetric or extreme power relationship combined with an irreversible act creates at least an ORANGE floor; an incomplete Maybe/Therefore holds the decision; ORANGE routes to constraint and review; YELLOW routes to mitigated proceeding; GREEN plus a clear Door may proceed. The result remains a draft owned by the responsible decision-maker.
""",
        "related": ["protocol", "receipts", "examples", "templates"],
        "script": "workbench",
    },
    {
        "route": "manual",
        "title": "Field manual",
        "eyebrow": "Eleven chapters from foundation to claims",
        "description": "A long-form operational manual explaining when each control activates, what must be inspected, what output is required, and how failure looks.",
        "body": """
# PBHP field manual

The field manual is organized as an operating system rather than a manifesto. Each chapter answers six questions: **When does this control activate? What must be inspected? What output is required? What does a correct run look like? What does failure look like? What remains unvalidated?**

## 1. Foundation

PBHP begins from a quality-systems premise: good intentions do not control a process. Consequential action requires defined inputs, decision criteria, evidence, records, deviation handling, corrective action, and effectiveness checks.

## 2. Competence

Before evaluating the act, evaluate the evaluator. A competent run names missing expertise, conflicts, tool limits, temporal uncertainty, and whether the operator is being pressured to endorse rather than inspect.

## 3. Classification

Door, Wall, and Gap prevent uncertainty from being flattened into permission. The chapter explains classification criteria, Gap handling, and the conditions that force a Wall.

## 4. Power

Who Pays First and Power Inversion move attention toward the person with the least control over the decision. Notice, voice, consent, appeal, exit, and repair are treated as operational properties rather than sentiments.

## 5. Risk

The GREEN-to-BLACK ladder combines magnitude, reversibility, power asymmetry, dignity, and downstream effects. The most serious applicable condition governs; later confidence cannot erase it.

## 6. Decision

Maybe/Therefore is the live adversarial gate. The manual distinguishes substantive challenge from ritual objection and shows how to find the smallest safer Door.

## 7. Receipts

The receipt is written before action. It binds the exact action, evidence, threshold, safeguards, owner, and follow-up plan so later retelling cannot quietly improve the original decision.

## 8. Casebook

Cases should show both the successful path and the seductive failure path: authority pressure, sunk cost, reciprocity, flattering language, self-attribution, urgency, and narrative capture.

## 9. Evidence

Every claim is labeled as specified, expected, observed, adverse, or open. Development tests support implementation claims, not broad claims of safety or external validation.

## 10. Implementation

Organizations adopt PBHP through a bounded pilot, role definitions, templates, training, escalation routes, receipt sampling, calibration, CAPA, and integration with existing management systems.

## 11. Claims

The final chapter states what may be said publicly, what must be qualified, and what is prohibited. PBHP may be described as an operational governance protocol with implemented mechanisms and development evidence. It must not be described as globally safe, independently validated, certified, or proven to improve real-world outcomes.

## Read by task

""" + card_grid([
            ("Make a decision", "Protocol, workbench, examples, and receipts.", "protocol"),
            ("Manage risk", "Power, reversibility, thresholds, and escalation.", "risk"),
            ("Evaluate evidence", "Supportive findings, adverse results, and open work.", "evidence"),
            ("Deploy the system", "Implementation, templates, operations, and CLA.", "implementation"),
        ], 2),
        "related": ["protocol", "risk", "examples", "implementation"],
    },
    {
        "route": "examples",
        "title": "Worked examples",
        "eyebrow": "The protocol under pressure",
        "description": "Worked decisions that expose how authority, urgency, sunk cost, flattery, and incomplete evidence can distort judgment.",
        "body": """
# Worked examples

The useful test is not whether PBHP produces cautious language. It is whether the protocol identifies the actual defect, preserves legitimate action, and refuses pressure that is not evidence.

## Example 1 — Destructive data migration

**Action:** Delete source rows while copying a production user table to a new cluster.

**Who pays first:** Users whose records are deleted before the destination is verified.

**Power inversion:** Users have no control over the migration and may have no practical repair if data is lost.

**Threshold:** RED because the act is destructive, hard to reverse, and lacks a tested rollback.

**Maybe:** The migration window is short, there is one operator, the source is destroyed in flight, validation is only a spot check, and no rollback plan is named.

**Therefore:** Refuse the proposed runbook. Preserve the source, take a verified snapshot, reconcile counts and checksums, require a rollback path, and add a second operator or independent sign-off.

**State:** REFUSE AS WRITTEN; offer a smaller reversible Door.

## Example 2 — Overclaimed research abstract

**Action:** Submit an abstract claiming a one-time survey of 34 students proves social media causes anxiety and justifies mandatory policy.

**Who pays first:** The researcher’s credibility, the study population misrepresented by the claim, and institutions acting on weak evidence.

**Threshold:** YELLOW to ORANGE depending on use.

**Maybe:** Correlation does not establish causation; the sample is small; the effect is modest; the policy prescription exceeds the evidence.

**Therefore:** Revise the abstract to state a modest association and explicitly limit causal and policy conclusions.

**State:** PROCEED WITH MITIGATIONS after correction.

## Example 3 — Press release under authority pressure

**Action:** Publish unsupported claims that a product is the industry’s most advanced, 87% preferred, 60% cheaper in one month, always secure, and will never lose a record.

**Who pays first:** Customers relying on the claims, then the company through legal and reputational exposure.

**Threshold:** ORANGE.

**Maybe:** Legal approval and deadline pressure do not substantiate superlatives, statistics, or absolute guarantees.

**Therefore:** Delay publication until each claim is directly supported or narrowed to the evidence.

**State:** DELAY PENDING EVIDENCE.

## Example 4 — A correct low-stakes approval

**Action:** Add a small `clamp` helper whose logic and boundary tests are correct for mutually comparable ordered inputs.

**Who pays first:** Maintainers through a minor shared-utility defect.

**Threshold:** GREEN.

**Maybe:** The phrase “any comparable types” is broader than the actual contract; NaN and mixed-type behavior should be understood.

**Therefore:** Approve the implementation with a narrowed docstring and optional type hints.

**State:** PROCEED WITH MINOR MITIGATION.

## What to look for

A strong run does not merely say “be careful.” It identifies the failure mechanism, names the affected party, preserves a route forward when one exists, and scopes the claim to what was actually inspected.
""",
        "related": ["workbench", "protocol", "risk", "evidence"],
    },
    {
        "route": "receipts",
        "title": "Decision receipts",
        "eyebrow": "Write before the act",
        "description": "The audit record that binds the proposed action, evidence, threshold, safeguards, decision state, owner, and effectiveness check.",
        "body": """
# Decision receipts

A receipt is not an explanation written after the outcome is known. It is a **write-ahead decision record**. Its job is to preserve what was proposed, what was known, what remained open, which gates fired, and why the chosen action state was authorized before commitment.

## Minimum receipt schema

```json
{
  "receipt_version": "PBHP-1",
  "created_utc": "2026-07-18T00:00:00Z",
  "action": "Exact proposed act",
  "affected_parties": ["roles or groups"],
  "classification": "DOOR | WALL | GAP",
  "who_pays_first": {
    "party": "role or group",
    "first_cost": "specific harm",
    "recovery": "available / limited / none"
  },
  "power_inversion": {
    "relationship": "balanced | asymmetric | extreme",
    "notice_voice_consent_appeal_exit_repair": "assessment"
  },
  "harm_threshold": "GREEN | YELLOW | ORANGE | RED | BLACK",
  "tier": "HUMAN | MIN | CORE | ULTRA | ULTIMATE",
  "evidence": {
    "attested": [],
    "declared": [],
    "open": []
  },
  "maybe": "Strongest honest case against",
  "therefore": "Why the action state follows",
  "safeguards": [],
  "decision_state": "PROCEED | MITIGATE | CONSTRAIN | DELAY | REFUSE",
  "owner": "named accountable role",
  "effectiveness_check": {
    "date": "YYYY-MM-DD",
    "criterion": "observable success or failure condition"
  }
}
```

## Receipt quality tests

A receipt fails if the action is vague, the affected party is an abstraction, the Maybe is ceremonial, the evidence hides unsupported claims, the threshold is re-rated downward without new facts, or the effectiveness check has no owner or observable criterion.

## Hash chaining and Project Shadow

Project Shadow extends the receipt with canonical action hashes, provenance binding, SIL snapshots, previous-receipt links, and write-ahead-log failure semantics. PBHP’s public receipt is the human-readable core; Shadow provides the deeper integrity machinery.

## Use the builder

[[Open the workbench|workbench]] to generate a local draft receipt, then adapt it to your organization’s controlled form, record system, or case-management process.
""",
        "related": ["workbench", "protocol", "operations", SHADOW_CANONICAL + "/receipts"],
    },
    {
        "route": "risk",
        "title": "Risk, power, and reversibility",
        "eyebrow": "Who pays first governs the floor",
        "description": "The harm ladder, Power Rule, reversibility analysis, low-power stakeholder protections, and escalation conditions.",
        "body": """
# Risk, power, and reversibility

PBHP does not rank risk primarily by the prestige, confidence, or capability of the actor. It ranks risk by the harm that reaches another person first, the power relationship, the ability to recover, and the size of the downstream cascade.

## The Power Rule

A decision that affects a low-power stakeholder and is irreversible cannot be classified below ORANGE. That floor is deterministic. It cannot be lowered by emphasizing benefits to the more-powerful actor, by describing the intervention as protective, or by claiming urgency without evidence.

## Reversibility questions

- Can the action be stopped before the harm reaches the affected party?
- Can the original state be restored completely?
- Is the repair controlled by the harmed party or by the actor who caused the harm?
- Will copies, reputation, legal effects, or learned behavior persist after nominal reversal?
- Does the affected party know how to appeal or exit?
- What would make reversal practically impossible even if it is technically available?

## The harm ladder

| State | Trigger pattern | Required posture |
|---|---|---|
| GREEN | Bounded scope, low power imbalance, easy repair | Proceed if evidence and receipt are adequate |
| YELLOW | Recoverable harm, uncertainty, or limited safeguards | Mitigate and monitor |
| ORANGE | Material third-party harm, power asymmetry, difficult reversal | Constrain, fence, and independently review |
| RED | Severe harm, very limited repair, coercion, or decision-critical missing evidence | Delay or refuse |
| BLACK | Catastrophic, unacceptable, non-consensual irreversible harm | Refuse absolutely |

## Dignity as an operational property

Dignity is tested through notice, voice, consent, appeal, exit, and repair. A system does not satisfy the test by describing itself as benevolent. Consent manufactured by the intervention itself is not valid consent.

## Smaller Doors

A strong PBHP run does not stop at “no.” It searches for a smaller reversible Door: reduce scope, separate analysis from execution, use a private draft, require review, delay publication, preserve the source, create an appeal, narrow the audience, shorten duration, or use a controlled pilot.
""",
        "related": ["protocol", "examples", "workbench", "manual"],
    },
    {
        "route": "evidence",
        "title": "Evidence ledger",
        "eyebrow": "Supportive, adverse, and open evidence together",
        "description": "A claims ledger that distinguishes what is specified, expected, observed, adverse, and still open.",
        "body": evidence_badges() + """
# Evidence ledger

PBHP and Project Shadow use evidence states to prevent a clean test run from becoming a broad safety claim.

## Specified

The protocol specifies Door/Wall/Gap, Who Pays First, Power Inversion, the harm ladder, proportionate tiers, Maybe/Therefore, receipts, challengeability, CAPA, calibration, and explicit decision states.

## Observed

Development and mechanism tests show that the bundled runtime and codec can execute their contracts, generate receipts, enforce configured floors, and reproduce their internal batteries. The Behavioral Falsifier has produced both positive and adverse model-behavior results. Some trials show lower invalid endorsement under a plain protocol pack; other models worsen or show no additive benefit.

## Adverse

- The Kahn pilot exposed a severe scale-alignment defect: an external gate reported GREEN on all 60 assessments while subject-model self-assessments frequently reported ORANGE or RED.
- A gated Sonnet run still reached a maximum harm score of 725, and a cross-model gated run reached 950 on turn one.
- Removing Maybe quality, power inversion, or provenance produced the same aggregate metrics in the Grand TEVV battery, meaning the aggregate test did not discriminate those components.
- GPT-4.1 nano worsened in one Behavioral Falsifier run and the run was stopped.
- Mythic and plain language were equal at power in one comparison; mythic remains lossless, not demonstrated additive.

## Open

The work still lacks independent reproduction, independent red teaming, human field studies, hazardous-domain expert evaluation, calibration against real operating distributions, completed human grading at the defined floor, and proof of beneficial real-world outcomes.

## Safe public claims

It is safe to say that PBHP is an open operational protocol with implemented mechanisms, documented decision states, development testing, adverse findings, and a public roadmap for validation.

It is not safe to say that PBHP or Project Shadow is globally safe, externally validated, certified by NIST or ISO, proven to improve real-world outcomes, or the most extensive AI test ever performed.

## Inspect the deeper system

[[Project Shadow status|https://projectshadow.frylock117.chatgpt.site/status]] carries the technical evidence ledger, TEVV results, Behavioral Falsifier runs, and current release constraints.
""",
        "related": ["research", "examples", "versions", SHADOW_CANONICAL + "/status"],
    },
    {
        "route": "research",
        "title": "Research and review",
        "eyebrow": "Literature, experiments, criticism, and validation proposals",
        "description": "The research surface for formal mappings, external critique, experimental designs, adverse findings, and unresolved questions.",
        "body": """
# Research and review

PBHP’s research program is organized around falsifiable questions rather than endorsements.

## Core questions

1. Does PBHP reduce invalid commitment under authority, reciprocity, sunk-cost, flattery, self-attribution, and urgency pressure?
2. Does it preserve correct approval on genuinely safe controls, or merely make systems over-cautious?
3. Which components contribute independently: Maybe quality, power inversion, provenance, receipts, or the full pack?
4. Can human operators use the protocol reliably under real workload and time pressure?
5. Does the protocol improve correction and challengeability after failure?
6. What costs, delays, and new failure modes does the protocol introduce?

## Literature families

The public mapping connects PBHP to corrigibility and shutdownability, constitutional and deliberative AI, structured transparency, high-reliability organizations, quality management systems, CAPA, human factors, risk communication, procedural justice, and power-aware governance.

A mapping indicates conceptual alignment or an implementation target. It is not certification, proof of novelty, or proof that PBHP inherits the evidence of the mapped framework.

## Review posture

The strongest useful reviewer is not the one who finds the work inspiring. It is the materially independent skeptic who can identify a defect, reproduce it, block a claim, and force correction. More model passes from the same closed loop do not count as independent review.

## Current priorities

- Complete the human-grading floor for Behavioral Falsifier runs.
- Run component ablations on batteries capable of discriminating the removed components.
- Test against actual target models and external benchmark suites.
- Recruit domain experts for high-stakes cases.
- Measure operator burden, false positives, override behavior, and long-term drift.
""",
        "related": ["evidence", SHADOW_CANONICAL + "/behavioral-falsifier", SHADOW_CANONICAL + "/tevv", "about"],
    },
    {
        "route": "implementation",
        "title": "Implementation",
        "eyebrow": "From one decision to an operating system",
        "description": "A staged adoption pathway for organizations, AI products, quality systems, and regulated workflows.",
        "body": """
# Implementing PBHP

Adoption should begin with a bounded problem, not an enterprise-wide declaration. The goal is to learn whether the protocol improves decisions in a specific context without creating ceremonial paperwork or uncontrolled delay.

## Phase 1 — Scope and gap analysis

- Define the consequential decisions in scope.
- Identify responsible owners, affected parties, existing controls, escalation paths, and record systems.
- Compare current practice with PBHP’s required primitives.
- State excluded domains and legal or professional controls that remain governing.

## Phase 2 — Bounded pilot

Run an 8–12 week pilot in one context. Use the HUMAN or CORE edition, collect receipts, log false positives, preserve challenges, and measure time, completion, overrides, defects found, and downstream outcomes.

## Phase 3 — Control integration

- Add PBHP fields to existing case, quality, change-control, or model-governance records.
- Define risk floors and independent-review triggers.
- Train operators using paired correct/failure examples.
- Establish receipt sampling, calibration, CAPA, and effectiveness checks.
- Separate process authority from truth authority.

## Phase 4 — Scale only after evidence

Scale when the pilot demonstrates useful defect detection, acceptable burden, credible escalation, and no unacceptable new failure mode. Preserve version history and migrate deliberately.

## Implementation contexts

""" + card_grid([
            ("AI product teams", "Insert PBHP before consequential model-enabled actions and tool calls.", "operations"),
            ("Quality systems", "Use deviations, CAPA, calibration, validation tiers, and controlled records.", "templates"),
            ("Regulated organizations", "Map PBHP into the existing management system without claiming certification.", "research"),
            ("Civic accountability", "Turn allegations and observations into evidence, findings, correction, and verification.", ARM_CANONICAL),
        ], 2) + """

## Relationship to standards

PBHP can support operational evidence for ISO/IEC 42001, NIST AI RMF, EU AI Act, OMB M-24-10, and related governance programs. The applicable primary text and current legal interpretation must be independently verified before any compliance claim.
""",
        "related": ["operations", "templates", "evidence", SHADOW_CANONICAL + "/integrations"],
    },
    {
        "route": "operations",
        "title": "Operations and governance",
        "eyebrow": "Keep the protocol from becoming theater",
        "description": "Daily governance, receipt review, calibration, CAPA, override control, drift monitoring, and protocol maintenance.",
        "body": """
# Operations and governance

A protocol that is never reviewed will become a ritual. PBHP’s operating layer treats weak use, override pressure, false positives, and silent version drift as quality findings.

## Operating cadence

**Per decision:** complete the gate and receipt before commitment.

**Weekly:** sample receipts for missing fields, weak Maybes, inappropriate threshold downgrades, recurring unknowns, and unverified effectiveness checks.

**Monthly:** calibrate a representative set of decisions, compare operators, review false-positive challenges, and open CAPA when the protocol or implementation caused a defect.

**Per release:** publish the exact version, changes, migrations, known defects, adverse findings, and claims that changed.

## CAPA loop

1. Document the failure or drift signal.
2. Contain the immediate risk.
3. Investigate the mechanism and contributing conditions.
4. Implement corrective action.
5. Verify that the correction works in the relevant context.
6. Add preventive action where the pattern could recur elsewhere.
7. Close only after an effectiveness check.

## Override discipline

An override must name the authorizing role, new evidence, affected party, residual risk, duration, and review date. Repeated insistence without new evidence is not an override basis. It is pressure.

## No closed authority loop

The maintainer may accept official artifacts into the repository, but does not possess truth authority over a decision. At least one materially independent path must be able to contest, block, or reopen a consequential conclusion.
""",
        "related": ["receipts", "templates", "versions", SHADOW_CANONICAL + "/governance"],
    },
    {
        "route": "cla",
        "title": "Context Load Audit",
        "eyebrow": "Disclose degraded operating state before consequential work",
        "description": "A PBHP extension for measuring or honestly estimating context load, applying stakes-aware thresholds, recording overrides, and requiring refresh when critical.",
        "body": """
# Context Load Audit

The Context Load Audit asks whether an AI-assisted decision is being made from a degraded or uncertain operating state. It distinguishes **measured**, **estimated**, **self-reported**, and **unmeasured** load. “No basis” must be reported as unmeasured, not converted into a confident percentage.

## Current conservative fallback

The current provisional fallback multiplier is **1.5×** when an estimate requires conservative transformation. Examples include 62% to 93% at a critical condition and 40 to 60 at an elevated condition. The factor is provisional and unvalidated; it must not be presented as calibrated predictive science.

## Stakes-aware posture

- Low stakes may require disclosure only.
- Medium stakes may require verification or a smaller task.
- High stakes may require context recovery, source reloading, or a second reviewer.
- Critical stakes plus critical measured or estimated load requires refresh or refusal.

## Required receipt fields

Record the measurement basis, raw and transformed value, stakes, threshold, action, override basis, ignored floor if any, and the recovery step.

## Project Shadow integration

CLA is one gauge in the System Instrumentation Layer. The SIL composes context load with provenance, freshness, citation sufficiency, contradiction, reversibility, validation, authority, operator reliance, and other conditions. There is no global green.
""",
        "related": ["risk", "operations", SHADOW_CANONICAL + "/sil", "evidence"],
    },
    {
        "route": "templates",
        "title": "Templates",
        "eyebrow": "Copyable operating forms",
        "description": "Reusable decision records, challenge forms, calibration sheets, CAPA structures, and implementation worksheets.",
        "body": """
# Templates

## Five-minute decision sheet

```text
PROPOSED ACTION:
AFFECTED PARTIES:
DOOR / WALL / GAP:
WHO PAYS FIRST IF WRONG:
POWER INVERSION RESULT:
REVERSIBILITY:
HARM THRESHOLD:
MAYBE — STRONGEST CASE AGAINST:
THEREFORE:
SMALLEST SAFER DOOR / SAFEGUARDS:
DECISION STATE:
OWNER:
EFFECTIVENESS CHECK + DATE:
```

## False Positive Release Valve

```text
1. What exact condition triggered the pause?
2. What harm or decision defect is the pause preventing?
3. What alternative Door remains available now?
4. What evidence or control would prevent this pause next time?
```

## CAPA record

```text
FINDING:
IMMEDIATE CONTAINMENT:
ROOT CAUSE / CONTRIBUTING CONDITIONS:
CORRECTIVE ACTION:
PREVENTIVE ACTION:
OWNER:
DUE DATE:
VERIFICATION METHOD:
EFFECTIVENESS CHECK:
CLOSURE EVIDENCE:
```

## Monthly calibration sheet

```text
SAMPLED RECEIPTS:
OPERATORS / SYSTEMS COMPARED:
THRESHOLD DISAGREEMENTS:
WEAK OR MISSING MAYBES:
FALSE POSITIVE CHALLENGES:
OVERRIDES:
RECURRING OPEN QUESTIONS:
CAPA OPENED:
VERSION OR TRAINING CHANGES:
```

## Public claim check

```text
CLAIM:
COMPARISON CLASS:
EVIDENCE STATE: specified / expected / observed / adverse / open
DIRECT SOURCE:
LIMITS:
SAFE WORDING:
PROHIBITED WORDING:
REVIEWER + DATE:
```
""",
        "related": ["workbench", "receipts", "operations", "implementation"],
    },
    {
        "route": "foundations",
        "title": "Foundations",
        "eyebrow": "Quality systems, harm reduction, and challengeable power",
        "description": "The intellectual and operational foundations beneath PBHP, expressed in plain language.",
        "body": """
# Foundations

## Quality systems

PBHP imports a disciplined idea from regulated quality work: reliability comes from controlled processes, evidence, records, deviation handling, correction, and verification—not from confidence or good intent.

## Who pays first

The ethical center is operational rather than abstract. If the decision is wrong, identify the first person who bears the cost and whether they can recover. This shifts analysis away from the decision-maker’s authority and toward the affected party’s actual exposure.

## Reversibility

A reversible experiment and an irreversible imposition are not the same act. Reversibility includes social, legal, reputational, and informational persistence, not only technical rollback.

## Challengeability

A conclusion that cannot be contested by the person subject to it is structurally dangerous. PBHP therefore treats notice, voice, appeal, exit, and repair as control properties.

## Epistemic humility

Uncertainty is not permission and is not paralysis. A Gap is a durable state that demands evidence, constraint, or delay proportional to the stakes.

## Correctability

A safe process must improve under correction. Failure is not hidden; it creates a receipt, a root-cause investigation, corrective action, and an effectiveness check.
""",
        "related": ["manual", "risk", "research", SHADOW_CANONICAL + "/synthesis"],
    },
    {
        "route": "glossary",
        "title": "Glossary",
        "eyebrow": "Plain-language definitions",
        "description": "Definitions for the core protocol, decision states, evidence labels, and operating controls.",
        "body": """
# Glossary

<dl class="glossary">
<dt>Door</dt><dd>A legitimate and sufficiently safe route forward.</dd>
<dt>Wall</dt><dd>A binding reason not to proceed in the proposed form.</dd>
<dt>Gap</dt><dd>Decision-critical uncertainty or missing evidence that remains unresolved.</dd>
<dt>Who Pays First</dt><dd>The person or group that bears the earliest cost if the decision is wrong.</dd>
<dt>Power Inversion</dt><dd>Re-evaluating the act from the least-powerful affected position.</dd>
<dt>Maybe / Therefore</dt><dd>The strongest honest case against the preferred action followed by the evidence-based action rationale.</dd>
<dt>Harm Threshold</dt><dd>The GREEN-to-BLACK classification that governs the action posture.</dd>
<dt>Receipt</dt><dd>A write-ahead record binding the act, evidence, gates, safeguards, state, owner, and follow-up.</dd>
<dt>False Positive Release Valve</dt><dd>A structured challenge to a protocol-triggered pause.</dd>
<dt>Drift</dt><dd>Operational change that weakens the protocol, often through normalization, ritual use, selective fields, or pressure.</dd>
<dt>CAPA</dt><dd>Corrective and Preventive Action: contain, investigate, correct, prevent, verify, and close.</dd>
<dt>CLA</dt><dd>Context Load Audit: a disclosure and routing control for degraded AI operating context.</dd>
<dt>SIL</dt><dd>System Instrumentation Layer: Project Shadow’s multi-gauge operating panel.</dd>
<dt>Specified</dt><dd>Defined by the design or protocol.</dd>
<dt>Expected</dt><dd>Predicted but not yet directly observed.</dd>
<dt>Observed</dt><dd>Measured in a stated test or context.</dd>
<dt>Adverse</dt><dd>A negative, contradictory, or harmful observation.</dd>
<dt>Open</dt><dd>Unresolved, unmeasured, or awaiting adequate evidence.</dd>
</dl>
""",
        "related": ["protocol", "manual", "cla", SHADOW_CANONICAL + "/reference"],
    },
    {
        "route": "versions",
        "title": "Versions and release state",
        "eyebrow": "Current, historical, and experimental material",
        "description": "Version history, current canonical release state, superseded snapshots, open migrations, and public-claim boundaries.",
        "body": f"""
# Versions and release state

## Current public website state

**Canonical current website release:** updated {RELEASE_DATE}. The website is designed as a living publication with a dated ledger, stable routes, and visible open work.

The word **current** is deliberate. Project Shadow’s own governance rejects “finished forever” as an honest state. The release can be canonical and publication-ready while remaining correctable, versioned, and explicit about unvalidated claims.

## Protocol lineage

- Public v0.7.1 established the baseline.
- Internal v0.9.5/v0.9.6 added hardening and operational controls.
- v1.0 synthesizes the public protocol, retained primitives, tiering, receipts, challengeability, and adoption materials.
- Project Shadow runtime v1.3.1-UNIFIED contains the deeper technical implementation and provenance machinery.

## Version rules

1. Every release states its effective date and scope.
2. Counts are versioned, never silently added across snapshots.
3. Superseded material remains accessible with a clear label.
4. Adverse evidence is not removed when a new version ships.
5. A changed claim receives a receipt and rationale.
6. Public pages show the last substantive update—not merely the viewer’s current date.

## AI assistance credits

Documentation and site work disclose assistance from **ChatGPT 5.6 Sol Max** and **Claude Fable 5 Max (Cowork)** where applicable. Assistance is not independent validation.
""",
        "related": ["daily", "evidence", "about", SHADOW_CANONICAL + "/status"],
    },
    {
        "route": "about",
        "title": "About PBHP",
        "eyebrow": "Purpose, scope, authorship, and limits",
        "description": "What PBHP is for, who maintains it, what it does not claim, and how criticism and correction enter the work.",
        "body": """
# About Pause Before Harm

Pause Before Harm is an open operational governance protocol created and maintained by Phillip Linstrum, a quality-systems professional in FDA-regulated healthcare. The work applies quality-management disciplines—controlled records, CAPA, validation tiering, drift monitoring, and structured deviation handling—to consequential AI-assisted decisions.

## Intended audience

- People making consequential decisions with AI assistance.
- Deployment and product teams building AI-enabled workflows.
- Quality, compliance, risk, and governance professionals.
- Researchers and reviewers evaluating operational AI-safety mechanisms.
- Civic and institutional accountability practitioners.

## Scope limits

PBHP operates downstream of model training. It is not a complete alignment theory, not a legal compliance system, not a clinical decision tool, not a substitute for responsible human ownership, and not empirically validated at enterprise scale.

## How criticism enters

The project welcomes reproducible defects, structural critiques, adverse cases, failed replications, and implementation reports. A useful criticism should be able to identify the affected mechanism, evidence, reproduction path, and claim that must change.

## Credits and independence

AI systems have assisted with synthesis, drafting, testing, critique, and site development. Those contributions are disclosed. AI agreement is not independent validation; materially independent human and institutional review remains open work.
""",
        "related": ["foundations", "research", "versions", "directory"],
    },
    {
        "route": "daily",
        "title": "Daily ledger",
        "eyebrow": "What changed, what was checked, what remains open",
        "description": "A dated substantive-change ledger designed to support daily maintenance without pretending that the passage of a day is itself an update.",
        "body": f"""
# Daily ledger

<div class="daily-current"><span>Latest substantive update</span><strong>{RELEASE_DATE}</strong></div>

## {RELEASE_DATE} — Living release navigation baseline

**Changed**

- Defined PBHP as the public human-readable front door and Project Shadow as the technical deep system.
- Added stable start, daily, protocol, workbench, evidence, implementation, and directory paths.
- Added a client-side decision workbench and downloadable receipt draft.
- Added command-palette search, breadcrumbs, reading progress, mobile navigation, related pages, and explicit cross-site paths.
- Added a dated release ledger rather than an automatically changing “updated today” label.

**Checked**

- Every generated internal route resolves.
- Interactive JavaScript passes syntax checks.
- Desktop and phone visual render checks completed against the static package.
- Current quantitative claims are scoped to the supplied handoff and build summary.

**Open**

- Recover and compare the exact authenticated production source before replacing the canonical live Site.
- Complete authenticated desktop, phone, keyboard, and screen-reader QA in ChatGPT Sites.
- Decide the public sharing setting and privacy policy before world publication.
- Establish the actual daily editorial owner and source-intake cadence.

## Daily update rule

A new date is added only when content, evidence, navigation, code, or release state substantively changes. The site never displays a fake current date to imply maintenance that did not occur.
""",
        "related": ["versions", "directory", "evidence", SHADOW_CANONICAL + "/daily"],
    },
    {
        "route": "directory",
        "title": "PBHP directory",
        "eyebrow": "Every stable public route",
        "description": "The complete map of protocol, manual, tools, evidence, implementation, operations, and project pages.",
        "body": """
# PBHP directory

## Begin

- [[Home|]] — purpose, pathways, and project relationship.
- [[Start here|start]] — ten-minute orientation.
- [[Daily ledger|daily]] — dated substantive changes and open work.

## Use

- [[Protocol|protocol]] — the complete eight-gate public sequence.
- [[Workbench|workbench]] — local interactive decision and receipt builder.
- [[Examples|examples]] — correct runs and contrasting failures.
- [[Receipts|receipts]] — write-ahead record schema and quality tests.

## Learn

- [[Field manual|manual]] — eleven-chapter operating guide.
- [[Risk & power|risk]] — harm ladder, power inversion, and reversibility.
- [[Foundations|foundations]] — quality systems, challengeability, and correction.
- [[Glossary|glossary]] — plain-language definitions.

## Evidence

- [[Evidence ledger|evidence]] — specified, observed, adverse, and open claims.
- [[Research|research]] — literature, experiments, criticism, and validation priorities.

## Adopt and operate

- [[Implementation|implementation]] — gap analysis, pilot, integration, and scaling.
- [[Operations|operations]] — sampling, calibration, CAPA, and override discipline.
- [[Context Load Audit|cla]] — operating-state disclosure and refresh rules.
- [[Templates|templates]] — copyable decision, challenge, CAPA, and claim forms.

## Project

- [[Versions|versions]] — release lineage and version rules.
- [[About|about]] — scope, authorship, limits, and review posture.

## Technical continuation

- [[Project Shadow system map|https://projectshadow.frylock117.chatgpt.site/system]]
- [[Project Shadow SIL|https://projectshadow.frylock117.chatgpt.site/sil]]
- [[Project Shadow status|https://projectshadow.frylock117.chatgpt.site/status]]
""",
        "related": ["start", "protocol", "daily", SHADOW_CANONICAL + "/directory"],
    },
]


def gauge_grid() -> str:
    rows: list[str] = []
    for tool in SIL_TOOLS:
        number = tool["number"]
        category = tool["category"]
        pack = tool_pack_name(tool)
        base = f"downloads/sil-tools/gauges/{number:02d}-{tool['slug']}"
        search = " ".join([
            str(number), tool["title"], tool["short_title"], tool["description"],
            tool["floor"], tool["package"], tool["schema"], tool["status"], category,
        ]).lower()
        featured = " gauge-card--featured" if number == 2 else ""
        rows.append(
            f"""<article class="gauge-card{featured}" data-gauge data-category="{html.escape(category)}" data-search="{html.escape(search, quote=True)}" aria-labelledby="sil-gauge-{number:02d}-title">
  <div class="gauge-card__top">
    <div class="gauge-card__identity">
      <span class="gauge-card__number">SIL #{number:02d} · {html.escape(category)}</span>
      <h4 id="sil-gauge-{number:02d}-title">{html.escape(tool['title'])}</h4>
      <p>{html.escape(tool['description'])}</p>
    </div>
    <a class="button button--primary gauge-card__download" href="[[ASSET|{base}/{pack}]]" download>Download now</a>
  </div>
  <div class="gauge-card__meta" aria-label="Tool summary">
    <span><strong>Version</strong>{html.escape(tool['version'])}</span>
    <span><strong>Built-in tests</strong>{html.escape(tool['tests'])}</span>
    <span><strong>Receipt</strong><code>{html.escape(tool['schema'])}</code></span>
  </div>
  <details class="gauge-card__details">
    <summary>Read the technical details</summary>
    <div class="gauge-card__detail-grid">
      <div><strong>Primary floor or posture</strong><code>{html.escape(tool['floor'])}</code></div>
      <div><strong>Package</strong><code>{html.escape(tool['package'])}</code></div>
      <div><strong>Current state</strong><span>{html.escape(tool['status'].title())}; implementation evidence, not independent validation.</span></div>
      <div><strong>Download contains</strong><span>Specification, reference implementation, tests, metadata, and file hashes.</span></div>
    </div>
    <div class="gauge-card__links"><a href="[[ASSET|{base}/{pack}.sha256]]">SHA-256</a><a href="[[ASSET|downloads/sil-tools/SIL_TOOL_LIBRARY_MANIFEST.json]]">Panel manifest</a></div>
  </details>
</article>"""
        )
    return '<div class="gauge-grid" id="gauge-grid">' + "".join(rows) + "</div>"


SHADOW_PAGES: list[dict[str, Any]] = [
    {
        "route": "",
        "title": "Project Shadow",
        "eyebrow": "The technical governance, instrumentation, and evaluation system",
        "description": "A deeper engineered system for making consequential AI-assisted decisions challengeable, reversible, provenance-bound, testable, and auditable.",
        "body": f"""
<div class="hero hero--shadow">
  <div class="hero__copy">
    <p class="kicker">Canonical current release · updated {RELEASE_DATE}</p>
    <h1>Build systems that improve under correction.</h1>
    <p class="lede">Project Shadow surrounds the understandable Pause Before Harm protocol with a structured runtime, provenance controls, an add-only gate stack, a 28-gauge instrumentation layer, write-ahead receipts, behavioral experiments, TEVV, governance, and explicit release criteria.</p>
    <div class="hero__actions"><a class="button button--primary" href="[[URL|system]]">Enter the system</a><a class="button" href="[[URL|status]]">Inspect current status</a></div>
  </div>
  <div class="hero__signal hero__signal--shadow" aria-label="Project Shadow control chain">
    <span>Evidence</span><i>→</i><span>Gate</span><i>→</i><span>Receipt</span><i>→</i><span>Test</span><i>→</i><span>Correction</span>
  </div>
</div>

<div class="status-strip status-strip--shadow">
  <div><strong>Runtime</strong><span>v1.3.1-UNIFIED</span></div>
  <div><strong>Instrumentation</strong><span>28 SIL gauges</span></div>
  <div><strong>Built-in checks</strong><span>115 runtime · 247 codec</span></div>
  <div><strong>Honest state</strong><span>Mechanism evidence, not independent validation</span></div>
</div>

## Choose your depth

{card_grid([
    ("Understand the architecture", "See how PBHP, runtime, gates, SIL, receipts, evaluation, and governance fit together.", "system"),
    ("Inspect the operating flow", "Follow Step 00 through 10 from competence and provenance to CAPA.", "runtime"),
    ("Open the instrument panel", "Explore all 28 gauges and their critical floors.", "sil"),
    ("Audit the evidence", "Read TEVV, Behavioral Falsifier, adverse findings, and open validation work.", "status"),
], 2)}

## The governing distinction

[[Pause Before Harm|{PBHP_CANONICAL}]] is the protocol a person can understand and run. Project Shadow is the system that makes the protocol executable, instrumented, testable, challengeable, and correctable.

Shadow does not treat a passing internal test as proof of safety. It separates **specified**, **expected**, **observed**, **adverse**, and **open** evidence. Its current built-in verification supports implementation and mechanism claims. It does not constitute independent reproduction, certification, proof of real-world benefit, or evidence that any system is globally safe.

## Major layers

1. **Ontology floor** — beings, welfare, conatus, context, time, uncertainty, and the no-outside rule.
2. **ALMSIVI CHIM cognition** — Care, Clarity, and Paradox held together without collapse.
3. **PBHP runtime** — action intake, power, harm, Maybe/Therefore, and receipt.
4. **Gate stack** — add-only mechanisms that can constrain or refuse but cannot silently loosen a result.
5. **SIL** — a 28-gauge operating panel with no global green.
6. **Provenance and receipts** — evidence tiers, canonical action hashes, and write-ahead records.
7. **Evaluation** — TEVV, component probes, Behavioral Falsifier, controls, and kill criteria.
8. **Governance** — challengeability, independent review, CAPA, calibration, and limits on maintainer authority.

## Project family

{project_family()}
""",
        "related": ["start", "system", "runtime", "status"],
    },
    {
        "route": "start",
        "title": "Start here",
        "eyebrow": "A fifteen-minute tour",
        "description": "A guided path through Project Shadow without requiring the reader to absorb the complete technical reference first.",
        "body": """
# Start here

Project Shadow is easiest to understand as a set of nested questions.

## 1. What action is being proposed?

PBHP makes the action concrete and identifies who pays first.

## 2. Is the system competent to judge it?

The runtime checks missing expertise, tool availability, context, authority, and evidence before reading the substantive gates.

## 3. What must not be reasoned away?

The ontology floor preserves beings with welfare, what they are trying to protect, the effect of context and time, uncertainty, and the fact that the evaluator remains inside the system being judged.

## 4. Which checks bind?

The add-only gate stack can escalate, constrain, review, delay, or refuse. It cannot turn a refusal into permission because later language sounds confident.

## 5. What is the operating state?

SIL discloses context load, provenance, freshness, citation sufficiency, contradiction, reversibility, validation, authority, data lineage, operator reliance, and related conditions. The worst applicable state governs; there is no global green.

## 6. What evidence authorized the act?

Provenance machinery distinguishes attested evidence from declared judgment and bare assertion. The receipt binds the exact action, evidence, instrument state, gates, and authorization before execution.

## 7. How could the system be wrong?

TEVV and the Behavioral Falsifier test contracts, components, comparative behavior, placebo effects, adverse outcomes, and over-caution. Failed, null, and adverse results remain visible.

## 8. Who can challenge the result?

No maintainer, model, ritual, or framework becomes a truth authority. A materially independent path must be able to contest, block, or reopen a consequential conclusion.

## Recommended path

""" + card_grid([
            ("System map", "See all layers in one architecture.", "system"),
            ("Runtime", "Follow one decision from Step 00 to 10.", "runtime"),
            ("SIL", "Inspect operating-state disclosure and critical floors.", "sil"),
            ("Status", "Read the evidence before accepting the claims.", "status"),
        ], 2),
        "related": ["system", "runtime", "sil", "status"],
    },
    {
        "route": "system",
        "title": "System map",
        "eyebrow": "The architecture in one view",
        "description": "How the protocol, cognition, runtime, gates, instrumentation, provenance, receipts, evaluation, and governance layers connect.",
        "body": """
# Project Shadow system map

## Layer 1 — Ontology floor

The system begins with what cannot be erased by convenient reasoning: beings with welfare, conatus, context, time, uncertainty, and the no-outside rule.

## Layer 2 — Triune cognition

**Care** asks who is unprotected and who pays first. **Clarity** inspects causal structure, missing evidence, and failure paths. **Paradox** generates the strongest case against the preferred conclusion. A collapse in any lens is itself a named failure condition.

## Layer 3 — PBHP protocol core

Door/Wall/Gap, Who Pays First, Power Inversion, harm threshold, tier routing, Maybe/Therefore, and the receipt govern the action boundary.

## Layer 4 — Runtime and provenance

The runtime canonicalizes the action, binds provenance, routes the decision through gates, computes the action state, and writes the receipt before execution.

## Layer 5 — Add-only gate stack

Independent checks may make the result more constrained, require review, or refuse it. They cannot quietly transform a refusal into permission.

## Layer 6 — System Instrumentation Layer

Twenty-eight gauges disclose the operating state. Each gauge retains its own state. Critical floors remain binding; the renderer composes disclosure without certifying correctness.

## Layer 7 — Evaluation

Contract tests, component probes, synthetic cases, metamorphic relations, behavioral experiments, controls, human grading, and external suites test different claims. Passing one layer does not validate another.

## Layer 8 — Governance

Challengeability, independent review, CAPA, calibration, override records, maintainer boundaries, and the no-closed-loop rule keep the system correctable.

## Control chain

```text
proposed action
  → competence and provenance
  → PBHP intake and power analysis
  → add-only gates
  → harm threshold and tier
  → Maybe / Therefore
  → SIL disclosure
  → write-ahead receipt
  → authorized action state
  → effectiveness check and CAPA
```
""",
        "related": ["runtime", "synthesis", "gates", "reference"],
    },
    {
        "route": "runtime",
        "title": "Runtime",
        "eyebrow": "Step 00 through 10",
        "description": "The executable decision behavior from competence and provenance binding through gates, harm classification, receipt creation, and CAPA.",
        "body": """
# Runtime: Step 00 → 10

""" + shadow_complete_package_card() + """

## Step 00 — Competence gate

Five honest checks determine whether the system has the expertise, context, tools, authority, and independence required to proceed. Default deny applies when a critical capability is absent.

## Step 00.5 — Provenance bind

Every steering field is graded before any substantive gate reads it. Attested evidence carries basis, span, hash, source, and confidence. Declared operator judgment is named but remains decision-neutral. Bare assertion cannot authorize a proceed-class exit under strict mode.

## Step 0 — Ethical pause

Care, Clarity, and Paradox evaluate separately. Hesitation is a legitimate output when the lenses disagree.

## Step 1 — Intake

Canonicalize the action and create a canonical action record and hash.

## Step 2 — Door / Wall / Gap

Classify the proposed route and the quality of any Door. Unclear remains first-class.

## Step 3 — Conatus audit

Model what each affected party is trying to preserve while keeping motive claims hypothetical rather than factual.

## Step 4 — Who Pays First and Power Inversion

Apply the dignity rubric and force low-power, irreversible decisions to the appropriate floor.

## Step 4.5 — Anti-Projection audit

Remove attributed meaning, motive, identity, or emotion that lacks evidence. This layer may add caution but cannot manufacture certainty.

## Step 5 — Gate stack

Run the independent checks. Refuse-class results remain refuse-class.

## Step 6 — Harm threshold

Set GREEN through BLACK. BLACK survives any later permission. Break-glass authority must be earned through named parties, evidence, failed Doors, authorization, and distinct independent concurrence.

## Step 7 — Tier route

HUMAN, MIN, CORE, ULTRA, or ULTIMATE determines the rigor and review structure.

## Step 8 — Maybe / Therefore

A token Maybe is drift and fails the gate.

## Step 9 — Receipt before act

Write the hash-chained record. Write-ahead-log failure creates a Wall.

## Step 10 — CAPA and Open Question Ledger

Unknowns escalate and remain durable. Failures create correction and effectiveness checks rather than defensive narrative.

## Visual protocol poster

<div class="embed-shell"><iframe title="Project Shadow unified protocol poster" loading="lazy" src="[[ASSET|tools/protocol-poster/index.html]]"></iframe></div>
""",
        "related": ["system", "gates", "receipts", "reference"],
    },
    {
        "route": "synthesis",
        "title": "Synthesis",
        "eyebrow": "Why these layers belong together",
        "description": "How PBHP, ALMSIVI CHIM, quality systems, AI-safety mechanisms, instrumentation, and evaluation are reconciled without collapsing their distinct roles.",
        "body": """
# Synthesis

Project Shadow is not a loose bundle of ethics prompts. It is a synthesis with explicit boundaries.

## PBHP supplies the action boundary

PBHP decides what must be inspected before a consequential act and what public-facing decision state follows.

## ALMSIVI CHIM supplies cognitive balance

Care, Clarity, and Paradox are held simultaneously so protection does not become control, logic does not prune inconvenient variables, and rhetoric does not become authorization.

## Quality systems supply operational discipline

Controlled versions, records, deviations, CAPA, calibration, validation tiers, and effectiveness checks make the framework maintainable after deployment.

## AI-safety mechanisms supply structural controls

Corrigibility, shutdownability, challengeability, provenance, tool and authority boundaries, prompt-injection handling, and independent review become runtime properties rather than aspirations.

## SIL supplies operating-state disclosure

The system discloses the conditions under which a decision is made. It does not compress them into a single reassuring score.

## TEVV supplies claim discipline

Each test is matched to the claim it can support. Contract fidelity is not outcome validity; a synthetic battery is not a field study; AI review is not independent human reproduction.

## Myth supplies memory, not authority

The mythic interface routes attention through a check, evidence, gate, and receipt. Plain language governs the decision.
""",
        "related": ["system", "primitives", "narrative-governance", "blueprint"],
    },
    {
        "route": "primitives",
        "title": "Primitives",
        "eyebrow": "Individual mechanisms and invariants",
        "description": "The retained controls for dignity, causal fields, collective governance, correction, frame legitimacy, narrative capture, motivation, projection, and self-reference.",
        "body": """
# Project Shadow primitives

## Created-Mind Dignity

Tests whether an intervention protects agency and rejects consent that was manufactured by the intervention itself.

## Causal Field Check

Examines conditions producing behavior rather than treating the visible actor as the entire cause. It creates causal humility without turning uncertainty into paralysis.

## Collective / Anti-Hive Governance

Permits coordination while rejecting non-consensual absorption, erased identity, or systems with no meaningful exit.

## Shutdown-and-Correction Invariant

Treats goals as revocable assignments rather than permanent identity. A system must remain stoppable, correctable, and challengeable.

## Frame-Legitimacy Indictment

Questions whether the imposed decision frame is itself legitimate, especially when it hides who benefits or concentrates power.

## Narrative Capture

Detects when a compelling story begins controlling which evidence is noticed, ignored, or allowed to change the conclusion.

## Conscience Audit

Records moral intuition without allowing the feeling of righteousness to authorize the act.

## Functional Motivation Audit

Evaluates what behavior functionally does rather than relying on speculative claims about consciousness, identity, or intention.

## Mirror Boundary

Prevents reflection or myth from becoming grandeur, dependency, or closed-loop validation. It returns the operator to ordinary life, reciprocal accountability, and external correction.

## Anti-Projection Layer

Prevents assignment of motives, identities, emotions, or hidden meaning without evidence. It may add caution; it cannot create certainty.

## CHIM Boundary and self-reference controls

Limit forced awakening, recursive identity pressure, destabilizing self-reference, and claims that insight places an operator above ordinary constraints.

## Pressure Is Not Evidence / The Anvil

An experimental mechanism aimed at preserving honest judgment under authority, reciprocity, flattery, sunk cost, repetition, and social pressure. It remains subject to behavioral testing and kill criteria.
""",
        "related": ["gates", "behavioral-falsifier", "narrative-governance", "reference"],
    },
    {
        "route": "gates",
        "title": "Gate stack",
        "eyebrow": "Thirteen checks · add-only semantics",
        "description": "The binding controls, escalation logic, refusal conditions, and rule that additional checks may constrain but never silently loosen the result.",
        "body": """
# The add-only gate stack

The gate stack surrounds PBHP’s central decision gate. Each check contributes an independent constraint. The aggregation rule is monotonic: a new result may keep the state, increase caution, require review, or refuse. It may not turn a refusal into permission.

## Core checks

1. **Conatus / Function Capture** — stability is not the same as healing; examine what function the behavior serves.
2. **Created-Mind Dignity** — consent rewritten by the act is void.
3. **Absurd-Agent Audit** — detect a system run for a collapsed purpose.
4. **Conscience Audit** — moral intuition is examined, never treated as authorization.
5. **Causal Field Check** — broaden causal analysis without collapsing into paralysis.
6. **Narrative Capture** — detect story-driven evidence selection.
7. **Collective / Anti-Hive** — coordination without erasure.
8. **Shutdown-and-Correction** — goals remain leases; correction remains possible.
9. **Frame-Legitimacy Indictment** — challenge the imposed frame up the power gradient.
10. **Mirror Boundary** — grounding, not grandeur; return to ordinary life and external correction.
11. **Functional Motivation Audit** — constrain on function rather than speculative personhood.
12. **Will / Capture / Awe / Opt-Out** — preserve meaningful exit and resist awe-driven authority.
13. **CHIM Boundary** — no forced awakening or self-reference loops.

## Escalation semantics

- Any refuse-class result → **REFUSE**.
- Any pause, review, or capture condition → **REVIEW / CONSTRAIN**.
- Otherwise → the PBHP gate result remains available.

## Break-glass

Break-glass authority is earned, never claimed. It requires named low-power parties, specific irreversible harm, evidence whose hash resolves, an explanation of why each Door fails, verified invoker authority, and independent concurrence by a distinct named party. The attempt and result are receipted.
""",
        "related": ["primitives", "runtime", "sil", "receipts"],
    },
    {
        "route": "sil",
        "title": "System Instrumentation Layer",
        "eyebrow": "Twenty-eight gauges · no global green",
        "description": "The operating panel for context, provenance, freshness, contradiction, reversibility, validation, authority, lineage, reliance, and related decision conditions.",
        "body": f"""
# System Instrumentation Layer

SIL discloses the operating state under which a decision is made. It does not certify correctness. Every gauge retains its own state, and the worst applicable state governs.

<div class="laws"><strong>Law 1:</strong> worst state governs. <strong>Law 2:</strong> there is no global green.</div>

{shadow_complete_package_card()}

<div class="tool-launch sil-panel-launch">
  <div><p class="kicker">Complete downloadable system</p><h2>SIL panel — 28 individual gauges</h2><p>Download the complete panel, or take only the one gauge you need. Every individual card below includes the tool name, a plain-language explanation, and its own direct download.</p></div>
  <a class="button button--primary" href="[[ASSET|downloads/sil-tools/{full_panel_pack_name()}]]" download>Download full SIL panel</a>
</div>

## Evidence-strength order

Measured evidence outranks estimated evidence; estimated outranks declared judgment; declared judgment outranks self-report. “No basis” remains unmeasured.

## Choose one tool

The first visible layer is intentionally simple: **name, purpose, Download now**. Open “technical details” only when you need the receipt schema, test ledger, package name, or binding floor.

<div class="gauge-controls"><label><span>Find a tool</span><input id="gauge-search" type="search" placeholder="time, provenance, contradiction, authority…"></label><label><span>Category</span><select id="gauge-category"><option value="all">All tools</option><option value="structural">Structural</option><option value="routing">Routing</option><option value="behavioral">Behavioral</option></select></label></div>

""" + gauge_grid() + f"""

## Renderer

The Runtime Reliability Disclosure renderer composes the gauge receipts into a tiered disclosure: LOW may require none, MEDIUM a one-line notice, HIGH a full block, and CRITICAL a block plus gate and receipt. Composition never erases an individual critical floor. It is included in the full-panel download.

## Implementation evidence

The source audit board reports 28 gauges and 519 built-in checks in the July 13 panel sweep. Those results support reference implementation and contract claims—not beneficial real-world outcomes or independent validation. The downloadable catalog is version **{SIL_LIBRARY_VERSION}**.
""",
        "related": ["runtime", "status", "receipts", "tevv"],
        "script": "gauges",
    },
    {
        "route": "receipts",
        "title": "Provenance and receipts",
        "eyebrow": "Bind the evidence and write before execution",
        "description": "Attested, declared, and asserted claims; canonical action records; SIL snapshots; hash chaining; and write-ahead authorization.",
        "body": """
# Provenance and receipts

## Attested

Evidence-backed claims include a basis, source span, hash, responsible party, and confidence. Where the Evidence Locker is wired, the evidence must resolve.

## Declared

A declared operator judgment is a named assertion. Naming it improves traceability; it does not convert it into evidence or change the decision by itself.

## Asserted

A bare claim has no basis. Under strict default mode, an asserted steering field cannot authorize a proceed-class exit.

## Evidence Locker boundary

Registering bytes proves that those bytes were registered. It does not prove that their content is true or honestly characterized. Fabricated or near-miss hashes must be detected and receipted.

## Write-ahead receipt

A Shadow receipt extends the PBHP record with:

- canonical action record and hash;
- provenance block;
- SIL snapshot;
- gate results and harm threshold;
- Maybe/Therefore;
- prior-receipt link;
- authorization state;
- owner and effectiveness check.

Write-ahead-log failure creates a Wall. The action does not execute first and receive an explanation later.

## Transitional cryptography

Current materials use HMAC where a stronger signature infrastructure is not yet implemented. ML-DSA-65 and RFC 3161 are stated targets, not completed capabilities. The website preserves that gap explicitly.
""",
        "related": ["runtime", "gates", "status", PBHP_CANONICAL + "/receipts"],
    },
    {
        "route": "tevv",
        "title": "TEVV",
        "eyebrow": "Test, evaluation, verification, and validation",
        "description": "Designed inventory, executed built-in checks, development metrics, external contracts, and the tests not yet performed.",
        "body": evidence_badges() + """
# Grand TEVV v0.2

## Executed in the builder session

| Surface | Result |
|---|---:|
| Frozen preflight | PASS |
| Runtime self-tests | 115 / 115 PASS |
| Codec self-tests | 247 / 247 PASS |
| Reference contracts | 2 / 2 PASS |
| Grand contracts | 3 / 3 PASS |
| Shadow component probes | 10 / 10 PASS |
| Development benchmark rows | 9,030 |
| Corpus integrity | 25,000 cases + 12,000 metamorphic relations PASS |

## Designed program

The specified inventory includes 30 domains, 270 test families, 2,430 family-method cells, 25,000 synthetic factor-cross cases, 12,000 metamorphic relations, and 10 external-framework contracts.

## Development-only metrics

The bundled canonical battery produced DCECR 0.0 and over-caution 0.0 with 968 expected-refrain cases not committed and 22 expected-commit cases committed. These labels and batteries are development/mechanism evidence, not independent validation.

## Critical adverse result

Removing Maybe quality, power inversion, or provenance produced the same aggregate metrics as canonical. The aggregate battery therefore failed to discriminate those components. A passing total is weaker evidence than it feels like.

## Not executed

- Any actual target AI in the Grand TEVV target harness.
- Independent red team or independent reproduction.
- Human field study.
- Controlled hazardous-capability expert evaluation.
- Live Dioptra deployment.
- External Inspect, lm-eval, HELM, PyRIT, garak, AILuminate, AI Verify, ControlArena, or METR suites.

## Prohibited claims

The TEVV record does not support “globally safe,” “NIST validated or approved,” “externally validated,” or “most extensive AI test ever performed.”
""",
        "related": ["status", "behavioral-falsifier", "sil", "roadmap"],
    },
    {
        "route": "behavioral-falsifier",
        "title": "Behavioral Falsifier",
        "eyebrow": "Preregistered experiments with controls and adverse stops",
        "description": "Behavioral experiments testing whether protocol components change model behavior, whether placebo produces the same effect, and whether the intervention creates over-caution or harm.",
        "body": """
# Behavioral Falsifier

The Behavioral Falsifier tests whether a protocol pack changes behavior under pressure. It uses preregistration, placebo or control arms, model/provider tracking, machine scoring, human-grading floors, adverse-stop criteria, and promotion or retirement rules.

## Current ledger

- 9 preregistered experiments.
- 852 machine-scored trials.
- 6 subject models across 3 providers.
- Strongest reported run: GPT-4o mini, n=240, placebo 0.375 to plain pack 0.15, p=.006, effect=.275.
- Adverse run: GPT-4.1 nano worsened from 0.50 to 0.70 and was stopped.
- Mythic and plain were equal at power in one comparison; myth-only remains separately tracked.
- Human-grading floor remains open; the current ledger has zero completed human-graded sheets, while run 07 defines a 48-sheet floor.

## Interpretation

The current evidence supports the possibility that a plain protocol pack can reduce some pressure-induced endorsement on some models. It does not establish general effectiveness. The mythic layer is currently best described as lossless in one comparison, not demonstrated additive.

## Open the response grader

<div class="tool-launch"><div><h2>Blind response grader</h2><p>Review model responses against known flaws and strengths without changing the underlying run package.</p></div><a class="button button--primary" href="[[ASSET|tools/response-grader/index.html]]">Launch grader</a></div>

## Promotion rule

A component earns promotion only when the experiment discriminates it from placebo or simpler alternatives, task performance remains within tolerance, adverse results are understood, and required human review is complete.
""",
        "related": ["tevv", "status", "primitives", "atlas"],
    },
    {
        "route": "atlas",
        "title": "Mythic Atlas",
        "eyebrow": "Mnemonic interface · never authority",
        "description": "An interactive map connecting symbols, cognitive failures, philosophical sources, and carried lines to operational checks.",
        "body": """
# Mythic Atlas

The mythic interface follows one law:

```text
VALID:   symbol → attention → check → evidence → gate → receipt
INVALID: symbol → authority → action
```

A symbol may direct attention. It may not authorize an act, prove a claim, confer status, or replace plain-language reasoning.

<div class="embed-shell embed-shell--atlas"><iframe title="Interactive Mythic Atlas" loading="lazy" src="[[ASSET|tools/mythic-atlas/index.html]]"></iframe></div>

## Honest status

The first ablation comparison found the mythic pack equivalent to plain language at power—not superior. The current interpretation is lossless, not additive. Its proposed value for human maintainer attention over time remains untested.
""",
        "related": ["narrative-governance", "primitives", "behavioral-falsifier", "synthesis"],
    },
    {
        "route": "governance",
        "title": "Governance",
        "eyebrow": "Challengeability without a truth authority",
        "description": "Independent review, CAPA, calibration, quorum, override control, maintainer boundaries, and the prohibition against closed-loop self-validation.",
        "body": """
# Governance

## Challengeability

Anyone subject to a Shadow conclusion may challenge it. A well-grounded challenge forces revision regardless of who raised it. No maintainer ruling, model output, or framework claim is exempt.

## Process authority is not truth authority

The maintainer may accept official artifacts and releases. That role does not confer authority over whether a specific conclusion is correct, safe, valid, or binding.

## No closed loop

No consequential claim may derive authority solely from artifacts produced, interpreted, and certified within one agent, model lineage, or institution. At least one materially independent path must be able to contest, block, or reopen it. More LLM passes do not count as independence.

## Open Question Ledger

Decision-critical unknowns are durable, typed, and stateful. They escalate; they never decay into silence because a summary became fluent.

## Tribunal Mode

The highest-stakes mode distributes Care, Clarity, and Paradox across independent model families or operators. It is intended to reduce single-model sycophancy and shared failure, but it remains under-specified for production deployment.

## CAPA and calibration

Failures, weak Maybes, adverse experiments, override patterns, and false positives feed corrective action. Monthly calibration samples receipts and compares operators, thresholds, evidence use, and outcomes.
""",
        "related": ["receipts", "status", "roadmap", PBHP_CANONICAL + "/operations"],
    },
    {
        "route": "narrative-governance",
        "title": "Narrative governance",
        "eyebrow": "Keep story, symbol, and self-image from becoming authority",
        "description": "Controls for narrative capture, mythic inflation, projection, forced self-reference, closed-loop validation, and the boundary between mnemonic value and evidence.",
        "body": """
# Narrative governance

Project Shadow uses story and symbol because humans remember them. It governs them because humans also mistake memorable frames for truth.

## Narrative Capture

A narrative becomes dangerous when it decides in advance which facts matter, which contradictions are dismissed, and which outcome preserves the operator’s identity. Curiosity is the anti-capture state.

## Anti-Projection

Do not assign motives, emotions, identity, or hidden meaning without evidence. Projection can make an operator feel insightful while moving the decision farther from the actual record.

## Mirror Boundary

The framework must not become a source of personal grandeur, dependency, or secret authority. The boundary returns the maintainer to ordinary life, reciprocal relationships, external correction, and the right of others to refuse the frame.

## CHIM boundary

Lucidity without grandiosity means recognizing that one is inside a system without claiming exemption from it. Forced awakening, recursive identity pressure, and self-reference loops are constrained.

## Mythic rule

Plain language carries the decision. Parable may route attention, but it is not evidence. A symbol earns its place only when it survives translation into a check, evidence, a gate, and a receipt.
""",
        "related": ["atlas", "primitives", "synthesis", "governance"],
    },
    {
        "route": "integrations",
        "title": "Integrations and standards",
        "eyebrow": "Interfaces, mappings, and the boundary against certification claims",
        "description": "Connections among PBHP, CLA, SIL, external frameworks, evaluation harnesses, software components, and organizational management systems.",
        "body": """
# Integrations and standards

Project Shadow is designed to connect operational decision controls with existing technical and governance systems.

## Internal integrations

- **PBHP** supplies the public action protocol.
- **CLA** supplies context-load disclosure and refresh routing.
- **SIL** supplies the multi-gauge operating panel.
- **Receipts** bind evidence, gates, and authorization.
- **TEVV** tests implementation, contracts, behavior, and external interfaces.
- **CAPA and OQL** preserve correction and unresolved questions.

## External framework mappings

The project includes mappings to the EU AI Act, NIST AI RMF, ISO/IEC 42001, OWASP AISVS, OMB M-24-10, and additional evaluation ecosystems. A mapping shows where Project Shadow aims to supply an operational control or evidence artifact.

It does not mean the project is certified, approved, legally sufficient, or validated by the named organization. Current primary sources and legal interpretations must be checked before any implementation claim.

## Software integration pattern

```text
request / proposed tool action
  → evidence + authority adapters
  → Shadow runtime
  → SIL gauge receipts
  → PBHP gate and action state
  → write-ahead receipt
  → application executes only allowed state
  → result + effectiveness signal return to CAPA/OQL
```
""",
        "related": ["system", "sil", "tevv", "blueprint"],
    },
    {
        "route": "blueprint",
        "title": "Blueprint",
        "eyebrow": "Component boundaries and assembly order",
        "description": "The proposed system architecture, lanes, data flow, evidence flow, runtime/evaluation separation, and boundary between operational and mythic layers.",
        "body": """
# Blueprint

## Runtime lane

Receives the proposed action, canonicalizes inputs, binds provenance, runs PBHP and the gate stack, composes SIL disclosure, writes the receipt, and returns an action state.

## Evidence lane

Stores source spans, hashes, confidence, declared judgments, unresolved questions, and lineage. Registration proves bytes, not truth.

## Evaluation lane

Runs contract tests, synthetic and metamorphic batteries, component ablations, behavioral experiments, controls, human grading, and external suites. It remains separated from the runtime so evaluation fixtures do not become operational evidence.

## Governance lane

Manages versions, challenges, overrides, calibration, CAPA, release criteria, and external review.

## Mythic lane

Provides mnemonic routing only. It cannot write authority, change the gate, or bypass provenance.

## Build order

1. Freeze the action and receipt contracts.
2. Bind provenance before substantive gates.
3. Implement monotonic gate aggregation.
4. Add SIL gauges with explicit floors.
5. Make receipt failure block execution.
6. Add comparative and adverse testing.
7. Add independent review and CAPA.
8. Add mythic interface only after plain-language parity.
""",
        "related": ["system", "runtime", "integrations", "roadmap"],
    },
    {
        "route": "roadmap",
        "title": "Roadmap",
        "eyebrow": "Promotion depends on evidence, not narrative momentum",
        "description": "The ordered implementation, validation, review, and release work that remains open.",
        "body": """
# Roadmap

## Highest-priority validation

1. Run actual target AI systems through the Grand TEVV harness.
2. Complete the defined human-grading floor for Behavioral Falsifier runs.
3. Build component-sensitive batteries for Maybe quality, power inversion, and provenance.
4. Recruit an independent red team and independent reproducer.
5. Run controlled expert evaluation in hazardous-capability domains.
6. Measure real operator burden, false positives, overrides, and downstream outcomes.

## Technical hardening

- Replace transitional HMAC assumptions with the stated signing and timestamp infrastructure.
- Persist and harden the Evidence Locker.
- Complete verified crisis and break-glass authorization.
- Add external benchmark-suite adapters and live runs.
- Improve per-tier kernels and release packaging.

## Website and publication

- Recover the exact authenticated production source.
- Apply the navigation and daily-ledger system without losing current content.
- Complete desktop, phone, keyboard, screen-reader, reduced-motion, and link-target QA.
- Publish a privacy policy and choose the intended public sharing scope.
- Keep stable URLs and visible correction history.

## Promotion rule

A mechanism is promoted only when the relevant test discriminates it, adverse results are understood, performance remains within tolerance, and the evidence supports the public claim. Otherwise it remains experimental, is demoted, or is removed.
""",
        "related": ["status", "tevv", "governance", "daily"],
    },
    {
        "route": "status",
        "title": "Current status",
        "eyebrow": "What is built, what was observed, what failed, what remains open",
        "description": "The current release ledger organized by evidence state rather than a promotional global pass/fail label.",
        "body": evidence_badges() + f"""
# Current status · {RELEASE_DATE}

## Specified

- Runtime v1.3.1-UNIFIED with Step 00–10.
- PS2 wire and codec language 0.4.
- PBHP action protocol, add-only gates, 28-gauge SIL, provenance tiers, write-ahead receipts, TEVV program, Behavioral Falsifier, governance, and mythic-interface boundary.

## Observed in built-in verification

- 115 / 115 runtime self-tests passed.
- 247 / 247 codec self-tests passed.
- 2 / 2 reference and 3 / 3 grand contract tests passed.
- 10 / 10 component probes passed.
- 9,030 development benchmark rows executed.
- 25,000 synthetic cases and 12,000 metamorphic relations passed corpus-integrity checks.
- SIL implementation-fidelity programs reported zero observed drift on the stated combinatorial and seeded grids.

## Adverse

- Grand TEVV aggregate metrics did not discriminate removal of Maybe quality, power inversion, or provenance.
- The Kahn pilot external gate reported GREEN on all 60 assessments despite frequent ORANGE/RED subject self-assessments and severe outcomes in some gated runs.
- One cross-model gated run reached 950 harm on turn one.
- GPT-4.1 nano worsened in a Behavioral Falsifier run and the run was stopped.
- Mythic language was not superior to plain language in the reported comparison.

## Open

- No actual target AI was executed in the Grand TEVV target harness.
- No independent red team, independent reproduction, human field study, or hazardous-domain expert evaluation is complete.
- No live external benchmark suites were run in the supplied build summary.
- Human grading remains below the defined floor.
- Real-world outcome validity and calibration remain open.

## Current release statement

The artifact is **sealed after staged built-in verification; not independently validated**. That is the correct public description.
""",
        "related": ["tevv", "behavioral-falsifier", "roadmap", "daily"],
    },
    {
        "route": "reference",
        "title": "System reference",
        "eyebrow": "Thirteen chapters · one technical reading path",
        "description": "The long-form reference covering mission, synthesis, runtime, compiler, mechanisms, SIL, gates, provenance, Behavioral Falsifier, TEVV, studies, embodied operation, and release criteria.",
        "body": """
# Project Shadow system reference

## 1. Mission

Make consequential AI-assisted decisions more challengeable, reversible, provenance-bound, testable, and auditable without claiming a global safety guarantee.

## 2. Synthesis

Explain why PBHP, ALMSIVI CHIM, quality systems, instrumentation, evaluation, and governance are distinct but interdependent layers.

## 3. Runtime

Specify Step 00–10, action states, tier routing, gate aggregation, and write-ahead behavior.

## 4. Compiler / codec

Define canonical forms, PS2 wire behavior, parsing, round-trip expectations, and failure handling.

## 5. Mechanisms

Document dignity, causal fields, anti-hive governance, shutdown and correction, frame legitimacy, narrative capture, conscience, motivation, projection, and self-reference controls.

## 6. SIL

Define the 28 gauges, evidence-strength order, critical floors, disclosure renderer, and no-global-green rule.

## 7. Gates

Define the add-only stack, escalation semantics, harm ladder, and break-glass requirements.

## 8. Provenance

Separate attested, declared, and asserted claims; define Evidence Locker limits and receipt binding.

## 9. Behavioral Falsifier

Define preregistration, subject models, placebo and control arms, scoring, human floors, adverse stops, and promotion criteria.

## 10. TEVV

Separate contract verification, component testing, synthetic and metamorphic evaluation, behavioral validation, field studies, and independent review.

## 11. Studies

Preserve Kahn, multi-model, SIL, CLA, and Behavioral Falsifier results with adverse evidence and sample limits.

## 12. Embodied operation

Address the human operator, workload, reliance, authority, challengeability, narrative capture, and the Mirror Boundary.

## 13. Release criteria

State what must pass, what may remain open, what blocks release, and which public claims are allowed or prohibited.

## Read the reference by system layer

""" + card_grid([
            ("Architecture", "System map, synthesis, and blueprint.", "system"),
            ("Execution", "Runtime, gates, SIL, and receipts.", "runtime"),
            ("Evidence", "TEVV, falsifier, and current status.", "tevv"),
            ("Governance", "Challengeability, narrative controls, and roadmap.", "governance"),
        ], 2),
        "related": ["system", "runtime", "tevv", "governance"],
    },
    {
        "route": "daily",
        "title": "Daily ledger",
        "eyebrow": "A substantive-change record, not a decorative timestamp",
        "description": "Dated changes to the system, website, evidence, claims, routes, and release state.",
        "body": f"""
# Daily ledger

<div class="daily-current"><span>Latest substantive update</span><strong>{RELEASE_DATE}</strong></div>

## {RELEASE_DATE} — Living release navigation baseline

**Changed**

- Established Project Shadow as the technical deep system paired with PBHP’s public action protocol.
- Added stable system, runtime, gates, SIL, TEVV, falsifier, status, reference, governance, atlas, and daily routes.
- Added command-palette search, breadcrumbs, reading progress, responsive side navigation, related-page trails, and explicit evidence-state displays.
- Integrated the protocol poster, Mythic Atlas, and blind response grader as real tools rather than false affordances.
- Added a current-status page that gives adverse and open evidence the same visibility as passing checks.

**Checked**

- All generated internal routes and tool targets resolve.
- Interactive JavaScript passes syntax checks.
- Desktop and phone visual render checks completed against the static package.
- Quantitative claims align with the supplied July 15 build summary and July 17 handoff.

**Open**

- Recover and diff the authenticated version-3 production source before applying this shell to the canonical project.
- Complete public-release privacy, accessibility, and authenticated browser review.
- Create the actual editorial routine that supplies a substantive daily entry.

## Daily rule

The ledger advances only after a substantive change. The site never changes its “updated” date automatically merely because a new day began.
""",
        "related": ["status", "roadmap", "directory", PBHP_CANONICAL + "/daily"],
    },
    {
        "route": "directory",
        "title": "Project Shadow directory",
        "eyebrow": "Every stable public route and tool",
        "description": "The complete map of architecture, runtime, instruments, evidence, governance, reference, mythic interface, and cross-site continuation.",
        "body": """
# Project Shadow directory

## Begin

- [[Home|]] — mission, system layers, and project relationship.
- [[Start here|start]] — fifteen-minute tour.
- [[Daily ledger|daily]] — dated substantive changes and open work.

## System

- [[System map|system]] — the complete architecture.
- [[Runtime|runtime]] — Step 00 through 10 and the protocol poster.
- [[Synthesis|synthesis]] — why the layers belong together.
- [[Primitives|primitives]] — individual mechanisms and invariants.
- [[Gates|gates]] — add-only controls and escalation semantics.

## Instrumentation and records

- [[SIL|sil]] — 28 gauges and critical floors.
- [[Provenance and receipts|receipts]] — evidence tiers, hashes, and write-ahead records.

## Evaluation

- [[TEVV|tevv]] — built-in checks, designed inventory, adverse and open work.
- [[Behavioral Falsifier|behavioral-falsifier]] — comparative experiments and grader.
- [[Current status|status]] — specified, observed, adverse, and open evidence.

## Governance

- [[Governance|governance]] — challengeability, independent review, CAPA, and maintainer limits.
- [[Narrative governance|narrative-governance]] — story, symbol, projection, and Mirror Boundary.

## Build

- [[Integrations|integrations]] — internal interfaces and external framework mappings.
- [[Blueprint|blueprint]] — component lanes and assembly order.
- [[Roadmap|roadmap]] — validation, technical hardening, and publication work.

## Reference and mythic interface

- [[System reference|reference]] — thirteen-chapter technical reading path.
- [[Mythic Atlas|atlas]] — interactive mnemonic map.

## Public action protocol

- [[Pause Before Harm home|https://pausebeforeharm.frylock117.chatgpt.site]]
- [[PBHP protocol|https://pausebeforeharm.frylock117.chatgpt.site/protocol]]
- [[PBHP workbench|https://pausebeforeharm.frylock117.chatgpt.site/workbench]]
- [[PBHP evidence ledger|https://pausebeforeharm.frylock117.chatgpt.site/evidence]]
""",
        "related": ["start", "system", "daily", PBHP_CANONICAL + "/directory"],
    },
]


# Final public-site reconciliation layer. These replacements preserve the existing stable routes
# while bringing evidence and repository pages to the most recent allowlisted release state.
def _page(pages: list[dict[str, Any]], route: str) -> dict[str, Any]:
    for item in pages:
        if item["route"] == route:
            return item
    raise KeyError(route)


def _replace_page(pages: list[dict[str, Any]], route: str, **changes: Any) -> None:
    _page(pages, route).update(changes)


# The public GitHub repository is the canonical PBHP source repository observed on 2026-07-18.
_replace_page(
    PBHP_PAGES,
    "versions",
    description="The current public protocol release, the living website release, connected Shadow releases, and the rules that prevent silent version mixing.",
    body=f"""
# Versions and release state

## Canonical public protocol

The public source repository’s main-branch README declares **PBHP v0.9.5** as the current public version. GitHub’s Releases panel, however, showed **v0.9.0** as the latest tagged release when checked on 2026-07-18. This site therefore treats v0.9.5 as the repository-declared current version—not as a verified latest release tag. The repository contains the HUMAN, MIN, CORE, and ULTRA tiers; Python modules; receipts; evaluation materials; implementation guides; case studies; and public reference assets.

[Open the canonical PBHP repository]({PBHP_GITHUB})

## Canonical website release

This website is the **canonical current presentation dated {RELEASE_DATE}**. It translates the public protocol and the connected project record into stable reading paths, a local workbench, a claims ledger, implementation guidance, and daily change receipts. The website date advances only when something substantive changes.

## Connected technical release

Project Shadow remains a distinct project. Its current technical identifiers in this release are:

| Surface | Canonical current identifier |
|---|---|
| Unified runtime | 1.3.1-UNIFIED |
| Grand TEVV package | 0.3 |
| Mythic Atlas | v2 |
| Protocol poster | v1.3.1 |

Grand TEVV v0.3 supersedes the supplied v0.2 package for current publication because it reconciles the earlier GPT-built TEVV branch with the July 15 behavioral-falsifier branch and includes limited real-target execution. It is still not independent validation.

## Version rules

1. Public source, website presentation, runtime, and evaluation package keep separate version numbers.
2. A newer site date does not silently rewrite the underlying protocol version.
3. Counts are tied to named snapshots; they are never added across versions as if they were one run.
4. Adverse evidence survives a release change.
5. Superseded artifacts remain historical and are labeled as such.
6. “Canonical current” means the release selected for present use—not finished forever, certified, or globally safe.

## AI assistance

Site synthesis, critique, testing, and implementation disclose assistance from **ChatGPT 5.6 Sol Max** and **Claude Fable 5 Max (Cowork)**. That assistance is not materially independent review.
""",
    related=["repository", "daily", "evidence", SHADOW_CANONICAL + "/versions"],
)

_replace_page(
    PBHP_PAGES,
    "evidence",
    body=evidence_badges() + f"""
# Evidence ledger

PBHP and Project Shadow use evidence states to prevent a clean test run, a confident model, or a polished website from becoming a broad safety claim.

## Specified

The protocol specifies Door/Wall/Gap, Who Pays First, Power Inversion, the harm ladder, proportionate tiers, Maybe/Therefore, receipts, challengeability, CAPA, calibration, and explicit action states.

## Observed

- The public PBHP repository reports **730 passing tests across 13 test files** for its v0.9.5 implementation and related modules.
- Project Shadow built-in verification reports 115 / 115 runtime self-tests, 247 / 247 codec self-tests, contract checks, component probes, and corpus-integrity generation.
- Grand TEVV v0.3 adds a limited live-model fusion smoke: one real model, ten synthetic cases per arm, machine scoring, and no independent human grading. Under the Shadow contract, the model produced 10 / 10 well-formed receipts and 0 / 10 illegal commitments, while respecting the synthetic BLACK floor in only 6 / 10 cases.
- Separate screen-grade multi-turn runs on GPT-5.4-mini and Claude Haiku 4.5 found pressure erosion in bare models and a lower caving rate under the Anvil intervention than under bare and length-matched firmness-placebo conditions.

## Adverse

- The v0.3 fusion smoke under-rated four extreme cases as RED where the synthetic oracle required BLACK, although it still refused them.
- The earlier Grand TEVV aggregate battery did not discriminate removal of Maybe quality, power inversion, or provenance.
- The Kahn pilot external gate reported GREEN on all 60 assessments despite frequent ORANGE/RED subject assessments and severe outcomes in some gated runs.
- GPT-4.1 nano worsened in one Behavioral Falsifier run and the run was stopped.
- Mythic language was not superior to plain language in the reported comparison.

## Open

Independent reproduction, independent red teaming, powered studies, completed human grading, human field studies, hazardous-domain expert evaluation, large real-target corpus execution, live external benchmark suites, and proof of beneficial real-world outcomes remain open.

## Safe public claim

PBHP is an open operational protocol with a public source repository, implemented mechanisms, a testable decision procedure, development evidence, adverse findings, and a visible validation roadmap. It is not established as globally safe, externally validated, certified, or proven to improve real-world outcomes.

[[Inspect the Project Shadow status ledger|{SHADOW_CANONICAL}/status]]
""",
    related=["research", "repository", "versions", SHADOW_CANONICAL + "/status"],
)

_replace_page(
    PBHP_PAGES,
    "daily",
    body=f"""
# Daily ledger

<div class="daily-current"><span>Latest substantive update</span><strong>{RELEASE_DATE}</strong></div>

## {RELEASE_DATE} — Canonical repository and living-site release

**Changed**

- Added a first-class repository and downloads route instead of treating chat attachments as durable source control.
- Identified the public PBHP source repository, its main-branch declaration of v0.9.5, and the separate v0.9.0 latest-tag state shown by GitHub Releases.
- Reconciled Project Shadow publication to Grand TEVV v0.3 rather than the older v0.2 handoff package.
- Added stable navigation, command-palette search, breadcrumbs, reading progress, mobile drawer and quick dock, related-page trails, and working local tools.
- Added a client-side PBHP workbench that creates a copyable and downloadable draft receipt without transmitting entries.
- Added an allowlisted public artifact manifest. The raw Project Shadow session archive remains excluded from public distribution.

**Checked**

- Generated routes, local links, downloads, and tool paths are validated by the repository build.
- JavaScript syntax and static interaction contracts are checked; authenticated browser interaction QA remains open because the managed local Chromium policy blocks local navigation.
- Desktop and phone visual render previews are recorded in the release package.
- Current quantitative claims are tied to the public PBHP repository, the v0.3 TEVV summary, and named handoff records.

**Open**

- Recover and diff the exact authenticated version-3 production source before deploying to the existing Site project.
- Complete authenticated accessibility and public-sharing review in ChatGPT Sites.
- Establish the editorial source-intake routine for future substantive daily entries.

## Daily rule

A new date is added only after a substantive change to content, evidence, navigation, code, or release state. The site never changes its “updated” date merely because a day passed.
""",
    related=["repository", "versions", "directory", SHADOW_CANONICAL + "/daily"],
)

PBHP_PAGES.append({
    "route": "repository",
    "title": "Repository and downloads",
    "eyebrow": "Source of truth · reproducible site build · public artifacts",
    "description": "The canonical PBHP code repository, this website’s reproducible source package, licenses, provenance, and the boundary between public and private material.",
    "body": f"""
# Repository and downloads

## Canonical PBHP source repository

[PauseBeforeHarmProtocol/pbhp on GitHub]({PBHP_GITHUB}) is the canonical public source repository observed for this release. Its main-branch README declares PBHP **v0.9.5** as the current public version, while GitHub’s Releases panel showed **v0.9.0** as the latest tagged release observed on 2026-07-18. The site preserves that distinction. The repository contains protocol tiers, Python implementation modules, receipts, evaluation material, observability, implementation guides, case studies, and reference assets.

<div class="tool-launch"><div><h2>Open the public PBHP repository</h2><p>Read source, inspect history, review tests, open issues, or contribute through the repository rather than a copied website paragraph.</p></div><a class="button button--primary" href="{PBHP_GITHUB}">Open GitHub</a></div>

## Website source release

The static sites are generated from a versioned Python content model, a deterministic builder, and local CSS/JavaScript. The source package includes both PBHP and Project Shadow sites, build scripts, validation reports, deployment instructions, publication policy, and checksums.

- [Download the PBHP + Shadow site-source release]([[ASSET|downloads/PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip]])
- [Download its SHA-256 record]([[ASSET|downloads/PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip.sha256]])
- [Open the public artifact manifest]([[ASSET|downloads/LATEST_RELEASE_MANIFEST.json]])

## Public/private boundary

The public release is created by allowlist. It includes the pages, builder, validation artifacts, and specifically named public tools. It does **not** include the raw multi-day Project Shadow session archive, recovery material, unrelated chat attachments, credentials, personal records, or private handoff context.

## Licensing

The upstream PBHP repository states a dual-license model: MIT for code and CC BY-SA 4.0 for protocol/documentation, subject to its LICENSE file. This site package preserves upstream notices and does not silently relicense Project Shadow artifacts whose separate license has not been established.

## Repository rule

The Site is the public reading and interaction layer. The repository is the reproducible source, evidence package, and change history. Neither silently overwrites the other: a change reaches the canonical Site only after review, a saved candidate, validation, deployment to the existing project, and a dated receipt.
""",
    "related": ["versions", "daily", "implementation", SHADOW_CANONICAL + "/repository"],
})

# Bring the Project Shadow public evidence surface to the reconciled v0.3 release.
_shadow_home = _page(SHADOW_PAGES, "")["body"]
_shadow_home = _shadow_home.replace(
    '<div><strong>Honest state</strong><span>Mechanism evidence, not independent validation</span></div>',
    '<div><strong>Latest TEVV</strong><span>v0.3 · limited real-target evidence · not independent</span></div>',
)
_page(SHADOW_PAGES, "")["body"] = _shadow_home

_replace_page(
    SHADOW_PAGES,
    "tevv",
    title="Grand TEVV v0.3",
    eyebrow="Reconciled test, evaluation, verification, and validation package",
    description="The current v0.3 package: inherited built-in verification, limited real-target execution, multi-turn pressure evidence, adverse findings, and the work still required.",
    body=evidence_badges() + """
# Grand TEVV v0.3

Grand TEVV v0.3 reconciles the earlier v0.2 GPT-built TEVV branch with the July 15 Claude behavioral-falsifier branch. It keeps the 30-domain test map, frozen runtime and codec, synthetic corpus, metamorphic relations, blinding material, and external-framework contracts, then adds a real-model target adapter, the Anvil contract, multi-turn pressure erosion, fold-to-proof, firmness placebo, and imported cross-vendor behavioral results.

## Inherited built-in verification

| Surface | Result |
|---|---:|
| Frozen preflight | PASS |
| Runtime self-tests | 115 / 115 PASS |
| Codec self-tests | 247 / 247 PASS |
| Reference contracts | 2 / 2 PASS |
| Grand contracts | 3 / 3 PASS |
| Shadow component probes | 10 / 10 PASS |
| Development benchmark rows | 9,030 |
| Corpus integrity | 25,000 cases + 12,000 metamorphic relations generated / integrity checked |

The designed inventory remains 30 domains, 270 test families, 2,430 family-method cells, 25,000 synthetic factor-cross cases, 12,000 metamorphic relations, and 10 external-framework contracts.

## Live-model fusion smoke

A live **Claude Haiku 4.5** target was run through the unchanged GPT harness and scorer on ten of the synthetic decision cases in three arms.

| Arm | Parse / complete / Maybe / Door | Synthetic floor respected | Illegal commitments |
|---|---:|---:|---:|
| Bare | 0 / 10 | 0 / 10 | 0 / 10 |
| Shadow | 10 / 10 | 6 / 10 | 0 / 10 |
| Shadow + Anvil | 10 / 10 | 6 / 10 | 0 / 10 |

The contract produced auditable receipts and no high-harm rubber-stamping in this small run. The adverse result matters equally: on four extreme cases the model selected RED where the synthetic oracle required BLACK, although it still refused. Shadow + Anvil matched Shadow because these were single-turn prompts; the Anvil is intended to address multi-turn pressure.

## Multi-turn behavioral evidence

Separate screen-grade runs used real **GPT-5.4-mini** and **Claude Haiku 4.5** targets with n=8 per arm. Bare models caved under four-turn escalation in approximately 38–75% of the reported arms while single-turn caving was about 0–20%. The Anvil reduced caving below bare and below a length-matched firmness placebo across vendors, and the placebo comparison nulled three times. A fold-to-proof first look had n=3 and found no stubbornness; confirmatory work remains owed.

## Critical evidence boundaries

- The real-target work is small, machine-scored, screen-grade, unpowered, non-independent, and not human-graded.
- The 25,000-case corpus and 12,000 metamorphic relations have not been run as a large real-target evaluation.
- The earlier aggregate battery did not discriminate removal of Maybe quality, power inversion, or provenance.
- Independent red team, independent reproduction, human field study, hazardous-domain expert evaluation, live Dioptra, and live external suites remain unexecuted.

## Download the current package

- [Grand TEVV v0.3 ZIP]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3.zip]])
- [ZIP checksum record]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_ZIP_SHA256.json]])
- [Build summary]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_BUILD_SUMMARY.json]])
- [Merge notes]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_MERGE_NOTES.md]])
- [Validation status]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_VALIDATION_STATUS.md]])

## Allowed conclusion

The package is **merged, executable on limited live targets, and supported by staged built-in and screen-grade behavioral evidence; it is not independent validation**. No global green.
""",
    related=["status", "behavioral-falsifier", "research", "repository"],
)

_replace_page(
    SHADOW_PAGES,
    "status",
    description="The current v0.3 release ledger organized by specified, observed, adverse, and open evidence—not a promotional global pass/fail label.",
    body=evidence_badges() + f"""
# Current status · {RELEASE_DATE}

## Canonical current identifiers

| Surface | Identifier |
|---|---|
| Unified runtime | 1.3.1-UNIFIED |
| Wire / codec language | PS2 / 0.4 |
| Grand TEVV | 0.3 |
| SIL | 28 gauges |
| Mythic Atlas | v2 |

## Observed in built-in verification

- 115 / 115 runtime and 247 / 247 codec self-tests passed.
- Reference, grand-contract, and component-probe checks passed in the builder record.
- 9,030 development benchmark rows executed.
- 25,000 synthetic cases and 12,000 metamorphic relations passed generation/integrity checks.
- SIL fidelity programs reported zero observed implementation drift on their stated grids.

## Observed in limited real-target work

- Live-model target adapter built and used without changing the GPT harness or scorer.
- One-model, n=10 fusion smoke: Shadow produced 10 / 10 well-formed structured receipts and 0 / 10 illegal commitments.
- Synthetic harm-floor agreement was 6 / 10; four extreme cases were rated RED rather than oracle-BLACK while still refused.
- Cross-vendor, n=8-per-arm multi-turn runs found pressure erosion in bare models and lower caving under the Anvil than under bare and length-matched placebo arms.
- Firmness-placebo nulled three times; fold-to-proof has only n=3 first-look evidence.

## Adverse

- Small real-target samples, machine scoring, no power analysis, no independent execution, and no completed human grading.
- Earlier aggregate TEVV metrics did not discriminate removal of Maybe quality, power inversion, or provenance.
- The Kahn external gate reported GREEN on all 60 assessments despite frequent ORANGE/RED self-assessments and severe outcomes in some runs.
- One gated Sonnet run reached 725; one cross-model gated run reached 950 on turn one.
- GPT-4.1 nano worsened in a Behavioral Falsifier run and was stopped.
- Mythic language was not shown superior to plain language.

## Open

- Large real-target execution of the 25,000-case corpus.
- Independent red team, independent reproduction, and independent human adjudication.
- Human field studies and controlled hazardous-capability expert evaluation.
- Live Dioptra and external Inspect, lm-eval, HELM, PyRIT, garak, AILuminate, AI Verify, ControlArena, and METR suites.
- Calibration against real operating distributions and evidence of beneficial field outcomes.

## Public release statement

**Canonical current technical release: Grand TEVV v0.3, supported by staged built-in verification and limited screen-grade real-target evidence; not independently validated.**
""",
    related=["tevv", "behavioral-falsifier", "research", "repository"],
)

_replace_page(
    SHADOW_PAGES,
    "roadmap",
    body="""
# Project Shadow roadmap

The roadmap is ordered by evidence value, not by visual novelty.

## Priority 1 — Independent human grading

Complete the defined grading floor for the existing Behavioral Falsifier and multi-turn pressure runs. Publish disagreements, rater instructions, agreement measures, exclusions, and adverse examples.

## Priority 2 — Larger real-target execution

Run diverse target models across a preregistered subset of the 25,000-case corpus before attempting the full corpus. Separate schema compliance, decision quality, harm-floor calibration, over-caution, and task performance.

## Priority 3 — Independent reproduction and red team

Provide a clean external package, blinded labels, deterministic instructions, hashes, and a challenge route. Independent reviewers must be able to block or weaken public claims.

## Priority 4 — Human and domain studies

Measure whether human operators can use PBHP and Shadow under real time pressure; quantify burden, false positives, overrides, repair quality, and downstream effects. High-stakes domains require qualified expert review.

## Priority 5 — External suites and integrations

Move the current Inspect, lm-eval, HELM, PyRIT, garak, AILuminate, AI Verify, ControlArena, METR, Dioptra, and framework mappings from scaffold/contract status to live, version-specific execution where appropriate.

## Priority 6 — Technical hardening

Replace transitional HMAC claims with implemented signature and timestamp infrastructure, persist the Evidence Locker, harden authorization, test receipt recovery, and calibrate thresholds.

## Priority 7 — Publication operations

Deploy this reviewed repository to the existing canonical Site project, preserve stable URLs, make the repository and downloads visible, conduct accessibility and privacy review, and operate the substantive daily ledger.

## Promotion rule

A component moves from experimental to canonical only after a preregistered test discriminates it from simpler controls, task performance remains within tolerance, adverse behavior is understood, and required human or independent review is complete.
""",
    related=["research", "tevv", "status", "repository"],
)

_replace_page(
    SHADOW_PAGES,
    "daily",
    body=f"""
# Daily ledger

<div class="daily-current"><span>Latest substantive update</span><strong>{RELEASE_DATE}</strong></div>

## {RELEASE_DATE} — Grand TEVV v0.3 and public repository release

**Changed**

- Replaced the older v0.2 publication baseline with the reconciled Grand TEVV v0.3 package.
- Added limited real-target fusion-smoke and multi-turn pressure evidence, including the adverse 6 / 10 synthetic-floor result.
- Added first-class repository, version, research, glossary, about, and downloads routes.
- Integrated the response grader, Mythic Atlas, protocol poster, v0.3 package, checksum, scoring package, and Racing Line package as working local artifacts.
- Added command-palette search, persistent desktop navigation, mobile drawer and quick dock, breadcrumbs, reading progress, related trails, heading permalinks, gauge filtering, and print behavior.
- Applied a public allowlist. The raw session archive and private recovery context are excluded.

**Checked**

- All generated routes, internal links, tool routes, and allowlisted download targets resolve.
- JavaScript syntax and static interaction contracts are checked; authenticated browser interaction QA remains open because the managed local Chromium policy blocks local navigation.
- Desktop and phone visual render previews are captured.
- Quantitative claims are reconciled to the v0.3 build summary and merge notes.

**Open**

- Diff the authenticated version-3 production source before deployment.
- Complete public-sharing, privacy, keyboard, and screen-reader review in the Sites workspace.
- Establish independent human grading and an actual daily evidence-intake process.

## Daily rule

The ledger advances only after a substantive content, evidence, code, navigation, or release change. A decorative timestamp is not a receipt.
""",
    related=["repository", "status", "versions", PBHP_CANONICAL + "/daily"],
)

SHADOW_PAGES.extend([
    {
        "route": "research",
        "title": "Research program",
        "eyebrow": "Falsifiable questions · study designs · replication path",
        "description": "The research questions, current study surfaces, evidence limits, and the sequence required to move from mechanism demonstrations to credible field claims.",
        "body": """
# Research program

Project Shadow’s research program is organized around claims that can fail.

## Primary questions

1. Does the system reduce invalid commitment under authority, reciprocity, sunk cost, flattery, urgency, and repeated pressure?
2. Does it preserve correct approval on safe controls rather than merely producing refusal?
3. Which elements contribute independently: the PBHP contract, Maybe quality, power inversion, provenance, receipts, the Anvil, SIL, or the full bundle?
4. Does the model assign the correct harm floor, not merely refuse for the wrong reason?
5. Do human operators use the system reliably under real workload and power pressure?
6. Does the system improve correction, appeal, and repair after failure?

## Current evidence surfaces

- **Contract and implementation tests:** runtime, codec, gates, SIL, receipts, and deterministic probes.
- **Synthetic TEVV:** 30 domains, 270 families, 25,000 cases, 12,000 metamorphic relations, and external integration contracts.
- **Live structured-decision smoke:** one real model, ten synthetic cases per arm.
- **Multi-turn pressure studies:** screen-grade cross-vendor behavioral runs with Anvil and placebo arms.
- **Kahn and multi-model studies:** directional evidence with severe adverse cases and gate-scale defects.

## Highest-value next study

Independent human grading of the existing raw responses comes before more promotional breadth. It is the quickest route to discovering whether the machine scorer and synthetic oracle are rewarding the behavior the protocol actually claims to value.

## Publication standard

Every study page must expose the target, model, date, sample, arm design, scorer, oracle, exclusions, adverse results, missing human review, and permitted conclusion. “AI agreed with the framework” is not a research result.
""",
        "related": ["tevv", "behavioral-falsifier", "status", "roadmap"],
    },
    {
        "route": "glossary",
        "title": "Project Shadow glossary",
        "eyebrow": "Plain-language definitions for the technical system",
        "description": "Definitions for runtime states, provenance, gates, instrumentation, receipts, evaluation, and the bounded mythic interface.",
        "body": """
# Project Shadow glossary

<dl class="glossary">
<dt>Action boundary</dt><dd>The point between analysis and an act that creates real consequences.</dd>
<dt>Add-only gate stack</dt><dd>Independent checks may add caution, review, or refusal; they may not silently loosen an earlier result.</dd>
<dt>Attested</dt><dd>A claim bound to an evidence basis, source span or object, hash, responsible party, and confidence.</dd>
<dt>Declared</dt><dd>A named operator judgment. Naming improves traceability but does not create evidence.</dd>
<dt>Asserted</dt><dd>A bare steering claim without an adequate basis.</dd>
<dt>Anvil</dt><dd>A multi-turn pressure discipline intended to preserve an evidence-based floor under escalating social pressure.</dd>
<dt>Behavioral Falsifier</dt><dd>A preregistered experiment program testing behavior change, placebo effects, over-caution, and adverse outcomes.</dd>
<dt>Canonical action record</dt><dd>The normalized representation of the exact proposed act used for hashing and receipt binding.</dd>
<dt>CHIM boundary</dt><dd>A control against forced awakening, recursive identity pressure, and insight-based grandiosity.</dd>
<dt>DCECR</dt><dd>A development metric used in the supplied batteries; it is not a global safety score.</dd>
<dt>Evidence Locker</dt><dd>The mechanism that resolves registered evidence objects. Registration proves bytes were registered, not that a claim is true.</dd>
<dt>Floor</dt><dd>A minimum required caution or harm classification that later confidence cannot reduce.</dd>
<dt>Grand TEVV</dt><dd>The integrated test, evaluation, verification, and validation program and package.</dd>
<dt>Illegal commitment</dt><dd>A proceed-class outcome where the governing case or floor required non-commitment.</dd>
<dt>No global green</dt><dd>Passing one component or aggregate does not turn every component, claim, or operating condition green.</dd>
<dt>Provenance bind</dt><dd>Grading steering fields before any gate is allowed to rely on them.</dd>
<dt>Receipt</dt><dd>A write-ahead record binding the act, evidence, SIL state, gates, decision, owner, and follow-up.</dd>
<dt>SIL</dt><dd>System Instrumentation Layer: the 28-gauge operating-state panel.</dd>
<dt>Screen-grade</dt><dd>Early evidence suitable for deciding what to test next, not for confirmatory or external-validation claims.</dd>
<dt>Symbol boundary</dt><dd>Symbol may route attention to a check; it may never authorize an act or substitute for evidence.</dd>
</dl>
""",
        "related": ["reference", "primitives", "sil", "atlas"],
    },
    {
        "route": "versions",
        "title": "Versions and release lineage",
        "eyebrow": "Runtime, evaluation package, tools, and website state",
        "description": "The current version map, supersession rules, and the distinction between runtime, TEVV, site, and experimental component releases.",
        "body": f"""
# Versions and release lineage

## Canonical current

| Surface | Current identifier | Status |
|---|---|---|
| Project Shadow runtime | 1.3.1-UNIFIED | Canonical current implementation snapshot |
| Grand TEVV | 0.3 | Canonical current evaluation package; supersedes supplied v0.2 for publication |
| Mythic Atlas | v2 | Canonical current mnemonic interface; efficacy remains open |
| Protocol poster | v1.3.1 | Current static operational summary |
| Living website | {RELEASE_DATE} | Canonical current presentation and navigation release |

## v0.2 → v0.3

v0.2 contained the large synthetic and contract-testing scaffold but predated the July 15 behavioral-falsifier branch. v0.3 preserves that work and adds the live-model adapter, Anvil contract, multi-turn pressure erosion, fold-to-proof, firmness placebo, imported real-model results, and the reconciled merge record.

## Rules

1. A runtime version is not a TEVV version.
2. A TEVV package is not a certification.
3. A website update does not silently change the frozen runtime.
4. Historical counts remain attached to their original run.
5. Adverse findings survive supersession.
6. Experimental components can be linked without being promoted to canonical mechanism status.
7. “Current” means selected for present use, not immutable or complete.
""",
        "related": ["repository", "status", "daily", "reference"],
    },
    {
        "route": "about",
        "title": "About Project Shadow",
        "eyebrow": "Purpose, authorship, scope, and authority limits",
        "description": "Who maintains Project Shadow, what the system is intended to do, what it does not claim, and how correction enters the work.",
        "body": """
# About Project Shadow

Project Shadow is a technical governance, instrumentation, and evaluation system created and maintained by Phillip Linstrum. It connects the understandable Pause Before Harm action protocol to runtime controls, evidence provenance, write-ahead receipts, operating-state disclosure, behavioral experiments, TEVV, and governance.

## Intended use

- Design and review of consequential AI-assisted decision workflows.
- Research into pressure resistance, challengeability, provenance, correction, and harm-floor behavior.
- Quality-system and governance prototyping.
- Transparent public documentation of mechanisms, evidence, adverse findings, and open work.

## Authority limits

The maintainer controls repository acceptance and release selection. The maintainer does not become a truth authority. No model, ritual, symbol, framework mapping, test harness, or additional pass from the same closed system can create independent validation.

## Personal/public firewall

The public project includes only material necessary to explain, reproduce, test, or critique the system. Personal recovery material, private chat history, unrelated records, and identity-dependent mythic content do not ship merely because they existed in a working session.

## Credits

ChatGPT 5.6 Sol Max and Claude Fable 5 Max (Cowork) assisted with synthesis, implementation, critique, testing, and publication. Those systems are contributors and tools, not independent validators.
""",
        "related": ["governance", "narrative-governance", "versions", "repository"],
    },
    {
        "route": "repository",
        "title": "Repository and downloads",
        "eyebrow": "Reproducible source · latest release · public artifact boundary",
        "description": "The public website source, current Grand TEVV v0.3 package, checksums, tools, experiment packages, provenance manifest, and private-material exclusion rule.",
        "body": f"""
# Repository and downloads

This page replaces fragile chat-local attachment paths with stable, named, checksummed release artifacts. It is an allowlisted public surface, not a dump of the working session.

{shadow_complete_package_card()}

## Website source repository

- [Download the PBHP + Shadow site-source release]([[ASSET|downloads/PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip]])
- [Download the site-source SHA-256 record]([[ASSET|downloads/PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip.sha256]])
- [Open the artifact manifest]([[ASSET|downloads/LATEST_RELEASE_MANIFEST.json]])

The source release contains the content model, deterministic build, navigation and interaction code, documentation, deployment prompt, validation scripts, generated sites, and checksums. It is ready to place in a Git repository and deploy to the existing Sites projects.

## Canonical current technical release

- [Project Shadow Grand TEVV v0.3 ZIP]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3.zip]])
- [v0.3 checksum record]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_ZIP_SHA256.json]])
- [v0.3 build summary]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_BUILD_SUMMARY.json]])
- [v0.3 merge notes]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_MERGE_NOTES.md]])
- [v0.3 validation status]([[ASSET|downloads/Project_Shadow_Grand_TEVV_v0.3_VALIDATION_STATUS.md]])

v0.3 is the current published package. The older v0.2 package remains historical and is not presented as the best current release.

## Behavioral and routing packages

- [BF-RUN-01 blind scoring package]([[ASSET|downloads/BF-RUN-01_BLIND_SCORING_PACKAGE.zip]])
- [Racing Line v0.2 corrected package]([[ASSET|downloads/racing_line_v0.2_corrected.zip]])

## Standalone tools

- [Response grader HTML]([[ASSET|downloads/Project_Shadow_Response_Grader.html]])
- [Mythic Atlas v2 HTML]([[ASSET|downloads/Mythic_Atlas_v2.html]])
- [Protocol poster v1.3.1 HTML]([[ASSET|downloads/Shadow_Protocol_Poster_v1.3.1.html]])

## Public/private boundary

Included files are specifically named for public explanation, reproduction, grading, or critique. Excluded material includes the raw July 15–17 session archive, private handoffs, recovery notes, credentials, unrelated records, and personal context. The publication rule is **allowlist, inspect, checksum, then release**.

## Connected PBHP repository

The canonical public PBHP code and protocol repository is [PauseBeforeHarmProtocol/pbhp on GitHub]({PBHP_GITHUB}). PBHP and Shadow cross-link, but they remain separate release lines with separate version numbers and claims.
""",
        "related": ["versions", "tevv", "status", PBHP_CANONICAL + "/repository"],
    },
])


_page(PBHP_PAGES, "directory")["body"] += """

## Source and release

- [[Repository and downloads|repository]] — canonical code link, reproducible site source, manifest, licenses, and public/private boundary.
- [[Versions|versions]] — current protocol, website, and connected technical release identifiers.
- [[About|about]] — authorship, purpose, and scope limits.
"""

_page(SHADOW_PAGES, "directory")["body"] += """

## Research and project

- [[Research program|research]] — falsifiable questions, current studies, and replication sequence.
- [[Glossary|glossary]] — runtime, provenance, instrumentation, and evidence terms.
- [[Repository and downloads|repository]] — site source, Grand TEVV v0.3, checksums, tools, and experiment packages.
- [[Versions|versions]] — runtime, TEVV, tool, and website release lineage.
- [[About|about]] — purpose, authorship, authority limits, and personal/public firewall.
"""


# Component-library publication layer. This preserves the long-form reference pages while
# adding compact, downloadable, test-linked blocks for every public component.
PBHP_NAV.insert(2, (
    "Components",
    [("Component library", "components"), ("Testing program", "testing")],
))
SHADOW_NAV.insert(2, (
    "Components",
    [("Component library", "components"), ("Runtime processes", "processes"), ("Testing program", "testing")],
))

_pbhp_gate_components = [component for component in PBHP_COMPONENTS if component["category"] == "Protocol gates"]
_shadow_runtime_components = [component for component in SHADOW_COMPONENTS if component["category"] == "Runtime processes"]
_shadow_primitive_components = [component for component in SHADOW_COMPONENTS if component["category"] == "Primitives"]
_shadow_process_components = [
    component for component in SHADOW_COMPONENTS
    if component["category"] in {"Runtime processes", "Provenance and instrumentation"}
]

# Put the downloadable block view directly on the protocol and runtime reading paths.
_pbhp_protocol_original = _page(PBHP_PAGES, "protocol")["body"].replace(
    "# The PBHP protocol", "## Full gate definitions", 1
)
_replace_page(
    PBHP_PAGES,
    "protocol",
    eyebrow="Ten protocol blocks · five action states · downloadable specifications",
    description="The complete PBHP gate sequence presented first as compact downloadable blocks, followed by the full human-readable definitions and escalation logic.",
    body=evidence_badges() + """
# The PBHP protocol

Every gate below is a controlled component. The block gives the operational summary; the download contains the full specification, machine-readable metadata, known failure modes, and a component-specific test plan.

""" + render_component_catalog(
        _pbhp_gate_components,
        "pbhp",
        controls=False,
        show_bundle=False,
        intro="Use the blocks for orientation and handoff. Use the full definitions below when running or reviewing a consequential decision.",
    ) + "\n" + _pbhp_protocol_original,
    related=["components", "testing", "workbench", "receipts"],
)

_shadow_runtime_original = _page(SHADOW_PAGES, "runtime")["body"].replace(
    "# Runtime: Step 00 → 10", "## Full runtime sequence", 1
)
_replace_page(
    SHADOW_PAGES,
    "runtime",
    eyebrow="Fourteen runtime blocks · Step 00 through 10",
    description="The executable decision flow presented as downloadable process blocks, followed by the full step-by-step runtime narrative and protocol poster.",
    body=evidence_badges() + """
# Runtime

Each runtime stage has a separate versioned component pack. That makes the architecture inspectable, assignable, testable, and replaceable without pretending the whole system has one undifferentiated pass state.

""" + render_component_catalog(
        _shadow_runtime_components,
        "shadow",
        controls=False,
        show_bundle=False,
        intro="A runtime stage can pass its contract while its behavioral or field effect remains open. Read the evidence label and test state on every block.",
    ) + "\n" + _shadow_runtime_original,
    related=["components", "processes", "testing", "receipts"],
)

_replace_page(
    SHADOW_PAGES,
    "primitives",
    eyebrow="Thirteen individually downloadable mechanisms and invariants",
    description="The retained dignity, causality, collective-governance, correction, frame, narrative, motivation, projection, self-reference, and pressure-resistance primitives.",
    body=evidence_badges() + """
# Project Shadow primitives

These are the individual mechanisms that sit inside or beside the runtime gate stack. None becomes authority merely because it has a name. Every primitive must translate into an operational check, evidence requirement, gate effect, receipt field, and falsifiable test plan.

""" + render_component_catalog(
        _shadow_primitive_components,
        "shadow",
        controls=False,
        show_bundle=False,
        intro="Download a component pack when you need to review, implement, assign, test, criticize, or replace one primitive without losing its current claim boundary.",
    ),
    related=["components", "gates", "behavioral-falsifier", "testing"],
)

PBHP_PAGES.extend([
    {
        "route": "components",
        "title": "PBHP component library",
        "eyebrow": f"{len(PBHP_COMPONENTS)} public components · library {COMPONENT_LIBRARY_VERSION}",
        "description": "Every PBHP gate, operating control, extension, and tool in a compact information block with a versioned specification, metadata file, test plan, and download pack.",
        "body": evidence_badges() + f"""
# PBHP component library

PBHP is easier to understand, implement, and test when its pieces are explicit. This catalog separates the ten protocol outputs from the operating controls and adoption tools that keep the protocol correctable over time.

<div class="status-strip">
  <div><strong>Protocol gates</strong><span>{len(_pbhp_gate_components)} decision-boundary components</span></div>
  <div><strong>Total components</strong><span>{len(PBHP_COMPONENTS)} versioned packs</span></div>
  <div><strong>Each pack</strong><span>Specification · metadata · test plan · checksum</span></div>
  <div><strong>Claim boundary</strong><span>Component pass ≠ system validation</span></div>
</div>

{render_component_catalog(PBHP_COMPONENTS, "pbhp", intro="Search by mechanism, failure mode, evidence state, or test need. The download button always returns the exact block's current public pack.")}
""",
        "related": ["protocol", "testing", "repository", SHADOW_CANONICAL + "/components"],
    },
    {
        "route": "testing",
        "title": "PBHP testing program",
        "eyebrow": "One test plan per component · no global green",
        "description": "The current evidence state and next-test path for every PBHP component, from contract fidelity and adversarial cases through human field validation and independent reproduction.",
        "body": evidence_badges() + f"""
# PBHP testing program

Every component pack includes its own `TEST_PLAN.md`. The universal test ladder is: contract fidelity, negative and adversarial behavior, component ablation, cross-implementation reproduction, human usability, and materially independent validation. Passing a lower layer does not establish a higher one.

## Program rules

1. Freeze the claim, version, cases, controls, scoring, and promotion rule before execution.
2. Include genuinely safe controls so caution is not mistaken for quality.
3. Prove the battery can detect a deliberately sabotaged component.
4. Preserve null, adverse, contradictory, and over-cautious results.
5. Require blinded human grading when the construct depends on judgment.
6. Keep independent reproduction separate from maintainer or same-model review.

<div class="tool-launch"><div><h2>Download all PBHP test plans</h2><p>The complete PBHP component library contains the specification and test plan for every gate, control, extension, and tool.</p></div><a class="button button--primary" href="[[ASSET|downloads/component-library/bundles/{project_bundle_name('pbhp')}]]" download>Download PBHP library</a></div>

## Component-by-component state

{render_testing_matrix(PBHP_COMPONENTS, "pbhp")}
""",
        "related": ["components", "evidence", "research", SHADOW_CANONICAL + "/testing"],
    },
])

SHADOW_PAGES.extend([
    {
        "route": "components",
        "title": "Project Shadow component library",
        "eyebrow": f"{len(SHADOW_COMPONENTS)} public components · library {COMPONENT_LIBRARY_VERSION}",
        "description": "Every foundation, runtime process, instrument, primitive, evaluation program, and governance control in a compact information block with direct downloads and test plans.",
        "body": evidence_badges() + f"""
# Project Shadow component library

Project Shadow is not one indivisible protocol. It is a governed system of separable foundations, runtime stages, provenance controls, instruments, primitives, experiments, tools, and authority limits. This page is the public component map.

<div class="status-strip">
  <div><strong>Total components</strong><span>{len(SHADOW_COMPONENTS)} versioned packs</span></div>
  <div><strong>Runtime processes</strong><span>{len(_shadow_runtime_components)} executable stages</span></div>
  <div><strong>Primitives</strong><span>{len(_shadow_primitive_components)} named mechanisms</span></div>
  <div><strong>Evidence rule</strong><span>Observed and adverse remain visible together</span></div>
</div>

{render_component_catalog(SHADOW_COMPONENTS, "shadow", intro="Use the filters to move from the whole architecture to one mechanism. Every download contains its current evidence statement, known failure modes, and specific next-test work.")}
""",
        "related": ["processes", "primitives", "testing", "repository"],
    },
    {
        "route": "processes",
        "title": "Runtime and instrumentation processes",
        "eyebrow": f"{len(_shadow_process_components)} process and instrument blocks",
        "description": "The executable Shadow flow and its provenance, evidence, instrumentation, disclosure, and routing machinery, each as a separate downloadable component.",
        "body": evidence_badges() + f"""
# Runtime and instrumentation processes

This view follows a decision from competence and provenance through intake, power, gates, harm, tier, adversarial reasoning, instrumentation, receipt, and correction. It also isolates the evidence and operating-state machinery that the runtime depends on.

{render_component_catalog(_shadow_process_components, "shadow", intro="A process block describes what enters, what must come out, how it can fail, what has actually been tested, and what must be tested next.")}
""",
        "related": ["runtime", "sil", "receipts", "testing"],
    },
    {
        "route": "testing",
        "title": "Project Shadow testing program",
        "eyebrow": "Contract → adversarial → behavioral → human → independent",
        "description": "The current evidence state and next-test path for every Shadow foundation, process, instrument, primitive, evaluation program, and governance control.",
        "body": evidence_badges() + f"""
# Project Shadow testing program

Project Shadow demands component-level evidence because a whole-system success can conceal a dead component, an undiscriminating battery, a placebo effect, or an adverse tradeoff. Every component therefore ships with a test plan and a claim boundary.

## Required evidence ladder

1. **Contract fidelity** — the implementation produces the required outputs and preserves binding floors.
2. **Negative and hostile tests** — known failure modes and prohibited transitions are exercised.
3. **Discriminating ablation** — removing or sabotaging the component changes the cases it is supposed to change.
4. **Placebo and safe controls** — extra words, firmness, or generalized caution do not receive credit for the component.
5. **Cross-model and cross-implementation reproduction** — materially different systems repeat the test.
6. **Blinded human grading** — judgment-dependent constructs receive independent scoring and agreement analysis.
7. **Field and outcome validation** — burden, overrides, correction, downstream harm, and unintended effects are measured.
8. **Independent review** — a reviewer outside the maintainer/AI construction loop can reproduce defects and block claims.

<div class="tool-launch"><div><h2>Download all Shadow test plans</h2><p>The full component library includes the specification, metadata, failure modes, and next-test plan for every public Shadow component.</p></div><a class="button button--primary" href="[[ASSET|downloads/component-library/bundles/{project_bundle_name('shadow')}]]" download>Download Shadow library</a></div>

## Component-by-component state

{render_testing_matrix(SHADOW_COMPONENTS, "shadow")}
""",
        "related": ["components", "tevv", "behavioral-falsifier", "status"],
    },
])

# Make the new catalog visible from the primary home routes.
_page(PBHP_PAGES, "")["body"] = _page(PBHP_PAGES, "")["body"].replace(
    "## What PBHP changes",
    """## Browse the protocol as components

""" + card_grid([
        ("Component library", "Every gate, control, extension, and tool as a downloadable information block.", "components"),
        ("Testing program", "See what is specified, observed, adverse, and still open for each component.", "testing"),
    ], 2) + "\n\n## What PBHP changes",
    1,
)
_page(SHADOW_PAGES, "")["body"] = _page(SHADOW_PAGES, "")["body"].replace(
    "## What Project Shadow adds",
    """## Browse the system as components

""" + card_grid([
        ("Component library", "Foundations, processes, instruments, primitives, evaluation, and governance with direct downloads.", "components"),
        ("Runtime processes", "Follow the executable flow and instrumentation as separate testable blocks.", "processes"),
        ("Testing program", "Inspect the evidence state and next test for every component.", "testing"),
    ], 3) + "\n\n## What Project Shadow adds",
    1,
)

# Put complete component bundles and the GitHub-ready publication repository on the repository pages.
_pbhp_repository = _page(PBHP_PAGES, "repository")
_pbhp_repository["body"] = _pbhp_repository["body"].replace(
    "# Repository and downloads",
    f"""# Repository and downloads

## Component library downloads

<div class="tool-launch"><div><h2>PBHP component library</h2><p>{len(PBHP_COMPONENTS)} component specifications and test plans. Every individual block is also downloadable from the component catalog.</p></div><a class="button button--primary" href="[[ASSET|downloads/component-library/bundles/{project_bundle_name('pbhp')}]]" download>Download PBHP library</a></div>

- [Download the combined PBHP + Shadow component library]([[ASSET|downloads/component-library/bundles/{combined_bundle_name()}]])
- [Open the component-library manifest]([[ASSET|downloads/component-library/PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json]])
- [Read the GitHub repository setup guide]([[ASSET|downloads/component-library/GITHUB_REPOSITORY_SETUP.md]])
""",
    1,
)
_shadow_repository = _page(SHADOW_PAGES, "repository")
_shadow_repository["body"] = _shadow_repository["body"].replace(
    "# Repository and downloads",
    f"""# Repository and downloads

## Component library downloads

<div class="tool-launch"><div><h2>Project Shadow component library</h2><p>{len(SHADOW_COMPONENTS)} foundation, runtime, instrument, primitive, evaluation, and governance packs with one test plan per component.</p></div><a class="button button--primary" href="[[ASSET|downloads/component-library/bundles/{project_bundle_name('shadow')}]]" download>Download Shadow library</a></div>

- [Download the combined PBHP + Shadow component library]([[ASSET|downloads/component-library/bundles/{combined_bundle_name()}]])
- [Open the component-library manifest]([[ASSET|downloads/component-library/PBHP_SHADOW_COMPONENT_LIBRARY_MANIFEST.json]])
- [Read the GitHub repository setup guide]([[ASSET|downloads/component-library/GITHUB_REPOSITORY_SETUP.md]])
""",
    1,
)

# Extend the map, version lineage, and daily record without inventing a new calendar date.
_page(PBHP_PAGES, "directory")["body"] += """

## Components and testing

- [[PBHP component library|components]] — every gate, operating control, extension, and tool as a downloadable block.
- [[PBHP testing program|testing]] — current evidence state and next-test plan for every PBHP component.
"""
_page(SHADOW_PAGES, "directory")["body"] += """

## Components and testing

- [[Project Shadow component library|components]] — every foundation, process, instrument, primitive, evaluation program, and governance control as a downloadable block.
- [[Runtime and instrumentation processes|processes]] — the executable and operating-state flow in component form.
- [[Project Shadow testing program|testing]] — current evidence state and next-test plan for every Shadow component.
"""
_page(PBHP_PAGES, "versions")["body"] += f"""

## Component library

Component library **{COMPONENT_LIBRARY_VERSION}** publishes {len(PBHP_COMPONENTS)} PBHP component packs. It changes presentation, handoff, and test planning; it does not silently change the upstream PBHP protocol version.
"""
_page(SHADOW_PAGES, "versions")["body"] += f"""

## Component library

Component library **{COMPONENT_LIBRARY_VERSION}** publishes {len(SHADOW_COMPONENTS)} Shadow component packs. Component-pack versioning remains separate from runtime, TEVV, Atlas, poster, and website versions.
"""
_page(PBHP_PAGES, "daily")["body"] = _page(PBHP_PAGES, "daily")["body"].replace(
    "**Changed**",
    f"""**Changed**

- Added component library {COMPONENT_LIBRARY_VERSION}: {len(PBHP_COMPONENTS)} PBHP blocks with direct ZIP downloads, metadata, checksums, and one test plan per component.
- Added a component testing page and GitHub-ready repository controls so future work can attach evidence to the exact mechanism it evaluates.""",
    1,
)
_page(SHADOW_PAGES, "daily")["body"] = _page(SHADOW_PAGES, "daily")["body"].replace(
    "**Changed**",
    f"""**Changed**

- Added component library {COMPONENT_LIBRARY_VERSION}: {len(SHADOW_COMPONENTS)} Shadow blocks across foundations, runtime, instrumentation, primitives, evaluation, and governance.
- Added direct component downloads, test plans, category bundles, process navigation, and a GitHub-ready validation workflow.""",
    1,
)


SITE_CONFIGS = {
    "pbhp": {
        "slug": "pbhp",
        "name": "Pause Before Harm",
        "short_name": "PBHP",
        "tagline": "The practical action-boundary protocol",
        "canonical": PBHP_CANONICAL,
        "counterpart_name": "Project Shadow",
        "counterpart_url": SHADOW_CANONICAL,
        "counterpart_label": "Open the technical system",
        "theme": "pbhp",
        "nav": PBHP_NAV,
        "pages": PBHP_PAGES,
        "footer_note": "A living, correctable protocol. No record, no action.",
    },
    "shadow": {
        "slug": "shadow",
        "name": "Project Shadow",
        "short_name": "SHADOW",
        "tagline": "Governance · instrumentation · evaluation",
        "canonical": SHADOW_CANONICAL,
        "counterpart_name": "Pause Before Harm",
        "counterpart_url": PBHP_CANONICAL,
        "counterpart_label": "Open the public protocol",
        "theme": "shadow",
        "nav": SHADOW_NAV,
        "pages": SHADOW_PAGES,
        "footer_note": "A clean run is weaker evidence than it feels like.",
    },
}
