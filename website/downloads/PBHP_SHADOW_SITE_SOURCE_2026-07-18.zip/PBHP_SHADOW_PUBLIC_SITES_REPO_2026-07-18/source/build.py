#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Any

import mistune
from bs4 import BeautifulSoup
from jinja2 import Environment, BaseLoader, select_autoescape

from site_data import RELEASE_DATE, SITE_CONFIGS

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(__file__).resolve().parent
STATIC = SOURCE / "static"
OUTPUT = ROOT / "sites"
VALIDATION = ROOT / "validation"
PUBLIC_ARTIFACTS = ROOT / "public-artifacts"

PAGE_TEMPLATE = r"""<!doctype html>
<html lang="en" data-theme="{{ site.theme }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="{{ page.description }}">
  <meta name="theme-color" content="{{ theme_color }}">
  <link rel="canonical" href="{{ canonical_url }}">
  <link rel="stylesheet" href="{{ asset_prefix }}assets/app.css">
  <title>{{ page.title }} · {{ site.name }}</title>
  <script type="application/ld+json">{{ json_ld | safe }}</script>
</head>
<body class="route-{{ route_class }}{% if is_home %} is-home{% endif %}">
  <a class="skip-link" href="#main">Skip to content</a>
  <div class="reading-progress" aria-hidden="true"><i id="reading-progress-bar"></i></div>

  <header class="mobile-header">
    <a class="mobile-brand" href="{{ home_href }}"><span>{{ site.short_name }}</span><small>{{ site.tagline }}</small></a>
    <div class="mobile-actions">
      <button class="icon-button" type="button" data-search-open aria-label="Search site"><span aria-hidden="true">⌕</span></button>
      <button class="icon-button" type="button" data-nav-toggle aria-label="Open navigation" aria-expanded="false"><span aria-hidden="true">☰</span></button>
    </div>
  </header>

  <div class="site-shell">
    <aside class="sidebar" id="site-navigation" aria-label="Primary navigation">
      <div class="sidebar__top">
        <a class="brand" href="{{ home_href }}">
          <span class="brand__mark" aria-hidden="true">{{ brand_mark }}</span>
          <span><strong>{{ site.name }}</strong><small>{{ site.tagline }}</small></span>
        </a>
        <button class="search-launch" type="button" data-search-open><span>Search everything</span><kbd>⌘ K</kbd></button>
      </div>

      <nav class="primary-nav">
        {% for group in nav_groups %}
        <section class="nav-group">
          <h2>{{ group.label }}</h2>
          {% for item in group["items"] %}
          <a href="{{ item.href }}"{% if item.active %} aria-current="page" class="active"{% endif %}><span>{{ item.label }}</span>{% if item.active %}<i aria-hidden="true"></i>{% endif %}</a>
          {% endfor %}
        </section>
        {% endfor %}
      </nav>

      <div class="sidebar__bottom">
        <a class="counterpart" href="{{ site.counterpart_url }}"><span>{{ site.counterpart_label }}</span><strong>{{ site.counterpart_name }} →</strong></a>
        <p><a href="{{ repository_href }}">Repository and downloads</a> · Current through <time datetime="{{ release_date }}">{{ release_date_display }}</time></p>
      </div>
    </aside>

    <div class="nav-scrim" data-nav-close></div>

    <main id="main" class="main-content" tabindex="-1">
      <div class="topline">
        <nav class="breadcrumbs" aria-label="Breadcrumb">
          <a href="{{ home_href }}">{{ site.short_name }}</a><span aria-hidden="true">/</span><span aria-current="page">{{ page.title }}</span>
        </nav>
        <div class="topline__actions">
          <a href="{{ daily_href }}">Daily</a>
          <a href="{{ repository_href }}">Repository</a>
          <a href="{{ directory_href }}">Directory</a>
          <button type="button" data-search-open>Search</button>
        </div>
      </div>

      {% if not is_home %}
      <header class="page-header">
        <p class="kicker">{{ page.eyebrow }}</p>
        <h1>{{ page.title }}</h1>
        <p>{{ page.description }}</p>
      </header>
      {% endif %}

      <div class="content-grid{% if not toc %} content-grid--single{% endif %}">
        <article class="prose" data-article>
          {{ body_html | safe }}
          {% if related %}
          <section class="related-pages" aria-labelledby="related-title">
            <p class="kicker">Continue</p>
            <h2 id="related-title">Related pages</h2>
            <div class="related-grid">
              {% for item in related %}<a href="{{ item.href }}"><strong>{{ item.title }}</strong><span>{{ item.description }}</span><i aria-hidden="true">→</i></a>{% endfor %}
            </div>
          </section>
          {% endif %}
        </article>
        {% if toc %}
        <aside class="page-toc" aria-label="On this page">
          <p>On this page</p>
          <ol>{% for item in toc %}<li class="toc-level-{{ item.level }}"><a href="#{{ item.id }}">{{ item.text }}</a></li>{% endfor %}</ol>
          <a class="toc-top" href="#main">Back to top ↑</a>
        </aside>
        {% endif %}
      </div>

      <footer class="site-footer">
        <div><strong>{{ site.name }}</strong><span>{{ site.footer_note }}</span></div>
        <div><a href="{{ about_or_status_href }}">{{ about_or_status_label }}</a><a href="{{ site.canonical }}">Canonical live URL</a></div>
        <p>Maintained by Phillip Linstrum. AI assistance disclosed: ChatGPT 5.6 Sol Max and Claude Fable 5 Max (Cowork). Assistance is not independent validation.</p>
      </footer>
    </main>
  </div>

  <nav class="mobile-dock" aria-label="Quick navigation">
    <a href="{{ home_href }}"><b aria-hidden="true">⌂</b><span>Home</span></a>
    <button type="button" data-search-open><b aria-hidden="true">⌕</b><span>Search</span></button>
    <a href="{{ repository_href }}"><b aria-hidden="true">⌘</b><span>Repo</span></a>
    <a href="{{ directory_href }}"><b aria-hidden="true">☷</b><span>Map</span></a>
  </nav>

  <dialog class="command-dialog" id="command-dialog" aria-labelledby="command-title">
    <div class="command-box">
      <div class="command-head"><div><p class="kicker">Navigate {{ site.short_name }}</p><h2 id="command-title">Search every page</h2></div><button class="icon-button" type="button" data-search-close aria-label="Close search">×</button></div>
      <label class="command-input"><span class="sr-only">Search</span><input id="command-query" type="search" autocomplete="off" placeholder="Try “power”, “provenance”, “SIL”, or “receipts”"></label>
      <div class="command-results" id="command-results" role="listbox" aria-label="Search results"></div>
      <div class="command-foot"><span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>Enter</kbd> open</span><span><kbd>Esc</kbd> close</span></div>
    </div>
  </dialog>

  <script>window.SITE_BOOT={{ boot_json | safe }};</script>
  <script src="{{ asset_prefix }}assets/app.js" defer></script>
</body>
</html>
"""


def slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9\s-]", "", value)
    value = re.sub(r"[\s_-]+", "-", value).strip("-")
    return value or "section"


def display_date(value: str) -> str:
    y, m, d = value.split("-")
    months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return f"{months[int(m)]} {int(d)}, {y}"


def local_url(current_route: str, target: str) -> str:
    if target.startswith(("http://", "https://", "mailto:", "tel:")):
        return target
    if target.startswith("#"):
        return target
    prefix = "" if current_route == "" else "../"
    if target == "":
        return "./" if current_route == "" else "../"
    return f"{prefix}{target.strip('/')}/"


def asset_url(current_route: str, target: str) -> str:
    prefix = "" if current_route == "" else "../"
    return f"{prefix}{target.lstrip('/')}"


def resolve_tokens(markdown_text: str, current_route: str) -> str:
    # Tokens inside raw HTML attributes.
    markdown_text = re.sub(
        r"\[\[URL\|([^\]]+)\]\]",
        lambda m: html.escape(local_url(current_route, m.group(1)), quote=True),
        markdown_text,
    )
    markdown_text = re.sub(
        r"\[\[ASSET\|([^\]]+)\]\]",
        lambda m: html.escape(asset_url(current_route, m.group(1)), quote=True),
        markdown_text,
    )

    # Wiki-style links in prose -> standard Markdown links.
    markdown_text = re.sub(
        r"\[\[([^\]|]+)\|([^\]]*)\]\]",
        lambda m: f"[{m.group(1)}]({local_url(current_route, m.group(2))})",
        markdown_text,
    )
    return markdown_text


def make_markdown() -> Any:
    renderer = mistune.HTMLRenderer(escape=False)
    return mistune.create_markdown(
        renderer=renderer,
        plugins=["table", "strikethrough", "task_lists", "url"],
    )


MARKDOWN = make_markdown()


def process_body(markdown_text: str, current_route: str, is_home: bool) -> tuple[str, list[dict[str, Any]], str]:
    resolved = resolve_tokens(markdown_text, current_route)
    rendered = MARKDOWN(resolved)
    soup = BeautifulSoup(rendered, "html.parser")

    if not is_home:
        first_h1 = soup.find("h1")
        if first_h1:
            first_h1.decompose()

    # IDs and table of contents.
    used: set[str] = set()
    toc: list[dict[str, Any]] = []
    for heading in soup.find_all(["h2", "h3"]):
        text = heading.get_text(" ", strip=True)
        base = slugify(text)
        candidate = base
        i = 2
        while candidate in used:
            candidate = f"{base}-{i}"
            i += 1
        used.add(candidate)
        heading["id"] = candidate
        toc.append({"level": int(heading.name[1]), "id": candidate, "text": text})

    # External link affordances and safe target behavior.
    for link in soup.find_all("a", href=True):
        href = link["href"]
        if href.startswith(("http://", "https://")):
            link["class"] = list(link.get("class", [])) + ["external-link"]
            link["target"] = "_blank"
            link["rel"] = "noopener noreferrer"

    # Wrap wide tables.
    for table in list(soup.find_all("table")):
        wrapper = soup.new_tag("div", attrs={"class": "table-scroll", "tabindex": "0"})
        table.wrap(wrapper)

    # Add copy buttons to code blocks.
    for pre in soup.find_all("pre"):
        pre["class"] = list(pre.get("class", [])) + ["code-block"]
        button = soup.new_tag("button", attrs={"class": "code-copy", "type": "button"})
        button.string = "Copy"
        pre.insert(0, button)

    plain_text = " ".join(soup.get_text(" ", strip=True).split())
    return str(soup), toc, plain_text


def page_lookup(site: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {page["route"]: page for page in site["pages"]}


def build_nav(site: dict[str, Any], current_route: str) -> list[dict[str, Any]]:
    groups = []
    for label, items in site["nav"]:
        groups.append(
            {
                "label": label,
                "items": [
                    {"label": item_label, "href": local_url(current_route, route), "active": route == current_route}
                    for item_label, route in items
                ],
            }
        )
    return groups


def related_items(site: dict[str, Any], current_route: str, related: list[str]) -> list[dict[str, str]]:
    lookup = page_lookup(site)
    items: list[dict[str, str]] = []
    for target in related:
        if target.startswith(("http://", "https://")):
            title = "Related external project"
            if "projectshadow" in target:
                title = "Project Shadow"
            elif "pausebeforeharm" in target:
                title = "Pause Before Harm"
            elif "americanrepairmanual" in target:
                title = "American Repair Manual"
            items.append({"title": title, "description": "Continue in the connected project or technical surface.", "href": target})
        elif target in lookup:
            page = lookup[target]
            items.append({"title": page["title"], "description": page["description"], "href": local_url(current_route, target)})
    return items[:4]


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def copy_tools(site_key: str, site_out: Path) -> None:
    if site_key != "shadow":
        return
    tools = site_out / "tools"
    tools.mkdir(parents=True, exist_ok=True)
    sources = {
        "response-grader": PUBLIC_ARTIFACTS / "Project_Shadow_Response_Grader.html",
        "mythic-atlas": PUBLIC_ARTIFACTS / "Mythic_Atlas_v2.html",
        "protocol-poster": PUBLIC_ARTIFACTS / "Shadow_Protocol_Poster_v1.3.1.html",
    }
    for name, source in sources.items():
        dest = tools / name / "index.html"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)


def copy_downloads(site_key: str, site_out: Path) -> list[str]:
    """Copy only the allowlisted public release artifacts into the generated site.

    The component library is recursive because each block has its own specification,
    metadata, test plan, ZIP, and checksum. Top-level technical artifacts remain
    Shadow-only except for the shared site-source release and manifest.
    """
    downloads = site_out / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    common_names = {
        "LATEST_RELEASE_MANIFEST.json",
        "PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip",
        "PBHP_SHADOW_SITE_SOURCE_2026-07-18.zip.sha256",
    }
    selected: list[Path] = []
    if PUBLIC_ARTIFACTS.exists():
        for name in sorted(common_names):
            path = PUBLIC_ARTIFACTS / name
            if path.is_file():
                selected.append(path)
        component_root = PUBLIC_ARTIFACTS / "component-library"
        if component_root.exists():
            selected.extend(path for path in sorted(component_root.rglob("*")) if path.is_file())
        if site_key == "shadow":
            selected.extend(
                path for path in sorted(PUBLIC_ARTIFACTS.iterdir())
                if path.is_file() and path.name not in common_names
            )
            sil_root = PUBLIC_ARTIFACTS / "sil-tools"
            if sil_root.exists():
                selected.extend(path for path in sorted(sil_root.rglob("*")) if path.is_file())

    copied: list[str] = []
    seen: set[Path] = set()
    for source in selected:
        if source in seen:
            continue
        seen.add(source)
        rel = source.relative_to(PUBLIC_ARTIFACTS)
        destination = downloads / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied.append(str(rel).replace("\\", "/"))
    return copied


def build_site(site_key: str, site: dict[str, Any]) -> dict[str, Any]:
    site_out = OUTPUT / site_key
    if site_out.exists():
        shutil.rmtree(site_out)
    site_out.mkdir(parents=True)
    shutil.copytree(STATIC, site_out / "assets")
    copy_tools(site_key, site_out)
    copied_downloads = copy_downloads(site_key, site_out)

    env = Environment(
        loader=BaseLoader(),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    template = env.from_string(PAGE_TEMPLATE)
    lookup = page_lookup(site)
    search_index = []
    rendered_pages: list[dict[str, Any]] = []

    for page in site["pages"]:
        route = page["route"]
        is_home = route == ""
        asset_prefix = "" if is_home else "../"
        body_html, toc, plain_text = process_body(page["body"], route, is_home)
        canonical_url = site["canonical"] + ("" if is_home else f"/{route}")
        nav_groups = build_nav(site, route)
        boot = {
            "site": site_key,
            "route": route,
            "searchIndex": f"{asset_prefix}assets/search-index.json",
            "canonical": site["canonical"],
        }
        json_ld = json.dumps(
            {
                "@context": "https://schema.org",
                "@type": "WebPage",
                "name": page["title"],
                "description": page["description"],
                "url": canonical_url,
                "isPartOf": {"@type": "WebSite", "name": site["name"], "url": site["canonical"]},
                "dateModified": RELEASE_DATE,
            },
            ensure_ascii=False,
        )
        context = {
            "site": site,
            "page": page,
            "body_html": body_html,
            "toc": toc if len(toc) >= 2 and not is_home else [],
            "is_home": is_home,
            "route_class": route.replace("/", "-") or "home",
            "asset_prefix": asset_prefix,
            "home_href": local_url(route, ""),
            "daily_href": local_url(route, "daily"),
            "directory_href": local_url(route, "directory"),
            "repository_href": local_url(route, "repository"),
            "nav_groups": nav_groups,
            "related": related_items(site, route, page.get("related", [])),
            "release_date": RELEASE_DATE,
            "release_date_display": display_date(RELEASE_DATE),
            "brand_mark": "PB" if site_key == "pbhp" else "S",
            "theme_color": "#f4f1e8" if site_key == "pbhp" else "#0a0d14",
            "canonical_url": canonical_url,
            "json_ld": json_ld,
            "boot_json": json.dumps(boot, ensure_ascii=False).replace("</", "<" + "\\/"),
            "about_or_status_href": local_url(route, "about" if site_key == "pbhp" else "status"),
            "about_or_status_label": "About and scope" if site_key == "pbhp" else "Current evidence status",
        }
        html_text = template.render(**context)
        dest = site_out / "index.html" if is_home else site_out / route / "index.html"
        write_text(dest, html_text)
        search_index.append(
            {
                "title": page["title"],
                "description": page["description"],
                "route": "./" if is_home else f"{route}/",
                "canonical": canonical_url,
                "text": plain_text[:12000],
                "headings": [item["text"] for item in toc],
            }
        )
        rendered_pages.append({"route": route, "path": str(dest.relative_to(site_out)), "title": page["title"]})

    write_text(site_out / "assets" / "search-index.json", json.dumps(search_index, ensure_ascii=False, indent=2))
    manifest = {
        "schema": "pbhp-shadow-living-site-manifest-v1",
        "site": site["name"],
        "canonical": site["canonical"],
        "release_date": RELEASE_DATE,
        "pages": rendered_pages,
        "tools": ["response-grader", "mythic-atlas", "protocol-poster"] if site_key == "shadow" else [],
        "downloads": copied_downloads,
    }
    write_text(site_out / "site-manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    return manifest


def validate_links(site_key: str, site: dict[str, Any]) -> dict[str, Any]:
    site_out = OUTPUT / site_key
    issues: list[dict[str, str]] = []
    html_files = sorted(site_out.rglob("*.html"))
    for file in html_files:
        soup = BeautifulSoup(file.read_text(encoding="utf-8"), "html.parser")
        for tag in soup.find_all(["a", "iframe"], href=True) + soup.find_all("iframe", src=True):
            attr = "href" if tag.has_attr("href") else "src"
            value = tag.get(attr, "")
            if not value or value.startswith(("http://", "https://", "mailto:", "tel:", "#", "data:", "javascript:")):
                continue
            clean = value.split("#", 1)[0].split("?", 1)[0]
            if not clean:
                continue
            target = (file.parent / clean).resolve()
            if clean.endswith("/"):
                target = target / "index.html"
            elif target.is_dir():
                target = target / "index.html"
            if not target.exists():
                issues.append({"file": str(file.relative_to(site_out)), "target": value})
        for tag in soup.find_all(["button", "a"]):
            if tag.name == "a" and not tag.get("href"):
                issues.append({"file": str(file.relative_to(site_out)), "target": "anchor without href"})
    return {"site": site_key, "html_files": len(html_files), "issues": issues, "pass": not issues}


def checksums() -> list[dict[str, Any]]:
    rows = []
    for path in sorted(OUTPUT.rglob("*")):
        if path.is_file():
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            rows.append({"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size, "sha256": digest})
    return rows


def main() -> int:
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    if VALIDATION.exists():
        shutil.rmtree(VALIDATION)
    OUTPUT.mkdir(parents=True)
    VALIDATION.mkdir(parents=True)

    manifests = []
    for key, site in SITE_CONFIGS.items():
        manifests.append(build_site(key, site))

    validation = [validate_links(key, site) for key, site in SITE_CONFIGS.items()]
    write_text(VALIDATION / "link-report.json", json.dumps(validation, indent=2))
    write_text(VALIDATION / "checksums.json", json.dumps(checksums(), indent=2))
    write_text(VALIDATION / "manifests.json", json.dumps(manifests, ensure_ascii=False, indent=2))

    failed = [row for row in validation if not row["pass"]]
    print(json.dumps({"sites": [m["site"] for m in manifests], "validation": validation}, indent=2))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
