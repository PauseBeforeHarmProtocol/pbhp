# PBHP + Project Shadow Public Sites Repository

Canonical-current website source for:

- **Pause Before Harm** — the public, human-readable action-boundary protocol.
- **Project Shadow** — the deeper technical governance, instrumentation, provenance, evaluation, and correction system.

Release date: **2026-07-18**

## What this repository fixes

The project record had been split across ChatGPT Sites, handoff files, standalone HTML tools, a public PBHP GitHub repository, and a private multi-day Project Shadow session archive. This repository creates one reproducible publication layer without dumping private working material onto the web.

It provides:

- stable, human-readable routes for both sites;
- desktop side navigation, mobile drawer and quick dock;
- breadcrumbs, related-page paths, heading permalinks, reading progress, and command-palette search;
- a local-only PBHP decision workbench and downloadable draft receipt;
- a filterable 28-gauge SIL reference with one direct download per gauge;
- a one-click Project Shadow complete package with `shadow.py`, `shadow_prompt.md`, and `shadow_lang.py` at the root;
- embedded Project Shadow poster and Mythic Atlas;
- a working blind response grader;
- repository and downloads pages on both sites;
- a 69-component public library: 24 PBHP components and 45 Project Shadow components;
- a compact information block, direct ZIP download, metadata file, checksum, and test plan for every component;
- filterable component, process, primitive, and testing pages;
- GitHub Actions validation, component-test issue templates, and repository release controls;
- an allowlisted, checksummed public artifact release;
- current Project Shadow publication based on **Grand TEVV v0.3**, not the superseded v0.2 handoff package;
- explicit specified / expected / observed / adverse / open evidence states;
- daily ledgers that change only after substantive work.

## Canonical source map

| Surface | Canonical current source |
|---|---|
| PBHP public protocol/code | `https://github.com/PauseBeforeHarmProtocol/pbhp` — main branch declares v0.9.5; GitHub Releases showed v0.9.0 as the latest tag observed 2026-07-18 |
| PBHP public Site | `https://pausebeforeharm.frylock117.chatgpt.site` — existing Site project, version 3 at handoff |
| Project Shadow public Site | `https://projectshadow.frylock117.chatgpt.site` — existing Site project, version 3 at handoff |
| Shadow runtime | v1.3.1-UNIFIED |
| Grand TEVV | v0.3 |
| Mythic Atlas | v2 |
| Shadow protocol poster | v1.3.1 |

## Build locally

```bash
python -m pip install -r requirements.txt
python scripts/build_component_artifacts.py
python scripts/build_sil_tool_artifacts.py
python scripts/build_shadow_complete_package.py
./scripts/make_source_release.py
./scripts/update_artifact_manifest.py
./scripts/build.sh
./scripts/validate.sh
./scripts/serve.sh
```

Validation includes deterministic link checks, content contracts, JavaScript syntax checks, static interaction contracts, and desktop/mobile visual render previews. Managed Chromium in this environment blocks all local navigation by policy, so authenticated browser interaction, keyboard, screen-reader, and production-route QA remain explicit release gates.

Then open:

- `http://127.0.0.1:4173/pbhp/`
- `http://127.0.0.1:4173/shadow/`


## Component library

The publication layer decomposes PBHP and Project Shadow into versioned components rather than presenting either project as a single undifferentiated artifact. Each component pack contains:

- `README.md` — purpose, mechanism, inputs, outputs, failure modes, evidence state, and claim boundary;
- `component.json` — machine-readable metadata;
- `TEST_PLAN.md` — contract, adversarial, ablation, cross-model, human, and independent-validation work;
- a deterministic ZIP and SHA-256 record.

PBHP exposes 24 components across protocol gates, operating controls, and implementation tools. Project Shadow exposes 45 components across foundations, runtime processes, provenance and instrumentation, primitives, evaluation, and governance. The complete library is in `public-artifacts/component-library/`.

The component view does not promote the evidence. A component may be specified or contract-tested while its behavioral, human, organizational, or safety effect remains adverse or open.

## Complete Project Shadow package

`public-artifacts/PROJECT_SHADOW_COMPLETE_PACKAGE_v1.3.1_2026-07-18.zip` is the simple one-click distribution. Its root contains:

- `shadow.py` — frozen runtime v1.3.1-UNIFIED;
- `shadow_prompt.md` — current target/system prompt contract;
- `shadow_lang.py` — PBHP-PS PS2 language/codec v0.4;
- `shadow_output_schema.json`, `verify.py`, manifests, checksums, and recorded test results.

The same package also contains the 28-gauge SIL panel, the Project Shadow component library, Grand TEVV v0.3, public tools, and experiment packs. The friendly runtime and language filenames are byte-identical to the canonical frozen files; compatibility aliases preserve the original import names. Packaged checks report 115/115 runtime self-tests, 247/247 language/codec self-tests, and a passing prompt/schema contract. These are implementation checks, not independent validation.

## GitHub remote

The repository includes `.github/workflows/validate.yml`, component-test and site-defect issue forms, and a pull-request template. See [`docs/GITHUB_REPOSITORY_SETUP.md`](docs/GITHUB_REPOSITORY_SETUP.md). Keep the established PBHP upstream repository as the canonical PBHP protocol/code line and use a separate remote for this combined website and Project Shadow publication history.

## Deploy to the existing ChatGPT Sites

Use the authenticated **Work → Sites** workspace and attach this repository ZIP. Do not create replacement projects. Follow [`docs/DEPLOY_TO_EXISTING_SITES.md`](docs/DEPLOY_TO_EXISTING_SITES.md). For daily source monitoring and candidate preparation, use [`docs/SCHEDULED_DAILY_MAINTENANCE.md`](docs/SCHEDULED_DAILY_MAINTENANCE.md).

The deployment workflow deliberately separates:

1. read-only recovery of the existing Site project;
2. source comparison and preservation of unrelated changes;
3. saved candidate version;
4. route, interaction, accessibility, privacy, and claim review;
5. deployment to the existing slug;
6. production verification;
7. public audience change only after the reviewed build is confirmed.

## Public/private boundary

The public package is allowlisted. It excludes the raw July 15–17 Project Shadow session archive, recovery material, credentials, unrelated records, and private handoff context. See [`docs/PUBLICATION_POLICY.md`](docs/PUBLICATION_POLICY.md).

## Evidence boundary

The current release contains real implementation checks and limited real-target behavioral evidence. It is **not independent validation**, **not certification**, and **not a global safety finding**. Grand TEVV v0.3 is screen-grade and mechanism-oriented; independent human grading, reproduction, red teaming, large real-target execution, and field validation remain open.

## Credits

Maintainer: **Phillip Linstrum**.

AI assistance disclosed: **ChatGPT 5.6 Sol Max** and **Claude Fable 5 Max (Cowork)**. Assistance is not materially independent review.
